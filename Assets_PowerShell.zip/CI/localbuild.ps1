if ( ((Get-ChildItem -Force).name -eq ".git").count -ne 1) {
  throw "Please run this script with the repository root as the working directory"
}

if (!(get-command nuget)) {
  throw "Please install nuget or add it to your path to run this script"
}

$Path = $(Get-Location).Path

try {
  nuget restore `
  "$path/lib_pwsh/packages.config" `
  -OutputDirectory "$path/lib_pwsh/packages" `
  -NonInteractive
} catch {
  throw "Error with Nuget: `n $_"
}

if (((Get-Module Pester -ListAvailable).version.tostring() -eq "4.9.0") -eq $false) {
  throw "Please install the Pester version 4.9.0: `n See https://github.com/pester/Pester/wiki/Installation-and-Update"
}