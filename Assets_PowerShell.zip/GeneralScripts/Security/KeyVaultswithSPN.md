# Introduction
This powershell script will create 2 key vaults, 1 for build keys and secerts (login details, certificates, encription URL etc) 
and the other ADE VAULT will store the VM wrapped keys, this way you don't have to search through 100's of wrapped keys for other secrets.

Also it creates an SPN within the tenant and adds the keys and secrets to the KeyVaults.



