<#

.SYNOPSIS
Checks to see if a Key Vault exists or not.

.DESCRIPTION
Rather than deploying a Key Vault every time, we can check to see if it exists first. The script will set an output variable  to 'true' if the Key Vault doesn't exist.

.EXAMPLE
./Check-KeyVaultExists.ps1 -KeyVaultName vault1 -OutputVarName outvar1

.NOTES
Written by Adam Evans (Sept 19) to support pipeline deployments

.LINK
http://www.newsignature.com

#>

param (
    [Parameter(Mandatory=$true)]
    [string]$KeyVaultName,
    [Parameter(Mandatory=$true)]
    [string]$OutputVarName
)

# Get a list of all the KeyVaults and filter for the one we are looking for.
$KV = Get-AzureRMKeyVault | Where-Object {$_.VaultName -eq $KeyVaultName}

# If it exists, return true in the output variable provided, otherwise return false.
If ($KV) {
    write-host "##vso[task.setvariable variable=$OutputVarName]false"
} else {
    write-host "##vso[task.setvariable variable=$OutputVarName]true"
}
