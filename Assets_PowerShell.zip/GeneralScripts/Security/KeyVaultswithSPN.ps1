﻿Connect-AzureRmAccount	
#Check the Subscription you want to connect to#
Get-AzurermSubscription

Install-Module -Name AzureRM -AllowClobber

# Set Subscription Name
$SubscriptionName = "UK Professional Services Dev/Test"

#Set the Subsciption you want to connect to
Select-AzurermSubscription -Subscription $SubscriptionName

$RGLocation = ''  # Enter region code, UKS, UKW, EUS etc
$envbuild = '' # Enter environment code, PRD, DEV, TST etc
    $RGName = '' # Enter existing RG name for Keyvault to be built into
	$MSDataCentre = '' # Enter region uksouth etc
    $NamePrefix = '' # Enter name prefix, client letters etc

    #The get RG command allows the module to load
    Get-AzureRmResourceGroup -Name $RGName
    Set-StrictMode -Version 3
    $azureResourcesModule = Get-Module 'AzureRM.Resources'


#region Setup Shared Resources
################################################################################################################################################
#      Create Shared resources environment 
################################################################################################################################################


	$aadAppName =  "$($NamePrefix)-$($envBuild)-VM-DISK-ENCRYPT"
	# $aadClientSecret = ""

	#############################################################################################################################################
	# Check if AAD app with $aadAppName was already created
    $SvcPrincipals = (Get-AzureRmADServicePrincipal -SearchString $aadAppName);
    if(-not $SvcPrincipals){
        # Create a new AD application if not created before
        $identifierUri = [string]::Format("http://localhost:8080/{0}",[Guid]::NewGuid().ToString("N"));
        $defaultHomePage = 'https://vmdiskencryption';
        $now = [System.DateTime]::Now;
        $oneYearFromNow = $now.AddYears(1);
        $aadClientSecret = [Guid]::NewGuid().ToString();
        Write-Host "Creating new AAD application ($aadAppName)";

        if($azureResourcesModule.Version.Major -ge 5){
            $secureAadClientSecret = ConvertTo-SecureString -String $aadClientSecret -AsPlainText -Force;
            $ADApp = New-AzureRMADApplication -DisplayName $aadAppName -HomePage $defaultHomePage -IdentifierUris $identifierUri  -StartDate $now -EndDate $oneYearFromNow -Password $secureAadClientSecret;
        }else{
            $ADApp = New-AzureRmADApplication -DisplayName $aadAppName -HomePage $defaultHomePage -IdentifierUris $identifierUri  -StartDate $now -EndDate $oneYearFromNow -Password $aadClientSecret;
        }

        $servicePrincipal = New-AzureRmADServicePrincipal -ApplicationId $ADApp.ApplicationId;
        $SvcPrincipals = (Get-AzureRmADServicePrincipal -SearchString $aadAppName);
        if(-not $SvcPrincipals){
            # AAD app wasn't created 
            Write-Error "Failed to create AAD app $aadAppName. Please log in to Azure using Connect-AzureRmAccount and try again";
            return;
        }

        $aadClientID = $servicePrincipal.ApplicationId;
        Write-Host "Created a new AAD Application ($aadAppName) with ID: $aadClientID and secret of $aadClientSecret";

    }else{

        if(-not $aadClientSecret){
            $aadClientSecret = Read-Host -Prompt "Aad application ($aadAppName) was already created, input corresponding aadClientSecret and hit ENTER. It can be retrieved from https://manage.windowsazure.com portal" ;
        }

        if(-not $aadClientSecret){
            Write-Error "Aad application ($aadAppName) was already created. Re-run the script by supplying aadClientSecret parameter with corresponding secret from https://manage.windowsazure.com portal";
            return;
        }

        $aadClientID = $SvcPrincipals[0].ApplicationId;
    }


	#############################################################################################################################################
	# Create Key Vault ADE


	$keyVaultName = "KV-DEV-$($RGLocation)-$($envBuild)-ADE"

	Try{
		$newKeyVault = Get-AzureRmKeyVault -VaultName $keyVaultName -ErrorAction SilentlyContinue;
    }
    Catch [System.ArgumentException]{
        Write-Host "Couldn't find Key Vault: $keyVaultName";
        $newKeyVault = $null;
    }

    # Create a new vault if vault doesn't exist
    if (-not $newKeyVault){
        Write-Host "Creating new key vault:  ($keyVaultName)";
        $newKeyVault = New-AzureRmKeyVault -VaultName $keyVaultName -ResourceGroupName $RGName -Sku Premium -Location $($MSDataCentre);
        Write-Host "Created a new KeyVault named $keyVaultName to store encryption keys";
    }

	#  Set Keyvault permisions
    Set-AzureRmKeyVaultAccessPolicy -VaultName $keyVaultName -ServicePrincipalName $aadClientID -PermissionsToKeys wrapKey -PermissionsToSecrets set;
	
	# Enable Key Vault Access rights
	Set-AzureRmKeyVaultAccessPolicy -VaultName $keyVaultName -EnabledForDiskEncryption -EnabledForTemplateDeployment -EnabledForDeployment;

	# Enable soft delete on KeyVault to not lose encryption secrets
    Write-Host "Enabling Soft Delete on KeyVault $keyVaultName";
    $resource = Get-AzureRmResource -ResourceId $newKeyVault.ResourceId;
    $resource.Properties | Add-Member -MemberType "NoteProperty" -Name "enableSoftDelete" -Value "true" -Force;

    Set-AzureRmResource -resourceid $resource.ResourceId -Properties $resource.Properties -Force;
	
	#############################################################################################################################################

	
    $diskEncryptionKeyVaultUrl = $newKeyVault.VaultUri;
	$keyVaultResourceId = $newKeyVault.ResourceId;

	$keyEncryptionKeyName = "VMDiskEncryption"

    Try{
        $kek = Get-AzureKeyVaultKey -VaultName $keyVaultName -Name $keyEncryptionKeyName -ErrorAction SilentlyContinue;
    }
    Catch [Microsoft.Azure.KeyVault.KeyVaultClientException]{
        Write-Host "Couldn't find key encryption key named : $keyEncryptionKeyName in Key Vault: $keyVaultName";
        $kek = $null;
    } 

    if(-not $kek){
        Write-Host "Creating new key encryption key named:$keyEncryptionKeyName in Key Vault: $keyVaultName";
        $kek = Add-AzureKeyVaultKey -VaultName $keyVaultName -Name $keyEncryptionKeyName -Destination Software -ErrorAction SilentlyContinue;
        Write-Host "Created  key encryption key named:$keyEncryptionKeyName in Key Vault: $keyVaultName";
    }

    $keyEncryptionKeyUrl = $kek.Key.Kid;

	#############################################################################################################################################

    Write-Host "Please note down below details that will be needed to enable encryption on your VMs in the Future" -foregroundcolor Green;

    if($aadAppName){
        Write-Host "`t aadClientID: $aadClientID" -foregroundcolor Green;
        Write-Host "`t aadClientSecret: $aadClientSecret" -foregroundcolor Green;
    }

    Write-Host "`t DiskEncryptionKeyVaultUrl: $diskEncryptionKeyVaultUrl" -foregroundcolor Green;
    Write-Host "`t DiskEncryptionKeyVaultId: $keyVaultResourceId" -foregroundcolor Green;

    if($keyEncryptionKeyName){
        Write-Host "`t KeyEncryptionKeyURL: $keyEncryptionKeyUrl" -foregroundcolor Green;
        Write-Host "`t KeyEncryptionKeyVaultId: $keyVaultResourceId" -foregroundcolor Green;
    }

    Write-Host "Please Press [Enter] after saving values displayed above. They are needed to enable encryption using Set-AzureRmVmDiskEncryptionExtension cmdlet" -foregroundcolor Green;


###############################################################################################################################

	# Create Key Vault Build

	$keyVaultNamebuild = "KV-DEV-$($RGLocation)-$($envBuild)-BUILD"

	Try{
		$newKeyVaultbuild = Get-AzureRmKeyVault -VaultName $keyVaultNamebuild -ErrorAction SilentlyContinue;
    }
    Catch [System.ArgumentException]{
        Write-Host "Couldn't find Key Vault: $keyVaultNamebuild";
        $newKeyVault = $null;
    }

    # Create a new vault if vault doesn't exist
    if (-not $newKeyVaultbuild){
        Write-Host "Creating new key vault:  ($keyVaultNamebuild)";
        $newKeyVaultbuild = New-AzureRmKeyVault -VaultName $keyVaultNamebuild -ResourceGroupName $RGName -Sku Premium -Location $($MSDataCentre);
        Write-Host "Created a new KeyVault named $keyVaultNamebuild to store encryption keys";
    }

	#  Set Keyvault permisions
    Set-AzureRmKeyVaultAccessPolicy -VaultName $keyVaultNamebuild -ServicePrincipalName $aadClientID -PermissionsToKeys wrapKey -PermissionsToSecrets set;
	
	# Enable Key Vault Access rights
	Set-AzureRmKeyVaultAccessPolicy -VaultName $keyVaultNamebuild -EnabledForDiskEncryption -EnabledForTemplateDeployment -EnabledForDeployment;

	# Enable soft delete on KeyVault to not lose encryption secrets
    Write-Host "Enabling Soft Delete on KeyVault $keyVaultNamebuild";
    $resource = Get-AzureRmResource -ResourceId $newKeyVaultbuild.ResourceId;
    $resource.Properties | Add-Member -MemberType "NoteProperty" -Name "enableSoftDelete" -Value "true" -Force;

    Set-AzureRmResource -resourceid $resource.ResourceId -Properties $resource.Properties -Force;

    #############################################################################################################################################

	
    $diskEncryptionKeyVaultUrl = $newKeyVaultbuild.VaultUri;
	$keyVaultResourceId = $newKeyVaultbuild.ResourceId;


        $aadClientIDName ='aadClientID' 
        $aadClientSecretName ='aadClientSecret' 
        $aadClientID
        $aadClientSecret
        $keyEncryptionKeyUrl
        $keyEncryptionKeyUrlname = 'keyEncryptionKeyUrl'
        $keyVaultResourceId
        $keyVaultResourceIdname = 'keyVaultResourceId'
        $pwd = ConvertTo-SecureString "$($aadClientID)" -AsPlainText -Force
        $pwd2 = ConvertTo-SecureString "$($aadClientSecret)" -AsPlainText -Force
        $pwd3 = ConvertTo-SecureString "$($keyEncryptionKeyUrl)" -AsPlainText -Force
        $pwd4 = ConvertTo-SecureString "$($keyVaultResourceId)" -AsPlainText -Force


# Add client ID

    Try{
        $kek = Get-AzureKeyVaultKey -VaultName $keyVaultNamebuild -Name $aadClientIDName -ErrorAction SilentlyContinue;
    }
    Catch [Microsoft.Azure.KeyVault.KeyVaultClientException]{
        Write-Host "Couldn't find key encryption key named : $aadClientIDName in Key Vault: $keyVaultNamebuild";
        $kek = $null;
    } 

    if(-not $kek){
        Write-Host "Creating new key encryption key named:$aadClientIDName in Key Vault: $keyVaultNamebuild";
        $kek = Set-AzureKeyVaultSecret -VaultName $keyVaultNamebuild -Name $aadClientIDName -SecretValue @pwd -ErrorAction SilentlyContinue;
        Write-Host "Created  key encryption key named:$aadClientIDName in Key Vault: $keyVaultNamebuild";
    }

    #Add client secret

        Try{
        $kek = Get-AzureKeyVaultKey -VaultName $keyVaultNamebuild -Name $aadClientSecret -ErrorAction SilentlyContinue;
    }
    Catch [Microsoft.Azure.KeyVault.KeyVaultClientException]{
        Write-Host "Couldn't find key encryption key named : $aadClientSecret in Key Vault: $keyVaultNamebuild";
        $kek = $null;
    } 

    if(-not $kek){
        Write-Host "Creating new key encryption key named:$aadClientSecret in Key Vault: $keyVaultNamebuild";
        $kek = Set-AzureKeyVaultSecret -VaultName $keyVaultNamebuild -Name $aadClientSecretname -SecretValue @pwd2 -ErrorAction SilentlyContinue;
        Write-Host "Created  key encryption key named:$aadClientSecret in Key Vault: $keyVaultNamebuild";
    }
    
    # Add keyEncryptionKeyUrl

    Try{
        $kek = Get-AzureKeyVaultKey -VaultName $keyVaultNamebuild -Name $keyEncryptionKeyUrlname -ErrorAction SilentlyContinue;
    }
    Catch [Microsoft.Azure.KeyVault.KeyVaultClientException]{
        Write-Host "Couldn't find key encryption key named : $keyEncryptionKeyUrlname in Key Vault: $keyVaultNamebuild";
        $kek = $null;
    } 

    if(-not $kek){
        Write-Host "Creating new key encryption key named:$keyEncryptionKeyUrlname in Key Vault: $keyVaultNamebuild";
        $kek = Set-AzureKeyVaultSecret -VaultName $keyVaultNamebuild -Name $keyEncryptionKeyUrlname -SecretValue @pwd3 -ErrorAction SilentlyContinue;
        Write-Host "Created  key encryption key named:$keyEncryptionKeyUrlname in Key Vault: $keyVaultNamebuild";
    }

    #Add keyVaultResourceId

        Try{
        $kek = Get-AzureKeyVaultKey -VaultName $keyVaultNamebuild -Name $keyVaultResourceIdname -ErrorAction SilentlyContinue;
    }
    Catch [Microsoft.Azure.KeyVault.KeyVaultClientException]{
        Write-Host "Couldn't find key encryption key named : $keyVaultResourceIdname in Key Vault: $keyVaultNamebuild";
        $kek = $null;
    } 

    if(-not $kek){
        Write-Host "Creating new key encryption key named:$keyVaultResourceIdname in Key Vault: $keyVaultNamebuild";
        $kek = Set-AzureKeyVaultSecret -VaultName $keyVaultNamebuild -Name $keyVaultResourceIdname -SecretValue @pwd4 -ErrorAction SilentlyContinue;
        Write-Host "Created  key encryption key named:$keyVaultResourceIdname in Key Vault: $keyVaultNamebuild";
    }