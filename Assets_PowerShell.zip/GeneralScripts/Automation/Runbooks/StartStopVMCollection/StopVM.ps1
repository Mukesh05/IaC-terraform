param(
    [Parameter(Mandatory=$true)]
    [string]$VMName,
    [Parameter(Mandatory=$true)]
    [string]$ResourceGroupName
)

# Authenticate to Azure using the Automation account service principal
If ($PSPrivateMetadata.JobId) {
    $conn = Get-AutomationConnection -Name "AzureRunAsConnection"
    $null = Add-AzAccount -ServicePrincipal -Tenant $conn.TenantId -ApplicationId $conn.ApplicationId -CertificateThumbprint $conn.CertificateThumbprint
}

# Need to add check to see if VM is actually online, else no point trying to stop it
$vmStatus = Get-AzVM -Name $VMName -ResourceGroupName $ResourceGroupName -Status

If ($vmStatus.Statuses.Code -contains "PowerState/deallocated") {
    write-verbose "VM already deallocated, no need to stop" -Verbose
} else {
    # Write out status information and stop the virtual machine
    Write-Verbose "Stopping VM $VMName" -Verbose

    $stop = Stop-AzVM -Name $VMName -ResourceGroupName $ResourceGroupName -Force

    Write-Verbose "VM stopped" -Verbose

    Write-Output "VM $VMName stopped"
}