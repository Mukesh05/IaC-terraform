param(
    [Parameter(Mandatory=$true)]
    [string]$CollectionName,
    [switch]$start,
    [switch]$stop
)

$ErrorActionPreference="Stop"

If (($start -and $stop) -or (!$start -and !$stop)) {
    Write-Error "Script called without either start or stop switch, or both switches provided"
}

# Authenticate to Azure using the Automation account service principal if running in Azure Automation rather than local computer
If ($PSPrivateMetadata.JobId) {
    $conn = Get-AutomationConnection -Name "AzureRunAsConnection"
    $null = Add-AzAccount -ServicePrincipal -Tenant $conn.TenantId -ApplicationId $conn.ApplicationId -CertificateThumbprint $conn.CertificateThumbprint
}

$VMs = Get-AzVM

# Check to make sure we have some VMs
If ($VMs) {

    # Only get VM's which have the ControllerShutdown tag and then filter them for a JSON property of Collection that matches our required collection
    $CollectionVMs = $VMs| Where-Object {$_.Tags.ControlledStopStart} | Where-Object {($_.Tags.ControlledStopStart | ConvertFrom-Json).Collection -eq $CollectionName}

    # Initialise an object to hold the VMs we want to look at, this object will take all the required properties from the VM object and extract the Tag values stored as JSON.
    # This will then allow us to sort the VMs by priority to ensure they are shutdown in the right order.
    $Collection = @()

    # Loop through each VM in our collection
    ForEach ($VM in $CollectionVMs) {
        # Initialise a row object to store out information
        $row = "" | Select-Object Name,ResourceGroupName,OS,Priority,ScriptPath,ExpectedString,PostStartupDelaySeconds

        # Get the properties of the VM
        $row.Name = $VM.Name
        $row.ResourceGroupName = $VM.ResourceGroupName
        If ($VM.OSProfile.WindowsConfiguration) {
            $row.OS = "Windows"
        }
        If ($VM.OSProfile.LinuxConfiguration) {
            $row.OS = "Linux"
        }
        If (!$row.OS) {
            write-error "Unable to determine VM operating system"
        }

        # Get the tag values and convert from JSON
        $tagContents = $VM.Tags.ControlledStopStart | ConvertFrom-Json

        # Store the required values, any empty properties will store a null value. Different values are required depending on calling the script with either start or stop.
        If ($start) {
            $row.Priority = $tagContents.StartPriority
            $row.PostStartupDelaySeconds = $tagContents.PostStartupDelaySeconds
        } else {
            $row.Priority = $tagContents.StopPriority
            $row.ScriptPath = $tagContents.ScriptPath
            $row.ExpectedString = $tagContents.ExpectedString
        }

        # Add the row to the output collection
        $Collection+=$row
    }

    # Check for any VM's missing a priority
    $missingPriority = $Collection | Where-Object {$_.Priority -eq $null}

    # If any VM's are missing a priority, stop the script and error as it can't continue
    If ($missingPriority) {
        write-error "One or more VM's missing priority: $(($missingPriority.Name -join ","))"
    }

    # Set the value for the output message dependent on parameter switch
    If ($start) {
        $msg = "start"
    } else {
        $msg = "stop"
    }

    Write-Output "Need to $msg $(($Collection).Count) VM's ($($Collection.Name -join ','))"

    # Loop through each server in the list
    Foreach ($VM in ($Collection | Sort-Object Priority)) {

        Write-output "Current VM: $($VM.Name) (Priority $($VM.Priority))"

        # If script was called with start switch then start the VMs
        If ($start) {

            $vmStatus = Get-AzVM -Name $VM.Name -ResourceGroupName $VM.ResourceGroupName -Status

            If ($vmStatus.Statuses.Code -contains "PowerState/running") {
                Write-Output "VM already running, no need to start"
            } else {
                Write-Output "Starting VM"

                $startVM = Start-AzVM -Name $VM.Name -ResourceGroupName $VM.ResourceGroupName
            }

            Write-Output "VM startup complete"

            # Check to see if a script path was provided, as we will need to run the pre-shutdown runbook
            If ($VM.PostStartupDelaySeconds) {

                Write-Output "Waiting for $($VM.PostStartupDelaySeconds) seconds as server set to have post startup delay"

                Start-Sleep -Seconds $VM.PostStartupDelaySeconds
            }

        # Other wise stop the VMs
        } else {
            # Check to see if a script path was provided, as we will need to run the pre-shutdown runbook
            If ($VM.ScriptPath) {

                # Splat the required parameters
                $params = @{
	                VMName = $VM.Name
	                ResourceGroupName = $VM.ResourceGroupName
                    ScriptPath = $VM.ScriptPath
                    OS = $VM.OS
                }

                # Add the ExpectedString to the splat if it was passed in
                If ($VM.ExpectedString) {
                    $params.Add('ExpectedString',$VM.ExpectedString)
                }

                Write-Output "Running pre-shutdown runbook against $($VM.Name)"

                # Call the RunRemoteScript runbook
                .\RunRemoteScript.ps1 @params
            }

            Write-Output "Running shutdown runbook against $($VM.Name)"

            # Call shutdown VM runbook
            .\StopVM.ps1  -VMName $VM.Name -ResourceGroupName $VM.ResourceGroupName
        }
    }

} else {
    write-output "No VM's found"
}

# Set the value for the output message dependent on parameter switch
If ($start) {
    $msg = "started"
} else {
    $msg = "stopped"
}

# End of script
Write-Output "$(($Collection).Count) VM's have been $msg ($($Collection.Name -join ','))"