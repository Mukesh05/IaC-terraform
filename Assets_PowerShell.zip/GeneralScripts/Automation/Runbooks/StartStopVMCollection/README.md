# Start Stop VM scripts with option shutdown script

These scripts need to be added to runbooks in an Azure Automation account and then the correct tags/schedules applied

## Automation Account Runbooks

Create three PowerShell Runbooks in an Automation Account, ensuring the runas account has permissions to query VM's and also start/stop VMs. The below scripts need to be used as the source code in runbooks of the same name.

### StartStopVMCollection.ps1

Starts/stops VMs for VM's in the provided collection name.

### RunRemoteScript.ps1

This script is triggered by the above script, it takes parameters of the VM Name, Resource Group Name, OS (Windows or Linux), the script path and any expected output from the script.

It can be run independently of the above script as required.

### StopVM.ps1

Again, a script called by the initial script, but can be run independently.

## VM Tags
VM's need to have a tag "ControlledStopStart" containing a JSON object with the following properties as required: -
- Collection (string) - required
- StartPriority (integer) - required if start scheduled
- StopPriority (integer) - required
- ExpectedString (string) - optional
- PostStartupDelaySeconds (integer) - optional
- ScriptPath (string) - optional

For example: -
```
{
    Collection: 'SAPPREPROD',
    StopPriority: 3,
    StartPriority: 1,
    PostStartupDelaySeconds: 900
}
```

## Scheduling the start/stop
Create two schedules, one for the start and one for the stop (or stop only if no start is required)

Assign the schedules to the StartStopVMCollection Runbook specifying the CollectionName parameter and $true for either the Start or Stop parameters