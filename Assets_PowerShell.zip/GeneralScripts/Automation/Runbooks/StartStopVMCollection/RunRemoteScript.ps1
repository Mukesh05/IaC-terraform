param(
    [Parameter(Mandatory=$true)]
    [string]$VMName,
    [Parameter(Mandatory=$true)]
    [string]$ResourceGroupName,
    [Parameter(Mandatory=$true)]
    [string]$OS,
    [Parameter(Mandatory=$false)]
    [string]$ScriptPath,
    [Parameter(Mandatory=$false)]
    [string]$ExpectedString
)

# Checking to see if VM is running or not, otherwise we can't run the remote commands
$VMDetail = Get-AzVM -Name $VMName -ResourceGroupName $ResourceGroupName -Status

If ($VMDetail.Statuses.Code -notcontains "PowerState/running") {
    write-verbose "The VM is not in the running state, unable to run scripts, skipping running scripts"
    Write-Output "Skipped running remote script"
} else {

    # Set details for specific OS as Windows and Linux differ for the run command and the file extension required
    Switch ($OS) {
        "Windows" {
            $commandID = 'RunPowerShellScript'
            $fileExtension = "ps1"
        }
        "Linux" {
            $commandID = 'RunShellScript'
            $fileExtension = "sh"
        }
    }

    # Create a temporary script file, as this needs to be picked up by the invoke command, this will be the path to the script on the VM that needs to be run
    $tempFile = "$env:TEMP\$($VMName)-$(get-date -Format yyyymmddhhmmss).$($fileExtension)"
    $ScriptPath | Out-File -FilePath $tempFile -Force

    If ($PSPrivateMetadata.JobId) {
        $conn = Get-AutomationConnection -Name "AzureRunAsConnection"
        $null = Add-AzAccount -ServicePrincipal -Tenant $conn.TenantId -ApplicationId $conn.ApplicationId -CertificateThumbprint $conn.CertificateThumbprint
    }

    # Run the script on the VM
    Write-Verbose "Running remote pre-shutdown script $ScriptPath" -Verbose
    $ScriptPathout = Invoke-AzVMRunCommand -ResourceGroupName $ResourceGroupName -VMName $VMName -CommandId $commandID -ScriptPath $tempFile

    # Tidy up the temporary file (even though it should be deleted)
    Remove-Item -Path $tempFile -Force

    Write-Verbose "Remote pre-shutdown script completed" -Verbose

    # Store the returned message in an easy to use variable
    $runmessage = $ScriptPathout.Value.Message

    # Initialise various objects
    $stdoutmsg = @()
    $stderrmsg = ""
    $stdout = $false
    $stderr = $false

    # Extract/split the returned message into useable objects
    foreach ($line in ($runmessage.Split([string[]]"`n", [StringSplitOptions]::None))) {
        switch ($line) {
        "[stdout]" {
                $stdout=$true
            }
        "[stderr]" {
                $stdout=$false
                $stderr=$true
            }
        }
        If ($stdout -and $line -ne "[stdout]") {
            $stdoutmsg += $line
        }
        If ($stderr -and $line -ne "[stderr]" -and $line.Length -gt 0) {
            $stderrmsg += "$($line)`n"
        }
    }

    # Check and see if there was an error running the script on the VM
    If ($stderrmsg.Length -gt 0) {
        Write-Error "There was an error running the script `n$stderrmsg"
    }

    # If an expected string was provided, check for it
    If ($ExpectedString) {
        If ($stdoutmsg -contains $ExpectedString) {
            Write-Verbose "Script was completed" -Verbose
            Write-Output "Success"
        } else {
            Write-Error "Unable to find expected string"
        }
    } else {
        Write-Output "RemoteScript Success"
    }
}