# Automation Account Runbooks
This folder contains other folders which contain runbooks files for use in Azure Automation Accounts