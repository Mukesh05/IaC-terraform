# Automation
This folder contains items relating to Azure Automation Accounts