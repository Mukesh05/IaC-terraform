<#

.SYNOPSIS
Reads the output from an ARM deployment step in Azure Devops and stores them individually inDevOps output variables.

.DESCRIPTION
Reads the ARM outputs from an Output variable and stores them individually in an Azure DevOps variable. This is to allow different tasks in Azure DevOps to access information from an ARM deployment, such as generated Storage Account names.

.EXAMPLE
./Read-AzDevopsARMOutputParams.ps1 -armOutputString "storageAccountName" -keynameSuffix "SAName"

.NOTES
Written by Bhupi Singh, with information sourced online

.LINK
http://www.newsignature.com

#>

param (
    [Parameter(Mandatory=$true)]
    [string]
    $armOutputString,
    [string]
    $keynameSuffix= ''
)

Write-Output "Retrieved input: $armOutputString"
# Convert the ARM output from JSON to a PSObject
$armOutputObj = $armOutputString | convertfrom-json

# Loop through each of the properties/outputs
$armOutputObj.PSObject.Properties | ForEach-Object {
    $type = ($_.value.type).ToLower()
    # Set the name of the output variable, with optional suffix to ensure it is unique as this could be called multiple times in a pipeline
    $keyname = "Output_"+$_.name+$keynameSuffix
    $value = $_.value.value

    # Change the output type depending in whether it is a secure string or not. Only strings and securestrings are supported for output
    if ($type -eq "securestring") {
        Write-Output "##vso[task.setvariable variable=$keyname;issecret=true]$value"
        Write-Output "Added VSTS variable '$keyname' ('$type')"
    } elseif ($type -eq "string") {
        Write-Output "##vso[task.setvariable variable=$keyname]$value"
        Write-Output "Added VSTS variable '$keyname' ('$type') with value '$value'"
    } else {
        Throw "Type '$type' is not supported for '$keyname'"
    }
}