<#

.SYNOPSIS
Compiles multiple JSON files into single output

.DESCRIPTION
As many JSON items are stored in the repo and need to be compiled together, this script reads all the files and then outputs them to a single output variable

.EXAMPLE
./Compile-JSONContent.ps1 -SourceDirectory c:\source -outputName outvar1

.NOTES
Written by Adam Evans (Oct 19)
Primary use is in an Azure Dev Ops pipeline, but can be modified for normal script operation.

.LINK
http://www.newsignature.com

#>

param(
  [Parameter(Mandatory=$true)]
  [string[]]$SourceDirectory, # Array of source directories to compile the output from
  [Parameter(Mandatory=$true)]
  [string]$OutputVarName, # Name of output variable to use
  [Parameter(Mandatory=$false)]
	[string]$filter="*.json" # Filter the file names, defaults to *.json if no filter is provided
)

# Output needs to be a JSON array, so we have to make the output an array
$output = "["

# Loop through each of the directories provided to get all the file
Foreach ($dir in $SourceDirectory) {

	# Get a list of files from the current iteration directory and filter
	$jsonFiles = Get-ChildItem -Path $dir/$filter

	# Loop through each file found
	Foreach ($file in $jsonFiles) {
		# Check to see if we are adding to an existing JSON entry (make sure the output isn't only "[") and also ensure there is currently no comma on the end of the string
		If ($output -ne "[" -and ($output -notmatch '.+?\,$')) {
			# If not the first time we are adding things in, and no comma on the end, add a comma
			$output+=","
		}
		# Append the JSON contents to the string
		$output += (Get-Content $file.FullName).replace("`n","").replace("`r","")
	}

}

# Close the output JSON array
$output+="]"

# Write the output so that it can be seen in Azure DevOps console/logs
Write-Host $output
# Write the output to the Azure DevOps variable
Write-Output "##vso[task.setvariable variable=$OutputVarName;]$output"