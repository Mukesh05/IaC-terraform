<#

.SYNOPSIS
Checks if a VM extension has already been deployed to an Azure VM.

.DESCRIPTION
Checks to see if a VM already has the specified VM extension deployed and sets the output variable to true, if not it the output variable to false. Designed for use in an Azure DevOps pipeline to allow other tasks to become conditional and not deploy if previously deployed.

.EXAMPLE
./Check-VMExtension.ps1 -VMName vm1 -VMResourceGroupName rg1 -ExtensionName AntiMalwareSaaS -OutputVarName outvar1

.NOTES
Written by Adam Evans (Oct 19)
Primary use is in an Azure Dev Ops pipeline, but can be modified for normal script operation.

.LINK
http://www.newsignature.com

#>

param (
  [Parameter(Mandatory=$true)]
  [string]$VMName,
  [Parameter(Mandatory=$true)]
  [string]$VMResourceGroupName,
  [Parameter(Mandatory=$true)]
  [string]$ExtensionName,
  [Parameter(Mandatory=$true)]
  [string]$OutputVarName
)

# Get all the Extensions on the VM
$vme = Get-AzVMExtension -ResourceGroupName $VMResourceGroupName -VMName $VMName

# Filter for the extension we are looking for
$vme = $vme | Where-Object {$_.Name -eq $ExtensionName -and $_.ProvisioningState -eq "Succeeded"}

# If the extension exists return true, if it doesn't exist return false
If ($vme) {
    write-host "VM extension '$ExtensionName' on VM '$VMName' in Resource Group '$VMResourceGroupName' valid."
    Write-Output "##vso[task.setvariable variable=$OutputVarName;]true"
} else {
    write-host "VM extension '$ExtensionName' on VM '$VMName' in Resource Group '$VMResourceGroupName' not valid."
    Write-Output "##vso[task.setvariable variable=$OutputVarName;]false"
}