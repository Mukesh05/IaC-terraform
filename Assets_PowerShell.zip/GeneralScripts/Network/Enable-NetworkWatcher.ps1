<#

.SYNOPSIS
Enables Network Watcher in a given location,

.DESCRIPTION
Script enables Network Watched in a given location if it doesn't already exist.

.EXAMPLE
./Enable-NetworkWatcher.ps1 -location westeurope

.NOTES
Written by Adam Evans (Nov 19)
Developed to resolve an issue in an Azure DevOps pipeline, as Azure Policies were enforcing that Network Watcher should be enabled on a Virtual Network, but it hadn't been enabled on the region so the deployment would fail.

.LINK
http://www.newsignature.com

#>

param(
    [Parameter(Mandatory=$true)]
    [string]$location
)

# Build the name of the Network Watcher we need enabled
$nwName = 'NetworkWatcher_'+$location.toLower()
# Set the default RG name
$nwRGName = "NetworkWatcherRG"

# Get the network watchers and filter for our local region
$nw = Get-AzNetworkWatcher | Where-Object {$_.Name -eq $nwName}

# check and see if it exists
If (!$nw) {
    # It doesn't exist so we need to create it

    # Get a list of the resource groups and see the default resource group exists
    $nwrg = Get-AzResourceGroup | Where-Object {$_.ResourceGroupName -eq $nwRGName}

    If (!$nwrg) {
        # It doesn't exist so create the resource group
        write-host "Need to create resource group $($nwRGName) as it doesn't currently exist"
        New-AzResourceGroup -Name $nwRGName -Location $location
    } else {
        write-host "Network watcher resource group '$nwRGName' already exists"
    }

    write-host "Need to create the network watcher '$nwName' for the local region as it doesn't exist"

    New-AzNetworkWatcher -Location $location -Name $nwName -ResourceGroupName $nwRGName
} else {
    write-host "Network watcher '$nwName' already exists"
}