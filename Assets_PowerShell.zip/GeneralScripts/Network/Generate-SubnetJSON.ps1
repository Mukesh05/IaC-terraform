<#

.SYNOPSIS
Generates from a source CSV file a JSON array of subnets for injection into a ARM template through copy and paste or through a template parameter.

.DESCRIPTION
Using a simple CSV file and relevant provided script parameters, the script generates the ARM JSON for use in the "subnets" section of a Virtual Network resource in an ARM template. The script supports injection of Route Table ID's and NSG ID's into the subnet entries. It assumes a single Route Table will be utilised and a standard NSG prefix will be used with the subnet name as a suffix. This was to meet the requirements stated by the original customer the script was developed for.

.EXAMPLE
./Generate-SubnetJSON.ps1 -subscriptionID -ResourceGroup -RouteTableName -NSGNamePrefix -ServiceEndpoints -location -SubnetCSVPath -DevOpsPipeline -OutputVariableName

.NOTES
Written by Adam Evans 17/01/2020

Sample CSV file: -

SubnetName,AddressPrefix,RouteTableEnabled,NSGEnabled,ServiceEndpointsEnabled
Restricted,10.20.31.64/26,true,true,true


.LINK
http://www.newsignature.com

#>

param(
    [string]$subscriptionID,
    [string]$ResourceGroup,
    [string]$RouteTableName,
    [string]$NSGNamePrefix,
    [string[]]$ServiceEndpoints,
    [string]$location,
    [string[]]$Global = "Microsoft.AzureActiveDirectory",
    [string]$SubnetCSVPath,
    [switch]$DevOpsPipeline,
    [string]$OutputVarName
)

If (!(Test-Path $SubnetCSVPath)) {
    throw "Unable to find CSV file $SubnetCSVPath"
}

$subnets = Import-Csv -LiteralPath $SubnetCSVPath

If ($ServiceEndpoints) {
    # Create the base array
    $compiledSE=@()

    #Loop through each of the Service Endpoints (if provided)
    Foreach ($endpoint in $ServiceEndpoints) {
        # If the endpoint is in the global list, don't limit to a region, if it's not, use the region specified
        If ($endpoint -in $global) {
            $locations = @()
        } else {
            $locations = $location
        }

        # Compile a hash table of the endpoint items
        $se = @{service=$endpoint;locations=$locations}

        # Add to the array of endpoints
        $compiledSE+=$se
    }
} else {
    $compiledSE=@()
}

$emptyArray=@()

$RouteTableID = "/subscriptions/$subscriptionID/resourceGroups/$ResourceGroup/providers/Microsoft.Network/routeTables/$RouteTableName"
$NSGPrefix = "/subscriptions/$subscriptionID/resourceGroups/$ResourceGroup/providers/Microsoft.Network/networkSecurityGroups/$NSGNamePrefix"



Function New-SubnetConfigHashTable {

    param(
        $SubnetName,
        $AddressPrefix,
        $RouteTable,
        $NSGIDPrefix,
        $ServiceEndpointList
    )

    # Create hash table with required fields from parameters
    $subProp = @{addressPrefix=$AddressPrefix}

    # If a route table has been provided, add the route table
    If ($RouteTable) {
        $subProp += @{routeTable=@{id=$RouteTable}}
    }

    # If an NSG prefix has been provided, add the NSG prefix with subnet suffix
    If($NSGIDPrefix) {
      $NSGResourceID=$NSGIDPrefix+'-'+$SubnetName
        $subProp += @{networkSecurityGroup=@{id=$NSGResourceID}}
    }

    # If one or more service endpoints has been provided, add the endpoint(s)
    If ($ServiceEndpointList) {
        $subProp += @{serviceEndpoints=$ServiceEndpointList}
    }
    return  @{name=$SubnetName; properties=$subProp}
}

# Create the output subnet array
$subArray = @()

# Loop through each of the input subnets
Foreach ($Subnet in $subnets) {

  # Build up the parameters to pass into the function.
    $functionParams = @{
        SubnetName = $Subnet.SubnetName
        AddressPrefix = $Subnet.AddressPrefix
    }

    If ($Subnet.RouteTableEnabled -eq "true") {
        $functionParams += @{RouteTable=$RouteTableID}
    }

    If ($Subnet.NSGEnabled -eq "true") {
        $functionParams += @{NSGIDPrefix=$NSGPrefix}
    }

    If ($Subnet.ServiceEndpointsEnabled -eq "true") {
        $functionParams += @{ServiceEndpointList=$compiledSE}
    }

    # Call the function and add to the output array
    $subArray += New-SubnetConfigHashTable @functionParams
}

# Convert the array into JSON
$json = ($subArray | ConvertTo-Json -depth 10)

# If the Remove new lines switch is provided
If ($DevOpsPipeline) {
  $json = $json.replace("`n","").replace("`r","")
}

# If there is a only a single entry, need to force the brackets on it to turn it into an array, else CICD could through an error as it's passed an object and not an array
If ($subArray.Count -eq 1) {
    Write-Host "need to add array brackets" -ForegroundColor Magenta
    $json = '['+$json+']'
}

# Output the JSON no matter what, if CICD will show it in the logs for easier troubleshooting
Write-Output $json

# If DevOps pipeline has been selected, it will output the value to a variable specified
If ($DevOpsPipeline) {
  Write-Output "##vso[task.setvariable variable=$OutputVarName;]$json"
}