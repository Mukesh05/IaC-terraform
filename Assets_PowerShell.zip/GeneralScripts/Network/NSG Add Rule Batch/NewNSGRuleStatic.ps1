﻿# This script creates a new Network Security Rule Config given the content of a CSV file and the Network Security Group rule definition below.

# To use:
# 1) Update the .\NewNSGRule.csv file with the names of the NSG's to update
# 2) Sign into the destination tenant and set context to the subscription you'll be working in
#     Examples
#      Connect-AzAccount -Tenant newsignature1.onmicrosoft.com
#      Set-AzContext -SubscriptionId $SubscriptionID
# 3) Run the Script
#     .\NewNSGRule.ps1

# Variables for New NSG Rule Criteria
$RuleName = "Thy-RDP-In" 					# Name
$Desc = "Permits RDP Access to Thycotic VM" #Description
$SrcIP = "10.4.194.228","10.4.142.4"		# Source Information
$DestIP = "*"								# Destination Information
$Proto = "TCP" 								# IP Protocol
$DestPort = "3389" 							# Destination Port
$SrcPort = "*" 								# Source Port
$Action = "Allow" 							# Action - Allow or Deny
$Priority = "222" 							# Priority 
$Direction = "Inbound" 						# Direction - Inbound or Outbound

# CSV File containing the resource group and network security group names
$CSVFile = ".\NewNsgRule.csv"

# Import the CSV File and don't process the headers in the for loop
$objCSV = Import-Csv -Path $CSVFile | Select-Object -Skip 0

# The Resource Type for a Network Security Group
$AzureResourceType = "Microsoft.Network/networkSecurityGroups"


# Collect the rule priorities now so we can search for potential collisions later

$aRules = @()
$i = 0

$objCSV | 	ForEach-Object {
$i++
	 $NSGName = "$($_.NSGName)"
    
			 Write-Host "Processing Line $i : $NSGName"

             # Get the resource  from Azure given the name from the CSV File
             $AzResource = Get-AzResource -Name $NSGName

             $NSGName = "$($AzResource.Name)"
             $RGName = "$($AzResource.ResourceGroupName)"

             
             # Validate we're working with an object of the expected type for NSG
             If ($AzResource.ResourceType -eq $AzureResourceType ) {
             
              #$NSG = Get-AzNetworkSecurityGroup -Name $NSGName -ResourceGroupName $RGName
              $aRules += $(Get-AzNetworkSecurityGroup -Name $NSGName -ResourceGroupName $RGName).SecurityRules.Priority

             }

}

# Set a start point for priority matching and convert to integer
$newPriority = $Priority/1
# Array to store our processing of the priorities
$matchtable = New-Object 'object[,]'2,3997

# Loop through the rule priority values we collected earlier and set the relative Azure Priority number
# Start and End loop on the minimum/maximum Azure rule Priority limits
For ($s = 100 ;$s -le 4096;$s++) {

    # Set our array index to position 0
    $index = $s - 100

    # For a given array position, set what the rule number is in the array
    # write-host $index, $s
    $matchtable[0,$index] = $s

}


# Loop through the collected priorities from Azure and set them as used
$aRules | ForEach-Object {
    $index = ($_/1)-100
    if ($index -ge 0) {
    #write-host $index
    $matchtable[1,$index] = "Match" }
}




# Locate the first unused rule priority number

$Priority = "221"
For ($s = 0 ;$s -le 3997;$s++) {

$p1 =  $matchtable[0,$s]/1
$p2 = $Priority/1
if ($matchtable[1,$s] -ne "Match" -and $p1 -ge $p2 ) {

write-host "Old Priority was $($Priority), New Priority is $($p1)" 

$Priority = $matchtable[0,$s] 
Break
}

}







$Priority = $newPriority

# Loop through each row in the CSV file
$objCSV | 	ForEach-Object {

			 # Assign the CSV File values to variables we can work with
	 
			 $NSGName = "$($_.NSGName)"

             
			 Write-Host "Processing Line $($objCSV.count) : $NSGName"

             # Get the resource  from Azure given the name from the CSV File
             $AzResource = Get-AzResource -Name $NSGName

             
             # Validate we're working with an object of the expected type for NSG
             If ($AzResource.ResourceType -eq $AzureResourceType ) {
                
                Write-Host "Found Azure Resource Name $($AzResource.Name) with Type $($AzResource.ResourceType)"

    			 # Get the Resource Group name from that resource
                 $NSGName = "$($AzResource.Name)"
                 $RGName = "$($AzResource.ResourceGroupName)"

                 # Get the Network Security Group info			  
	    		 $NSG = Get-AzNetworkSecurityGroup -Name $NSGName -ResourceGroupName $RGName

		    	 # Add the new Network Security Group Rule to the Network Security Group
			     $NSG | Add-AzNetworkSecurityRuleConfig `
			 			-Name $RuleName `
			 			-Description $Desc `
						-Access $Action `
						-Protocol $Proto `
						-Direction $Direction `
						-Priority $Priority `
						-SourceAddressPrefix $SrcIP `
						-SourcePortRange $SrcPort `
						-DestinationAddressPrefix $DestIP `
						-DestinationPortRange $DestPort 

			    #Write the Network Security Group with the new rule
	            $NSG | Set-AzNetworkSecurityGroup
                }
                else { Write-Host "Found Azure Resource with Name $($_.NSGName) but different type, ignoring"}
            }

