<#

.SYNOPSIS
Deploys Azure Policies based on the input parameters.

.DESCRIPTION
A script based on the default Azure Policy task in Azure DevOps, but converted to take script parameters and also to check for existing policy definitions etc.

.EXAMPLE
./Deploy-AzurePolicy.ps1 -policyName "policy1" -policyDisplayName "Policy 1" -policyDescription "This policy is a demo for the script example -managementGroupName "3sk3jj-d2fddf3-sfef334" -policyRules "C:\policy.rules.json" -policyParameters "c:\policy.params.json"

.NOTES
Written by Adam Evans (Oct 19) to support deployment of Azure Policies through Azure DevOps pipelines

.LINK
http://www.newsignature.com

#>

# Input variables: set these values in the variables section of the release pipeline

#   policyName          - [required] Policy definition name
#   policyDisplayName   - [optional] Policy definition display name
#   policyDescription   - [optional] Policy definition description
#   subscriptionId      - [optional] Id of subscription the definition will be available in
#   managementGroupName - [optional] Name of management group the definition will be available in
#   policyRule          - [required] Policy definition rule in JSON string format or path to a file containing JSON policy definition rule
#   policyParameters    - [optional] Policy parameter values in JSON string format

# Notes:
#   Refer to https://docs.microsoft.com/en-us/azure/azure-policy/ for documentation on the Powershell cmdlets and the JSON input formats
#   File path value for $(PolicyRule) may be a fully qualified path or a path relative to $(System.DefaultWorkingDirectory)

param(
    [string]$policyName,
    [string]$policyDisplayName,
    [string]$policyDescription,
    [string]$subscriptionId,
    [string]$managementGroupName,
    [string]$policyRule,
    [string]$policyParameters,
    [string]$policyMode="Indexed"
)


if ($managementGroupName) {
    $searchParameters = @{ManagementGroupName=$managementGroupName}
} else {
    if (!$subscriptionId) {
        write-host "Need to get sub id"
        $subscription = (Get-AzContext).Subscription
        $subscriptionId = $subscription.Id
        write-host "Sub ID is $subscriptionId"
    }
    $searchParameters = @{SubscriptionId=$subscriptionId}
}

# Get list of existing policies
$ExistingPolicies = Get-AzPolicyDefinition @searchParameters

# Filter to see if the policy exists or not as we need to do different things according to this
$currentPolicy = $ExistingPolicies | Where-Object {$_.Name -eq $policyName}


if (!$policyName)
{
    throw "Unable to create policy definition: required input variable value `$(PolicyName) was not provided"
}

if (!$policyRule)
{
    throw "Unable to create policy definition: required input variable value `$(PolicyRule) was not provided"
}

if ($subscriptionId -and $managementGroupName)
{
    throw "Unable to create policy definition: `$(SubscriptionId) '$subscriptionId' and `$(ManagementGroupName) '$managementGroupName' were both provided. Either may be provided, but not both."
}

<#$azureRMModule = (Get-Module -Name AzureRM)
if ($managementGroupName -and (-not $azureRMModule -or $azureRMModule.version -lt 6.4))
{
    throw "For creating policy as management group, Azure PS installed version should be equal to or greater than 6.4"
}#>

# Splat the required parameters into the hash table
$cmdletParameters = @{Name=$policyName; Policy=$policyRule;}

# Add optional parameters
if ($policyDisplayName) {
    $cmdletParameters += @{DisplayName=$policyDisplayName}
}

if ($policyDescription){
    $cmdletParameters += @{Description=$policyDescription}
}

if ($subscriptionId){
    $cmdletParameters += @{SubscriptionId=$subscriptionId}
}

if ($managementGroupName){
    $cmdletParameters += @{ManagementGroupName=$managementGroupName}
}

if ($policyParameters){
    $cmdletParameters += @{Parameter=$policyParameters}
}

# If the current policy doesn't exist, add in the policy mode which defaults to 'indexed'
if (!$currentPolicy) {
    $cmdletParameters += @{Mode=$policyMode}
}

# If the policy doesn't exist, create it, or update it
If (!$currentPolicy -or ($currentPolicy.Properties.parameters -and !$policyParameters)) {
    # If policy parameters have been removed, we have to remove the original policy
    If ($currentPolicy.Properties.parameters -and !$policyParameters) {
        Write-Warning "Removing policy '$policyDisplayName ($policyName)' as parameters need to be removed"
        $assignments = Get-AzPolicyAssignment -PolicyDefinitionId $currentPolicy.ResourceId
        If ($assignments) {
            Foreach ($assignment in $assignments) {
                Write-Warning "Removing policy assignment '$($assignment.Name)'"
                Remove-AzPolicyAssignment -Id $assignment.ResourceId
            }
        } else {
            write-host "No policy assignments found"
        }
        Write-Warning "Assignments will need to be added again as this script only updates the policy"
        Remove-AzPolicyDefinition -Id $currentPolicy.ResourceId -Force
    }
    # Create policy
    write-host "Policy '$policyDisplayName ($policyName)' doesn't exist, creating"
    New-AzPolicyDefinition @cmdletParameters
} else {
    # Update policy
    write-host "Policy '$policyDisplayName ($policyName)' already exists, updating policy"
    #$DebugPreference="Continue"
    Set-AzPolicyDefinition @cmdletParameters
    #$DebugPreference="SilentlyContinue"
}