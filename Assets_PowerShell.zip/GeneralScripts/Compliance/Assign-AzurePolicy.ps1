<#

.SYNOPSIS
Script to assign Azure Policies based on the input parameters.

.DESCRIPTION
A script based on the default Azure Policy task in Azure DevOps, but converted to take script parameters and also to check for existing policy etc.

.EXAMPLE
./Assign-AzurePolicy.ps1 -assignmentName "assignment1" -assignmentDisplayName "Assignment of XXXX Policy to XXXX management group" -assignmentDescription "This policy assignment is a demo for the script example" -policyName "policyXXXX" -managementGroupName "3sk3jj-d2fddf3-sfef334" -policyParameters "c:\policy-params.json"

.NOTES
Written by Adam Evans (Oct 19) to support deployment of Azure Policies through Azure DevOps pipelines. Origin script taken from Azure DevOps but heavily customised.

BUG: If the policy is defined at Management Group level and assigned to multiple subscriptions the ability to change parameters is restricted. The code in this script was developed in a small local subscription with the parameter file updates causing issues in larger environments.

.LINK
http://www.newsignature.com

#>

# Input variables: set these values in the variables section of the release pipeline

#   AssignmentName        - [required] Policy assignment name
#   AssignmentDisplayName - [optional] Policy assignment display name
#   AssignmentDescription - [optional] Policy assignment description
#   PolicyName            - [optional] Name of policy definition to assign
#   PolicySetName         - [optional] Name of policy set definition to assign
#   ResourceGroupName     - [optional] Name of resource group the policy [set] definition will be applied to
#   SubscriptionId        - [optional] Id of subscription the policy [set] definition will be applied to
#   ManagementGroupName   - [optional] Name of management group the policy [set] definition will be applied to
#  PolicyParameters      - [optional] Policy parameter values in JSON string format

# Notes:
#   Refer to https://docs.microsoft.com/en-us/azure/azure-policy/ for documentation on the Powershell cmdlets and the JSON input formats

param(
    $assignmentName,
    $assignmentDisplayName,
    $assignmentDescription,
    $policyName,
    $policySetName,
    $resourceGroupName,
    $subscriptionId,
    $managementGroupName,
    $policyParameters,
    [string[]]$notManagementGroupName,
    [string[]]$notSubscriptionId,
    [switch]$assignIdentity,
    [string]$location
)


if (!$assignmentName)
{
    throw "Unable to create policy assignment: required input variable value `$(AssignmentName) was not provided"
}

if (!$policyName -and !$policySetName)
{
    throw "Unable to create policy assignment: neither `$(PolicyName) nor `$(PolicySetName) was provided. One or the other must be provided."
}

if ($policyName -and $policySetName)
{
    throw "Unable to create policy assignment: `$(PolicyName) '$policyName' and `$(PolicySetName) '$policySetName' were both provided. Either may be provided, but not both."
}

if ($subscriptionId -and $managementGroupName)
{
    throw "Unable to create policy assignment: `$(SubscriptionId) '$subscriptionId' and `$(ManagementGroupName) '$managementGroupName' were both provided. Either may be provided, but not both."
}

if ($managementGroupName -and $resourceGroupName)
{
    throw "Unable to create policy assignment: `$(ManagementGroupName) '$managementGroupName' and `$(ResourceGroupName) '$resourceGroupName' were both provided. Either may be provided, but not both."
}

# Return the policy assignments and filter for the existing assignment
$existingPolicyAssignment = Get-AzureRmPolicyAssignment | Where-Object { $_.Name -eq $assignmentName }

# Build the default scope (MG, Sub or RG) and set the default search parameters hash table
if ($managementGroupName) {
    $scope = "/providers/Microsoft.Management/managementGroups/$managementGroupName"
    $searchParameters = @{ManagementGroupName=$managementGroupName}
} else {
  # Not a management group but no subscription ID was provided, default to current subscription
    if (!$subscriptionId) {
        write-host "Need to get sub id"
        $subscription = (Get-AzureRmContext).Subscription
        $subscriptionId = $subscription.Id
        write-host "Sub ID is $subscriptionId"
    }

    $scope = "/subscriptions/$subscriptionId"
    $searchParameters = @{SubscriptionId=$subscriptionId}

    # Resource Group name was provided so add to the end of the scope.
    if ($resourceGroupName) {
        $scope += "/resourceGroups/$resourceGroupName"
    }
}

# Get contents of the parameters file and check to see if they are different
If ($policyParameters -and $existingPolicyAssignment) {
    # Load the parameter file contents, convertfrom then back to JSON (can't remember why we did this, but it fixed an issue)
    $paramFileContents = Get-Content "$policyParameters" | ConvertFrom-Json | ConvertTo-Json
    # Get parameters from existing assignment
    $existingParams = $existingPolicyAssignment.Properties.parameters | ConvertTo-Json
    If ($paramFileContents -ne $existingParams) {
        write-host "Params are different"
        $updatedParams = $true
    } else {
        write-host "Params are the same"
        $updatedParams = $false
    }
}

# Check if there is no policy assignment or the parameters need to be updated and update cmdlet parameters accordingly.
If (!$existingPolicyAssignment -or $updatedParams) {
    write-host "Going to need full details for adding a new assignment"
    $cmdletParameters = @{Name=$assignmentName; Scope=$scope}
} else {
    write-host "Only non param updates, only need resource Id"
    $cmdletParameters = @{Id=$existingPolicyAssignment.ResourceId}
}

# Add an assignment display name to the cmdlet parameters if provided
if ($assignmentDisplayName){
    $cmdletParameters += @{DisplayName=$assignmentDisplayName}
}

# Add an assignment description to the cmdlet parameters if provided
if ($assignmentDescription){
    $cmdletParameters += @{Description=$assignmentDescription}
}

# If a policy name has been provided and hasn't been assigned, or the policy name has been provided and has updated parameters, check policy definition exists and add to the cmdlet parameters
if (($policyName -and !$existingPolicyAssignment) -or ($policyName -and $updatedParams)){
    # Get the policy definitions and filter for the policy name providede
    $policyDefinition = Get-AzureRmPolicyDefinition @searchParameters | Where-Object { $_.Name -eq $policyName }
    # If it doesn't exist, throw an error
    if (!$policyDefinition)
    {
        throw "Unable to create policy assignment: policy definition $policyName does not exist"
    }
    # Add the policy definition to the object
    $cmdletParameters += @{PolicyDefinition=$policyDefinition}
}

# If a policyset name has been provided and hasn't been assigned, or the policyset name has been provided and has updated parameters, check policyset definition exists and add to the cmdlet parameters
if (($policySetName -and !$existingPolicyAssignment) -or ($policySetName -and $updatedParams)){
    # Get the policyset definitions and filter for the policy name providede
    $policySetDefinition = Get-AzureRmPolicySetDefinition @searchParameters | Where-Object { $_.Name -eq $policySetName }

    # If it doesn't exist, throw an error
    if (!$policySetDefinition)
    {
        throw "Unable to create policy assignment: policy set definition $policySetName does not exist"
    }

    # Add the policyset definition to the object
    $cmdletParameters += @{PolicySetDefinition=$policySetDefinition}
}

# Build exclusions
$notScope = @()

# If any Management Group names have been provided, add them to the notScope exclusion list
if ($notManagementGroupName) {
    foreach ($group in $notManagementGroupName) {
        $notScope+= "/providers/Microsoft.Management/managementGroups/$group"
    }
}

# If any Subscription ID's have been provided, add them to the notScope exclusion list
if ($notSubscriptionId) {
    foreach ($sub in $notSubscriptionId) {
        $notScope += "/subscriptions/$notSubscriptionId"
    }
}

# If any exclusions were added above, add them to the cmdlet parameter object
If ($notScope) {
    $cmdletParameters += @{NotScope=$notScope}
}

# If we need to assign an identity, add the required parameters to the cmdlet string
if ($assignIdentity){
    $cmdletParameters += @{
        assignIdentity=$true
        Location=$location
    }
}

# Check to see if the assignment exists already
If (!$existingPolicyAssignment) {
    # Doesn't exist, create new policy
    write-host "Policy assignment '$assignmentName' doesn't exist, creating assignment."

    # If policy parameters have been provided, add them to the cmdlet parameters
    if ($policyParameters){
        $cmdletParameters += @{PolicyParameter=$policyParameters}
    }
    # Create a new policy assignment
    &New-AzureRmPolicyAssignment @cmdletParameters

} else {
    # Already exists, update policy using the policy ID and not the name
    write-host "Policy assignment '$assignmentName' already exists, updating assignment."

    # If the parameters haven't changed, just update assignment description etc.
    If (!$updatedParams) {
        write-host "No updates to parameter file, just updating existing assignment without updating parameters"

        # Set the policy definition as we only have updated parameters
        Set-AzureRmPolicyAssignment @cmdletParameters
    } else {
        # Add the parameters to the cmdlet parameters
        if ($policyParameters){
            $cmdletParameters += @{PolicyParameter=$policyParameters}
        }
        # Remove the policy as the parameters file has been updated
        write-host "Removing the policy assignment so we can update the parameters (can't add/remove parameters once it's been assigned)"
        Remove-AzureRmPolicyAssignment -Id $existingPolicyAssignment.ResourceId -confirm:$false

        # Add the policy back with the new parameters
        write-host "Adding assignment back with new parameters"
        New-AzureRmPolicyAssignment @cmdletParameters
    }
}