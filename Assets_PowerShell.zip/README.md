# Assets_PowerShell

This repository is intended to hold standalone PowerShell modules and their associated tests.
These may be consumed as part of the DriveTrain product assemblies, or used by themselves by individual engineers as single-solutions.

## Getting Started

If you've never worked with PowerShell modules before, it may be a good idea to create your own one from scratch in a personal test environment first.

There are many good resources on how to write PowerShell modules, here are some we recommend;

- https://docs.microsoft.com/en-us/powershell/developer/module/understanding-a-windows-powershell-module
- https://docs.microsoft.com/en-us/powershell/developer/module/how-to-write-a-powershell-script-module
- https://powershellexplained.com/2017-05-27-Powershell-module-building-basics/
- https://ramblingcookiemonster.github.io/Building-A-PowerShell-Module/
- https://docs.microsoft.com/en-us/powershell/developer/module/how-to-write-a-powershell-module-manifest
- https://docs.microsoft.com/en-us/powershell/developer/module/writing-help-for-windows-powershell-modules

## Build and Test

It is a requirement for every module included in this repository to include some level of unit test coverage.
For unit tests, this repository uses the [Pester PowerShell Testing Framework](https://github.com/pester/Pester)
A [Build Pipeline](https://dev.azure.com/newsigcode/DriveTrain/_build?definitionId=128&_a=summary) is configured on this repository to ensure no PRs to master will complete if the associated tests do not pass.

To build this repository locally, please run .\CI\localbuild.ps1 from the repo root.

## Contribute

We welcome contributions from *anybody* into this repository.
To ensure that the repository contains good-quality modules, to make a contribution you will need to make a *pull request* from a branch that you have created. This ensures that the contents of the repository have been peer-reviewed.

As above, please ensure you are including some level of basic unit tests with your PowerShell module.

## Legal
Please note the contents of the .LICENSE file stored in this repository.

It is required that a Master Services Agreement (MSA) is in place between New Signature and any customer where Drivetrain is used.

Please ensure that any code you contribute is either your own work, released under a permissive (non-copyleft) licence, or has been developed on a customer engagement where a Master Services Agreement is in place.

If you have any questions or queries about this, please contact legal@newsignature.com.

### Using Git

If you are unfamiliar with Git, or you do not understand how to create a pull request or git branch, the following references may be helpful for you if you are new to Git source control.

- https://git-scm.com/videos
- https://docs.microsoft.com/en-us/azure/devops/repos/git/gitworkflow?view=azure-devops

If you are still stuck after reviewing the above, message the Platform Services team in the Drivetrain Teams -> General Channel and someone will be happy to walk you through how to get started.

### Repo Structure

Scripts that aren't specifically used by Drivetrain deployments should be stored in the "GeneralScripts" folder. Scripts are then group into subfolders containing the area the are related to (e.g. Compute, Network etc.). Create subfolders as required.