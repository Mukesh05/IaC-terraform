Using Module ..\lib_pwsh\Helpers.psm1

Describe "Landing Zone Class" {
    InModuleScope Helpers {
        Context 'Class Inheritance' {
            It 'checks that LandingZone inherits from Common' {
                $Parameters = [LandingZone]::new()
                $Parameters.AzureTenant -is [AzureTenant] | Should Be $true
                $Parameters.ResourceGroupName | Should Be ''
                $Parameters.ManualSelection | Should Be $false
            }
        }
        Context "Showing Summary of current install Q&A" {
            It "displays the summary with no additional lines, if no properties are set." {
                Mock Write-Host -ParameterFilter { $Object -eq "This installs LaunchPad Essentials: A single VNet into a single resource group, with a 2-controller new Active Directory Forest,  Bastion VM for remote access, VPN gateway, as well as installing governance elements." }
                Mock Write-Host -ParameterFilter { $Object -eq "" }

                $controlParameters = [LandingZone]::new()
                $controlParameters.AzureTenant.Id = ''
                $controlParameters.ShowSummary()

                Assert-MockCalled Write-Host -ParameterFilter { $Object -eq "" } -Exactly 4 -Scope It
            }
            It "displays the tenants name if the tenant parameter has been set" {
                Mock Write-Host -ParameterFilter { $Object -eq "This installs LaunchPad Essentials: A single VNet into a single resource group, with a 2-controller new Active Directory Forest,  Bastion VM for remote access, VPN gateway, as well as installing governance elements." }
                Mock Write-Host -ParameterFilter { $Object -eq "Deploying to the Tenancy - Azure Context" }
                Mock Write-Host -ParameterFilter { $Object -eq "" }

                $controlParameters = [LandingZone]::new()
                $controlParameters.AzureTenant.Id = "Azure Context"
                $controlParameters.AzureTenant.Name = "Azure Context"
                $controlParameters.ShowSummary()

                Assert-MockCalled Write-Host -ParameterFilter { $Object -eq "Deploying to the Tenancy - Azure Context" } -Exactly 1 -Scope It
                Assert-MockCalled Write-Host -ParameterFilter { $Object -eq "" } -Exactly 4 -Scope It
            }
        }
        Context "Requesting confirmation that entered information IsVvalid" {
            It 'returns true if no data is flagged a entered by the user.' {
                Mock Read-Host
                $controlParameters = [LandingZone]::new()
                $controlParameters.ManualSelection = $false
                $controlParameters.IsValid() | Should Be $true
                Assert-MockCalled Read-Host -Exactly 0 -Scope It
            }
            It "prompts the user to confirm the options selected are valid" {
                Mock Read-Host {return 'Y'}
                Mock Write-Host
                $controlParameters = [LandingZone]::new()
                $controlParameters.ManualSelection = $true
                $controlParameters.IsValid() | Should Be $true
                Assert-MockCalled Write-Host -ParameterFilter { $Object -eq "" } -Exactly 4 -Scope It
                Assert-MockCalled Read-Host -Exactly 1 -Scope It
            }
            It "resets all fields if the user replies 'N' to the prompt" {
                Mock Read-Host {return 'N'}
                Mock Write-Host
                $controlParameters = [LandingZone]::new()
                $controlParameters.ManualSelection = $true
                $controlParameters.AzureTenant.Id = "Azure Context"
                $controlParameters.AzureSubscriptionId = "Azure Context"
                $controlParameters.ActiveDirectory.AdminUser = "Azure Context"
                $controlParameters.ActiveDirectory.AdminPassword = ConvertTo-SecureString -String 'Azure Context' -AsPlainText -Force
                $controlParameters.IsValid() | Should Be $false
                $controlParameters.AzureTenant.Id | Should Be ''
                $controlParameters.AzureSubscriptionId | Should Be ''
                $controlParameters.ActiveDirectory.AdminUser | Should Be ''
                $controlParameters.ActiveDirectory.AdminPassword | Should Be $null
                Assert-MockCalled Write-Host -ParameterFilter { $Object -eq "" } -Exactly 4 -Scope It
                Assert-MockCalled Read-Host -Exactly 1 -Scope It
            }
        }
    }
}