#Requires -Version 5.1
Using Module ..\lib_pwsh\Helpers.psm1

Import-Module -Name ..\lib_pwsh\Instrumentation.psm1 -Force
Import-Module -Name ..\lib_pwsh\UserInterface.psm1 -Force

Class LandingZoneTest : LandingZone {
  ShowSummary() { }
}

InModuleScope -ModuleName UserInterface {

  Describe 'Show-Menu Function' {
    It 'displays a Menu with the specified Title' {
      Mock Write-Host
      Show-Menu
    }
  }

  Describe 'Clear-Scrollback' {
    BeforeEach {
      $VerbosePreference = "SilentlyContinue"
      $DebugPreference = "SilentlyContinue"
    }
    It 'Does not call Clear-Host if the Verbose preference is set to Continue' {
      Mock Clear-Host
      Clear-Scrollback -Verbose
      Assert-MockCalled Clear-Host -Times 0 -Scope It
    }
    It 'Does not call Clear-Host if the Debug preference is set to Inquire' {
      Mock Clear-Host
      Clear-Scrollback -Debug
      Assert-MockCalled Clear-Host -Times 0 -Scope It
    }
    It 'Calls Clear-Host if the Verbose preference is set to SilentlyContinue' {
      Mock Clear-Host
      Clear-Scrollback
      Assert-MockCalled Clear-Host -Times 1 -Scope It
    }
    It 'Calls Clear-Host the Debug preference is set to SilentlyContinue' {
      Mock Clear-Host
      Clear-Scrollback
      Assert-MockCalled Clear-Host -Times 1 -Scope It
    }
  }

  Describe 'Get-ActiveDirectory Function' {
    Context 'Getting Active Directory information for a new AD forest' {
      It 'does not prompt the user to enter AD information if the information has already been set' {
        $Parameters = [LandingZone]::new()
        $Parameters.ActiveDirectory.DomainName = "Azure Context"
        $Parameters.ActiveDirectory.AdminUser = "Azure Context"
        $Parameters.ActiveDirectory.AdminPassword = ConvertTo-SecureString -String "Azure Context" -AsPlainText -Force
        Get-ActiveDirectory -controlParameters $Parameters
        $Parameters.ManualSelection | Should Be $false
      }
      It 'prompts the user to enter AD Domain Name if the information has not already been set' {
        $Parameters = [LandingZoneTest]::new()
        $Parameters.ActiveDirectory.AdminUser = "Azure Context"
        $Parameters.ActiveDirectory.AdminPassword = ConvertTo-SecureString -String "Azure Context" -AsPlainText -Force
        Mock Clear-Scrollback
        Mock Write-Host
        Mock Read-Host { return 'Azure Context' }
        Get-ActiveDirectory -controlParameters $Parameters
        Assert-MockCalled Clear-Scrollback -Exactly 1 -Scope It
        Assert-MockCalled Read-Host -Exactly 1 -Scope It
        $Parameters.ActiveDirectory.DomainName | Should Be 'Azure Context'
        $Parameters.ManualSelection | Should Be $true
      }
    }
    Context 'Getting Active Directory information for an existing AD forest' {

    }
  }

  Describe 'Get-AzureSubscription Function' {
    It 'does not as the user to select a subscription if the subscription has already been set' {
      $AzureTenant1 = @{
        displayname = "Azure Context"
        tenantId    = "Azure Context"
      }
      $AzureTenant2 = @{
        displayname = "Azure Context1"
        tenantId    = "Azure Context1"
      }

      $AzureTenants = @(
        $AzureTenant1
        $AzureTenant2
      )

      Mock Get-AzTenantListfromREST { return $AzureTenants }
      Mock Get-AzSubscription { return @{
          Id          = "Azure Context"
          displayname = "Azure Context1"
          tenantId    = "Azure Context1"
        }
      }
      $Parameters = [ControlParameters]::new()
      $Parameters.AzureSubscriptionId = "Azure Context"
      Get-AzureSubscription -controlParameters $Parameters
      $Parameters.ManualSelection | Should Be $false
    }
    It 'asks the user to select a tenant if the subscription has not already been set' {
      $AzureSubscription1 = @{
        Name           = "Azure Context"
        SubscriptionId = "Azure Context"
      }
      $AzureSubscription2 = @{
        Name           = "Azure Context1"
        SubscriptionId = "Azure Context1"
      }

      $AzureSubscriptions = @(
        $AzureSubscription1
        $AzureSubscription2
      )

      Mock Get-AzSubscription { return $AzureSubscriptions }
      Mock Clear-Scrollback
      Mock Show-Menu
      Mock Read-Host { return 1 }
      $Parameters = [ControlParameters]::new()

      Get-AzureSubscription -controlParameters $Parameters
      Assert-MockCalled Show-Menu -Exactly 1 -Scope It
      $Parameters.AzureSubscriptionName | Should Be "Azure Context"
      $Parameters.AzureSubscriptionId | Should Be "Azure Context"
      $Parameters.ManualSelection | Should Be $true
    }
  }

  Describe 'Get-AzureTenant Function' {
    It 'does not ask the user to select a tenant if the subscription has already been set' {
      $AzureTenant1 = @{
        displayname = "Azure Context"
        tenantId    = "Azure Context"
      }
      $AzureTenant2 = @{
        displayname = "Azure Context1"
        tenantId    = "Azure Context1"
      }

      $AzureTenants = @(
        $AzureTenant1
        $AzureTenant2
      )

      Mock Get-AzTenantListfromREST { return $AzureTenants }
      Mock Get-AzSubscription { return @{
          Id          = "Azure Context"
          displayname = "Azure Context1"
          tenantId    = "Azure Context1"
        }
      }
      $Parameters = [ControlParameters]::new()
      $Parameters.AzureSubscriptionId = "Azure Context"
      Get-AzureTenant -controlParameters $Parameters
      $Parameters.ManualSelection | Should Be $false
    }
    It 'asks the user to select a tenant if the subscription has not already been set' {
      $AzureTenant1 = @{
        displayname = "Azure Context"
        tenantId    = "Azure Context"
      }
      $AzureTenant2 = @{
        displayname = "Azure Context1"
        tenantId    = "Azure Context1"
      }

      $AzureTenants = @(
        $AzureTenant1
        $AzureTenant2
      )

      Mock Get-AzTenantListfromREST { return $AzureTenants }
      Mock Clear-Scrollback
      Mock Show-Menu
      Mock Read-Host { return 1 }
      $Parameters = [ControlParameters]::new()

      Get-AzureTenant -controlParameters $Parameters
      Assert-MockCalled Show-Menu -Exactly 1 -Scope It
      $Parameters.AzureTenant.Name | Should Be "Azure Context"
      $Parameters.AzureTenant.Id | Should Be "Azure Context"
      $Parameters.ManualSelection | Should Be $true
    }
  }

  Describe 'Get-ResourceGroupName Function' {
    It 'does not ask the user to enter a resource group if the resource group has already been set' {
      $Parameters = [ControlParameters]::new()
      $Parameters.ResourceGroupName = "Azure Context"
      Get-ResourceGroupName -controlParameters $Parameters
      $Parameters.ManualSelection | Should Be $false
    }
    It 'does ask the user to enter a resource group if the resource group has not already been set' {
      Mock Clear-Scrollback
      Mock Read-Host { return "Azure Context" }
      $Parameters = [ControlParameters]::new()
      Get-ResourceGroupName -controlParameters $Parameters
      $Parameters.ResourceGroupName | Should Be "Azure Context"
      $Parameters.ManualSelection | Should Be $true
    }
  }

  Describe 'Get-MultiSelectionOptionFromUser function' {
    It 'returns the first item of the list when that item number is selected by the user' {
      $options = @('first','second','third')

      $title = "selection from first second and third"

      Mock Clear-Scrollback
      Mock Show-Menu

      Mock Read-Host { return 1 } -Verifiable

      $result = Get-MultiSelectionOptionFromUser -Title $title -Options $options

      $result | Should Be 'first'
    }
    It 'returns the last item of the list when that item number is selected by the user' {
      $options = @('first','second','third')

      $title = "selection from first second and third"

      Mock Clear-Scrollback
      Mock Show-Menu

      Mock Read-Host { return 3 } -Verifiable

      $result = Get-MultiSelectionOptionFromUser -Title $title -Options $options

      $result | Should Be 'third'
    }
    It 'returns the second item of the list when that item number is selected by the user, after reprompting for input past end' {
      $options = @('first','second','third')
      $title = "selection from first second and third"

      Mock Clear-Scrollback
      Mock Show-Menu

      $script:ReadHostMockCallCount = 0;

      Mock Read-Host {
        if ($script:ReadHostMockCallCount -eq 0) {
          $script:ReadHostMockCallCount += 1
          return 4 # first call returns 4
        } else {
          $script:ReadHostMockCallCount += 1
          return 2 # subsequent call returns 2
        }
      } -Verifiable

      $result = Get-MultiSelectionOptionFromUser -Title $title -Options $options

      $result | Should Be 'second'
      $script:ReadHostMockCallCount | Should Be 2
      Assert-VerifiableMock
    }
  }
}