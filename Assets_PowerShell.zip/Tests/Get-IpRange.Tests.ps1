[cmdletbinding()]
Param(
  [string] $SourceFolder = "$PSScriptRoot\..\lib_pwsh"
)
#Import Modules
Import-Module -Name "$($SourceFolder)\Get-IpRange" -Force

# Pester tests
Describe 'Get-IpRange' {
  It "Returns an object describing the range 172.16.0.0/22" {
    $range = Get-IpRange -ip 172.16.0.0 -maskbits 22
    $range.start | Should -Be '172.16.0.0'
    $range.end | Should -Be '172.16.3.255'
    $range.mask | Should -Be '255.255.252.0'
    $range.broadcast | Should -Be '172.16.3.255'
    $range.network | Should -Be '172.16.0.0'
    $range.cidr | Should -Be '172.16.0.0/22'
    $range.next | Should -Be '172.16.4.0'
    $range.maskbits | Should -Be 22
  }

  It "Returns an object describing the range 172.16.0.0 mask 255.255.252.0" {
    $range = Get-IpRange -ip 172.16.0.0 -mask 255.255.252.0
    $range.start | Should -Be '172.16.0.0'
    $range.end | Should -Be '172.16.3.255'
    $range.mask | Should -Be '255.255.252.0'
    $range.broadcast | Should -Be '172.16.3.255'
    $range.network | Should -Be '172.16.0.0'
    $range.cidr | Should -Be '172.16.0.0/22'
    $range.next | Should -Be '172.16.4.0'
    $range.maskbits | Should -Be 22
  }

  It "Returns an object describing the range -start '172.16.0.0' -end '172.16.3.255'" {
    $range = Get-IpRange -start 172.16.0.0 -end 172.16.3.255
    $range.start | Should -Be '172.16.0.0'
    $range.end | Should -Be '172.16.3.255'
    $range.mask | Should -Be '255.255.252.0'
    $range.broadcast | Should -Be '172.16.3.255'
    $range.network | Should -Be '172.16.0.0'
    $range.cidr | Should -Be '172.16.0.0/22'
    $range.next | Should -Be '172.16.4.0'
    $range.maskbits | Should -Be 22
  }

  It "Returns an object describing the range -cidr '172.16.0.0/22'" {
    $range = Get-IpRange -cidr '172.16.0.0/22'
    $range.start | Should -Be '172.16.0.0'
    $range.end | Should -Be '172.16.3.255'
    $range.mask | Should -Be '255.255.252.0'
    $range.broadcast | Should -Be '172.16.3.255'
    $range.network | Should -Be '172.16.0.0'
    $range.cidr | Should -Be '172.16.0.0/22'
    $range.next | Should -Be '172.16.4.0'
    $range.maskbits | Should -Be 22
  }
}

Describe 'Split-IpRange' {
  It 'returns two networks when asked to split a range into two parts' {
    $parts = Split-IpRange -start '192.168.1.0' -maskbits 24 -segments 2
    $parts.Count | Should -Be 2

    $parts[0].start | Should -Be '192.168.1.0'
    $parts[0].mask | Should -Be '255.255.255.128'

    $parts[1].start | Should -Be '192.168.1.128'
    $parts[1].mask | Should -Be '255.255.255.128'
  }
  It 'throws an exception when the mask plus segments are invalid' {
    { Split-IpRange -start '192.168.1.0' -maskbits 31 -segments 4 } | Should -Throw
  }
  It 'throws an exception when the segments value is not in the 2 power series' {
    { Split-IpRange -start '192.168.1.0' -maskbits 22 -segments 3 } | Should -Throw
  }
  It 'returns four networks when asked to split a range into four parts' {
    $parts = Split-IpRange -start '192.168.1.0' -maskbits 24 -segments 4
    $parts.Count | Should -Be 4

    $parts[0].start | Should -Be '192.168.1.0'
    $parts[0].end | Should -Be '192.168.1.63'
    $parts[0].mask | Should -Be '255.255.255.192'

    $parts[1].start | Should -Be '192.168.1.64'
    $parts[1].mask | Should -Be '255.255.255.192'
    $parts[1].end | Should -Be '192.168.1.127'

    $parts[2].start | Should -Be '192.168.1.128'
    $parts[2].mask | Should -Be '255.255.255.192'
    $parts[2].end | Should -Be '192.168.1.191'

    $parts[3].start | Should -Be '192.168.1.192'
    $parts[3].mask | Should -Be '255.255.255.192'
    $parts[3].end | Should -Be '192.168.1.255'
  }
}

Describe 'Get-MaskBitsSet' {
  It 'returns 2 when given 3' {
    Get-MaskBitsSet -int 3 | Should -Be 2
  }
  It 'returns 0 when given 0' {
    Get-MaskBitsSet -int 0 | Should -Be 0
  }
}

Describe "Test-CidrValidation" {
  It 'returns True for valid cidr value' {
    Test-CidrValidation -cidr '1.1.1.1/1' | Should -Be $true
  }
  It 'returns True for valid cidr value' {
    Test-CidrValidation -cidr '10.0.0.0/16' | Should -Be $true
  }
  It 'returns False for invalid cidr value' {
    Test-CidrValidation -cidr '1000.12.28' | Should -Be $false
  }
  It 'returns False for invalid CIDR value' {
    Test-CidrValidation -cidr '14.214196.8./100' | Should -Be $false
  }
}
