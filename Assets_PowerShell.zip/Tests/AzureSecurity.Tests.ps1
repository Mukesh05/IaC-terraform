Import-Module -Name "$($PSScriptRoot)\..\lib_pwsh\Instrumentation.psm1" -Force
Import-Module -Name "$($PSScriptRoot)\..\lib_pwsh\AzureSecurity.psm1" -Force

Describe "Set-SecurityProviderRegistration" {
  InModuleScope -ModuleName AzureSecurity {
    It "Throws an error if there is no AzContext" {
      Mock Get-AzContext -MockWith { return $null } -ModuleName AzureSecurity
      { Set-SecurityProviderRegistration } | Should throw
    }
    It "Acts correctly if the providers are already registered" {
      Mock Get-AzContext -MockWith { return $true } -ModuleName AzureSecurity
      Mock Get-AzResourceProvider -ModuleName AzureSecurity -MockWith {
        return @(
          [PSCustomObject]@{
            ProviderNamespace = "Microsoft.Security";
            RegistrationState = "Registered"
          },
          [PSCustomObject]@{
            ProviderNamespace = "Microsoft.PolicyInsights";
            RegistrationState = "Registered"
          }
        )
      }
      Set-SecurityProviderRegistration
    }
  }
}

Describe 'Set-JustInTime' {
  BeforeEach {
    $VerbosePreference = "SilentlyContinue"
    $DebugPreference = "SilentlyContinue"
  }
  InModuleScope -ModuleName AzureSecurity {
    It "Calls Get-SecurityModule" {
      Mock Get-SecurityModule -ModuleName AzureSecurity -Verifiable
      Mock Get-AzResource -MockWith { return [PSCustomObject]@{
          Location          = "UKSouth";
          ResourceGroupName = "test";
          Name              = "test"
          ID                = "test"
        }
      } -ModuleName AzureSecurity
      Mock Set-AzJitNetworkAccessPolicy -Verifiable -ModuleName AzureSecurity
      Set-JustInTime -vmID "test"
      Assert-VerifiableMock
    }
    It "Throws an error when it can't find the VM" {
      Mock Get-AzResource -MockWith { return $null }  -ModuleName AzureSecurity
      { Set-JustInTime -vmID "test" } | Should Throw
    }
    It 'Calls Set-AzJitNetworkAccessPolicy when correct input is provided' {
      Mock Get-AzResource -MockWith { return [PSCustomObject]@{
          Location          = "UKSouth";
          ResourceGroupName = "test";
          Name              = "test"
          ID                = "test"
        } } -Verifiable -ModuleName AzureSecurity
      Mock Set-AzJitNetworkAccessPolicy -Verifiable -ModuleName AzureSecurity
      Set-JustInTime -vmID "test"
      Assert-VerifiableMock
    }
  }
}
