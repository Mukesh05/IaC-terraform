Using module ..\lib_pwsh\Instrumentation.psm1

Describe 'telemetryClient Class' {
  It 'Checks that the telemetryClient can be initialised' {
    $telemetryClient.client | Should -Not -Be $null
    $telemetryClient.connected | Should -Be $true
  }
  It 'Checks that a trace message can be sent' {
    $telemetryClient.sendTrace("Pester Testing")
  }
  It 'Checks that a event message can be sent' {
    $telemetryClient.sendEvent("Pester Testing")
  }
  It 'Checks that a exception message can be sent' {
    $telemetryClient.sendError([exception]$exception)
  }
}

Describe 'Messaging Functions' {
  InModuleScope Instrumentation {
    It 'Checks that Send-Error runs without issue' {
      Mock Write-Error -Verifiable
      Send-Error -Message "Testing" -Exception [exception]$exception
      Assert-MockCalled Write-Error -Times 1
    }
    It 'Checks that Send-Trace runs without issue' {
      Send-Trace -Message "Testing"
    }
    It 'Checks that Send-Event runs without issue' {
      Send-Event -Message "Testing"
    }
    It 'Checks that Send-Event -WriteOutput writes Output' {
      Mock -CommandName Write-Output
      Send-Event -WriteOutput -Message "Testing"
      Assert-MockCalled -CommandName Write-Output -Times 1
    }
  }
}

Describe 'Getting the App Insights Session Information' {
  InModuleScope Instrumentation {
    It 'checks that Get-SessionId returns a value if telemetry client is connected' {
      Get-SessionId | Should -Not -Be $null
    }
  }
}