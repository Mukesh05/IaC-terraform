Import-Module -Name "Az.Accounts" -Force
Import-Module -Name "Az.Resources" -Force
Import-Module -Name "$($PSScriptRoot)\..\lib_pwsh\Instrumentation.psm1" -Force
Import-Module -Name "$($PSScriptRoot)\..\lib_pwsh\AzureGeneral.psm1" -Force

Class Context {
  [String] $Name
}

$global:GetAzContextCalled = 0
$global:Context = [Context]::new()
$global:Context.Name = 'AzureContext'

InModuleScope -ModuleName AzureGeneral {
  Describe 'Connect-Azure' {
    It 'does not call Connect-AzAccount if the Azure context already exists' {
      Mock Connect-AzAccount { }
      Mock Get-AzContext { return $global:Context }
      Mock Send-Trace -ParameterFilter { $Message -eq 'Connect to Azure' }
      Connect-Azure
      Assert-MockCalled Connect-AzAccount -Exactly 0 -Scope It
      Assert-MockCalled Send-Trace -Exactly 1 -Scope It
    }
    It 'throws and exception if the call to Connect-AzAccount does not result in a AzContext' {
      Mock Connect-AzAccount { }
      Mock Get-AzContext { Return $null }
      Mock Send-Trace -ParameterFilter { $Message -eq 'Connect to Azure' }
      { Connect-Azure } | Should Throw "Unable to get Azure Context."
      Assert-MockCalled Get-AzContext -Exactly 2 -Scope It
      Assert-MockCalled Connect-AzAccount -Exactly 1 -Scope It
      Assert-MockCalled Send-Trace -Exactly 1 -Scope It
    }

    It 'calls Connect-AzAccount if the Azure context does not exist' {
      Mock Connect-AzAccount { }
      $global:GetAzContextCalled = 0
      Mock Get-AzContext { If ($global:GetAzContextCalled -eq 0) { $global:GetAzContextCalled = 1; Return $null } Else { Return $global:Context } }
      Mock Send-Trace -ParameterFilter { $Message -eq 'Connect to Azure' }
      Connect-Azure
      Assert-MockCalled Connect-AzAccount -Exactly 1 -Scope It
      Assert-MockCalled Send-Trace -Exactly 1 -Scope It
    }
  }

  Describe "Get-ManagementGroupChildNodes" {
    $responseNoDecendants = ConvertFrom-Json '[ ]'
    $responseMultipleSubscriptions = ConvertFrom-Json '[
                                    {
                                      "name":  "9c636c18-61e5-4590-9eaa-a67cf09f42d4",
                                      "id":  "/subscriptions/9c636c18-61e5-4590-9eaa-a67cf09f42d4",
                                      "type":  "/subscriptions"
                                    },
                                    {
                                      "name":  "9c636c18-61e5-4590-9eaa-a67cf09f42d4",
                                      "id":  "/subscriptions/9c636c18-61e5-4590-9eaa-a67cf09f42d4",
                                      "type":  "/subscriptions"
                                    },
                                    {
                                      "name": "IntegrationTesting",
                                      "id": "/providers/Microsoft.Management/managementGroups/IntegrationTesting",
                                      "type": "/providers/Microsoft.Management/managementGroups"
                                    }
                                  ]'
    $responseMultipleManagementGroups = ConvertFrom-Json '[
                                    {
                                      "name":  "9c636c18-61e5-4590-9eaa-a67cf09f42d4",
                                      "id":  "/subscriptions/9c636c18-61e5-4590-9eaa-a67cf09f42d4",
                                      "type":  "/subscriptions"
                                    },
                                    {
                                      "name": "IntegrationTesting",
                                      "id": "/providers/Microsoft.Management/managementGroups/IntegrationTesting",
                                      "type": "/providers/Microsoft.Management/managementGroups"
                                    },
                                    {
                                      "name": "IntegrationTesting",
                                      "id": "/providers/Microsoft.Management/managementGroups/IntegrationTesting",
                                      "type": "/providers/Microsoft.Management/managementGroups"
                                    }
                                  ]'
    It "throws an exception if an error object is returned" {
      Mock Send-Trace -ParameterFilter { $Message -eq "Get-ManagementGroupChildNodes" }
      Mock Invoke-GetRestMethod { Throw "An Error has occured" }

      { Get-ManagementGroupChildNodes } | Should Throw "An Error has occured"
      Assert-MockCalled Send-Trace -Scope It -Exactly 1
    }
    It "returns an empty array if the management group has no decendants" {
      Mock Send-Trace -ParameterFilter { $Message -eq "Get-ManagementGroupChildNodes" }
      Mock Invoke-GetRestMethod { return $responseNoDecendants }

      (Get-ManagementGroupChildNodes -ManagementGroupId "DriveTrain").count | Should Be 0
      Assert-MockCalled Send-Trace -Scope It -Exactly 1
    }
    It "returns both management group and subscription nodes if only passed a management group id" {
      Mock Send-Trace -ParameterFilter { $Message -eq "Get-ManagementGroupChildNodes" }
      Mock Invoke-GetRestMethod { return $responseMultipleSubscriptions }

      (Get-ManagementGroupChildNodes -ManagementGroupId "DriveTrain").count | Should Be 3
      Assert-MockCalled Send-Trace -Scope It -Exactly 1
    }
    It "returns both management group and subscription nodes if passed a management group id and the subscription and management group switch" {
      Mock Send-Trace -ParameterFilter { $Message -eq "Get-ManagementGroupChildNodes" }
      Mock Invoke-GetRestMethod { return $responseMultipleSubscriptions }

      (Get-ManagementGroupChildNodes -ManagementGroupId "DriveTrain").count | Should Be 3
      Assert-MockCalled Send-Trace -Scope It -Exactly 1
    }
    It "returns only subscription nodes if passed a management group id and the subscription switch" {
      Mock Send-Trace -ParameterFilter { $Message -eq "Get-ManagementGroupChildNodes" }
      Mock Invoke-GetRestMethod { return $responseMultipleSubscriptions }

      (Get-ManagementGroupChildNodes -ManagementGroupId "DriveTrain" -Subscriptions).count | Should Be 2
      Assert-MockCalled Send-Trace -Scope It -Exactly 1
    }
    It "returns only management group nodes if passed a management group id and the management group switch" {
      Mock Send-Trace -ParameterFilter { $Message -eq "Get-ManagementGroupChildNodes" }
      Mock Invoke-GetRestMethod { return $responseMultipleSubscriptions }

      (Get-ManagementGroupChildNodes -ManagementGroupId "DriveTrain" -ManagementGroups).count | Should Be 1
      Assert-MockCalled Send-Trace -Scope It -Exactly 1
    }
    It "returns only management group nodes if passed a management group id and the management group switch and there are multiple management group decendants" {
      Mock Send-Trace -ParameterFilter { $Message -eq "Get-ManagementGroupChildNodes" }
      Mock Invoke-GetRestMethod { return $responseMultipleManagementGroups }

      (Get-ManagementGroupChildNodes -ManagementGroupId "DriveTrain" -ManagementGroups).count | Should Be 2
      Assert-MockCalled Send-Trace -Scope It -Exactly 1
    }
  }

  Describe "Set-ResourceProviders" {
    It "Acts correctly if the providers are already registered" {
      $VerbosePreference = Continue
      Mock Register-AzResourceProvider
      Mock Get-AzResourceProvider -ModuleName AzureGeneral -MockWith {
        return @(
          [PSCustomObject]@{
            ProviderNamespace = "Microsoft.Security";
            RegistrationState = "Registered"
          },
          [PSCustomObject]@{
            ProviderNamespace = "Microsoft.PolicyInsights";
            RegistrationState = "Registered"
          }
        )
      }
      Set-ResourceProviders -ResourceProviders @("Microsoft.OperationsManagement",
        "Microsoft.PolicyInsights",
        "Microsoft.Security"
      )

      Assert-MockCalled Register-AzResourceProvider -Scope It -Exactly 0
    }
    It "Attempts to register, then throws correctly if the providers do not register properly" {
      $VerbosePreference = Continue
      Mock Get-AzResourceProvider -ModuleName AzureGeneral -MockWith {
        return @(
          [PSCustomObject]@{
            ProviderNamespace = "Microsoft.Security";
            RegistrationState = "NotRegistered"
          },
          [PSCustomObject]@{
            ProviderNamespace = "Microsoft.PolicyInsights";
            RegistrationState = "NotRegistered"
          }
        )
      }
      Mock Register-AzResourceProvider -ModuleName AzureGeneral -MockWith {
        return $true
      }

      {
        Set-ResourceProviders -Retries 1 -SecondsDelay 1 `
          -ResourceProviders @("Microsoft.OperationsManagement",
          "Microsoft.PolicyInsights",
          "Microsoft.Security"
        ) -ErrorAction Stop
      } | Should Throw "Unable to confirm all the resource providers are registered, please check manually and re-run the install."

      Assert-MockCalled Register-AzResourceProvider -Scope It -Exactly 2
    }
  }
}