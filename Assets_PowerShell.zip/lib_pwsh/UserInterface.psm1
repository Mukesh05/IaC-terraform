#Requires -Version 5.1
#Requires -Modules Instrumentation, AzureGeneral
Using Module .\Helpers.psm1

Function Clear-Scrollback {
  [CmdletBinding()]
  Param ( )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    If (-not (($DebugPreference -eq "Inquire") -or ($VerbosePreference -eq "Continue"))) {
      Clear-Host
    }
  }
  End {
  }
}

Function Get-VmCredential {
  [CmdletBinding()]
  Param (
    [AdvancedLandingZoneHub] $controlParameters,
    [string] $Message
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    If (([String]::IsNullOrEmpty($controlParameters.VmAdminUserName)) `
        -or ($null -eq $controlParameters.VmAdminPassword)) {
      Clear-Scrollback
      $cred = Get-Credential -Message $Message
      $controlParameters.VmAdminUserName = $cred.UserName
      $controlParameters.VmAdminPassword = $cred.Password
      $controlParameters.ManualSelection = $true
    }
  }
  End {
  }
}

Function Get-VpnConnectionDetails {
  [CmdletBinding()]
  Param (
      [Parameter()]
      [AdvancedLandingZoneHub] $controlParameters,
      [Parameter()]
      [string[]] $vpnSkuOptions = ("Basic,Standard,HighPerformance,UltraPerformance," + `
                                   "VpnGw1,VpnGw2,VpnGw3,VpnGw4,VpnGw5," + `
                                   "VpnGw1AZ,VpnGw2AZ,VpnGw3AZ,VpnGw4AZ,VpnGw5AZ," + `
                                   "ErGw1AZ,ErGw2AZ,ErGw3AZ".Split(','))
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    # flag invalid configuration
    if ([String]::IsNullOrEmpty($controlParameters.GatewaySKU) `
        -or [String]::IsNullOrEmpty($controlParameters.GatewayPreSharedKey) `
        -or [String]::IsNullOrEmpty($controlParameters.RemoteGatewayIpAddress) `
        -or [String]::IsNullOrEmpty($controlParameters.RemoteNetworkCIDR))
    {
      # ask first - if we want to deploy one - we need to collect more info
      Clear-Scrollback
      $yesOrNo = (Read-Host -Prompt "Add a VPN Gateway to your deployment? (Y/N)")
      $controlParameters.ShouldDeployVpnGateway = ('y' -eq $yesOrNo.ToLowerInvariant())

      if($controlParameters.ShouldDeployVpnGateway) {
        # collect all the other details if we need the gateway - don't bother if not.

        $controlParameters.GatewaySKU = Get-MultiSelectionOptionFromUser -Title "Select VPN Gateway SKU" `
                                                                         -Options $vpnSkuOptions

        Clear-Scrollback
        $controlParameters.GatewayPreSharedKey = (Read-Host -Prompt "Enter VPN Pre-Shared Key")
        Clear-Scrollback
        $controlParameters.RemoteGatewayIpAddress = (Read-Host -Prompt "Public IP address of On-Premise VPN appliance")
        Clear-Scrollback
        $controlParameters.RemoteNetworkCIDR = (Read-Host -Prompt "On-Premise IP network CIDRs as comma separated list").Split(',')
      }

      $controlParameters.ManualSelection = $true
    }
  }
  End { }
}

Function Get-BastionHostDetails {
  [CmdletBinding()]
  Param (
      [Parameter()]
      [AdvancedLandingZoneHub] $controlParameters,
      [HashTable] $recommendations = @{
        BastionVmSize = @("Standard_B2s", "Standard_D2_v3", "Standard_D2_v2");
        BastionOsVersion = @('2019-Datacenter', '2016-Datacenter');
      }
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet `
                         -SessionState $ExecutionContext.SessionState
  }
  Process {
    # flag invalid configuration and prompt user
    if ([string]::IsNullOrEmpty($controlParameters.BastionVmSize) -or `
        [string]::IsNullOrEmpty($controlParameters.BastionOsVersion))
    {
      $controlParameters.BastionVmSize = Get-MultiSelectionOptionFromUser `
                                                        -Title "Select Bastion Host VM Size/SKU" `
                                                        -Options $recommendations['BastionVmSize']

      $controlParameters.BastionOsVersion = Get-MultiSelectionOptionFromUser `
                                                        -Title "Select Bastion Host VM OS" `
                                                        -Options $recommendations['BastionOsVersion']

      $controlParameters.ManualSelection = $true
    }
  }
  End { }
}

Function Get-MultiSelectionOptionFromUser {
  [CmdletBinding()]
  param (
    [string] $Title,
    [string[]] $Options
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    [string] $selectedItemValue = [string]::Empty
    do {
      Clear-Scrollback

      Show-Menu -Title $Title -Options $Options
      $selection = -1 # invalid if parsing fails on next line
      [int]::TryParse((Read-Host -Prompt "Please make a selection"), [ref] $selection) |Out-Null
      $selection--

      if ($selection -ge 1 -or $selection -le $options.Count) {
        $selectedItemValue = $options[$selection]
      }
    } while ([string]::IsNullOrEmpty($selectedItemValue))

    return $selectedItemValue
  }
  End { }
}

Function Get-EnvironmentCode {
  [CmdletBinding()]
  Param (
    [AdvancedLandingZoneHub] $controlParameters
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet `
                         -SessionState $ExecutionContext.SessionState
  }
  Process {
    if ([String]::IsNullOrEmpty($controlParameters.EnvironmentCode))
    {
      $controlParameters.EnvironmentCode = (Read-Host -Prompt "Please enter an environment id code")

      $controlParameters.ManualSelection = $true
    }
  }
  End { }
}

Function Get-ActiveDirectory {
  [CmdletBinding()]
  Param (
    [LandingZone] $controlParameters,
    [bool] $NewForest = $false
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    If (($controlParameters.ActiveDirectory.DomainName -eq '') `
          -or ([String]::IsNullOrEmpty($controlParameters.ActiveDirectory.AdminUser)) `
          -or ($null -eq $controlParameters.ActiveDirectory.AdminPassword)) {
      If ($controlParameters.ActiveDirectory.DomainName -eq '') {
        Clear-Scrollback
        $controlParameters.ShowSummary()
        $controlParameters.ActiveDirectory.DomainName = (Read-Host -Prompt "Enter Active Directory Domain e.g. NewSignature.com")
      }
      If ($controlParameters.ActiveDirectory.AdminUser -eq '') {
        Clear-Scrollback
        $controlParameters.ShowSummary()
        $controlParameters.ActiveDirectory.AdminUser = (Read-Host -Prompt "Enter the active directory admin username")
      }
      If (!$controlParameters.ActiveDirectory.AdminPassword) {
        Clear-Scrollback
        $controlParameters.ShowSummary()
        $controlParameters.ActiveDirectory.AdminPassword = (Read-Host -Prompt "Enter the active directory admin password " -AsSecureString)
      }

      $controlParameters.ManualSelection = $true
    }
  }
  End {
  }
}

Function Get-AzureSubscription {
  [CmdletBinding()]
  Param (
    [string] $Title = 'Select Subscription',
    [ControlParameters] $controlParameters
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    If ($controlParameters.AzureSubscriptionId -eq '') {
      $AzureSubcriptions = Get-AzSubscription -tenantid $controlParameters.AzureTenant.ID | Sort-Object {$_.Name}
      Show-Menu -Title $Title -Options $AzureSubcriptions.Name
      $SubscriptionSelection = [int](Read-Host -Prompt "Please make a selection")
      $SubscriptionSelection--
      $controlParameters.AzureSubscriptionName = $AzureSubcriptions[$SubscriptionSelection].Name
      $controlParameters.AzureSubscriptionId = $AzureSubcriptions[$SubscriptionSelection].SubscriptionId
      $controlParameters.ManualSelection = $true
    }
    Else {
      $subscription = Get-AzSubscription -SubscriptionId $controlParameters.AzureSubscriptionId -TenantId $controlParameters.AzureTenant.ID
      if ($null -eq $subscription) { throw "Unable to find subscription with ID $($controlParameters.AzureSubscriptionId)" }
      $controlParameters.AzureSubscriptionName = $subscription.Name
    }
  }
  End {
  }
}

Function Get-AzureTenant {
  [cmdletbinding()]
  Param (
    [ControlParameters] $controlParameters
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    #If not set, interactively get Tenant
    $tenants = Get-AzTenantListfromREST
    If ($controlParameters.AzureSubscriptionId -eq '') {
      Send-Trace -Message "Get-AzureTenant : Interactive Tenant Selection triggered"
      Show-Menu -Title 'Select Customer Azure Tenant' -Options $tenants.displayname
      $tenantSelection = [int](Read-Host -Prompt "Please make a selection")
      $tenantSelection--
      $controlParameters.AzureTenant.Name = $tenants[$tenantSelection].displayname
      $controlParameters.AzureTenant.Id = $tenants[$tenantSelection].tenantId
      $controlParameters.ManualSelection = $true
    }
    Else {
      Send-Trace -Message "Get-AzureTenant : Tenant selection passed via command line"
      try {$(Get-AzSubscription -SubscriptionId $controlParameters.AzureSubscriptionId).TenantId }
      catch { throw "Unable to find tenant using subscription ID $($controlParameters.AzureSubscriptionId)" }
      $controlParameters.AzureTenant.Name = "N/A - Supplied via Command Line"
      $controlParameters.AzureTenant.Id = $(Get-AzSubscription -SubscriptionId $controlParameters.AzureSubscriptionId).TenantId
    }
  }
  End { }
}

Function Get-ResourceGroupName {
  [cmdletbinding()]
  Param (
    [ControlParameters] $controlParameters
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    If ($controlParameters.ResourceGroupName -eq '') {
      $controlParameters.ResourceGroupName = (Read-Host -Prompt "Enter the Resource Group Name, if left blank a default name will be used.")
      $controlParameters.ManualSelection = $true
    }
  }
  End { }
}

Function Show-Menu {
  [CmdletBinding(DefaultParameterSetName = 'AllVariables')]
  Param (
    [string]$Title = 'Title Here',
    [string[]]$Options
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    Write-Host "================ $Title ================"
    Write-Host ""
    $count = 1;
    ForEach ($option In $Options) {
      Write-Host $count": "$option
      $count++
    }
    Write-Host ""
  }
  End { }
}

Export-ModuleMember `
  -Function `
    Clear-Scrollback, `
    Get-ActiveDirectory, `
    Get-AzureSubscription, `
    Get-AzureTenant, `
    Get-ResourceGroupName, `
    Show-Menu, `
    Get-VmCredential, `
    Get-EnvironmentCode, `
    Get-MultiSelectionOptionFromUser, `
    Get-BastionHostDetails, `
    Get-VpnConnectionDetails