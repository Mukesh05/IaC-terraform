
#Requires -Module Instrumentation
function Get-SecurityModule {
  if (
    $null -eq ((Get-Module -ListAvailable) | Where-Object { $_.name -match "Az.Security" }
    )
  ) {
    try {
      Install-Module "Az.Security" -RequiredVersion "0.7.6" -Scope CurrentUser -Force -AllowClobber
    }
    catch {
      throw "Unable to load dependent module Az.Security: `n $_"
    }
  }
}

Function Set-SecurityProviderRegistration {
  try {
    $RETRIES_MAX = 60

    if (Get-AzContext) {
      $providers = get-azresourceprovider -ListAvailable

      if (($providers | Where-Object { $_.providernamespace -eq "Microsoft.Security" }).registrationstate -eq "NotRegistered") {
        Register-AzResourceProvider -ProviderNamespace 'Microsoft.Security'
        $retries = $RETRIES_MAX
        do {
          $retries -= 1
          Start-Sleep 1
        } while (
          ((get-azresourceprovider -ListAvailable | Where-Object { $_.providernamespace -eq "Microsoft.Security" }).registrationstate -ne "Registered") `
            -or ($retries -ne 0)
        )
        if ((get-azresourceprovider -ListAvailable | Where-Object { $_.providernamespace -eq "Microsoft.Security" }).registrationstate -ne "Registered") {
          throw "Unable to register Microsoft.Security"
        }
      }

      if (($providers | Where-Object { $_.providernamespace -eq 'Microsoft.PolicyInsights' }).registrationstate -eq "NotRegistered") {
        Register-AzResourceProvider -ProviderNamespace 'Microsoft.PolicyInsights'
        $retries = $RETRIES_MAX
        do {
          $retries -= 1
          Start-Sleep 1
        } while (
          ((get-azresourceprovider -ListAvailable | Where-Object { $_.providernamespace -eq 'Microsoft.PolicyInsights' }).registrationstate -ne "Registered") `
            -or ($retries -ne 0)
        )
        if ((Get-AzResourceProvider -ListAvailable | Where-Object { $_.providernamespace -eq 'Microsoft.PolicyInsights' }).registrationstate -ne "Registered") {
          throw "Unable to register PolicyInsights"
        }
      }
    }
    else {
      throw "Error in Set-SecurityProviderRegistration: Not logged in to Azure "
    }
  }
  catch {
    throw "Error registering resource providers: $_ "
  }
}

Function Set-JustInTime {
  Param (
    [Parameter(Mandatory = $true)]
    [string]$vmID,
    [Parameter(Mandatory = $false)]
    [Int32]$accessPort = 3389
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    Get-SecurityModule
    Set-SecurityProviderRegistration

    $vm = (Get-AzResource -Id $vmID)
    if ($null -eq $vm) {
      throw "Unable to find VM with ID $vmID"
    }

    $JitPolicy = (@{
        id    = "$($vm.id)"
        ports = (
          @{
            number                     = $accessPort;
            protocol                   = "*";
            allowedSourceAddressPrefix = @("*");
            maxRequestAccessDuration   = "PT3H"
          }
        )
      }
    )
    $JitPolicyArr = @($JitPolicy)
    try {
      Set-AzJitNetworkAccessPolicy -Kind "Basic" -Location "$($vm.location)" -Name "default" -ResourceGroupName "$($vm.ResourceGroupName)" -VirtualMachine $JitPolicyArr
    }
    catch {
      throw "Error setting JIT Policy:`n $_ "
      return $_
    }
  }
  End { }
}

Function Set-SecurityWorkspace {
  Param(
    [Parameter(Mandatory = $true)]
    [string]$workspaceID
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    Get-SecurityModule
    Set-SecurityProviderRegistration
    try {
      Set-AzSecurityWorkspaceSetting -Name "default" `
        -Scope "/subscriptions/$((Get-AzContext).subscription.id)" `
        -WorkspaceId "$workspaceID"

      Set-AzSecurityAutoProvisioningSetting -Name "default" -EnableAutoProvision
    }
    catch {
      throw "Error setting security workspace setting: `n $_ "
    }
  }
  End { }
}

Function Set-SecurityCenter {
  try {
    # See https://docs.microsoft.com/en-us/azure/security-center/security-center-powershell-onboarding
    if (Get-AzContext) {
      Get-SecurityModule
      Set-SecurityProviderRegistration

      try {
        $bundles = @(
          "VirtualMachines",
          "SqlServers",
          "AppServices",
          "StorageAccounts",
          "SqlServerVirtualMachines"
          "KubernetesService",
          "ContainerRegistry",
          "KeyVaults"
        )
        foreach ($bundle in $bundles) {
          Set-AzSecurityPricing -Name "$bundle" -PricingTier "Standard"
        }
      }
      catch {
        throw "Error setting ASC SKU: `n $_"
      }
      try {
        $Policy = Get-AzPolicySetDefinition | Where-Object { $_.Properties.displayName -EQ '[Preview]: Enable Monitoring in Azure Security Center' }
        New-AzPolicyAssignment `
          -Name "ASC Default <$((Get-AzContext).subscription.id)>"`
          -DisplayName "Security Center Default $((Get-AzContext).subscription.id)" `
          -PolicySetDefinition $Policy `
          -Scope "/subscriptions/$((Get-AzContext).subscription.id)"
      }
      catch {
        throw "Error setting ASC Policy: `n $_"
      }
    }
    else {
      throw "Error in Set-SecurityCenter: Not logged in to Azure "
    }
  }
  catch {
    throw "Error in Set-SecurityCenter: $_ "
  }
}


Export-ModuleMember `
  -Function `
  Set-JustInTime, `
  Set-SecurityWorkspace, `
  Set-SecurityCenter