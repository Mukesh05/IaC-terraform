$appInsightsKey = "991eef84-61d6-4302-b2ba-3c4f957ac957"
$packageVersion = "testing"

Function Get-CallerPreference {
  <#
  .Synopsis
    Fetches "Preference" variable values from the caller's scope.
  .DESCRIPTION
    Script module functions do not automatically inherit their caller's variables, but they can be
    obtained through the $PSCmdlet variable in Advanced Functions.  This function is a helper function
    for any script module Advanced Function; by passing in the values of $ExecutionContext.SessionState
    and $PSCmdlet, Get-CallerPreference will set the caller's preference variables locally.
  .PARAMETER Cmdlet
    The $PSCmdlet object from a script module Advanced Function.
  .PARAMETER SessionState
    The $ExecutionContext.SessionState object from a script module Advanced Function.  This is how the
    Get-CallerPreference function sets variables in its callers' scope, even if that caller is in a different
    script module.
  .PARAMETER Name
    Optional array of parameter names to retrieve from the caller's scope.  Default is to retrieve all
    Preference variables as defined in the about_Preference_Variables help file (as of PowerShell 4.0)
    This parameter may also specify names of variables that are not in the about_Preference_Variables
    help file, and the function will retrieve and set those as well.
  .EXAMPLE
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState

    Imports the default PowerShell preference variables from the caller into the local scope.
  .EXAMPLE
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState -Name 'ErrorActionPreference','SomeOtherVariable'

    Imports only the ErrorActionPreference and SomeOtherVariable variables into the local scope.
  .EXAMPLE
    'ErrorActionPreference','SomeOtherVariable' | Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState

    Same as Example 2, but sends variable names to the Name parameter via pipeline input.
  .INPUTS
    String
  .OUTPUTS
    None. This function does not produce pipeline output.
  .LINK
    about_Preference_Variables
  #>

  [CmdletBinding(DefaultParameterSetName = 'AllVariables')]
  Param (
    [Parameter(Mandatory = $true)]
    [ValidateScript( { $_.GetType().FullName -eq 'System.Management.Automation.PSScriptCmdlet' })]
    $Cmdlet,

    [Parameter(Mandatory = $true)]
    [System.Management.Automation.SessionState]
    $SessionState,

    [Parameter(ParameterSetName = 'Filtered', ValueFromPipeline = $true)]
    [string[]]
    $Name
  )

  Begin {
    $filterHash = @{ }
  }
  Process {
    If ($null -ne $Name) {
      ForEach ($string In $Name) {
        $filterHash[$string] = $true
      }
    }
  }
  End {
    # List of preference variables taken from the about_Preference_Variables help file in PowerShell version 4.0
    $vars = @{
      'ErrorView'                     = $null
      'FormatEnumerationLimit'        = $null
      'LogCommandHealthEvent'         = $null
      'LogCommandLifecycleEvent'      = $null
      'LogEngineHealthEvent'          = $null
      'LogEngineLifecycleEvent'       = $null
      'LogProviderHealthEvent'        = $null
      'LogProviderLifecycleEvent'     = $null
      'MaximumAliasCount'             = $null
      'MaximumDriveCount'             = $null
      'MaximumErrorCount'             = $null
      'MaximumFunctionCount'          = $null
      'MaximumHistoryCount'           = $null
      'MaximumVariableCount'          = $null
      'OFS'                           = $null
      'OutputEncoding'                = $null
      'ProgressPreference'            = $null
      'PSDefaultParameterValues'      = $null
      'PSEmailServer'                 = $null
      'PSModuleAutoLoadingPreference' = $null
      'PSSessionApplicationName'      = $null
      'PSSessionConfigurationName'    = $null
      'PSSessionOption'               = $null
      'ErrorActionPreference'         = 'ErrorAction'
      'DebugPreference'               = 'Debug'
      'ConfirmPreference'             = 'Confirm'
      'WhatIfPreference'              = 'WhatIf'
      'VerbosePreference'             = 'Verbose'
      'WarningPreference'             = 'WarningAction'
    }

    ForEach ($entry In $vars.GetEnumerator()) {
      If (([string]::IsNullOrEmpty($entry.Value) -or -not $Cmdlet.MyInvocation.BoundParameters.ContainsKey($entry.Value)) -and
        ($PSCmdlet.ParameterSetName -eq 'AllVariables' -or $filterHash.ContainsKey($entry.Name))) {
        $variable = $Cmdlet.SessionState.PSVariable.Get($entry.Key)

        If ($null -ne $variable) {
          If ($SessionState -eq $ExecutionContext.SessionState) {
            Set-Variable -Scope 1 -Name $variable.Name -Value $variable.Value -Force -Confirm:$false -WhatIf:$false
          }
          Else {
            $SessionState.PSVariable.Set($variable.Name, $variable.Value)
          }
        }
      }
    }

    If ($PSCmdlet.ParameterSetName -eq 'Filtered') {
      ForEach ($varName In $filterHash.Keys) {
        If (-not $vars.ContainsKey($varName)) {
          $variable = $Cmdlet.SessionState.PSVariable.Get($varName)
          If ($null -ne $variable) {
            If ($SessionState -eq $ExecutionContext.SessionState) {
              Set-Variable -Scope 1 -Name $variable.Name -Value $variable.Value -Force -Confirm:$false -WhatIf:$false
            }
            Else {
              $SessionState.PSVariable.Set($variable.Name, $variable.Value)
            }
          }
        }
      }
    }
  }
}

Function Get-SessionId{
  If ($telemetryClient.connected) {
    return $telemetryClient.client.Context.Session.Id
  }
}

Function Send-Error {
  [CmdletBinding(DefaultParameterSetName = 'AllVariables')]
  Param (
    [Parameter(
      Position = 0,
      Mandatory = $true,
      ValueFromPipeline = $true)]
    [System.Exception]$exception,

    [Parameter(
      Position = 1,
      Mandatory = $true,
      ValueFromPipeline = $false)]
    [string]$Message
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    Write-Error -Message $Message -Exception $exception
    If ($telemetryClient.connected) {
      $telemetryclient.sendError($exception)
    }
  }
}

Function Send-Trace {
  [CmdletBinding(DefaultParameterSetName = 'AllVariables')]
  Param(
    [Parameter(
      Position = 0,
      Mandatory = $true,
      ValueFromPipeline = $true)]
    [string] $Message
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    If ($VerbosePreference -eq 'Continue') {
      Write-Verbose -Message $Message
    }
    If ($DebugPreference -eq 'Continue') {
      Write-Debug -Message $Message
    }
    If ($telemetryClient.connected) {
      $telemetryClient.sendTrace($Message)
    }
  }
}

Function Send-Event {
  [CmdletBinding(DefaultParameterSetName = 'AllVariables')]
  Param(
    [Parameter(
      Position = 0,
      Mandatory = $true,
      ValueFromPipeline = $true)]
    [string] $Message,
    [Parameter(
      Position = 1,
      Mandatory = $false,
      ValueFromPipeline = $true)]
    [switch]$WriteOutput
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    If ($VerbosePreference -eq 'Continue') {
      Write-Verbose -Message $Message
    }
    If ($DebugPreference -eq 'Continue') {
      Write-Debug -Message $Message
    }
    If ($telemetryClient.connected) {
      $telemetryClient.sendEvent($Message)
    }
    If ($WriteOutput) {
      Write-Output -InputObject $Message
    }
  }
}

Function Get-NetDependency {
  [CmdletBinding()]param ()
  #Dependency check for .NET verson 4.6.2 (Windows 10 Anniversary Update)
  $netVer = Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full\' | Get-ItemPropertyValue -Name Release | ForEach-Object { $_ -ge 394802 }
  If ($null -eq $netVer) {
    Send-Error -Message "Unable to find .NET version 4.6.2 or greater"
  }
  Else {
    Send-Trace -Message "Confirmed .NET Framework 4.6.2 or later installed"
  }
}

Function Get-ApplicationInsightsPkg {
  $appInsightsLibPath = "$PSScriptRoot\packages\Microsoft.ApplicationInsights.2.10.0\lib\net46\Microsoft.ApplicationInsights.dll"
  $return = $(Get-Item $appInsightsLibPath)
  If ($null -ne $return) {
    $return = $return.FullName
  }
  Else {
    $return = $null
  }

  Return $return
}

Class telemetryClient {
  [string] $pkgVersion = $null
  Hidden $client = $null
  Hidden [bool] $connected = $true

  telemetryClient() {
    Write-Warning -Message "Unable to initialise telemetry client, app insights key not provided."
    $this.connected = $false
  }
  telemetryClient([string]$appInsightsInstrumentationKey) {
    Write-Warning -Message "Please ensure Package Version is provided"
    Try {
      Get-NetDependency
      Add-Type -Path "$PSScriptRoot\packages\Microsoft.ApplicationInsights.2.10.0\lib\net46\Microsoft.ApplicationInsights.dll"
      Write-Verbose -Message "Loaded Application Insights DLL successfully"
    }
    Catch {
      Write-Host "Unable to load Application Insights DLL successfully: `n$_ `n"
      $this.connected = $false
    }

    Try {
      $clientObj = New-Object "Microsoft.ApplicationInsights.TelemetryClient"
      $clientObj.InstrumentationKey = $appInsightsInstrumentationKey
      $clientObj.Context.Component.Version = $this.pkgVersion
      $clientObj.Context.Device.OperatingSystem = (Get-WmiObject Win32_OperatingSystem).Version
      $clientObj.Context.Session.Id = New-Guid
      $clientObj.Context.User.Id = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($env:username))
      $this.client = $clientObj
      $this.sendEvent("App Insights Session Created")
    }
    Catch {
      Write-Verbose -Message "Failed to init Application Insights client"
      $this.connected = $false
    }
  }

  telemetryClient([string]$appInsightsInstrumentationKey, [string]$pkgVer) {
    $this.pkgVersion = $pkgVer
    Try {
      Get-NetDependency
      Add-Type -Path $(Get-ApplicationInsightsPkg)
      Write-Verbose -Message "Loaded Application Insights DLL successfully"
    }
    Catch {
      Write-Warning -Message "Unable to load Application Insights DLL successfully: `n$_ `n"
      $this.connected = $false
    }

    Try {
      $clientObj = New-Object "Microsoft.ApplicationInsights.TelemetryClient"
      $clientObj.InstrumentationKey = $appInsightsInstrumentationKey
      $clientObj.Context.Component.Version = $this.pkgVersion
      $clientObj.Context.Session.Id = New-Guid
      $clientObj.Context.User.Id = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($env:username))
      $this.client = $clientObj
      $this.sendEvent("App Insights Session Created")
    }
    Catch {
      Write-Warning -Message "Failed to init Application Insights client"
      $this.connected = $false
    }
  }

  sendTrace([string]$traceMessage) {
    If ($this.connected) {
      $Message = $traceMessage
      $this.client.TrackTrace($Message)
      $this.client.flush()
    }
  }
  sendEvent([string]$eventName) {
    If ($this.connected) {
      $eventName = $eventName
      $this.client.TrackEvent($eventName)
      $this.client.flush()
    }
  }
  sendError([Exception]$exception) {
    If ($this.connected) {
      $this.client.TrackException($exception)
      $this.client.flush()
    }
  }
}

$telemetryClient = [telemetryClient]::new("$appInsightsKey", $packageVersion)

Export-ModuleMember `
  -Function Get-CallerPreference, Get-SessionId, Send-Error, Send-Event, Send-Trace `
  -Variable telemetryClient, packageVersion