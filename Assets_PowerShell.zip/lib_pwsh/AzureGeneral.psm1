#Requires -Modules Az.Resources, Instrumentation

Function Connect-Azure {
  [CmdletBinding(DefaultParameterSetName = 'AllVariables')]
  Param (
    [switch] $SkipUserCheck
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    Send-Trace -Message "Connect to Azure"
    $needLogin = $false
    $context = Get-AzContext
    If ($null -eq $context) {
      $needLogin = $true
    }
    Else {
      If (-not $SkipUserCheck) {
        If ($context.Account.Type -eq 'User') {
          Disconnect-AzAccount | Out-Null
          $needlogin = $true
        }
      }
    }

    If ($needLogin) {
      Connect-AzAccount
      $context = Get-AzContext
    }

    If ($null -eq $context) {
      Throw "Unable to get Azure Context."
    } Else {
      return $context
    }
  }
  End { }
}

Function Get-AzTenantListfromREST {
  [CmdletBinding()] Param ()

  Send-Trace -message "Get-AzTenantListfromREST"

  Return Invoke-GetRestMethod -Uri "https://management.azure.com/tenants?api-version=2017-08-01"
}

Function Get-ManagementGroupChildNodes {
  [CmdletBinding()]
  [OutputType([Array])]
  Param (
    [string] $ManagementGroupId,
    [switch] $Subscriptions,
    [switch] $ManagementGroups
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    Send-Trace -Message "Get-ManagementGroupChildNodes"

    $returnCriteria = '*'
    If ($Subscriptions) { $returnCriteria = "/subscriptions" }
    If ($ManagementGroups) { $returnCriteria = "/providers/Microsoft.Management/managementGroups" }
    If ($Subscriptions -And $ManagementGroups) { $returnCriteria = "*" }

    [Array]$result = @( Invoke-GetRestMethod -Uri ("https://management.azure.com/providers/Microsoft.Management/managementGroups/{0}/descendants?api-version=2018-03-01-preview" -f $ManagementGroupId) | Where-Object { $_.type -Like "$returnCriteria" } )

    # the ,$result forces the return to be an array, basically stops PowerShell unboxing a single object from an array.
    Return ,$result
  }
  End { }
}

Function Invoke-DeleteRestMethod {
  <#
  .Synopsis
    Performs a Delete request, using an established Azure Context.
  .PARAMETER Uri
    The FQDN Uri for the http request.
  .EXAMPLE
    Invoke-DeleteRestMethod -Uri "https://management.azure.com/tenants?api-version=2017-08-01"

    Calls the Uri with Invoke-RestMethod, using the Azure Context already established.
  .INPUTS
    String
  .OUTPUTS
    None. This function does not produce pipeline output.
  #>
  [CmdletBinding()]
  Param (
    [string] $Uri
  )

  Send-Trace -message "Invoke-DeleteRestMethod"

  $currentAzureContext = Get-AzContext
  $azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
  $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile)
  $token = $profileClient.AcquireAccessToken($currentAzureContext.Subscription.TenantId).AccessToken

  $headers = @{ }
  $headers.Add('Authorization', "Bearer $token")
  $headers.Add('Host', "management.azure.com")

  Invoke-RestMethod -Method DELETE -Uri $Uri -Headers $headers -ErrorVariable ResponseError -ErrorAction SilentlyContinue -UseBasicParsing
  If ($ResponseError -ne '') {
    Send-Trace -message $ResponseError
    Throw "An Error has occured"
  }
}

Function Invoke-GetRestMethod {
  <#
  .Synopsis
    Performs a Get request, using an established Azure Context, and return the result back to the caller for futher processing.
  .PARAMETER Uri
    The FQDN Uri for the http request.
  .EXAMPLE
    Invoke-GetRestMethod -Uri "https://management.azure.com/tenants?api-version=2017-08-01"

    Calls the Uri with Invoke-RestMethod, using the Azure Context already established.
  .INPUTS
    String
  .OUTPUTS
    None. This function does not produce pipeline output.
  #>
  [CmdletBinding()]
  Param (
    [string] $Uri
  )

  Send-Trace -message "Invoke-GetRestMethod"

  $currentAzureContext = Get-AzContext
  $azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
  $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile)
  $token = $profileClient.AcquireAccessToken($currentAzureContext.Subscription.TenantId).AccessToken

  $headers = @{ }
  $headers.Add('Authorization', "Bearer $token")
  $headers.Add('Host', "management.azure.com")

  $response = Invoke-RestMethod -Method GET -Uri $Uri -Headers $headers -ErrorVariable ResponseError -ErrorAction SilentlyContinue -UseBasicParsing
  If ($ResponseError -ne '') {
    Send-Trace -message $ResponseError
    Throw "An Error has occured"
  }

  Return $response.value
}

Function Invoke-PostRestMethod {
  <#
  .Synopsis
    Performs a POST request, using an established Azure Context, and return the result back to the caller for futher processing.
  .PARAMETER Uri
    The FQDN Uri for the http request.
  .EXAMPLE
    Invoke-PostRestMethod -Uri "https://management.azure.com/tenants?api-version=2017-08-01" -Body $Body

    Calls the Uri with Invoke-RestMethod, using the Azure Context already established.
  .INPUTS
    String
  .OUTPUTS
    Json
  #>
  [CmdletBinding()]
  Param (
    [string] $Uri,
    [string] $Body = $null
  )

  Send-Trace -message "Invoke-PutRestMethod"

  $currentAzureContext = Get-AzContext
  $azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
  $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile)
  $token = $profileClient.AcquireAccessToken($currentAzureContext.Subscription.TenantId).AccessToken

  $headers = @{ }
  $headers.Add('Authorization', "Bearer $token")
  $headers.Add('Host', "management.azure.com")

  If ($null -eq $Body) {
    Invoke-RestMethod -Method POST -Uri $Uri -Headers $headers -ContentType "application/json" -ErrorVariable ResponseError -ErrorAction SilentlyContinue -UseBasicParsing
  }
  Else {
    Invoke-RestMethod -Method POST -Uri $Uri -Headers $headers -ContentType "application/json" -Body $Body -ErrorVariable ResponseError -ErrorAction SilentlyContinue -UseBasicParsing
  }

  If ($ResponseError -ne '') {
    Send-Trace -message $ResponseError
    Throw "An Error has occured"
  }

  Return $response.value
}

Function Invoke-PutRestMethod {
  <#
  .Synopsis
    Performs a Put request, using an established Azure Context, and return the result back to the caller for futher processing.
  .PARAMETER Uri
    The FQDN Uri for the http request.
  .EXAMPLE
    Invoke-PutRestMethod -Uri "https://management.azure.com/tenants?api-version=2017-08-01" -Body $Body

    Calls the Uri with Invoke-RestMethod, using the Azure Context already established.
  .INPUTS
    String
  .OUTPUTS
    Json
  #>
  [CmdletBinding()]
  Param (
    [string] $Uri,
    [string] $Body
  )

  Send-Trace -message "Invoke-PutRestMethod"

  $currentAzureContext = Get-AzContext
  $azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
  $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile)
  $token = $profileClient.AcquireAccessToken($currentAzureContext.Subscription.TenantId).AccessToken

  $headers = @{ }
  $headers.Add('Authorization', "Bearer $token")
  $headers.Add('Host', "management.azure.com")

  Invoke-RestMethod -Method PUT -Uri $Uri -Headers $headers -ContentType "application/json" -Body $Body -ErrorVariable ResponseError -ErrorAction SilentlyContinue -UseBasicParsing
  If ($ResponseError -ne '') {
    Send-Trace -message $ResponseError
    Throw "An Error has occured"
  }

  Return $response.value
}

Function Set-ResourceProviders {
  [CmdletBinding()]
  Param (
    [string[]] $ResourceProviders,
    [int]$retries = 10,
    [int]$secondsDelay = 60
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    Send-Event -message "Checking for unregistered Resource Providers. Please note this step may take some time." -WriteOutput
    $notRegistered = (Get-AzResourceProvider -ProviderNamespace $ResourceProviders | Where-Object { $_.RegistrationState -ne 'Registered' })

    If ($null -ne $notRegistered -And $notRegistered.Count -ge 1) {
      Send-Event -message "Registering Resource Providers. Found $($notregistered.count)"
      (Get-AzResourceProvider -ProviderNamespace $ResourceProviders | Where-Object { $_.RegistrationState -ne 'Registered' -and $_.RegistrationState -ne 'Registering' }) | Register-AzResourceProvider | Out-Null
    }

    Try {
      $retrycount = 0
      $completed = $false

      While (-not $completed) {
        $completed = ((Get-AzResourceProvider -ProviderNamespace $ResourceProviders | Where-Object { $_.RegistrationState -ne 'Registered' -and $_.RegistrationState -ne 'Registering' }).Count -eq 0)
        If (-not $completed) {
          If ($retrycount -ge $retries) {
            Throw
          }
          $retrycount++
          Send-Event -message  ("Waiting {0} for Resource Provider Registration to complete." -f $secondsDelay)
          Start-Sleep $secondsDelay
        }
      }
    }
    Catch {
      Send-Error -message "Unable to confirm all the resource providers are registered, please check manually and re-run the install." -exception $_.Exception
      Break;
    }
  }
  End { }
}

<#
.SYNOPSIS
 Given details for an existing log analytics workspace, it
 returns "None", "Minimal", "Recommended" or "All" as the tier setting.

.PARAMETER SubscriptionId
  Azure subscription, defaults to current if not supplied
.PARAMETER WorkspaceName
  Log analytics workspace name
.PARAMETER WorkspaceResourceGrup
  Log analytics workspace resource group
.EXAMPLE
  $value = Get-AzSecurityCenterTierSetting -SubscriptionId $sub -WorkspaceResourceGroup $rg -WorkspaceName $ws
#>
function Get-AzSecurityCenterTierSetting
{
    param (
        [Parameter()]
        [String]$SubscriptionId = (Get-AzContext).Subscription.Id,
        [Parameter()]
        [String]$WorkspaceName,
        [Parameter()]
        [String]$WorkspaceResourceGroup
    )

    $RESTURI = "https://management.azure.com/subscriptions/" + $subscriptionId + `
               "/resourcegroups/" + $workspaceResourceGroup + `
               "/providers/Microsoft.OperationalInsights/Workspaces/" + $workspaceName + `
               "/datasources/SecurityEventCollectionConfiguration?api-version=2015-11-01-preview"

    $response = Invoke-GetRestMethod -Uri $RESTURI

    $response.properties.Tier
}

Export-ModuleMember -Function "Connect-Azure", `
            "Get-AzTenantListfromREST", `
            "Get-ManagementGroupChildNodes", `
            "Get-AzSecurityCenterTierSetting", `
            "Invoke-DeleteRestMethod", `
            "Invoke-GetRestMethod", `
            "Invoke-PostRestMethod", `
            "Invoke-PutRestMethod", `
            "Set-ResourceProviders"
