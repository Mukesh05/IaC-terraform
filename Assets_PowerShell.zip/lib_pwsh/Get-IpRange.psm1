<#
  .SYNOPSIS
    Get the IP addresses in a range
  .EXAMPLE
    Get-IpRange -start 192.168.8.2 -end 192.168.8.20
  .EXAMPLE
    Get-IpRange -ip 192.168.8.2 -mask 255.255.255.0
  .EXAMPLE
    Get-IpRange -ip 172.16.0.0 -maskbits 22
  .EXAMPLE
    Get-IpRange -cidr '192.168.0.0/24'
  .OUTPUTS
    Custom object describing the subnet range, e.g.

    Get-IpRange -ip 172.16.0.0 -maskbits 22

    gives:

        mask      : 255.255.252.0
        broadcast : 172.16.3.255
        network   : 172.16.0.0
        start     : 172.16.0.0
        end       : 172.16.3.255
        cidr      : 172.16.0.0/22
        next      : 172.16.4.0

#>
function Get-IpRange {
  param (
    [string]$cidr,
    [string]$start,
    [string]$end,
    [string]$ip,
    [string]$mask,
    [int]$maskbits
  )
  if ($cidr) {
    $cidrSegments = $cidr.Split('/')
    $ip = $cidrSegments[0]
    $maskbits = [int64]::Parse($cidrSegments[1])
  }

  if ($ip) {
    $ipaddr = [Net.IPAddress]::Parse($ip)

    if ($maskbits) {
      # stringify the mask with n '1's and 32-n '0's and convert to int with from-base-2 function
      $mask = Convert-INT64toIP -int ([convert]::ToInt64(("1" * $maskbits + "0" * (32 - $maskbits)), 2))
      $maskaddr = [Net.IPAddress]::parse($mask)
    }
    if ($mask) {
      $maskaddr = [Net.IPAddress]::Parse($mask)
    }

    # get the network from the masked address
    $networkaddr = New-Object Net.IPAddress ($maskaddr.address -band $ipaddr.address)

    # get the broadcast address by masking and flipping bits in the host range
    [int64]$broadcast = [Net.IPAddress]::parse("255.255.255.255").Address `
      -bxor $maskaddr.Address `
      -bor $networkaddr.Address

    $broadcastaddr = New-Object Net.IPAddress ($broadcast)

    $startaddr = $networkaddr
    $endaddr = $broadcastaddr
  }
  else {
    # network ip not given so we derive from the range given instead
    $startaddr = [Net.IPAddress]::parse($start)
    $endaddr = [Net.IPAddress]::parse($end)
    $maskaddr = [Net.IPAddress]::new((-bnot ($startaddr.Address -bxor $endaddr.Address)) -band ([math]::Pow(2, 32) - 1))

    $networkaddr = $startaddr.IpAddressToString
    $broadcastaddr = $endaddr.IpAddressToString
  }

  if (-not $maskbits) {
    $maskbits = Get-MaskBitsSet -int ($maskaddr.address)
  }

  $next = Convert-INT64toIP -int ((Convert-IPtoINT64 -ip $endaddr.IpAddressToString) + 1)

  return New-Object PSObject -Property @{
    start     = $startaddr.IpAddressToString
    end       = $endaddr.IpAddressToString
    mask      = $maskaddr.IpAddressToString
    next      = $next
    network   = $networkaddr
    broadcast = $broadcastaddr
    cidr      = "$($startaddr.IpAddressToString)/$($maskbits)"
    maskbits  = $maskbits
  }
}

<#
  .SYNOPSIS
    Split ip range into ranges that can be used for subnets
  .EXAMPLE
    Split-IpRange -ip 172.16.0.0 -maskbits 22 -segments 2
  .OUTPUTS
    Custom object array describing the subnet ranges with n equal segments from the original range
#>
function Split-IpRange {
  param (
    [string]$start,
    [int]$maskbits,
    [int]$segments
  )

  # find how many bits (nth power of 2) we need to add to the subnet mask when breaking the network into subnets
  $segmentBits = [math]::Log10($segments) / [math]::Log10(2)

  if (($segmentBits + $maskbits) -gt 31) {
    throw 'cannot subnet these addresses - not enough address range provided'
  }

  if ([math]::Truncate($segmentBits) -ne $segmentBits) {
    throw 'cannot subnet these addresses - expect a power of 2 in the segments parameter'
  }

  $returnRanges = New-Object -TypeName "System.Collections.ArrayList"
  $segmentRange = Get-IpRange -ip $start -maskbits ($maskbits + $segmentBits)
  $returnRanges.Add($segmentRange) | Out-Null

  for ($segment = 1; $segment -lt $segments; $segment++) {
    $segmentRange = Get-IpRange -ip $segmentRange.next -maskbits ($maskbits + $segmentBits)
    $returnRanges.Add($segmentRange) | Out-Null
  }
  return $returnRanges
}

<#
  .SYNOPSIS
    returns number of binary bits that are set to '1' in an integer by shifting
    and masking with '1' to test each bit
  .OUTPUTS
    string value for the IP address (dotted quad format)
  .NOTES
    Only tests 32 bits for use in IP address mask calculations
#>
function Get-MaskBitsSet() {
  param ([int64]$int)

  [int64]$count = 0
  $bitsInIpAddress = 32
  for ($i = 0; $i -le $bitsInIpAddress; $i++) {
    if (($int -shr $i) -band 1) {
      $count++
    }
  }

  return $count
}

<#
  .SYNOPSIS
    Convert IP address from integer in base 64 to avoid sign issues with int 32 to string
  .OUTPUTS
    string value for the IP address (dotted quad format)
#>
function Convert-INT64toIP() {
  param ([int64]$int)

  # for each 8 bit section of the 4-byte address shift right to the octet's dot and mask with 255 to get the octet value as a string
  # then concatenate
  return (($int -shr 24) -band 255).ToString() + '.' `
    + (($int -shr 16) -band 255).ToString() + '.' `
    + (($int -shr 8) -band 255).ToString() + '.' `
    + ($int -band 255).ToString()
}

<#
  .SYNOPSIS
    Convert IP address string to integer in base 64 to avoid sign issues with int 32
  .OUTPUTS
    integer value for the IP address
#>
function Convert-IPtoINT64() {
  param (
    [string]$ip
  )

  # assemble the DWORD byte by byte by multiplying by the boundary bit values and adding together
  $octets = $ip.split(".")
  return [int64]([int64]$octets[0] * [math]::Pow(2, 24) `
      + [int64]$octets[1] * [math]::Pow(2, 16) `
      + [int64]$octets[2] * [math]::Pow(2, 8) `
      + [int64]$octets[3])
}

function Test-CidrValidation() {
  [CmdLetBinding()]
  param (
    [string] $cidr
  )
  $validCidrFilter = '^([0-9]{1,3}\.){3}[0-9]{1,3}(\/([0-9]|[1-2][0-9]|3[0-2]))?$'
  $result = $CIDR -match $validCidrFilter
  return $result
}

Export-ModuleMember "Split-IpRange"
Export-ModuleMember "Get-IpRange"
Export-ModuleMember "Get-MaskBitsSet"
Export-ModuleMember "Test-CidrValidation"

