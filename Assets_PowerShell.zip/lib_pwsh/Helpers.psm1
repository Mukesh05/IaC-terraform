Class AzureTenant {
  [string] $Id = ''
  [string] $Name = ''
}

Class AzureManagementGroup {
  [string] $Id = ''
  [string] $Name = ''
}

Class AzureSubscription {
  [string] $Id = ''
  [string] $Name = ''
}

Class AzureResourceGroup {
  [string] $Name = ''
  [string] $Location = ''
}

Class ActiveDirectory {
  [string] $DomainName = ''
  [string] $AdminUser = ''
  [securestring] $AdminPassword
  ActiveDirectory() {
  }
}

Class ControlParameters {
  [AzureTenant] $AzureTenant = [AzureTenant]::new()
  [string] $AzureSubscriptionId = ''
  [string] $AzureSubscriptionName = ''
  [string] $ResourceGroupName = ''
  [string] $ResourceGroupLocation = ''
  [bool] $ManualSelection = $false
  [string] $DeploymentStorageAccount = ''
  [string] $DeploymentKeyVault = ''
  [string] $ManagementGroup = ''
  [string] $Architecture = ''

  ShowSummary() {
  }
  [bool] IsValid() {
    return $false
  }
}

Class HubInfrastructureDeploymentParameters : ControlParameters {
  # network
  [string] $VNetCIDR = ''
  [string] $GatewayCIDR = ''
  [string] $GatewaySKU = ''
  [string] $SubNetCIDR = ''
  [string] $RemoteGatewayIpAddress = ''
  [string] $RemoteNetworkCIDR = ''

  # monitoring settings
  [string] $MonitoringLocation = ''
  [string] $MonitoringResourceGroup = ''
  [string] $AlertEmailName = ''
  [string] $AlertEmailAddress = ''

}

Class AdvancedLandingZoneHub : HubInfrastructureDeploymentParameters {

  # vnet and core settings
  [string] $EnvironmentCode = ''
  [int] $FirewallPublicIpAddressCount = 1
  [int[]] $FirewallAvailabilityZones = @()
  [string] $VmAdminUserName = ''
  [securestring] $VmAdminPassword = $null
  [string] $VNetCIDR = ''
  [string[]] $VnetDnsServerAddresses = @()

  # vpn gateway settings
  [bool] $ShouldDeployVpnGateway = $false
  [string] $GatewayPreSharedKey = ''

  # bastion host settings
  [string] $BastionVmSize = 'Standard_B2s'
  [string] $BastionOsVersion = '2019-Datacenter'

  AdvancedLandingZoneHub() {
    $this.ManualSelection = $false
  }

  ShowSummary() {
    Write-Host ("This installs LaunchPad Advanced Hub: A single VNet into a single resource group, " + `
        "with a 2-controller DNS that can be uplifted to AD, a Bastion VM for remote access, VPN gateway, " + `
        "as well as installing monitoring and governance elements.")
    Write-Host -Object ""
    Write-Host -Object ""
    If ($this.AzureTenant.Id -ne '') {
      Write-Host -Object "Deploying to the AAD Tenant - $($this.AzureTenant.Name)"
    }
    If ($this.AzureSubscriptionId -ne '') {
      Write-Host "Deploying to the Azure Subscription - $($this.AzureSubscriptionName)"
    }
    If ($this.VmAdminUserName -ne '') {
      Write-Host "Creating Bastion Host with username: $($this.VmAdminUserName)"
    }
    If ($this.ResourceGroupName -ne '') {
      Write-Host "Creating Resource in resource group - $($this.ResourceGroupName)"
    }
    If ($this.ResourceGroupLocation -ne '') {
      Write-Host "Creating Resource in location - $($this.ResourceGroupLocation)"
    }
    If ($this.MonitoringResourceGroup -ne '') {
      Write-Host "Creating Monitoring assets in Resource Group $($this.MonitoringResourceGroup)"
    }
    If ($this.AlertEmailName -ne '') {
      Write-Host "Email alerts to - $($this.AlertEmailName)"
    }
    If ($this.AlertEmailAddress -ne '') {
      Write-Host "Emails alerts to email - $($this.AlertEmailAddress)"
    }
    If ($this.VNetCIDR -ne '') {
      Write-Host "LaunchPad VNet IP Address Range (CIDR Format) - $($this.VNetCIDR)"
    }
    If (($null -ne $this.VnetDnsServerAddresses) `
        -or ($this.VnetDnsServerAddresses.Count -eq 0)) {
      Write-Host "LaunchPad DNS Servers - $($this.VnetDnsServerAddresses)"
    }
    If ($this.GatewayCIDR -ne '') {
      Write-Host "LaunchPad Gateway IP Address Range (CIDR Format) - $($this.GatewayCIDR)"
    }
    If ($this.GatewaySKU -ne '') {
      Write-Host "Gateway SKU - $($this.GatewaySKU)"
    }
    If ($this.RemoteGatewayIpAddress -ne '') {
      Write-Host "Remote IP address of the on-premises or remote VPN Endpoint - $($this.RemoteGatewayIpAddress)"
    }
    If ($this.RemoteNetworkCIDR -ne '') {
      Write-Host "Remote or On-Premises Network IP Address Range (CIDR Format) - $($this.RemoteNetworkCIDR)"
    }
    If ($this.BastionVmSize -ne '') {
      Write-Host "VM Size For Bastion (RDP) Host - $($this.BastionVmSize)"
    }
    If ($this.BastionOsVersion -ne '') {
      Write-Host "VM Operating System for Bastion Host - $($this.BastionOsVersion)"
    }
    If ($this.EnvironmentCode -ne '') {
      Write-Host "Environment code for hub deployment - $($this.EnvironmentCode)"
    }
    If ($this.FirewallPublicIpAddressCount -ne 0) {
      Write-Host "Number of Public IPs to assign to Azure Firewall - $($this.FirewallPublicIpAddressCount)"
    }
    If (($null -ne $this.FirewallAvailabilityZones) -and ($this.FirewallAvailabilityZones.Count -gt 0)) {
      Write-Host "Firewall Availability Zones assigned - $($this.FirewallAvailabilityZones)"
    }

    Write-Host -Object ""
    Write-Host -Object ""
  }

  [bool]IsValid() {
    If ($this.ManualSelection) {
      $this.ShowSummary()
      $deploymentConfirmed = Read-Host "Enter 'Y' to continue deployment or 'N' to start selection of parameters again"
      If ($deploymentConfirmed.ToUpperInvariant() -ne 'Y') {
        # TODO confirm inversion here is ok
        $this.AzureTenant = [AzureTenant]::new()
        $this.VmAdminUserName = ''
        $this.VmAdminPassword = $null
        $this.AzureSubscriptionId = ''
        $this.ResourceGroupName = ''
        $this.ResourceGroupLocation = ''
        $this.MonitoringResourceGroup = ''
        $this.AlertEmailName = ''
        $this.AlertEmailAddress = ''
        $this.VNetCIDR = ''
        $this.GatewayCIDR = ''
        $this.GatewaySKU = ''
        $this.SubNetCIDR = ''
        $this.RemoteGatewayIpAddress = ''
        $this.RemoteNetworkCIDR = ''
      }

      Return ($deploymentConfirmed.ToUpperInvariant() -eq 'Y')
    }
    Else {
      Return $true
    }
  }
}

Class LandingZone : HubInfrastructureDeploymentParameters {
  [ActiveDirectory] $ActiveDirectory = [ActiveDirectory]::new()

  LandingZone() {
    $this.ManualSelection = $false
  }

  ShowSummary() {
    Write-Host ("This installs LaunchPad Essentials: A single VNet into a single resource group, with " + `
        "a 2-controller new Active Directory Forest,  Bastion VM for remote access, VPN gateway, " + `
        "as well as installing governance elements.")
    Write-Host -Object ""
    Write-Host -Object ""
    If ($this.AzureTenant.Id -ne '') {
      Write-Host -Object "Deploying to the Tenancy - $($this.AzureTenant.Name)"
    }
    If ($this.AzureSubscriptionId -ne '') {
      Write-Host "Deploying to the Azure Subscription - $($this.AzureSubscriptionName)"
    }
    If ($this.ActiveDirectory.DomainName -ne '') {
      Write-Host "Creating Active Directory domain of $($this.ActiveDirectory.DomainName)"
    }
    If ($this.ActiveDirectory.AdminUser -ne '') {
      Write-Host -Object "Active Directory Admin User is $($this.ActiveDirectory.AdminUser)"
    }
    If ($this.ResourceGroupName -ne '') {
      Write-Host "Creating Resource in resource group - $($this.ResourceGroupName)"
    }
    If ($this.ResourceGroupLocation -ne '') {
      Write-Host "Creating Resource in location - $($this.ResourceGroupLocation)"
    }
    If ($this.MonitoringResourceGroup -ne '') {
      Write-Host "Creating Monitoring assets in Resource Group $($this.MonitoringResourceGroup)"
    }
    If ($this.AlertEmailName -ne '') {
      Write-Host "Email alerts to - $($this.AlertEmailName)"
    }
    If ($this.AlertEmailAddress -ne '') {
      Write-Host "Emails alerts to email - $($this.AlertEmailAddress)"
    }
    If ($this.VNetCIDR -ne '') {
      Write-Host "LaunchPad VNet IP Address Range (CIDR Format) - $($this.VNetCIDR)"
    }
    If ($this.GatewayCIDR -ne '') {
      Write-Host "LaunchPad Gateway IP Address Range (CIDR Format) - $($this.GatewayCIDR)"
    }
    If ($this.GatewaySKU -ne '') {
      Write-Host "Gateway SKU - $($this.GatewaySKU)"
    }
    If ($this.SubNetCIDR -ne '') {
      Write-Host "LaunchPad SubNet IP Address Range (CIDR Format) - $($this.SubNetCIDR)"
    }
    If ($this.RemoteGatewayIpAddress -ne '') {
      Write-Host "Remote IP address of the on-premises or remote VPN Endpoint - $($this.RemoteGatewayIpAddress)"
    }
    If ($this.RemoteNetworkCIDR -ne '') {
      Write-Host "Remote or On-Premises Network IP Address Range (CIDR Format) - $($this.RemoteNetworkCIDR)"
    }
    Write-Host -Object ""
    Write-Host -Object ""
  }
  [bool] IsValid() {
    If ($this.ManualSelection) {
      $this.ShowSummary()
      $deploymentConfirmed = Read-Host "Enter 'Y' to continue deployment or 'N' to start selection of parameters again"
      If ($deploymentConfirmed.ToUpperInvariant() -eq 'N') {
        $this.AzureTenant = [AzureTenant]::new()
        $this.ActiveDirectory = [ActiveDirectory]::new()
        $this.AzureSubscriptionId = ''
        $this.ResourceGroupName = ''
        $this.ResourceGroupLocation = ''
        $this.MonitoringResourceGroup = ''
        $this.AlertEmailName = ''
        $this.AlertEmailAddress = ''
        $this.VNetCIDR = ''
        $this.GatewayCIDR = ''
        $this.GatewaySKU = ''
        $this.SubNetCIDR = ''
        $this.RemoteGatewayIpAddress = ''
        $this.RemoteNetworkCIDR = ''
      }

      Return ($deploymentConfirmed.ToUpperInvariant() -eq 'Y')
    }
    Else {
      Return $true
    }
  }
}
