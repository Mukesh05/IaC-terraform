#Requires -Version 5.1

[CmdLetBinding()]
Param ()

#Region Helper Functions

#Helper Function for retrieving tenant information from REST API
Function Get-AzTenantListfromREST {
  [CmdletBinding()] Param ()
  $currentAzureContext = Get-AzContext
  $azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
  $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile)
  $token = $profileClient.AcquireAccessToken($currentAzureContext.Subscription.TenantId).AccessToken

  $headers = @{
    'Authorization' = "Bearer $token"
    'Host'          = "management.azure.com"
    'Content-Type'  = 'application/json'
  }
  $uri = "https://management.azure.com/tenants?api-version=2017-08-01"

  $response = Invoke-WebRequest -Uri $uri -Headers $headers -Method Get -UseBasicParsing
  $tenants = $response.content | ConvertFrom-Json
  $tenants = $tenants.value

  Return $tenants
}

Function Get-CurrentPublicIP {
  [CmdletBinding()] Param ()

  $headers = @{
    'Content-Type' = 'application/json'
  }

  $uri = "https://canihazip.com/s"
  $response = Invoke-WebRequest -uri $uri -Headers $headers -Method Get -UseBasicParsing
  return $response.content

}

Function Get-CurrentCountry {
  [CmdletBinding()] Param (
    [string]$IP
  )

  $headers = @{
    'Content-Type' = 'application/json'
  }

  $apikey = "?access_key=f5514ee0dcca853e583f9cc85c3d0d01"
  $baseuri = "http://api.ipstack.com/"

  $response = Invoke-WebRequest -uri $($baseuri + $IP + $apikey) -Headers $headers -Method Get -UseBasicParsing
  $response = $response.content | ConvertFrom-Json
  return $response

}

Function Start-PauseBeforeExit {
  Read-Host "Press Enter to Continue"
  exit
}
#endregion


#Region Execution

#Install the required PowerShell Module
try { Import-Module Az.ManagementPartner -RequiredVersion 0.7.1 -ErrorAction Stop | Out-Null }
catch {
  try {
    #-Scope CurrentUser is set to prevent requiring admin rights for installation
    Install-Module Az.ManagementPartner -Force -Scope CurrentUser -RequiredVersion 0.7.1
  }
  catch {
    Write-Output "Error! Issue installing required PowerShell module:`n$_"
    Start-PauseBeforeExit
  }
}

#Login to Azure if not logged in already
if ($null -eq $(Get-AzContext)) { Login-AzAccount }

#Get User Location, then deduce PAL code to associate from there
$location = $(get-currentcountry -ip $(get-currentpublicIP))
$palcode = ""
if ($location.continent_code -eq "EU") { $palcode = 931327 }
if ($location.country_name -eq "Canada") { $palcode = 549168 }
if ($location.country_name -eq "United States") { $palcode = 713499 }
if ($palcode -eq "") { $palcode = 713499 }

#List of Tenants to not associate PAL with
[System.Collections.ArrayList]$nstenants = @()
$nstenants.Add("a1a2578a-8fd3-4595-bb18-7d17df8944b0")
$nstenants.Add("6f1aa459-4cba-45cc-a9a9-3b24a8334aee")
$nstenants.Add("2423800d-a0ca-441c-aad2-7b2fbb6879c4")

#Loop through tenants
foreach ($tenant in Get-AzTenantListfromREST) {
  if ($false -eq ($nstenants -contains $tenant.TenantId)) {
    Write-Output "Associating PAL code with $($tenant.displayname)..."
    try {
      #Associate partner code with user, thus implementing partner admin link
      if ($null -eq $(Get-AzManagementPartner)) {
        New-AzManagementPartner -PartnerID $palcode
      }
      else {
        Update-AzManagementPartner -PartnerID $palcode
      }
    }
    catch {
      #Ensure we drop out of the loop & script with Start-PauseBeforeExit if there is an error
      Write-Output "Error: Unable to associate PAL code:`n$_"
    }
  }
}
Start-PauseBeforeExit

#EndRegion