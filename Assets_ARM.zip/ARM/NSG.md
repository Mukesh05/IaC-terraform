<h1>Revisions</h1>
Nov-11-2019, Rev 0.1, Initial release

<h1>Author</h1>
akhassanov@newsignature.com

<h1>Network Security Group (NSG) details</h1>
<ul>
<li>Only location and NSG name are parametarized/li>
<li>Includes custom inbound and outbound rules</li>

</ul>