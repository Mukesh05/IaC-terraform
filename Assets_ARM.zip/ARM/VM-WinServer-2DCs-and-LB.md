<h1>Revisions</h1>
Nov-15-2019, Rev 0.1, Initial release

<h1>Author</h1>
akhassanov@newsignature.com

<h1>Deployed resources</h1>
This template deploys a set of 2 Virtual Machines to be an AD Domain Controller behind internal LB.
LB is configured to host NPS/Radius service.
<ul>
<li>1 Availability Set</li>
<li>1 Internal Load Balnacer with rules for UDP:1812, UDP:1913, UDP:1645, UDP:1646</li>
<li>2 NICs with static private IP, connected to iLB pool</li>
<li>2 VMs:  tags, Windows 2016, 10 GB data manged disk </li>
<li>2 VM extension: Antimalware</li>
</ul>