This template allows deploying a Red Hat Enterprise Linux VM (RHEL 7.7, using the latest image for the selected RHEL version from the marketplace. 

This will deploy a Standard B2s VM in the location of your chosen resource group with additional data disks attached to the VM and a dynamic Public IP.


