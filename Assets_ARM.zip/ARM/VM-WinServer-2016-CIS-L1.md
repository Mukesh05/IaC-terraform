#VM-WinServer-2016-CIS-L1

##Description
This template deploys N number of Windows Server 2016 Boxs with Center for Internet Security Level 1 (CIS-L1) hardening standards using the marketplace image provided by the Center for Internet Security

It additionally will associate a managed data disk of variable size and Standard_LRS performance with each machine, as well as deploying the Antimalware Extension onto the machine with a default configuration.

###Resources Deployed
- N number of Windows Servers
- N number of Network Interfaces
- N number of Managed Disks for Data
- N number of Managed Disks for OS
- N number of Antimalware extensions

###How to use

Example parameters-

```
Virtual Machine Name : ["vmpheukscrdc01","vmpheukscrdc02","vmpheukscradc01"]
Private IP Address : ["172.30.8.10","172.30.8.11","172.30.8.12"]
Zones: ["1","2","1"]
```

The above will deploy three virtual machines, associated with the IP address and zone in the same index of the other arrays.

I.e. VM vmpheukscrdc02 will be created with IP address 172.30.8.11 in Availability Zone 2