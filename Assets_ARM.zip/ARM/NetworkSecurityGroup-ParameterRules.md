# Revisions
16/01/2020, Rev 0.1, Updated

# Author
adam.evans@newsignature.com

# Details
Alternate NSG template that takes its rules from a parameter. Allows for rules to be stored in source control and passed in through a script or CICD process.

# Project/Customer Usage
Originally created for Maersk CSP project.