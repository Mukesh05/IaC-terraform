<h1>Revisions</h1>
Nov-12-2019, Rev 0.1, Initial release

<h1>Author</h1>
akhassanov@newsignature.com

<h1>Juniper Network Virtual Appliance based on Azure Gallery Image</h1>
No code optimization was done - JSON template and parameter files were created by Azure portal.
