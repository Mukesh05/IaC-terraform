# Revisions
16/01/2020, Rev 0.2, Updated

# Author
Original author unknown
Update 16/01/2020 by adam.evans@newsignature.com

# Details
Updated template to support optional vaultStorageType parameter, allows the vault to be created as LRS storage at point of deployment

# Project/Customer Usage
