# Revisions
16/01/2020, Rev 0.1, Updated

# Author
adam.evans@newsignature.com

# Details
Template to add, replace or remove items from a KeyVault access policy. Allows the policy to be amended simply though ARM deployments rather than having to resort to scripts to amend the policy.

Requires that an idList is provided of AAD objectID's for users and service principals.

# Project/Customer Usage
Originally created for Maersk CSP project.