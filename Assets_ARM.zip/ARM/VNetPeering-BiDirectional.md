# Revisions
16/01/2020, Rev 0.1, Initial release

# Author
adam.evans@newsignature.com

# Details
Template creates Virtual Network Peering in both directions between two Virtual Networks. They can be located in the same or different subscriptions, but must be located within the same tenant.

The account (UPN/SPN) used to deploy the template will require relevant permissions in the subscription(s) containing the Virtual Networks.

# Project/Customer Usage
Originaly developed for the Maersk CSP project