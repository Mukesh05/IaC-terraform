<h1>Revisions</h1>
Nov-15-2019, Rev 0.1, Initial release

<h1>Author</h1>
akhassanov@newsignature.com

<h1>Deployed resources</h1>
This template deploys a set of Virtual Machines with corresponding resources.
Deploymnet of Azure resources marked as (opt) can be skipped by adjusting the parameter file.
<ul>
<li>(opt) availabilitySet (opt)</li>
<li>1 or more networkInterfaces: with/without PIP, liunked/unlinked form LB, Static Private IP, </li>
<li>1 or more VM:  tags, VM name dynamically generated, Azure Galary/custom VM image, datadisk </li>
<li>(opt) VM extension: Antimalware</li>
<li>(opt) VM extension: ADJoin</li>
<li>(opt) VM extension: Octopus</li>
<li>(opt) VM extension: PS script - configure Octopus</li>
<li>(opt) VM extension: PS script - initialize and format data disk</li>
<li>(opt) VM extension: OMS extention</li>
<li>(opt) PIP: can be attached to VM NIC or LB</li>
<li>(opt) internal LB</li>
<li>(opt) external LB</li>
</ul>
