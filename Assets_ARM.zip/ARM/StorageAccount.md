# Revisions
17/01/2020, Rev 0.1, Initial Release

# Author
adam.evans@newsignature.com

# Details
Deploys a Storage account with either a name prefix and uniquestring, or a specified name dependent on the parameters used.

# Project/Customer Usage
Originally written for the Maersk CSP project.