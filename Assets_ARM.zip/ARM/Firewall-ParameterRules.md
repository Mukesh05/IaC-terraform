# Revisions
16/01/2020, Rev 0.1, Updated

# Author
adam.evans@newsignature.com

# Details
Deployment of Azure Firewall with the ability to push rules (NAT, Network, Application) in through parameters. Was used in a CICD pipeline with the rules stored in source control, combined and injected into the template through the relevant parameters.

An existing Public IP address resource, and existing vNet details need to be provided as parameters.

If dynamic rules aren't required, the parameters could be removed and rules hardcored. Or for an initial blank deployment don't specify the rule parameters and it will deploy with no rules.

Includes parameter to enable Threat Protection if required

# Project/Customer Usage
Originally created for Maersk CSP project.