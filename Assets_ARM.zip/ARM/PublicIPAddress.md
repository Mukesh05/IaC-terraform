# Revisions
16/01/2020, Rev 0.1, Updated

# Author
adam.evans@newsignature.com

# Details
Template to deploy a Public IP address, with parameters to allow customisation of the properties.

Parameters allow for a DNS label to be optionally set, along with an optional six character unique string suffix on the label.

# Project/Customer Usage
Originally created for Maersk CSP project.