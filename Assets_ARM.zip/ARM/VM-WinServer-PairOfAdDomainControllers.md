<h1>Revisions</h1>
Nov-15-2019, Rev 0.1, Initial release

<h1>Author</h1>
akhassanov@newsignature.com

<h1>Deployed resources</h1>
This template deploys a set of 2 Virtual Machines to be an AD Domain Controller.
<ul>
<li>1 Availability Set</li>
<li>2 NICs with static private IP</li>
<li>2 VMs:  tags, Windows 2016, 10 GB data manged disk </li>
<li>2 VM extension: Antimalware</li>
</ul>