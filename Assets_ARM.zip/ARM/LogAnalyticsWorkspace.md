# Revisions
16/01/2020, Rev 0.1, Updated

# Author
adam.evans@newsignature.com

# Details
Creates a Log Analytics Workspace, defaults to PerGB2018 SKU but can be overridden as required.

# Project/Customer Usage
Originally created for Maersk CSP project.