<h1>Revisions</h1>
Nov-05-2019, Rev 0.1, Initial release

<h1>Author</h1>
akhassanov@newsignature.com

<h1>Deployed resources</h1>
<ul>
<li>NIC</li>
<li>One or more data disks</li>
<li>Diagnostic storage account</li>
<li>CentOS 7.5 Linux VM</li>
<li>Tags for each deployed resorce</li>
<li>Username and password from a keyvault</li>
<li>VM connects to an existing VNET\Subnet</li>
</ul>

<h1>CentOS hardening procedure</h1>

<h2>Step 1. Prepare</h2>

-
  - Logon to https://workbench.cisecurity.org
  - Download CIS\_CentOS\_Linux\_7\_v2.1.0 Remediation Kit.zip
  - Download and install https://winscp.net/
  - WinSCP to 10.100.0.197, logon as LocalAdmin
  - WinSCP CIS\_CentOS\_Linux\_7\_Benchmark\_v2.1.0.sh to Linux server/home/LocalAdmin
  - download and unzip openSSH-Win64 from https://github.com/PowerShell/Win32-OpenSSH/releases

cd C:\...\Downloads\OpenSSH-Win64\OpenSSH-Win64\

-
  - Connect to Linux server

ssh LocalAdmin@server\_ip\_address

-
  - Elevate to root (https://minionshk.wordpress.com/2016/08/12/how-to-enable-root-access-on-azure-linux-virtual-machine/)

sudo su –

-
  - Check the current root access is configured or not (LOCK means root access is disabled (default))

grep root /etc/shadow

-
  - Enable root access you should define to root password for now

passwd

-
  - Check the current root access status again

grep root /etc/shadow

<h2>Step 2. Install Java (JRE1.8)</h2>

-
  - Download from https://java.com/en/download/help/linux\_x64\_install.xml
  - WinSCP jre-8u221-linux-x64.tar.gz to Linux server/home/LocalAdmin

ssh LocalAdmin@10.100.0.197

sudo su –

cd /usr

mkdir java

cd java

tar zxvf /home/LocalAdmin/jre-8u221-linux-x64.tar.gz

<h2>Step 3. Update env. variables in profile file</h2>

cd /etc

vi profile

i

pathmunge /usr/java/jre1.8.0\_221/bin

JAVA\_HOME=/usr/java/jre1.8.0\_221/

export PATH USER LOGNAME MAIL HOSTNAME HISTSIZE HISTCONTROL

<ESC>;:wq

env

exit

sudo su –

env

<h2>Step 4. Evaluate OS before hardening</h2>

-
  - Download ciscat-full-bundle-2019-07-26-v3.0.60.zip from workbench.cisecurity.org
  - unzip file to cis-cat-full folder
  - WinSCP cis-cat-full to Linux server/home/LocalAdmin

ssh LocalAdmin@10.100.0.197

sudo su –

-
  - Grant shell script execute permissions

cd /home/LocalAdmin/cis-cat-full/

chmod +x CIS-CAT.sh

-
  - Run the script

N

Benchmark: #14 -- CIS CentOS Linux 7 Benchmark

Profile: #1 -- xccdf\_org.cisecurity.benchmarks\_profile\_Level\_1\_-\_Server

N <Enter>

-
  - Review the report in /home/LocaAdmin

<h2>Step 5. Execute the hardening script</h2>

cd /home/LocalAdmin/

sh CIS\_CentOS\_Linux\_7\_Benchmark\_v2.1.0.sh "Level 1 - Server"

<h2>Step 6. Re-evaluate OS post-hardening</h2>

cd /home/LocalAdmin/cis-cat-full/

./CIS-CAT.sh -a -f -r /home/LocalAdmin

Benchmark: #14 -- CIS CentOS Linux 7 Benchmark

Profile: #1 -- xccdf\_org.cisecurity.benchmarks\_profile\_Level\_1\_-\_Server

<Enter>

-
  - Review the report in /home/LocaAdmin
  - Copy reports for Audit

<h2>Create LocalAdmin account on CentOS</h2>

1. Log in to your server as the root user.

ssh root@server\_ip\_address

ssh [LocalAdmin@10.100.0.197]

sudo su –

2. Use the adduser command to add a new user to your system.

adduser LocalAdminSec

  - Use the passwd command to update the new user's password.

passwd LocalAdminSec

  - Set and confirm the new user's password at the prompt. A strong password is highly recommended!

Set password prompts:

Changing password for user username.

New password:

Retype new password:

passwd: all authentication tokens updated successfully.

3.  Use the usermod command to add the user to the wheel group.

usermod -aG wheel LocalAdminSec

By default, on CentOS, members of the wheel group have sudo privileges.

4.  Test sudo access on new user account
  - Use the su command to switch to the new user account.

su - LocalAdminSec

  - As the new user, verify that you can use sudo by prepending "sudo" to the command that you want to run with superuser privileges.

sudo command\_to\_run

  - For example, you can list the contents of the /root directory, which is normally only accessible to the root user.

sudo ls -la /root

  - The first time you use sudo in a session, you will be prompted for the password of the user account. Enter the password to proceed.

Output:

[sudo] password for username:

If your user is in the proper group and you entered the password correctly, the command that you issued with sudo should run with root privileges.