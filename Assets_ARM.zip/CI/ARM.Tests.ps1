# $templates = Get-ChildItem ./ARM | Where-Object { $_.Extension -match "JSON" }
# Nov-11-2019, akhassanov@newsignature.com,  exclude parameter files from validation
$templates = Get-ChildItem .\ARM | Where-Object { ($_.Extension -match "JSON") -AND ($_.NAME -notlike "*.parameters.json")}
$regexCommentFilter = '(?:[^:])(//[A-Za-z0-9 .]*)'

# 17 Jan 2020, Adam Evans, Exclude legacy files from the template parameter metadata check, else the build will fail
$paramCheckExclude = "APIManagement-Service.json","Analysis-Service.json","ApplicationGateway.json","AutomationAccounts.json","AvailabilitySet.json","AzureBatch-Service.json","AzureContainerInstance.json","AzureContainerRegistry.json","CDN-Endpoint.json","Cognitive-Service.json","Configure-JoinedADForest.json","DataFactory.json","DataLake-StoreAndAnalytics.json","CosmosDB.json","EventGrid-Topic.json","DeployAllResources.json","ExpressRoute.json","EventHub.json","Firewall.json","IOTHub.json","HDInsight-Cluster.json","Juniper-NVA.parameters.json","Juniper-NVA.md","Juniper-NVA.json","Kubernetes-Service.json","KeyVault.json","LogicApp.json","LocalNetworkGateways.json","MySqlServer-Service.json","NIC.json","NSG.parameters.json","NSG.md","NSG.json","NamingConvention.json","Network-Connections.json","PostgradeSQL.json","PowerBI.json","RedisCache.json","SearchService.json","Relay-Service.json","SqlServer-ElasticPool.json","SignalR.json","TrafficManager.json","TimeSeries.json","StreamAnalytics-Job.json","URI-Provider-All.json","VM-Linux-CentOS-CIS-Hardened.json","VM-Linux.json","VM-Linux-CentOS-CIS-Hardened.md","VM-Linux-CentOS-CIS-Hardened.parameters.json","VM-LinuxRedHat7.7.json","VM-LinuxRedHat7.7.md","VM-LinuxRedHat7.7withPIP.md","VM-LinuxRedHat7.7.parameters.json","VM-LinuxRedHat7.7withPIP.json","VM-SwissArmyKnife.json","VM-SwissArmyKnife.md","VM-LinuxRedHat7.7withPIP.parameters.json","VM-SwissArmyKnife.parameters.json","VM-WinServer-2DCs-and-LB.json","VM-WinServer-2DCs-and-LB.md","VM-WinServer-2DCs-and-LB.parameters.json","VM-WinServer-DomainJoinedJumpBox.json","VM-WinServer-JoinADForest.json","VM-WinServer-NewADForest.json","VM-WinServer-PairOfAdDomainControllers.json","VM-WinServer-PairOfAdDomainControllers.md","VM-WinServer-PairOfAdDomainControllers.parameters.json","VM-Windows.json","VMSS.json","VMs-RecoveryServiceVault-Backup.json","VMs-WinServer-DomainJoined.json","VNet-DnsServerAndGatewaySubnet.json","VNet-DnsServer.json","VNet.json","VNet-GatewaySubnet.json","VNet-NsgRules.json","VNetPeering.json","VNetVpnGateways.json","WebApp-Windows.json"

Describe 'Testing ARM Templates' {

    Foreach ($template in $templates) {
        Context "Testing $($template.Name) : $($template.FullName)" {
            $msg = "Checks the Template ["+$($template.Name)+"] is valid JSON"
            It "$msg" {
                Write-Output "Filename and path : $($template.FullName)"
                $content = Get-Content "$($template.FullName)"
                $content = [regex]::Replace($content, $regexCommentFilter, "") #Regex to remove ARM comments from JSON before checking validity
                $json = $content | ConvertFrom-JSON -ErrorAction Stop
                $json | Should not be $null
            }

            # 17 Jan 2020, Adam Evans, Addtional test added to ensure that new Template have descriptions in the meta data for all parameters in a template
            # Check and see if the template name is the exclusion list at the beginning of this script
            If ($template.Name -notin $paramCheckExclude) {
              # Load the template in and convert from JSON, can't use the object above as that is in an "It" so can't be referenced properly
              $json = Get-Content $template.fullname | ConvertFrom-Json
              # Get the parameters from the template
              $jsonParams = $json.parameters

              # Loop through each parameter, have to use the PSObject properties to get the names of each parameter
              Foreach ($jsonParam in $jsonParams.PSObject.Properties) {
                # Retrieve the parameter name
                $paramName = $jsonParam.Name
                # Get the parameter values, by selecting the parameter from the original parameters object and expand on the parameter property so we can compare its contents
                $paramValues = $jsonParams | Select-object $paramName -ExpandProperty $paramName
                It "Check parameter $($paramName) in template $($template.Name) has metadata descriptions on all template parameters" {
                  $paramValues.metadata.description | Should not be $null
                }
              }
            }
         }

    }
}

Describe 'Self-test: Validate regex comment filter will strip comments, but not affect URIs' {
    $inputJsonDocument = `
@'
{
    "contentVersion": "1.0.0.0",
    "$schema": "https://schema.management.azure.com/schemas/2015-01-01/deploymentTemplate.json#",
    "parameters": {
        "dataFactoryName": {
            "type": "string",
            "defaultValue": "[concat('adf-', uniqueString(resourceGroup().id))]",
            "metadata": {
                "description": "Name of the data factory. Must be globally unique."  // comment with spaces
            }
        }
    },
    "variables": {},
    "resources": [ // comment here
        {
            "type": "Microsoft.DataFactory/factories",
            "apiVersion": "2018-06-01",
            "name": "[parameters('dataFactoryName')]",
            "location": "[resourceGroup().location]",
            "identity": {
                "type": "SystemAssigned"
            }
        }
    ] //comment here
}
'@

    $expectedJsonDocument = `
@'
{
    "contentVersion": "1.0.0.0",
    "$schema": "https://schema.management.azure.com/schemas/2015-01-01/deploymentTemplate.json#",
    "parameters": {
        "dataFactoryName": {
            "type": "string",
            "defaultValue": "[concat('adf-', uniqueString(resourceGroup().id))]",
            "metadata": {
                "description": "Name of the data factory. Must be globally unique."
            }
        }
    },
    "variables": {},
    "resources": [
        {
            "type": "Microsoft.DataFactory/factories",
            "apiVersion": "2018-06-01",
            "name": "[parameters('dataFactoryName')]",
            "location": "[resourceGroup().location]",
            "identity": {
                "type": "SystemAssigned"
            }
        }
    ]
}
'@
    $result =  [regex]::Replace($inputJsonDocument, $regexCommentFilter, "")

    it 'should not contain comments' {
        ($result.contains('comment')) | should be $false
    }

    it 'should contain unaffected uris' {
        ($result.contains('https://schema.management.azure.com/schemas/2015-01-01/deploymentTemplate.json#')) | should be $true
    }

    it 'should json deserialize expected data' {
        $json = $expectedJsonDocument | ConvertFrom-JSON -ErrorAction Stop
        $json | Should not be $null
    }

    it 'should json deserialize result data' {
        $json = $result | ConvertFrom-JSON -Verbose -ErrorAction Stop
        $json | Should not be $null
    }
}
