The customRBACrolesTemplate.json ARM template deploys 5 custom RBAC roles:
- SLA Private DNS zone joiner = has the ability to join resources in private DNS zone
- SLA Subnet joiner = has the ability to join resources in subnets of VNETs
- SLA Deployment = has the ability to do deployemnts of resources
- SLA Private endpoints = has the ability to manage private endpoints (creating and deleting them)
- SLA Locking = has the ability to manage locks (read/write/delete)


The ARM template can be easily deployed through PowerShell command:
New-AzDeployment -location northeurope -TemplateFile customRBACrolesTemplate.json

No parameters are required to be configured for this script.