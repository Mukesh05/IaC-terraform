The Monitoring & Alerting piece consists of 3 subparts:

1) Deploy ActionGroup

the deploy-actiongroup.json + parameters.deploy-actiongroup.json ARM templates deploy 1 ActionGroup that is meant to handle Alerts inside Azure.

The ARM templates deploys a single resource, an ActionGroup, which handles an ITSM receiver, so that integration with ServiceNow (or other ITSMs) will be made.

This script requires some pre-requisites: 
For the deployment to work, a connection to ServiceNow must exist inside Azure.

As parameters, the following have been defined:
- actionGroupName = the desired name of the actionGroup
- actionGroupShortName = the desired short-name of the actionGroup
- itsmReceivers = this parameters contains details about the pre-requisite connection to the ITSM. It requires its name, workspaceId, connectionId, ticketConfiguration and region.

The ARM template can be easily deployed through PowerShell command:
New-AzResouceGroupDeployment -Mode Incremental -ResourceGroupName <nameofRG> -TemplateFile deploy-actiongroup.json -TemplateParameterFile parameters.deploy-actiongroup.json
---------------

2) Deploy Alerts

the deploy-alerts.json + parameters.deploy-alerts.json ARM templates deploy a total of 31 pre-defined alerts in Azure that are meant to monitor standard actions regarding App Services, SQL, API Management, etc.

The script requires some pre-requisites:
For the deployment to work, a Log Analytics Workspace and an ActionGroup must exist inside Azure.
The alerts link-up with an ActionGroup, so presumably step-1 needs to be executed before-hand.

As parameters, the following have been defined:
- subscriptionID = the subscription ID where the alerts where the Log Analytics Workspace and ActionGroup are located
- workspaceName = the name of the Log Analytics Workspace holding the diagnostics logs of the resources
- workspaceResourceGroup = the RG of the Log Analytics Workspace
- location = the Azure location where the alerts will be deployed
- actionGroupName = the actionGroup to which the alerts will be linked
- actionGroupResourceGroup = the RG of the actionGroup

The ARM template can be easily deployed through PowerShell command:
New-AzResourceGroupDeployment -Mode Incremental -ResourceGroupName <nameofRG> -TemplateFile deploy-alerts.json -TemplateParameterFile parameter.deploy-alerts.json
---------------

3) Deploy Policies

The sub-folder Policies-LogAnalytics&eventHub contains a series of JSONs and PowerShell scripts that are nested and trigger each other.

The main (and only file) that needs to be trigged for the policies to be deployed is deploy-policies.ps1
It is important that the folder/file structure to remain the same, as deploy-policies.ps1 triggers all the other PowerShell scripts and JSON files for deployment.

The script deploys 15 custom policies and afterwards it creates an policySet with these 15 custom policies + 7 built-in from Azure. As a final step, the initiative is assigned to an Azure subscription.

The script requires some pre-requisites:
For the deployment to work, a Log Analytics Workspace and an eventHub must exist inside Azure, so that all logs defined by the policies will be fed into these resources. the eventHub must contain an Authorization Rule (preferably with all permissions assigned).

As parameters, the following have been defined:
- subscriptionID = the subscription ID on which the policies and initiative will be defined and assigned
- location = the location of of the policies and initiative
- logAnalyticsWorkspaceName = the name of the pre-existing logAnalyticsWorkspaceName
- eventHubRG = the RG of the pre-existing eventHub
- eventHubNamespace = the name of the pre-existing eventHub
- eventHubAuthorizationRule = the name of the authorization rule set on the pre-existing eventHub
