﻿$subscriptionID = "c1319338-2a94-4cd5-a59a-e7233cf51c0e"
$location = "westeurope"
$logAnalyticsWorkspaceName = "DefaultWorkspace-c1319338-2a94-4cd5-a59a-e7233cf51c0e-WEU"
$eventHubRG = "sla-rg"
$eventHubNamespace = "sla-logs-event-hub"
$eventHubAuthorizationRule = "sla-test"


$eventHubRuleId = "/subscriptions/" + $subscriptionID + "/resourceGroups/" + $eventHubRG + "/providers/Microsoft.EventHub/namespaces/" + $eventHubNamespace + "/authorizationrules/" + $eventHubAuthorizationRule
$policiesFolder = Resolve-path "Policies"
$policiesSetFile = Resolve-path "PolicySet\policyset.json"

.\deploy-policyDef.ps1 -folderPath $policiesFolder.Path -Recurse -subscriptionId $subscriptionID
.\deploy-policySetDef.ps1 -definitionFile $policiesSetFile.Path -subscriptionId $subscriptionID


$definition = Get-AzPolicySetDefinition | Where-Object { $_.Properties.DisplayName -eq 'SLA Initiative' }
New-AzPolicyAssignment -Name "sla-initiative" -DisplayName "SLA - Initiative" -PolicySetDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -logAnalytics $logAnalyticsWorkspaceName -eventHubNamespace $eventHubNamespace -eventHubRuleId $eventHubAuthorizationRule -eventHubRG $eventHubRG -eventHubRGLocation $location


#uncomment this paragraph or part of it if you want to assign the policies (or some of them) individually
<#
$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Enable Diagnostics - Activity Log - send to central Log Analytics and Event Hub' }
New-AzPolicyAssignment -Name "activity-log-deploy-diag-settings" -DisplayName "SLA - Deploy Diagnostic settings for Activity Log" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -logAnalytics $logAnalyticsWorkspaceName -eventHubName $eventHubNamespace -eventHubRuleId $eventHubRuleId

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Enable Diagnostics - API Management - send to central Log Analytics' }
New-AzPolicyAssignment -Name "api-management-deploy-diag-settings" -DisplayName "SLA - Deploy Diagnostic settings for API Management" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -logAnalytics $logAnalyticsWorkspaceName

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Enable Diagnostics - App Services - send to central Log Analytics and Event Hub' }
New-AzPolicyAssignment -Name "app-service-deploy-diag-settings" -DisplayName "SLA - Deploy Diagnostic settings for App Services" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -logAnalytics $logAnalyticsWorkspaceName -eventHubName $eventHubNamespace -eventHubRuleId $eventHubRuleId

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Enable Diagnostics - Automation Accounts - send to central Log Analytics' }
New-AzPolicyAssignment -Name "automation-accounts-deploy-diag-settings" -DisplayName "SLA - Deploy Diagnostic settings for Automation Accounts" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -logAnalytics $logAnalyticsWorkspaceName

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Enable Diagnostics - CosmosDB - send to central Log Analytics' }
New-AzPolicyAssignment -Name "cosmos-db-deploy-diag-settings" -DisplayName "SLA - Deploy Diagnostic settings for Cosmos DB" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -logAnalytics $logAnalyticsWorkspaceName

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Enable Diagnostics - Data Lake Store - send to central Log Analytics' }
New-AzPolicyAssignment -Name "datalake-store-deploy-diag-settings" -DisplayName "SLA - Deploy Diagnostic settings for Data Lake Store" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -logAnalytics $logAnalyticsWorkspaceName

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Enable Diagnostics - Logic App Integration Accounts - send to central Log Analytics' }
New-AzPolicyAssignment -Name "logicapp-integrationaccounts-deploy-diag-settings" -DisplayName "SLA - Deploy Diagnostic settings for Logic App Integration Accounts" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -logAnalytics $logAnalyticsWorkspaceName

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Enable Diagnostics - Logic App Workflows - send to central Log Analytics' }
New-AzPolicyAssignment -Name "logicapp-workflows-deploy-diag-settings" -DisplayName "SLA - Deploy Diagnostic settings for Logic App Workflows" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -logAnalytics $logAnalyticsWorkspaceName

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Enable Diagnostics - Redis Cache - send to central Log Analytics' }
New-AzPolicyAssignment -Name "redis-cache-deploy-diag-settings" -DisplayName "SLA - Deploy Diagnostic settings for Redis" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -logAnalytics $logAnalyticsWorkspaceName

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Enable Diagnostics - SQL Managed Instance - send to central Log Analytics' }
New-AzPolicyAssignment -Name "sql-managedinstance-deploy-diag-settings" -DisplayName "SLA - Deploy Diagnostic settings for SQL Managed Instance" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -logAnalytics $logAnalyticsWorkspaceName

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Enable Diagnostics - SQL Managed Instance Databases - send to central Log Analytics' }
New-AzPolicyAssignment -Name "sql-managedinstancedb-deploy-diag-settings" -DisplayName "SLA - Deploy Diagnostic settings for SQL Managed Instance Database" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -logAnalytics $logAnalyticsWorkspaceName

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Deploy Log analytics Auditing Settings to Event Hub' }
New-AzPolicyAssignment -Name "loganalytics--deploy-auditing-settings" -DisplayName "SLA - Deploy Log analytics Auditing Settings to Event Hub" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -eventHubName $eventHubNamespace -eventHubRuleId $eventHubRuleId

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Enable Auditing - SQL Managed Instance - send to central Log Analytics and Event Hub' }
New-AzPolicyAssignment -Name "auditing-sql-mi-deploy" -DisplayName "SLA - Enable Auditing - SQL Managed Instance - send to central Log Analytics and Event Hub" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -logAnalytics $logAnalyticsWorkspaceName -eventHubName $eventHubNamespace -eventHubRuleId $eventHubRuleId

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Enable Auditing - SQL Server - send to central Log Analytics and Event Hub' }
New-AzPolicyAssignment -Name "auditing-sql-server-deploy" -DisplayName "SLA - Enable Auditing - SQL Server - send to central Log Analytics and Event Hub" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -logAnalytics $logAnalyticsWorkspaceName -eventHubName $eventHubNamespace -eventHubRuleId $eventHubRuleId

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Deploy Azure Security Center Pricing Tier' }
New-AzPolicyAssignment -Name "turn-on-azure-defender-plan" -DisplayName "SLA - Turn on Azure Defender Plan" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -virtualMachinesTier Free -appServicesTier Standard -sqlServersTier Standard -sqlServerVirtualMachinesTier Free -storageAccountsTier Standard -kubernetesServiceTier Free -containerRegistryTier Free -keyVaultsTier Standard



#assigning built-in policies
$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Deploy Diagnostic Settings for Data Lake Analytics to Log Analytics workspace' }
New-AzPolicyAssignment -Name "datalake-analytics-deploy-diag-settings" -DisplayName "SLA - Deploy Diagnostic settings for Key Vault" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -logAnalytics $logAnalyticsWorkspaceName

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Deploy Diagnostic Settings for Key Vault to Event Hub' }
New-AzPolicyAssignment -Name "key-vault-deploy-diag-settings-eventhub" -DisplayName "SLA - Deploy Diagnostic settings for Key Vault to EventHub" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -eventHubRuleId $eventHubRuleId

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Deploy Diagnostic Settings for Logic Apps to Log Analytics workspace' }
New-AzPolicyAssignment -Name "logic-apps-deploy-diag-settings" -DisplayName "SLA - Deploy Diagnostic settings for Logic Apps" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -logAnalytics $logAnalyticsWorkspaceName

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Deploy - Configure diagnostic settings for SQL Databases to Log Analytics workspace' }
New-AzPolicyAssignment -Name "sql-database-deploy-diag-settings" -DisplayName "SLA - Deploy diagnostic settings to SQL Databases" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -logAnalytics $logAnalyticsWorkspaceName

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Deploy Diagnostic Settings for Azure SQL Database to Event Hub' }
New-AzPolicyAssignment -Name "sql-database-deploy-diag-settings-eventhub" -DisplayName "SLA - Deploy diagnostic settings to SQL Servers to Event Hub" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -eventHubRuleId $eventHubRuleId

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Deploy Advanced Data Security on SQL servers' }
New-AzPolicyAssignment -Name "sql-server-deploy-VA-and-ATP" -DisplayName "SLA - Deploy Azure SQL Vulnerability Assessment and ATP" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Deploy export to Event Hub for Azure Security Center data' }
New-AzPolicyAssignment -Name "ASC-data-deploy-export-eventhub" -DisplayName "SLA - Deploy export to EventHub for ASC data" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -resourceGroupName $eventHubRG  -resourceGroupLocation $location -eventHubDetails $eventHubRuleId
#>