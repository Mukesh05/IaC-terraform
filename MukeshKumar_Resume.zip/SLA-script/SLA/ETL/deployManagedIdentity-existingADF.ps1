﻿$datafactoryName1 = "nameofdatafactory1"
$datafactoryName2 = "nameofdatafactory2"
$ResourceGroupName = "RGofDataFactories"
$location = "locationofdatafactories"

Set-AzDataFactoryV2 -ResourceGroupName $ResourceGroupName -Name $datafactoryName1 -Location $location -Force
Set-AzDataFactoryV2 -ResourceGroupName $ResourceGroupName -Name $datafactoryName2 -Location $location -Force