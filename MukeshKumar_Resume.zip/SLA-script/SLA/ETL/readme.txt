The ETL piece consists of 3 sub-parts:

1) Custom RBAC Role - ADF pipeline executor
The customRBACrolesTemplate-ADF-pipeline-executor.json ARM template deploys 1 custom RBAC roles that has the ability to create runs in an Azure Data Factory pipeline.

The ARM template can be easily deployed through PowerShell command:
New-AzDeployment -location northeurope -TemplateFile customRBACrolesTemplate-ADF-pipeline-executor.json

No parameters are required to be configured for this script.
---------------

2) Terraform files creating ETL resources (still in progress)
The sub-folder terraform-ETL contains 2 files - main.tf + parameters.tfvars.
the main file handles the creation of the following resources via terraform:
- creation of 2 Azure Data Factories
- creation of a specified number of Azure VMs and Azure NIC that are integrated in a pre-existing subnet.

This script requires some pre-requisites: 
For the deployment to work, an VNET with a dedicated subnet in which VMs will be placed must exist before-hand

As parameters, the following have been defined:
rgname = the name of the existing resource group where the ADFs + VMs will be deployed
- location = the Azure location where the resources will be deployed
- datafactoryname1 = the name of the first ADF
- datafactoryname2 = the name of the second ADF
- adminusername = the username that will be used for windows/RDP login into the VMs
- adminpassword = the password that will be used for windows/RDP login into the VMS
- vmprefix = the prefix that will be used as naming for the VMs. Example: if the vmprefix is set as "nameofvms", then the VMs will be created as "nameofvms-1", "nameofvms-2", etc.
- vmcount = the number of the VMs that will be created
- vmsku = the Windows OS of the VMs. Can be "2012-Datacenter", "2016-DatacenteR", "2019-Datacenter", etc
- vmsize = the Azure size of the VMs
- vnetname = the pre-existing VNET where the VMs will be placed
- subnetname = the pre-existing subnet where the VMs will be placed
- vnetrgname = the RG of the pre-existing VNET where the VMs will be placed

An example of how parameters can be defined can be found in parameters.tfvars file
---------------

3) Ensure existence of ManagedIdentity for Azure Data Factory

After Azure Data Factories have been deployed (presumably with step-2), a PowerShell script is required to ensure that System Assigned Managed Identities will be created for the ADFs

deployManagedIdentity-existingADF.ps1 script is handling this. Once executed, System Assigned Managed Identities will exist for the ADFs.

As parameters, the following have been defined:
- datafactoryName1 = name of the first ADF
- datafactoryName2 = name of the second ADF
- ResourceGroupName = name of the RG hosting the ADFs
- location = the Azure location to which the the ADFs have been deployed

