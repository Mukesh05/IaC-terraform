﻿$ActionGroupName = "test-actiongroup"
$ActionGroupRG = "sla-spoketest-rg"

$actiongroup = Get-AzActionGroup -Name $ActionGroupName -ResourceGroup $ActionGroupRG -WarningAction Ignore
 
$ServiceHealthRegions = @(
                    "North Europe"
                    )
                     
$params = @{
    LogAlertName = "Azure Health Service Notification"
    ServiceHealthRegions = $ServiceHealthRegions
    actiongroupresourceid = $actiongroup.id
}
 
New-AzResourceGroupDeployment -Name "Azure-Service-AlertNotification" -ResourceGroupName $ActionGroupRG -TemplateFile .\ServiceHealthAlert.json -TemplateParameterObject $params