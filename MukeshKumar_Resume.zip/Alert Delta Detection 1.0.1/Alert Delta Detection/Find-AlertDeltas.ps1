﻿[CmdletBinding()]

Param(
  [string] $ResourceGroupName
)

#Verify target subscription is in context
If ((Get-AzContext) -eq $null){
    Write-Host "No Azure Context found. Collecting connection information from user..."
    $TenantId = Read-Host "Provide the Azure Tenant ID"
    $SubscriptionId = Read-Host "Provide the Azure Subscription ID where Drivetrain is installed"
    Connect-AzAccount -Tenant $TenantId -Subscription $SubscriptionId
}
Else {
    Write-Host "You are currently connected to subscription: $((Get-AzContext).Subscription.Name)" -ForegroundColor Yellow
    If ((Read-Host "Is this the correct subscription? Y/N") -notlike "y") {
        Write-Host "Please update your Azure Context to target the correct subscription, or log out of Azure PowerShell, and rerun this script."
        exit
    }
}

# Determine ResourceGroupName if not provided
If ($ResourceGroupName -eq ''){
  Write-Host "Checking for existing monitoring installation in subscription $((Get-AzContext).Subscription.Id)" 
  Write-Host "Auto Sensing Resource Group"
  $ResourceGroup = Get-AzResourceGroup -Tag @{ 'NS-DriveTrain' = $null }

  If (($ResourceGroup | Measure-Object).Count -eq 0) {
    # If there is no resource group with the NS-Drivetrain tag.
    Write-Host "Resource Group scanning failed. Requesting User Input for Resource Group"
    $ResourceGroupName = (Read-Host -Prompt "Please enter the name of the resource group in subscription $SubscriptionId")
  }
    ElseIf (($ResourceGroup | Measure-Object).Count -eq 1) {
    # If there is an existing Resource Group with the NS-Drivetrain tag
    Write-Host "Found existing Monitoring installation in $($ResourceGroup.ResourceGroupName)!" 
    $ResourceGroupName = $ResourceGroup.ResourceGroupName
    $installedVersion = $ResourceGroup.Tags.Values
    $installedVersion = ($installedVersion.Trim()).SubString(0, 5)
    Write-Host "The Monitoring version installed is : $($installedVersion)"
  }
  Else {
    throw "There is more than one resource group with a DriveTrain tag. Please rerun the script, specifying the target Resource Group as a parameter. Terminating."
  }
}
# Determine name of alert rule file to compare
$FileName = [System.String]::Concat("Release", $installedVersion, "_alerts.json")

$alertArchivePath = "$PSScriptRoot\oldAlerts"

# Retrieve OOTB alert rules from disk

$ootbMetricRules = (Get-Content -Path $alertArchivePath\$FileName | ConvertFrom-Json).outputs.metricAlerts.value | Sort-Object -Property "name"
$ootbSQRRules = (Get-Content -Path $alertArchivePath\$FileName | ConvertFrom-Json).outputs.SQRAlerts.value + `
                (Get-Content -Path $alertArchivePath\$FileName | ConvertFrom-Json).outputs.SQRMetrics.value `
                | Sort-Object -Property "name"

# Fetch and store Alert Rules deployed in Azure

$azMetricAlerts = Get-AzResource -ResourceGroupName $ResourceGroupName -ResourceType microsoft.insights/metricAlerts -ExpandProperties
$azSQRAlerts = Get-AzResource -ResourceGroupName $ResourceGroupName -ResourceType microsoft.insights/scheduledqueryrules -ExpandProperties

<#

Property Mapping

Mapping Metric Alerts

Property: OOTB = Azure
---------------------------
Alert Rule Name: $ootbMetricRules[i].name = $azMetricAlerts[i].Name
Severity: $ootbMetricRules[i].severity = $azMetricAlerts[i].Properties.severity
Enabled: (OOTB enabled by default) = $azMetricAlerts[i].Properties.enabled
Evaluation Frequency: $ootbMetricRules[i].evaluationFrequency = $azMetricAlerts[i].Properties.evaluationFrequency
Window Size: $ootbMetricRules[i].windowSize = $azMetricAlerts[i].Properties.windowSize
Threshold: $ootbMetricRules[i].criterion.threshold = $azMetricAlerts[i].Properties.criteria.allOf[0].threshold
Metric Name: $ootbMetricRules[i].criterion.metricName = $azMetricAlerts[i].Properties.criteria.allOf[0].metricName
Dimensions Name: $ootbMetricRules[i].criterion.dimensions[j].name = $azMetricAlerts[i].Properties.criteria.allOf[0].dimensions[j].name
Dimensions Operator: $ootbMetricRules[i].criterion.dimensions[j].operator = $azMetricAlerts[i].Properties.criteria.allOf[0].dimensions[j].operator
Dimensions Value: $ootbMetricRules[i].criterion.dimensions[j].values = $azMetricAlerts[i].Properties.criteria.allOf[0].dimensions[j].values
Operator: $ootbMetricRules[i].criterion.operator = $azMetricAlerts[i].Properties.criteria.allOf[0].operator
Time Aggregation: $ootbMetricRules[i].criterion.timeAggregation = $azMetricAlerts[i].Properties.criteria.allOf[0].timeAggregation


Mapping SQR Alerts

Property: OOTB = Azure
---------------------------
Name: $ootbSQRRules[i].name = $azSQRAlerts[i].Name
Severity: $ootbSQRRules[i].severity = $azSQRAlerts[i].Properties.action.severity
Enabled: (OOTB Enabled by default) = $azSQRAlerts[i].Properties.enabled
Evaluation Frequency: $ootbSQRRules[i].schedule.frequency = $azSQRAlerts[i].Properties.schedule.frequencyInMinutes
Window Size: $ootbSQRRules[i].schedule.timeWindow = $azSQRAlerts[i].Properties.schedule.timeWindowInMinutes
Query: $ootbSQRRules[i].source.query = $azSQRAlerts[i].Properties.source.query
Threshold Operator: $ootbSQRRules[i].trigger.thresholdOperator = $azSQRAlerts[i].Properties.action.trigger.thresholdOperator
Threshold: $ootbSQRRules[i].trigger.threshold = $azSQRAlerts[i].Properties.action.trigger.threshold

#>

$htmlFrags = @()

$htmlFrags += "<h1> Alert Rule Delta Report </h1> <h2>Drivetrain Monitoring version: $($installedVersion) <br> Subscription: $((Get-AzContext).Subscription.Name) </h2>"

$htmlFrags += @"
    <p>This report was generated by the Find-AlertDeltas.ps1 script, written by Brendan Thomas on the Platform Services Team. <br>
    Below is a summary of any changes between Drivetrain Monitoring Alert Rules in a customer environment and their OOTB configuration. ONLY properties that have changed are documented here; if an Alert Rule property is not listed, it was not changed from the OOTB configuration.<br>
"@

Write-Host "Processing Metric Alert Rules..."

ForEach ($alert in $azMetricAlerts) {
    $ootbAlertRule = $ootbMetricRules | Where-Object {$_.name -eq $alert.Name}

    $diff = New-Object -TypeName PSObject

    If ($null -ne $ootbAlertRule) {

        If ($null -ne (Compare-Object $ootbAlertRule.severity $alert.Properties.severity)){
            $diff | Add-Member -MemberType NoteProperty -Name "Severity" -Value $alert.Properties.severity
        }

        If ($alert.Properties.enabled -eq $false){
            $diff | Add-Member -MemberType NoteProperty -Name "Enabled" -Value "False"
        }

        If ($null -ne (Compare-Object $ootbAlertRule.evaluationFrequency $alert.Properties.evaluationFrequency)){
            $diff | Add-Member -MemberType NoteProperty -Name "Evaluation Frequency" -Value $alert.Properties.evaluationFrequency
        }

        If ($null -ne (Compare-Object $ootbAlertRule.windowSize $alert.Properties.windowSize)){
            $diff | Add-Member -MemberType NoteProperty -Name "Window Size" -Value $alert.Properties.windowSize
        }

        If ($null -ne (Compare-Object $ootbAlertRule.criterion.threshold $alert.Properties.criteria.allOf[0].threshold)){
            $diff | Add-Member -MemberType NoteProperty -Name "Threshold" -Value $alert.Properties.criteria.allOf[0].threshold
        }

        If ($null -ne (Compare-Object $ootbAlertRule.criterion.metricName $alert.Properties.criteria.allOf[0].metricName)){
            $diff | Add-Member -MemberType NoteProperty -Name "Metric Name" -Value $alert.Properties.criteria.allOf[0].metricName
        }

        If ($null -ne (Compare-Object $ootbAlertRule.criterion.operator $alert.Properties.criteria.allOf[0].operator)){
            $diff | Add-Member -MemberType NoteProperty -Name "Operator" -Value $alert.Properties.criteria.allOf[0].operator
        }

        If ($null -ne (Compare-Object $ootbAlertRule.criterion.timeAggregation $alert.Properties.criteria.allOf[0].timeAggregation)){
            $diff | Add-Member -MemberType NoteProperty -Name "Time Aggregation" -Value $alert.Properties.criteria.allOf[0].timeAggregation
        }

        For ($i = 0; $i -lt $ootbAlertRule.criterion.dimensions.count; $i++){

            $ootbAlertDim = $ootbAlertRule.criterion.dimensions[$i] 

            $azAlertDim = $alert.Properties.criteria.allOf[0].dimensions | Where-Object {$_.name -eq $ootbAlertDim.name}

            If ($null -eq $azAlertDim){
                $diff | Add-Member -MemberType NoteProperty -Name "Dimension Removed $i" -Value $ootbAlertDim.name

            }

            Else{
                If ($null -ne (Compare-Object $ootbAlertDim $azAlertDim -Property name, operator, values)){
                    $diff | Add-Member -MemberType NoteProperty -Name "Dimension$i Name" -Value $azAlertDim.name
                    $diff | Add-Member -MemberType NoteProperty -Name "Dimension $i Operator" -Value $azAlertDim.operator
                    $diff | Add-Member -MemberType NoteProperty -Name "Dimension $i Value" -Value $azAlertDim.values
                }
            }
        }

        If (($diff | Get-Member -MemberType NoteProperty).Count -ne 0){
            $alertName = $alert.Name
            $htmlFrags += $diff | ConvertTo-Html -Fragment -PreContent "<h2> $alertName </h2>" -PostContent "<br>" -As List
        }
    }
    #ElseIf ($azSQRAlerts.name.Contains($alert.Name)) {
    #    Write-Verbose ("Alert Rule " + $alert.Name + " is a SQR alert, Omitting from report.")
    #}
    Else {
        Write-Verbose ("Alert Rule " + $alert.Name + " Not found in OOTB Configuration. Adding entire rule to report.")
        $diff | Add-Member -MemberType NoteProperty -Name "Severity" -Value $alert.Properties.severity
        $diff | Add-Member -MemberType NoteProperty -Name "Enabled" -Value "False"
        $diff | Add-Member -MemberType NoteProperty -Name "Evaluation Frequency" -Value $alert.Properties.evaluationFrequency
        $diff | Add-Member -MemberType NoteProperty -Name "Window Size" -Value $alert.Properties.windowSize
        $diff | Add-Member -MemberType NoteProperty -Name "Threshold" -Value $alert.Properties.criteria.allOf[0].threshold
        $diff | Add-Member -MemberType NoteProperty -Name "Metric Name" -Value $alert.Properties.criteria.allOf[0].metricName
        $diff | Add-Member -MemberType NoteProperty -Name "Operator" -Value $alert.Properties.criteria.allOf[0].operator
        $diff | Add-Member -MemberType NoteProperty -Name "Time Aggregation" -Value $alert.Properties.criteria.allOf[0].timeAggregation
        For ($i = 0; $i -lt $alert.Properties.criteria.allOf[0].dimensions.count; $i++){
            $azAlertDim = $alert.Properties.criteria.allOf[0].dimensions[$i]
            $diff | Add-Member -MemberType NoteProperty -Name "Dimension$i Name" -Value $azAlertDim.name
            $diff | Add-Member -MemberType NoteProperty -Name "Dimension $i Operator" -Value $azAlertDim.operator
            $diff | Add-Member -MemberType NoteProperty -Name "Dimension $i Value" -Value $azAlertDim.values
        }
        $alertName = $alert.Name
        $htmlFrags += $diff | ConvertTo-Html -Fragment -PreContent "<h2> $alertName </h2>" -PostContent "<br>" -As List
    }
}

Write-Host "Processing Scheduled Query Rules..."
ForEach ($alert in $azSQRAlerts){
    $ootbAlertRule = $ootbSQRRules | Where-Object {$_.name -eq $alert.Name}

    $diff = New-Object -TypeName PSObject

    If ($null -ne $ootbAlertRule){
        If ($null -ne (Compare-Object $ootbAlertRule.severity $alert.Properties.action.severity)){
            $diff | Add-Member -MemberType NoteProperty -Name "Severity" -Value $alert.Properties.action.severity
        }

        If ($alert.Properties.enabled -eq $false){
            $diff | Add-Member -MemberType NoteProperty -Name "Enabled" -Value "False"
        }

        If ($null -ne (Compare-Object $ootbAlertRule.schedule.frequency $alert.Properties.schedule.frequencyInMinutes)){
            $diff | Add-Member -MemberType NoteProperty -Name "Evaluation Frequency" -Value $alert.Properties.schedule.frequencyInMinutes
        }

        If ($null -ne (Compare-Object $ootbAlertRule.schedule.timeWindow $alert.Properties.schedule.timeWindowInMinutes)){
            $diff | Add-Member -MemberType NoteProperty -Name "Window Size" -Value $alert.Properties.schedule.timeWindowInMinutes
        }

        If ($null -ne (Compare-Object $ootbAlertRule.source.query $alert.Properties.source.query)){
            $diff | Add-Member -MemberType NoteProperty -Name "Query" -Value $alert.Properties.source.query
        }

        If ($null -ne (Compare-Object $ootbAlertRule.trigger.thresholdOperator $alert.Properties.action.trigger.thresholdOperator)){
            $diff | Add-Member -MemberType NoteProperty -Name "Operator" -Value $alert.Properties.action.trigger.thresholdOperator
        }

        If ($null -ne (Compare-Object $ootbAlertRule.trigger.threshold $alert.Properties.action.trigger.threshold)){
            $diff | Add-Member -MemberType NoteProperty -Name "Threshold" -Value $alert.Properties.action.trigger.threshold
        }

        If (($diff | Get-Member -MemberType NoteProperty).Count -eq 1){
            $alertName = $alert.Name
            $propName = ($diff | Get-Member -MemberType NoteProperty).Name
            $htmlFrags += $diff | ConvertTo-Html -Fragment -PreContent "<h2> $alertName </h2>" -PostContent "<br>" -As List | % { $_ -replace '/*:', $propName }
        }
        
        ElseIf (($diff | Get-Member -MemberType NoteProperty).Count -ne 0){
            $alertName = $alert.Name
            $htmlFrags += $diff | ConvertTo-Html -Fragment -PreContent "<h2> $alertName </h2>" -PostContent "<br>" -As List
        }
    }
    ElseIf ($azMetricAlerts.name.Contains($alert.Name)) {
        Write-Verbose ("Alert Rule " + $alert.Name + " is a metric alert, Omitting from report.")
    }
    Else{
        Write-Verbose ("Alert Rule " + $alert.Name + " Not found in OOTB Configuration. Adding entire rule to report.")
        $diff | Add-Member -MemberType NoteProperty -Name "Severity" -Value $alert.Properties.action.severity
        $diff | Add-Member -MemberType NoteProperty -Name "Enabled" -Value "False"
        $diff | Add-Member -MemberType NoteProperty -Name "Evaluation Frequency" -Value $alert.Properties.schedule.frequencyInMinutes
        $diff | Add-Member -MemberType NoteProperty -Name "Window Size" -Value $alert.Properties.schedule.timeWindowInMinutes
        $diff | Add-Member -MemberType NoteProperty -Name "Query" -Value $alert.Properties.source.query
        $diff | Add-Member -MemberType NoteProperty -Name "Operator" -Value $alert.Properties.action.trigger.thresholdOperator
        $diff | Add-Member -MemberType NoteProperty -Name "Threshold" -Value $alert.Properties.action.trigger.threshold
        $alertName = $alert.Name
        $htmlFrags += $diff | ConvertTo-Html -Fragment -PreContent "<h2> $alertName </h2>" -PostContent "<br>" -As List
    }
}

$header = @"
<style>
    h1, h2 {
        font-family: Arial, Helvetica, sans-serif;
    }

    table {
        border: 0px; 
		font-family: Arial, Helvetica, sans-serif;
    }

    td {
		padding: 4px;
		margin: 0px;
		border: 3px;
	}

    tbody tr:nth-child(even) {
        background: #f0f0f2;
    }

    p {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 16px;
    }

</style>
"@

ConvertTo-Html -Body $htmlFrags -Title "Alert Rule Delta Report" `
    -Head $header `
    -PostContent "<p>Creation Date: $(Get-Date)</p>" `
    | Out-File .\AlertDiff.html