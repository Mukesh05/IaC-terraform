<#
.SYNOPSIS
If you are running this on your local machine, please run it with the repo root as your working directory.
#>

try {
  Import-Module Az
}
catch {
  Install-Module Az -Force -Scope CurrentUser -AllowClobber
  Import-Module Az -Force
}

if (($null -eq $env:Build_ArtifactStagingDirectory) -and ($(get-location).path.split('\')[-1] -notmatch "Assets_DSC")) {
  Write-Warning "Please run this with the repository root as your working directory"
}
else {

  function Get-DSCFiles {
    $dscfiles = @()
    foreach ($ps1 in $(
        Get-ChildItem .\DSC_Configurations\ |
          Where-Object {
            $_.extension -match ".ps1"
          }
      )) {
      $dscfiles += $ps1.fullname
    }
    return $dscfiles
  }
  
  Function Install-DSCResources {
    $modules = @()
    Write-Output "Scanning DSC for required DSC resources..."

    foreach ($dscfile in Get-DSCFiles) {
      $modules += $(
        Get-content $dscfile |
          Where-Object {
            $_ -match "Import-DscResource -ModuleName "
          }
      ).replace("Import-DscResource -ModuleName ", '').split(',').replace(',', '').replace(' ', '')
    }

    $modules = $modules | Sort-Object | Get-Unique

    Write-Output "Found the following required DSC Resources:"
    Write-Output $modules

    foreach ($module in $modules) {
      Write-Output "Looking for $module locally."

      if ((Get-Module -ListAvailable -Name $module).Count -gt 0) {
        Write-Output "Found $module locally installed."
      }
      else {
        Write-Output "$module doesn't look to be installed locally, trying to download from the internet."
        try {
          Install-Module $module -Force -Scope CurrentUser
        }
        catch {
          "Error installing $module : `n"
          $_
        }
      }
    }
  }


  function Publish-DSCConfigs {

    if ($null -eq $env:Build_ArtifactStagingDirectory) {
      $test = $(get-item ./bin -ErrorAction SilentlyContinue).psiscontainer
      if ( !($test)  ) { New-Item ./bin -ItemType Directory }
      $env:Build_ArtifactStagingDirectory = $(Get-Item ./bin).FullName + "\"
    }

    foreach ($dscfile in Get-DSCFiles) {
      try {
        $dscname = $dscfile.split('\')
        $dscname = $dscname[$dscname.count - 1]
        $archivepath = $(
          $env:Build_ArtifactStagingDirectory + "\" + $dscname.trim('.ps1') + ".zip"
        )

        Write-Output "Compiling $dscname to $archivepath"
        Publish-AzVMDscConfiguration `
          -ConfigurationPath $dscfile `
          -ConfigurationArchivePath $archivepath
      }
      catch {
        Write-Warning "Error compiling DSC for configuration $dscname : `n "
        $_
      }
    }
  }

  Install-DSCResources
  Publish-DSCConfigs
  $env:Build_ArtifactStagingDirectory = $null
}