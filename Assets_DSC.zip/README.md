# Assets_DSC

This repository is intended to hold standalone PowerShell DSC configurations and their associated tests.
These  may be consumed as part of the DriveTrain product assemblies, or used by themselves by individual engineers as single-solutions.

## Getting Started

If you've never worked with PowerShell DSC configurations before, it may be a good idea to create your own one from scratch in a personal test environment first.

There are many good resources on how to write PowerShell DSC configurations, here are some we recommend;

- https://docs.microsoft.com/en-us/PowerShell DSC/developer/module/understanding-a-windows-PowerShell DSC-module
- https://docs.microsoft.com/en-us/PowerShell DSC/developer/module/how-to-write-a-PowerShell DSC-script-module
- https://PowerShell DSCexplained.com/2017-05-27-PowerShell DSC-module-building-basics/
- https://ramblingcookiemonster.github.io/Building-A-PowerShell DSC-Module/
- https://docs.microsoft.com/en-us/PowerShell DSC/developer/module/how-to-write-a-PowerShell DSC-module-manifest
- https://docs.microsoft.com/en-us/PowerShell DSC/developer/module/writing-help-for-windows-PowerShell DSC-configurations

## Build and Test

It is a requirement for every module included in this repository to include some level of unit test coverage.
For unit tests, this repository uses the [Pester PowerShell DSC Testing Framework](https://github.com/pester/Pester)
A [Build Pipeline](https://dev.azure.com/newsigcode/DriveTrain/_build?definitionId=128&_a=summary) is configured on this repository to ensure no PRs to master will complete if the associated tests do not pass.

To run tests locally, install the Pester Module and run Invoke-Pester from the repository root.

## Contribute

We welcome contributions from *anybody* into this repository.
To ensure that the repository contains good-quality configurations, to make a contribution you will need to make a *pull request* from a branch that you have created. This ensures that the contents of the repository have been peer-reviewed.

As above, please ensure you are including some level of basic unit tests with your PowerShell DSC module.

## Legal
Please note the contents of the .LICENSE file stored in this repository.

It is required that a Master Services Agreement (MSA) is in place between New Signature and any customer where Drivetrain is used.

Please ensure that any code you contribute is either your own work, released under a permissive (non-copyleft) licence, or has been developed on a customer engagement where a Master Services Agreement is in place.

If you have any questions or queries about this, please contact legal@newsignature.com.

### Using Git

If you are unfamiliar with Git, or you do not understand how to create a pull request or git branch, the following references may be helpful for you if you are new to Git source control.

- https://git-scm.com/videos
- https://docs.microsoft.com/en-us/azure/devops/repos/git/gitworkflow?view=azure-devops

If you are still stuck after reviewing the above, message the Platform Services team in the Drivetrain Teams -> General Channel and someone will be happy to walk you through how to get started.
