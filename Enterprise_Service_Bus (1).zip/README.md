# Introduction 
This project is the first phase of engineering to use the new ESB components created for the Platform Team 
and will implement the design shown [here](https://dev.azure.com/newsigcode/DriveTrain/_wiki/wikis/DriveTrain.wiki/1788/Integration-Patterns).

# Getting Started

This project contains a number of Azure Functions and will be built, tested and deployed via Azure Pipelines.
