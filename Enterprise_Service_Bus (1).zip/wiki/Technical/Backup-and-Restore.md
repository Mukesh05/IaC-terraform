[[_TOC_]]

# Backup and Restore of Azure Storage Table

## Introduction

This wiki is for backing up and restoring the Storage table used in ESB operations. 

## Pre requisites

1. An automation account is used to execute the runbooks for backup and restore.
2. A system assigned managed identity is created for the automation account.

   ![](../images/ManagedIdentity.png)   

3. The managed identity is assigned "contributor" role on the storage account that holds the storage table. A "reader" role is also assigned
   on the resource group that contains the storage account.

   ![](../images/PermissionForManagedIdentity.png)

4. A key Vault. The managed identity is given "Get" access permission on the key vault.

   ![](../images/AccessOnKeyVault.png)

## Backup

![](../images/backup.png)

## Restore

![](../images/restore.png)





