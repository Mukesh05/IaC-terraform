# SCCM Integration - Adding a Client to get a Client Key

## Introduction

To add a client to the APIM Instance we create a subscription resource in the **parent/body** section of the **src\APIM\iac\subscribers-SccmManagment.bicep** template with the following:

``` bicep

resource subscription_sccm_dhac 'Microsoft.ApiManagement/service/subscriptions@2019-12-01' = {
  name: '${ApimServiceName}/dhac'
  properties: {
    scope: '/products/sccm-management'
    displayName: 'SCCM Schedule - De Havilland Aircraft of Canada'
    state: 'active'
    allowTracing: false
  }
  dependsOn: [
    product_sccm_management
  ]
}

```

Note here, the client id for APIM's reference is **dhac** so replace this in the **name** and the **resource** identifiers. Then use a suitable human-readable name in the **displayName** property so that the client can be identified by an engineer in the portal.

To commit this change to the Production environment:

* Create a branch on the ESB repository with a linked work item
* Add the section
* Commit
* Push

---

## DEPRECATED -- Introduction - ARM - DEPRECATED

To add a client to the APIM Instance we create a subscription resource in the **resources** [] section of the **\src\APIM\apim.template.json** template with the following:

``` JSON
    {
      "name": "[concat(parameters('ApimServiceName'), '/sccm-management-bco')]",
      "type": "Microsoft.ApiManagement/service/subscriptions",
      "apiVersion": "2019-12-01",
      "properties": {
        "scope": "/products/sccm-management",
        "displayName": "SCCM Schedule - Brookfield",
        "state": "active",
        "allowTracing": false
      },
      "dependsOn": [
        "[resourceId('Microsoft.ApiManagement/service/products', parameters('ApimServiceName'), 'sccm-management')]"
      ]
    },
```

The ***name*** should set be: "[concat(parameters('ApimServiceName'), '/sccm-management-*CLIENT SHORT CODE*')]" e.g. where client short code is bco for Brookfield, etc.

The ***displayName*** should be updated accordingly too with a sensible note to indicate the purpose of the subscription in a human readable form.

## DEPRECATED -- Applying the Change - ARM - DEPRECATED

Pull-request, merge, then deploy this change. From this point you should be able to go into APIM and click on the **Subscriptions** entry in the left blade. Find the subscription you just added and copy the primary key to the engineer who will be installing the agent on the client's SCCM server so that the agent service can call the scheduler service in the cloud.
