# API Management Configuration

## Introduction

Using Azure API Management gives a structured and clean interface to any and all API services that the Platform
Team creates and shares with the business.

These can be data feeds, RPC management services and other functions that require automation/integration.

## Configuring APIM

This is fiddly and doesn't have strong automation and DevOps support. It is more geared towards manual
administration - something this team is too small to entertain.

## Entities in APIM (Glossary of Terms)

[Microsoft API Management ARM Documentation](https://docs.microsoft.com/en-us/azure/templates/microsoft.apimanagement/service)

| Item | Description |
| ------------- |---------------------------------------------------------------- |
|*Users* | Subscribers that can be given individual *Subscriptions* or added to *Groups* - not used |
|*Groups* | Collections of *Users* that can be assigned *Subscriptions* - not used|
|*APIs* | One or more services that are provided as an endpoint from API Management with *Operations*|
|*Back-End* | API or App that is being proxied/brokered via API Management|
|*Operations* | GETs, POSTs, PUTs, DELETEs on one or more *API*s that are exposed through an *API*|
|*Products* | Collection of *API* that can be bundled and exposed to *Subscriptions*|
|*Subscriptions* | Entity that defines access to a *Product* yields API Keys that can be used to consume API's using HTTPS|
|*Policies* | Programmatic transformation that can be executed on the data for both requests and responses that are passing through. Can be applied to *Products*, *APIs*, *Operations*|
|*Named values* | Special values that are used as tokens throughout API Management|
|*Logger* | Connection to an Application Insights Workspace that can be used to capture telemetry from *API*'s|

## Exposing an Azure Function through API Management

There is no natural automation for this. The process for making this happen was reverse-engineered using the [API Management DevOps Kit](https://github.com/Azure/azure-api-management-devops-resource-kit) after configuring the function in API Management using the Azure Portal. The API Management DevOps Kit provides a tool that can be used to extract a configuration from APIM as a set of ARM Templates. From these templates it is possible to diff configurations in APIM after a change and makes apparent how APIM configures the Azure Function in it's internal representations.

``` azurepowershell
az login
az account set --subscription a796a3fe-dffd-4ae7-9aee-f76574986de6 # 'New Signature - GMS - ESB QA'
git clone https://github.com/Azure/azure-api-management-devops-resource-kit.git
cd c:\temp
mkdir apim
cd .\azure-api-management-devops-resource-kit\src\APIM_ARMTemplate\apimtemplate
dotnet build
.\bin\Debug\netcoreapp3.1\apimtemplate.exe extract `
                                    --sourceApimName apim-dti-qa-uks `
                                    --destinationApimName apim-dti-qa-uks `
                                    --resourceGroup RG-DTI-QA-Core `
                                    --fileFolder c:\temp\apim
cd c:\temp\apim
dir
```
Do this *before* and *after* adding a new item and you will be able to diff the copies to determine how to describe the resources in template form.

After doing this you can then decompile the result into bicep using the az bicep cli tool to get the bicep representation.

``` bash
az bicep decompile --file 'your-file-name-here'
```
