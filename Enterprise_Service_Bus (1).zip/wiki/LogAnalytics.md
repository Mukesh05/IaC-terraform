# Log Analytics Proxy Function Architecture

## High Level Diagram

![Architecture Diagram](images/laquery.png)

## Details

### Advantages and Security

The new service has the following advantages.

- The Power BI user now only needs an API key to access the data from all client logs, via an API Management endpoint, restricted to Log Analytics data access only.
- All customer connection data is secured in Service Now and is queried by the function when the query requests are made. This is flexible in that there are no changes to be made when new clients are added.
- The function can query and aggregate all client data responses and 'enriches' each record with the *tenantId* and *client account name* for the client providing that record in the aggregation processing. All records are returned in a single data set that makes report generation easier.

## Summary

The service provided here can be configured to give access to many clients, with per-consumer API keys. If required we can control the request rate with API Management Policy and monitor any issues with the usage using App Insights alerts.
