# APIs Published

## 'Reporting Data Mart' Services and Data Feeds

### IntuneData

The [Microsoft Intune data feed](https://docs.microsoft.com/en-us/mem/intune/developer/reports-proc-create-with-odata) gives access to data from a single tenant, each requiring individual authentication.

#### Objectives

- To provide convenient access to this data for the reporting team,
- Platform Team provide a new service that is a single API Key authenticated
- Service is an Intune ODATA feed that queries across all customer tenants.
- When queries are processed, we enrich the data by aggregating requests across tenants and adding the tenant id to each record to assist with report processing.

e.g. For Devices ...

``` json
{
    "@odata.context": "https://apim-dti-qa-uks.azure-api.net/intune/IntuneData/$metadata#devices",
    "@odata.count": 0,
    "value": [
        {
            "deviceKey": 1294122,
            "deviceId": "d6f9e292-a1df-4174-9b8f-20a6ac6d7e6f",
            "deviceName": "User deleted for this device",
            ...
            <<snip>>
            ...
            "tenant": "daf884b0-be16-4f2a-8bbb-dc6099a56844"
        },
        {
            "deviceKey": 1294123,
            "deviceId": "14b823d0-6f73-4990-8419-b192cf554f39",
```

#### Endpoints

QA   URI - [https://apim-dti-qa-uks.azure-api.net/intune/IntuneData/?api-version=v1.0](https://apim-dti-qa-uks.azure-api.net/intune/IntuneData/?api-version=v1.0)

Prod URI - [https://apim-dti-prod-uks.azure-api.net/intune/IntuneData/?api-version=v1.0](https://apim-dti-prod-uks.azure-api.net/intune/IntuneData/?api-version=v1.0)

To request an API Key contact the Platform Services Team.

The service is provided via the Azure API Management appliance and Azure Functions.

#### Power BI Support

[The Microsoft Documentation](https://docs.microsoft.com/en-us/mem/intune/developer/reports-proc-create-with-odata) gives a sense of how to connect to the raw data feed provided by Microsoft and what you can expect to receive back. The enhanced feed that we provide supplies the same schema of data, enriched with a Tenant Id for each record.

To pull data from the feed in Power BI, use the code below in the advanced editor, replacing [type] with the data type you want to retrieve records for and providing a valid subscription key where shown. All subscriptions carry the same data types/classes because they are all provided from Microsoft's standards-based InTune service in the source tenant.

``` dax
   dax
let
    feed = OData.Feed("https://apim-dti-qa-uks.azure-api.net/intune/IntuneData/[type]?api-version=v1.0", null, [Headers=[#"Ocp-Apim-Subscription-Key"="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"]])
in
    feed

```

To get available query data types, use a browser or web query tool to call this GET method:

``` code
URI
https://apim-dti-qa-uks.azure-api.net/intune/IntuneData?api-version=v1.0&Subscription-Key=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

```

The response message should contain a list of types for which the uri property
of each record shows the correct term.

e.g.

``` json
{
  "@odata.context": "http://fa-dti-intunedataapi-qa.azurewebsites.net/api/IntuneData/$metadata",
  "value": [
    {
      "name": "mobileAppInstallStates",
      "kind": "EntitySet",
      "url": "mobileAppInstallStates"
    },
    {
      "name": "mobileAppInstallStatusCounts",
      "kind": "EntitySet",
      "url": "mobileAppInstallStatusCounts"
    },
    {
      "name": "appRevisions",
      "kind": "EntitySet",
      "url": "appRevisions"
    },
    {
      "name": "appTypes",
      "kind": "EntitySet",
      "url": "appTypes"
    },
```

## Update Management

### Log Analytics Data

This service provides a proxy to access the Log Analytics Workspaces of all enrolled clients so that queries can be executed against the log data lakes, providing diagnostics and insights data that can be used for advanced reporting in PowerBI.

#### Log Analyitcs Objectives

- To provide update management data for reporting
- To provide any other data required from Log Analytics in a future-proof way

The Log Analytics query must be placed within a PowerBI Advanced query, having a
JSON request body and any elements that break the schema of the request must be
wrapped or escaped to ensure that the request is well-formed both in the JSON
message and also when presented to the Log Analytics Workspace(s) API.

e.g.

``` JSON
let
url = "https://apim-dti-qa-uks.azure-api.net/fa-dti-loganalyticsapi-qa/LogAnalytics?subscription-key=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
body = "{
  ""query"":""Update | where TimeGenerated>ago(5h) and OSType=='Linux' and SourceComputerId in ((Heartbeat | where TimeGenerated>ago(12h) and OSType=='Linux' and notempty(Computer) | summarize arg_max(TimeGenerated, Solutions) by SourceComputerId | where Solutions has 'updates' | distinct SourceComputerId)) | summarize hint.strategy=partitioned arg_max(TimeGenerated, UpdateState, Classification, BulletinUrl, BulletinID) by SourceComputerId, Product, ProductArch | where UpdateState=~'Needed' | project-away UpdateState, TimeGenerated | summarize computersCount=dcount(SourceComputerId, 2), ClassificationWeight=max(iff(Classification has 'Critical', 4, iff(Classification has 'Security', 2, 1))) by id=strcat(Product, '_', ProductArch), displayName=Product, productArch=ProductArch, classification=Classification, InformationId=BulletinID, InformationUrl=tostring(split(BulletinUrl, ';', 0)[0]), osType=1 | union(Update | where OSType!='Linux' and (Optional==false or Classification has 'Critical' or Classification has 'Security') and SourceComputerId in ((Heartbeat | where OSType=~'Windows' and notempty(Computer) | summarize arg_max(TimeGenerated, Solutions) by SourceComputerId | where Solutions has 'updates' | distinct SourceComputerId)) | summarize hint.strategy=partitioned arg_max(TimeGenerated, UpdateState, Classification, Title, KBID, PublishedDate, Approved) by Computer, SourceComputerId, UpdateID | where UpdateState=~'Needed' and Approved!=false | project-away UpdateState, Approved, TimeGenerated | summarize computersCount=dcount(SourceComputerId, 2), displayName=any(Title), publishedDate=min(PublishedDate), ClassificationWeight=max(iff(Classification has 'Critical', 4, iff(Classification has 'Security', 2, 1))) by id=strcat(UpdateID, '_', KBID), classification=Classification, InformationId=strcat('KB', KBID), InformationUrl=iff(isnotempty(KBID), strcat('https://support.microsoft.com/kb/', KBID), ''), osType=2) | sort by ClassificationWeight desc, computersCount desc, displayName asc | extend informationLink=(iff(isnotempty(InformationId) and isnotempty(InformationUrl), toobject(strcat('{ \""uri\"": \""', InformationUrl, '\"", \""text\"": \""', InformationId, '\"", \""target\"": \""blank\"" }')), toobject(''))) | project-away ClassificationWeight, InformationId, InformationUrl | where classification <> 'Definition Updates'""
  }",
Source = Json.Document(Web.Contents(url,
[
    Headers = [#"Content-Type" = "application/json"],
    Content = Text.ToBinary(body)
])),
    TypeMap = #table(
    { "AnalyticsTypes", "Type" },
    {{ "string", Text.Type },
    { "int", Int32.Type },
    { "long", Int64.Type },
    { "real", Double.Type },
    { "timespan", Duration.Type },
    { "datetime", DateTimeZone.Type },
    { "bool", Logical.Type },
    { "guid", Text.Type },
    { "dynamic", Text.Type }}),
    DataTable = Source[tables]{0},
    Columns = Table.FromRecords(DataTable[columns]),
    ColumnsWithType = Table.Join(Columns, {"type"},
    TypeMap , {"AnalyticsTypes"}),
    Rows = Table.FromRows(DataTable[rows], Columns[name]),
    Table = Table.TransformColumnTypes(Rows, Table.ToList(ColumnsWithType, (c) => { c{0}, c{3}}))
in Table
```

and

``` JSON
let
url = "https://apim-dti-qa-uks.azure-api.net/fa-dti-loganalyticsapi-qa/LogAnalytics?subscription-key=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
body = "{
  ""query"": ""AzureDiagnostics | where Category == 'AzureBackupReport' | where SchemaVersion_s == 'V2' | where OperationName == 'Job' and JobOperation_s == 'Backup' | project BackupManagementType_s,BackupItemType_s, JobStatus_s, JobFailureCode_s, Resource, BackupItemUniqueId_s, JobOperation_s, State_s, DataTransferredInMB_s""
}",
Source = Json.Document(Web.Contents(url,
[
    Headers = [#"Content-Type" = "application/json"],
    Content = Text.ToBinary(body)
])),
    TypeMap = #table(
    { "AnalyticsTypes", "Type" },
    {{ "string", Text.Type },
    { "int", Int32.Type },
    { "long", Int64.Type },
    { "real", Double.Type },
    { "timespan", Duration.Type },
    { "datetime", DateTimeZone.Type },
    { "bool", Logical.Type },
    { "guid", Text.Type },
    { "dynamic", Text.Type }}),
    DataTable = Source[tables]{0},
    Columns = Table.FromRecords(DataTable[columns]),
    ColumnsWithType = Table.Join(Columns, {"type"},
    TypeMap , {"AnalyticsTypes"}),
    Rows = Table.FromRows(DataTable[rows], Columns[name]),
    Table = Table.TransformColumnTypes(Rows, Table.ToList(ColumnsWithType, (c) => { c{0}, c{3}}))
in Table
```

### Log Analytics Endpoints

QA   URI - [https://apim-dti-qa-uks.azure-api.net/fa-dti-loganalyticsapi-qa/LogAnalytics?subscription-key=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx](https://apim-dti-qa-uks.azure-api.net/fa-dti-loganalyticsapi-qa/LogAnalytics?subscription-key=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx)

Prod URI - [https://apim-dti-prod-uks.azure-api.net/fa-dti-loganalyticsapi-qa/LogAnalytics?subscription-key=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx](https://apim-dti-prod-uks.azure-api.net/fa-dti-loganalyticsapi-qa/LogAnalytics?subscription-key=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx)

To request an API Key contact the Platform Services Team.

The service is provided via the Azure API Management appliance and Azure Functions.

## SCCM Data

This service provides a proxy to access the SCCM data query results.

### SCCM Data Objectives

- To provide SCCM sql query data to reporting

This is dependent on data being present in Azure from a successful run of the given SCCM SQL query.

**NB:** check the schedule of the PowerBI pull to be after the SCCM data query's scheduled execution. This function pulls the latest results.

e.g.

``` JSON
let
    Key = "APIM KEY FOR REPORT DATA MART SUBSCRIPTION",
    PageNumber = "1",
    PageSize = "1",
    Url = "https://apim-dti-prod-uks.azure-api.net/sccmdata/queryresult/data/smalldata?subscription-key=" & Key & "&pagenumber=" & PageNumber & "&pagesize=" & PageSize,

    GetJson = (Url) =>
        let
            Options = [Headers=[ContentType="application/json"]],
            RawData = Web.Contents(Url, Options),
            Json    = Json.Document(RawData),
            Data = try Json[data] otherwise null,
            NextPage = try Json[nextPage] otherwise null,
            Res = [data=Data, nextPage=NextPage]
        in
            Res,

    Data = List.Generate(() =>
                [result = GetJson(Url)],
                each [result][data] <> null,
                each [result = GetJson([result][nextPage] & "&subscription-key=" & Key)],
                each [result][data]),

    #"Converted to Table" = Table.FromList(Data, Splitter.SplitByNothing(), null, null, ExtraValues.Error),
    #"Expanded Column1" = Table.ExpandListColumn(#"Converted to Table", "Column1"),
    #"Expanded Column2" = Table.ExpandRecordColumn(#"Expanded Column1",
                                                   "Column1",
                                                   {​​"id", "schedule", "is_read", "is_run", "query_result", "type", "message_type", "clientCode", "queryResultCreatedOn", "queryName"}​​,
                                                   {​​"Column1.id", "Column1.schedule", "Column1.is_read", "Column1.is_run", "Column1.query_result", "Column1.type", "Column1.message_type", "Column1.clientCode", "Column1.queryResultCreatedOn", "Column1.queryName"}​​)
in
   #"Expanded Column2"
```

The PowerBI user is responsible for structuring the query data set to match the expected columns in the SCCM query upstream.

The pagination is mapped to client id's so a page size of '1' would receive records for one client only. Further pages will return other clients in turn. The PowerBI service is required to traverse all pages to pull all records. This is more efficient for larger data sets. Note in the above example **smalldata** is the id of the SCCM query that may have been executed against one or more clients.

### SCCM Data Endpoints

QA   URI - [https://apim-dti-qa-uks.azure-api.net/sccmdata/queryresult/data/{queryname}?subscription-key=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx](https://apim-dti-qa-uks.azure-api.net/sccmdata/queryresult/data/{queryname}?subscription-key=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx)

Prod URI - [https://apim-dti-prod-uks.azure-api.net/sccmdata/queryresult/data/{queryname}?subscription-key=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx](https://apim-dti-prod-uks.azure-api.net/sccmdata/queryresult/data/{queryname}?subscription-key=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx)

To request an API Key contact the Platform Services Team.

The service is provided via the Azure API Management appliance and Azure Functions.

## InTune Graph Desktop and Defender Hygiene Report API

This service provides a proxy to access the SCCM data query results.

### InTune Graph Data Objectives

- To provide InTune Windows Desktop and Defender Health reporting data as a service

This is dependent on each client having been OnBoarded and the appropriate Graph API consent given.

**NB:** check the schedule of the PowerBI pull to be after the InTune Graph API scheduled execution. This function pulls the latest results.

### InTune Graph Data Schedule

The schedule for this system is managed in an Azure Table

[Table Storage](https://portal.azure.com/#@NEWSIGNATURE1.onmicrosoft.com/resource/subscriptions/3a74db16-883d-4ac1-b7f7-ee0335c94bad/resourceGroups/RG-DTI-PROD-Apps/providers/Microsoft.Storage/storageAccounts/sadtiprodintunereport/storageexplorer) - You will need to be authenticated to do this.

e.g.

``` JSON
let
    Key = "APIM KEY FOR REPORT DATA MART SUBSCRIPTION",
    PageNumber = "1",
    PageSize = "1",
    Url = "https://https://apim-dti-prod-uks.azure-api.net/intunereportdata/queryresult/data/reportdata?subscription-key=" & Key & "&pagenumber=" & PageNumber & "&pagesize=" & PageSize,

    GetJson = (Url) =>
        let
            Options = [Headers=[ContentType="application/json"]],
            RawData = Web.Contents(Url, Options),
            Json    = Json.Document(RawData),
            Data = try Json[data] otherwise null,
            NextPage = try Json[nextPage] otherwise null,
            Res = [data=Data, nextPage=NextPage]
        in
            Res,

    Data = List.Generate(() =>
                [result = GetJson(Url)],
                each [result][data] <> null,
                each [result = GetJson([result][nextPage] & "&subscription-key=" & Key)],
                each [result][data]),

    #"Converted to Table" = Table.FromList(Data, Splitter.SplitByNothing(), null, null, ExtraValues.Error),
    #"Expanded Column1" = Table.ExpandListColumn(#"Converted to Table", "Column1"),
    #"Expanded Column2" = Table.ExpandRecordColumn(#"Expanded Column1",
                                                   "Column1",
                                                   {​​"id", "schedule", "is_read", "is_run", "query_result", "type", "message_type", "clientCode", "queryResultCreatedOn", "queryName"}​​,
                                                   {​​"Column1.id", "Column1.schedule", "Column1.is_read", "Column1.is_run", "Column1.query_result", "Column1.type", "Column1.message_type", "Column1.clientCode", "Column1.queryResultCreatedOn", "Column1.queryName"}​​)
in
   #"Expanded Column2"
```

The PowerBI user is responsible for structuring the query data set to match the expected columns in the InTune extract query upstream.

The pagination is mapped to client id's so a page size of '1' would receive records for one client only. Further pages will return other clients in turn. The PowerBI service is required to traverse all pages to pull all records. This is more efficient for larger data sets. Note in the above example **smalldata** is the id of the InTune Graph Report  that may have been executed against one or more clients.

### InTune Graph Data Endpoints

QA   URI - [https://apim-dti-qa-uks.azure-api.net/intunereportdata/queryresult/data/{queryname}?subscription-key=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx](https://apim-dti-qa-uks.azure-api.net/intunereportdata/queryresult/data/{queryname}?subscription-key=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx)

Prod URI - [https://apim-dti-prod-uks.azure-api.net/intunereportdata/queryresult/data/{queryname}?subscription-key=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx](https://apim-dti-prod-uks.azure-api.net/intunereportdata/queryresult/data/{queryname}?subscription-key=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx)

To request an API Key contact the Platform Services Team.

The service is provided via the Azure API Management appliance and Azure Functions.