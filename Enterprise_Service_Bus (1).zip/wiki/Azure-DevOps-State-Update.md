# Azure DevOps State Update Function Architecture

## High Level Diagram

![Architecture Diagram](images/AzDOEvtListHLD.png)

## Details

To aid reporting on work status and keep synchronization between a work item and its parent, a service has been
built to:

- move a Story or Bug work item into an active state if a child Task work item is moved into an active state
from an inactive state.
- Copy the Source field from any parent work item to a child with no source set, whenever a child work item is created.

## Summary

The service is fully configured using Terraform, though a PAT token for Azure DevOps must be added to the key
vault in order for it to read and write data from Azure DevOps using the REST API.

## PAT Token

The function relies on a key vault secret called AzureDevOpsPAT in the core keyvault. This is manually set to a value
extracted from Azure DevOps. The person creating the PAT must have access to the Engineering Project tickets.

### Generating PAT Token

When the PAT is generated the following permissions are required: **Work Items (Read, Write, & Manage)** and set the duration to custom, using the date picker to set validity for a year or so. Note the expiry date and create it - giving it a meaningful name in your PAT token list, e.g. 'AzureDevOpsPAT'. Copy the value so that it can be pasted into Key Vault next.

No other permissions are required.

### Adding to Key Vault

Using the Azure Portal, go to the appropriate key vault, e.g. kv-dti-prod-core, and update the AzureDevOpsPAT secret as follows:

- Click New Version
- Paste the copied key value in the value/secret field
- Set the expiry date ONE WEEK BEFORE the date the PAT expires
- Edit the Tags to indicate that you updated it: e.g. 'Created By' = '*Your Name*' etc.

To pick up the new setting - restart the function.
