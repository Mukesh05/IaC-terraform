# InTune Graph WDDH Function Architecture

## High Level Diagram

![Architecture Diagram](images/intunegraphreport.png)

## Details

### As-is. Issues and Compromises

There currently isn't a meaningful way of exporting data at volume and scale from InTune's reporting system into a central reporting dashboard across clients.

### To Be. Advantages and Security

The To-be flow shows a number of improvements.

- The Power BI user now only needs an API key to access the data from all client InTune systems, via an API Management endpoint, restricted to InTune data access only.
- All customer connection data is secured in Service Now and is queried by the function when the report generation requests are made. This is flexible in that there are no changes to be made to this system when new clients are added.
- The function can extract report data from all client instances and 'enriches' each record with the *tenantId* for the client providing that record in the aggregation processing. All records are returned in a single data set that makes report generation easier.

## Summary

The service provided here can be configured to give access to many clients, with per-consumer API keys. If required we can control the request rate and monitor any issues with the usage using App Insights.
