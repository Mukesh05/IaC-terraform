# InTune OData DW Function Architecture

## High Level Diagram

![Architecture Diagram](images/intune.png)

## Details

### As-is. Issues and Compromises

The As-is flow shows a Power BI report that can query an individual client's InTune data warehouse.
This requires using a highly sensitive service principal that the client has approved access for.
This service principal may well have access to other systems and data sources that are beyond the scope of this data retrieval and furthermore should not be held in Power BI.

Again, the connection is for a single InTune from a single Tenant.
To generate reports it would be more effort to bring together data from many clients, having many sets of sensitive credentials used to gain access to the data, and requiring updates to PowerBI every time a new client is on-boarded.

### To Be. Advantages and Security

The To-be flow shows a number of improvements.

- The Power BI user now only needs an API key to access the data from all client data warehouses, via an API Management endpoint, restricted to InTune data access only.
- All customer connection data is secured in Service Now and is queried by the function when the InTune requests are made. This is flexible in that there are no changes to be made when new clients are added.
- The function can query and aggregate all client data warehouses and 'enriches' each record with the *tenantId* for the client providing that record in the aggregation processing. All records are returned in a single data set that makes report generation easier.

## Summary

The service provided here can be configured to give access to many clients, with per-consumer API keys. If required we can control the request rate and monitor any issues with the usage using App Insights.
