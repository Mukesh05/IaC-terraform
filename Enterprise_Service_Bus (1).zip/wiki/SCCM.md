# SCCM Data Architecture

## High Level Diagram

![Architecture Diagram](images/sccmdata.png)

## Details

### As-is. Issues and Compromises

The As-is flow is based on hard-coded queries that are configured in the legacy CMP system. Queries in the system are executed on MCode agents that live on SCCM servers for each client and execute SQL queries on a time schedule. This data is returned to storage and then decoded into a SQL database. Any edits that are required to the client queries can result in a requirement for a code change in the C# decoding classes and sometimes a change to the SQL storage schema in the CMP database. This is not a sustainable model and leaves the Engineering Platform team as an essential blocker to making such updates - given that a code change and push to production is required to enable the update to work.

### To Be. Advantages and Security

- The Power BI user now only needs an API key to access the data from all client SCCM data queries, via an API Management endpoint, restricted to SCCM data access only.
- All customer connection data is secured in ServiceNow and Azure Storage and is queried by the function when the SCCM requests are made. This is flexible in that there are no changes to be made when new clients are added.
- The function can retrieve data from any SCCM query that has successfully executed. Data is enriched in each record with the *tenantId* for the client providing that record in the aggregation processing. All records are returned in a single data set that makes report generation easier.
- Queries and Schedules for all clients are now managed using the Query Admin portal so that GMS folks are able to control and maintain their own data sources.

## Summary

The service provided here can be configured to give access to many clients, with per-consumer API keys. If required we can control the request rate and monitor any issues with the usage using App Insights.
