# Enterprise Service Bus and API Platform

## Introduction

This repository represents the source configuration components for the DriveTrain ESB
functions and integrations.

1. Enterprise Service Bus
At the core we will have a service bus and standard API and integration patterns around it.
This enables secure and reliable messaging solutions.
2. API Proxy Layer
Facilitates joins of data from multiple clients for provision to PowerBI and other ESB functions.

## Goals

To deploy, manage and secure all components with infrastructure and
configuration as code using our [standard development methodology](https://dev.azure.com/newsigcode/Engineering/_wiki/wikis/Engineering/14/Contributing-Code).

## Guiding Principles

- Standards-based
- Re-usability
- Reliability
- Idempotence
- Modularity

## API's Provided

Look [here](APIs) for details of the API's currently provided by the ESB Data Mart.

## Other Services Provided

[Azure DevOps Work Item State Update](AzureDevOpsStateUpdate)

### Feedback

Any feedback is very welcome! Please direct your feedback to:
PlatformServices@NewSignature.com

## Legal

All content here is company confidential.

## Technical Background

[API Management](Technical/API-Management)
