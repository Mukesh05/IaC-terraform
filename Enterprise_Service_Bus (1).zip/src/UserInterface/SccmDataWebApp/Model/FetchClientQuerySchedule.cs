﻿using System.Collections.Generic;

namespace SccmDataWebApp.Model
{
	public class FetchClientQuerySchedule
	{
		public List<string> ClientCodes { get; set; }
		public string SelectedClientCode { get; set; }
		public bool EditMode { get; set; }

		public FetchClientQuerySchedule()
		{
			ClientCodes = new List<string>();
		}
		public IEnumerable<QuerySchedule> querySchedules { get; set; }
	}
}
