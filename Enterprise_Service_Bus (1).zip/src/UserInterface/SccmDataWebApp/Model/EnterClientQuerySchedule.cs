﻿using System;

namespace SccmDataWebApp.Model
{
	public class EnterClientQuerySchedule
	{


		public string ClientCode { get; set; }
		public string SccmServer { get; set; }
		public string Name { get; set; }
		public string ScheduleUTC { get; set; }
		public string Query { get; set; }
		public int LastQueryRowCount { get; set; }
		public string LastQueryResult { get; set; }
	}
}
