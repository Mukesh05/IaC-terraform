﻿using System; 
using FluentValidation;
using SccmDataWebApp.Model;
using Cronos;
using FluentValidation.Validators;
using FluentValidation.Resources;

namespace UserInterface.CustomValidation
{
	public class EnterClientQueryScheduleValidator : AbstractValidator<EnterClientQuerySchedule>
	{
		public EnterClientQueryScheduleValidator()
		{
			RuleFor(x => x.ClientCode)
							.NotEmpty()
							.WithMessage("Please select value for ClientCode");

			RuleFor(x => x.Name)
							.NotEmpty()
							.WithMessage("Please select value for Name");

			RuleFor(x => x.Query)
							.NotEmpty()
							.WithMessage("Please select value for Query");

			RuleFor(x => x.SccmServer)
							.NotEmpty()
							.WithMessage("Please select value for SccmServer");

			RuleFor(x => x.ScheduleUTC)
							.NotEmpty()
							.Must(Parse);
		}

		private bool Parse(EnterClientQuerySchedule model, string ScheduleUTC, PropertyValidatorContext context)
		{
			try
			{
				CronExpression.Parse(ScheduleUTC);
			}
			catch(Exception ex)
			{
				//context.Rule.CurrentValidator.Options.ErrorCode = "ScheduleUTC is invalid";
				context.Rule.MessageBuilder = c => "ScheduleUTC is invalid";

				return false;
			}
			
			return true;
			
		}
	}
}
