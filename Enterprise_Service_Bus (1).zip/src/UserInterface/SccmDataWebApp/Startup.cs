﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Azure.Identity;
using System.IO;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using System;
using SccmDataWebApp.Services;
using Microsoft.AspNetCore.Authentication.AzureAD.UI;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Authorization;
using UserInterface.CustomValidation;
using FluentValidation;

namespace SccmDataWebApp
{
	public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
			services.AddAuthentication(AzureADDefaults.AuthenticationScheme)
					.AddAzureAD(options => Configuration.Bind("AzureAd", options));

			services.AddControllersWithViews(options =>
            {
                var policy = new AuthorizationPolicyBuilder()
                    .RequireAuthenticatedUser()
                    .Build();
                options.Filters.Add(new AuthorizeFilter(policy));
            });

			IConfigurationRefresher configRefresher = null;

			var appconfigConnectionString = Environment.GetEnvironmentVariable("appconfigconnectionstring");

			//Basic config setup
			var configBuilder = new ConfigurationBuilder()
				.SetBasePath(Directory.GetCurrentDirectory())
				.AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
				.AddEnvironmentVariables();
					

			//Azure App config setup
			configBuilder.AddAzureAppConfiguration(options =>
			{
				options.Connect(appconfigConnectionString)
			    .Select("SccmDataUI:*")
			   .ConfigureKeyVault(kv =>
			   {
				   kv.SetCredential(new DefaultAzureCredential()); //NuGet Azure.Identity
			   });
				configRefresher = options.GetRefresher();
			});

			IConfiguration config = configBuilder.Build();

			//Setup access to this web app. All pages require access.
			var accessGroupId = config["SCCMDataUI:AzureADAccessGroupId"];
			services.AddRazorPages()
					.AddMvcOptions(options => options.Filters.Add(new AuthorizeFilter("app-access")));

			services.AddAuthorization(options =>
			{
				options.AddPolicy("app-access", p =>
				{
					p.RequireClaim("groups", accessGroupId);
				});
			});

			services.AddLogging();

			// Register Config services
			services.AddSingleton<IConfiguration>((services) =>
			{
				return config;
			});

			services.AddSingleton<IConfigurationRefresher>((services) =>
			{
				return configRefresher;
			});

			services.AddRazorPages();
			services.AddServerSideBlazor();
			services.AddHttpClient<ISccmQueryScheuleApi, SccmDataWebApp.Services.SccmQueryScheduleApi>(client =>
			{
				client.BaseAddress = new Uri(config["SccmDataUI:QueryScheduleBaseUrl"]);
			});
			services.AddValidatorsFromAssemblyContaining<EnterClientQueryScheduleValidator>();
			
		}

		// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
		public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapBlazorHub();
                endpoints.MapFallbackToPage("/_Host");
            });
        }
    }
}
