﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using Cronos;
using Microsoft.Extensions.Configuration;
using SccmDataWebApp.Model;

namespace SccmDataWebApp.Services
{
	public class SccmQueryScheduleApi : ISccmQueryScheuleApi
	{
		HttpClient _httpClient;
		string _baseUrl;
		string _functionKey;

		public SccmQueryScheduleApi(HttpClient httpClient, IConfiguration config)
		{
			_httpClient = httpClient;
			_baseUrl = config["SccmDataUI:QueryScheduleBaseUrl"] + $"{"/api/schedule"}";
			_functionKey = config["SccmDataUI:FunctionKey"];
		}

		public async Task<HttpResponseMessage> Insert(QuerySchedule qs)
		{
			var url = $"{_baseUrl}?code={_functionKey}";
			var jsonDoc = Newtonsoft.Json.JsonConvert.SerializeObject(qs);
			HttpRequestMessage httpRequestMessage = new HttpRequestMessage
			{
				RequestUri = new Uri(url),
				Content = new StringContent(jsonDoc),
				Method = HttpMethod.Post
			};
			var json = await _httpClient.SendAsync(httpRequestMessage);

			return json;
		}

		public async Task<HttpResponseMessage> Delete(QuerySchedule qs)
		{
			var url = $"{_baseUrl}?code={_functionKey}";
			var jsonDoc = Newtonsoft.Json.JsonConvert.SerializeObject(qs);
			HttpRequestMessage httpRequestMessage = new HttpRequestMessage
			{
				RequestUri = new Uri(url),
				Content = new StringContent(jsonDoc),
				Method = HttpMethod.Delete
			};
			var json = await _httpClient.SendAsync(httpRequestMessage);

			return json;
		}

		public async Task<IEnumerable<QuerySchedule>> List(string ClientCode)
		{
			try
			{
				var url = $"{_baseUrl}/{ClientCode}?code={_functionKey}";
				var json = await _httpClient.GetStringAsync(url);
				var jsonDoc = JsonDocument.Parse(json);
				var querySchedules = jsonDoc.RootElement.GetProperty("result").EnumerateArray();
				List<QuerySchedule> scheduleList = new List<QuerySchedule>();
				foreach (var schedule in querySchedules)
				{
					var x = JsonSerializer.Deserialize<QuerySchedule>(schedule.GetRawText(), new JsonSerializerOptions()
					{
						PropertyNameCaseInsensitive = true
					});
					scheduleList.Add(x);
				}

				return scheduleList;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public async Task<List<string>> GetClientCodeList()
		{
			try
			{
				var url = $"{_baseUrl}/data/clientcodes?code={_functionKey}";
				var json = await _httpClient.GetStringAsync(url);
				var jsonDoc = JsonDocument.Parse(json);
				var clientCodes = jsonDoc.RootElement.GetProperty("result").EnumerateArray();
				List<string> clientCodeList = new List<string>();
				foreach (var clientCode in clientCodes)
				{
					var x = JsonSerializer.Deserialize<string>(clientCode.GetRawText(), new JsonSerializerOptions()
					{
						PropertyNameCaseInsensitive = true
					});
					clientCodeList.Add(x);
				}

				return clientCodeList;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}
