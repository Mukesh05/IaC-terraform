﻿using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using SccmDataWebApp.Model;

namespace SccmDataWebApp.Services
{
	public interface ISccmQueryScheuleApi
	{
		Task<IEnumerable<QuerySchedule>> List(string ClientCode);
		Task<HttpResponseMessage> Insert(QuerySchedule qs);
		Task<HttpResponseMessage> Delete(QuerySchedule qs);
		Task<List<string>> GetClientCodeList();
	}
}