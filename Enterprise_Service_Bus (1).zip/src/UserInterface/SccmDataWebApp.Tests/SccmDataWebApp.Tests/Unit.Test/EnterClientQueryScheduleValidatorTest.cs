﻿using System;
using FluentValidation.TestHelper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UserInterface.CustomValidation;

namespace SccmDataWebApp.Tests
{
	[TestClass]
	public class EnterClientQueryScheduleValidatorTest
	{
		EnterClientQueryScheduleValidator validator = new EnterClientQueryScheduleValidator();

		[TestMethod]
		public void ShouldHaveValidationErrorWhenNoClientCodeIsSupplied()
		{
			validator.ShouldHaveValidationErrorFor(x => x.ClientCode, (string)"").WithErrorMessage("Please select value for ClientCode");
		}

		[TestMethod]
		public void ShouldHaveNoValidationErrorWhenClientCodeIsSupplied()
		{
			validator.ShouldNotHaveValidationErrorFor(x => x.ClientCode, (string)"abc");
		}

		[TestMethod]
		public void ShouldHaveValidationErrorWhenNoQueryIsSupplied()
		{
			validator.ShouldHaveValidationErrorFor(x => x.Query, (string)"").WithErrorMessage("Please select value for Query");
		}

		[TestMethod]
		public void ShouldHaveNoValidationErrorWhenQueryIsSupplied()
		{
			validator.ShouldNotHaveValidationErrorFor(x => x.Query, (string)"abc");
		}

		[TestMethod]
		public void ShouldHaveValidationErrorWhenNoSccmServerIsSupplied()
		{
			validator.ShouldHaveValidationErrorFor(x => x.SccmServer, (string)"").WithErrorMessage("Please select value for SccmServer");
		}

		[TestMethod]
		public void ShouldHaveNoValidationErrorWhenSccmServerIsSupplied()
		{
			validator.ShouldNotHaveValidationErrorFor(x => x.SccmServer, (string)"abc");
		}

		[TestMethod]
		public void ShouldHaveValidationErrorWhenInvalidScheduleUTCIsSupplied()
		{
			validator.ShouldHaveValidationErrorFor(x => x.ScheduleUTC, (string)"abc").WithErrorMessage("ScheduleUTC is invalid");
		}

		[TestMethod]
		public void ShouldHaveNoValidationErrorWhenValidScheduleUTCIsSupplied()
		{
			validator.ShouldNotHaveValidationErrorFor(x => x.ScheduleUTC, (string)"  @yearly      ");
		}
	}
}
