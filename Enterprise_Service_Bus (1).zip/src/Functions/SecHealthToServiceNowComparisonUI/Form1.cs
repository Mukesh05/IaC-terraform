﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using SecHealthToServiceNowComparison.Model;
using SecHealthToServiceNowComparisonUI.Model;

namespace SecHealthToServiceNowComparisonUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

		private void Form1_Load(object sender, EventArgs e)
		{
			lblNonMatching.Text = "Click Compare...";
			lblMatching.Text = "Click Compare...";
		}

		private void button1_Click(object sender, EventArgs e)
		{
			HttpClient _httpClient = new HttpClient();
			var responseContent = _httpClient.GetAsync(textBox1.Text).Result.Content.ReadAsStringAsync().Result;
			var response = JsonConvert.DeserializeObject<CompareAzureSNowAlertsOnDemandResponse>(responseContent);
			string delimiter = "\n";
			if (response.nonMatchingAlerts.Count > 0)
			{
				lblNonMatching.Text = response.nonMatchingAlerts.Aggregate((i, j) => i + delimiter + j);
			}
			if (response.matchingSnowAlerts.Count > 0)
			{
				lblMatching.Text = response.matchingSnowAlerts.Aggregate((i, j) => i + delimiter + j);
			}
		}
	}
}
