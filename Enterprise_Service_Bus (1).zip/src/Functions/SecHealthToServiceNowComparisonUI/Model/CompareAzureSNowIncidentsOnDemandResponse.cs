﻿using System;
using System.Collections.Generic;

namespace SecHealthToServiceNowComparisonUI.Model
{
	public class CompareAzureSNowIncidentsOnDemandResponse
	{
		public List<string> matchingSnowIncidents = new List<string>();
		public List<string> nonMatchingIncidents = new List<string>();

	}
}
