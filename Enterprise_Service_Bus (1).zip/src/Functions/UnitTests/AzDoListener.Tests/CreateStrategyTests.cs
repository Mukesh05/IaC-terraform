﻿using NUnit.Framework;
using Moq;
using AzDoListener;
using Microsoft.Extensions.Logging;
using AzDoListener.Events;
using AzDoListener.WorkItem;
using AzDoListener.Strategies;
using System.Threading.Tasks;

namespace AzDoListenerStateUpdateTests
{
	[TestFixture]
	class CreateStrategyTests
	{
		private const string DUMMYPAT = "pafdjfkl;dsajfkl;dasjfl;kdsajflkdasjlfkdjasl;fdat";

		[Test]
		public void Given_ATaskWorkItemWithoutParent_WhenSourceIsNull_Then_DoNothing_And_LogOutcome()
		{
			// Setup
			Mock<ILogger<ProcessAzDoWorkItemEvent>> mockLogger = new Mock<ILogger<ProcessAzDoWorkItemEvent>>();
			Mock<AzDoTicketCreateEvent> mockEvent = new Mock<AzDoTicketCreateEvent>();
			Mock<IAzDoWorkItemFactory> mockWorkItemFactory = new Mock<IAzDoWorkItemFactory>();
			Mock<IAzDoWorkItem> mockTaskWorkItem = new Mock<IAzDoWorkItem>();
			Mock<IAzDoWorkItem> mockStoryWorkItem = new Mock<IAzDoWorkItem>();

			// Expectations
			mockEvent.Setup(ev => ev.Href)
					 .Returns("dummyhref");

			mockEvent.SetupGet(e => e.WorkItemId)
					 .Returns(100)
					 .Verifiable();

			mockEvent.SetupGet(e => e.WorkItemType)
					 .Returns("Task")
					 .Verifiable();

			mockEvent.Setup(e => e.Source)
					 .Returns<string>(null)
					 .Verifiable();

			mockWorkItemFactory.Setup(f => f.GetAzDoWorkItem(It.Is<string>((value) => value == "dummyhref"),
														It.IsAny<string>()))
							   .Returns(mockTaskWorkItem.Object)
							   .Verifiable();

			mockTaskWorkItem.Setup(t => t.Get())
							.Verifiable();

			mockTaskWorkItem.Setup(t => t.ParentHref)
							.Returns<string>(null)
							.Verifiable();

			mockTaskWorkItem.Setup(t => t.Type)
							.Returns("Task")
							.Verifiable();

			// Execute
			var strategy = new CreateEventStrategy(DUMMYPAT,
												mockLogger.Object,
												mockWorkItemFactory.Object,
												mockEvent.Object);

			var t = strategy.Execute();
			t.Wait();

			// Verify

			mockEvent.Verify(ev => ev.Href, Times.Exactly(2));

			mockWorkItemFactory.Verify(f => f.GetAzDoWorkItem(It.IsAny<string>(),
														It.IsAny<string>()),
														Times.Exactly(1));

			mockTaskWorkItem.Verify(t => t.Get(), Times.Once());

			mockTaskWorkItem.Verify(t => t.Update(), Times.Never());

			mockStoryWorkItem.Verify(t => t.Get(), Times.Exactly(0));

			mockLogger.VerifyLogging("100 of type Task has been created with href dummyhref", LogLevel.Information, Times.Once())
					  .VerifyLogging("Using PAT Token : pafdj", LogLevel.Information, Times.Once())
					  .VerifyLogging("Ticket does not have a parent.", LogLevel.Information, Times.Once());
		}

		[Test]
		public void Given_ATaskWorkItemWithSource_Then_DoNothing_And_LogOutcome()
		{
			// Setup
			Mock<ILogger<ProcessAzDoWorkItemEvent>> mockLogger = new Mock<ILogger<ProcessAzDoWorkItemEvent>>();
			Mock<AzDoTicketCreateEvent> mockEvent = new Mock<AzDoTicketCreateEvent>();
			Mock<IAzDoWorkItemFactory> mockWorkItemFactory = new Mock<IAzDoWorkItemFactory>();
			Mock<IAzDoWorkItem> mockTaskWorkItem = new Mock<IAzDoWorkItem>();
			Mock<IAzDoWorkItem> mockStoryWorkItem = new Mock<IAzDoWorkItem>();

			// Expectations
			mockEvent.Setup(ev => ev.Href)
					 .Returns("dummyhref");

			mockEvent.SetupGet(e => e.WorkItemId)
					 .Returns(100)
					 .Verifiable();

			mockEvent.SetupGet(e => e.WorkItemType)
					 .Returns("Task")
					 .Verifiable();

			mockEvent.Setup(e => e.Source)
					 .Returns("Engineering")
					 .Verifiable();

			mockWorkItemFactory.Setup(f => f.GetAzDoWorkItem(It.Is<string>((value) => value == "dummyhref"),
														It.IsAny<string>()))
							   .Returns(mockTaskWorkItem.Object)
							   .Verifiable();

			mockTaskWorkItem.Setup(t => t.Get())
							.Verifiable();

			mockTaskWorkItem.Setup(t => t.ParentHref)
							.Returns("Engineering")
							.Verifiable();

			mockTaskWorkItem.Setup(t => t.Type)
							.Returns("Task")
							.Verifiable();

			mockTaskWorkItem.Setup(t => t.Source)
							.Returns("Engineering")
							.Verifiable();

			// Execute
			var strategy = new CreateEventStrategy(DUMMYPAT,
												mockLogger.Object,
												mockWorkItemFactory.Object,
												mockEvent.Object);

			var t = strategy.Execute();
			t.Wait();

			// Verify
			/*
			 * - task get called once
			 * - task Source is called once
			 * - workitem factory called once
			 */

			mockTaskWorkItem.Verify(t => t.Get(), Times.Once());

			mockTaskWorkItem.Verify(t => t.Source, Times.Once());

			mockWorkItemFactory.Verify(f => f.GetAzDoWorkItem(It.IsAny<string>(),
														It.IsAny<string>()), Times.Once());

			mockLogger.VerifyLogging("100 of type Task has been created with href dummyhref", LogLevel.Information, Times.Once())
					  .VerifyLogging("Using PAT Token : pafdj", LogLevel.Information, Times.Once())
					  .VerifyLogging("Work Item 100 already has a source.", LogLevel.Information, Times.Once());

		}

		[Test]
		public void Given_ATaskWorkItemWithNullSource_AndParentSourceIsNull_Then_DoNothing_And_LogOutcome()
		{
			// Setup
			Mock<ILogger<ProcessAzDoWorkItemEvent>> mockLogger = new Mock<ILogger<ProcessAzDoWorkItemEvent>>();
			Mock<AzDoTicketCreateEvent> mockEvent = new Mock<AzDoTicketCreateEvent>();
			Mock<IAzDoWorkItemFactory> mockWorkItemFactory = new Mock<IAzDoWorkItemFactory>();
			Mock<IAzDoWorkItem> mockTaskWorkItem = new Mock<IAzDoWorkItem>();
			Mock<IAzDoWorkItem> mockStoryWorkItem = new Mock<IAzDoWorkItem>();

			// Expectations
			mockEvent.Setup(ev => ev.Href)
					 .Returns("dummyhref");

			mockEvent.SetupGet(e => e.WorkItemId)
					 .Returns(100)
					 .Verifiable();

			mockEvent.SetupGet(e => e.WorkItemType)
					 .Returns("Task")
					 .Verifiable();

			mockEvent.Setup(e => e.Source)
					 .Returns<string>(null)
					 .Verifiable();

			mockWorkItemFactory.Setup(f => f.GetAzDoWorkItem(It.Is<string>((value) => value == "dummyhref"),
											It.IsAny<string>()))
				   .Returns(mockTaskWorkItem.Object)
				   .Verifiable();

			mockWorkItemFactory.Setup(f => f.GetAzDoWorkItem(It.Is<string>((value) => value == "parent"),
														It.IsAny<string>()))
							   .Returns(mockStoryWorkItem.Object)
							   .Verifiable();

			mockTaskWorkItem.Setup(t => t.Get())
							.Verifiable();

			mockTaskWorkItem.Setup(t => t.ParentHref)
							.Returns("parent")
							.Verifiable();

			mockTaskWorkItem.Setup(t => t.Type)
							.Returns("Task")
							.Verifiable();

			mockTaskWorkItem.Setup(t => t.Source)
							.Returns<string>(null)
							.Verifiable();

			mockTaskWorkItem.Setup(t => t.Id)
							.Returns(100)
							.Verifiable();

			mockStoryWorkItem.Setup(s => s.Get())
							 .ReturnsAsync(true)
							 .Verifiable();

			mockStoryWorkItem.Setup(s => s.Update())
							 .Verifiable();

			mockStoryWorkItem.Setup(s => s.Source)
							 .Returns<string>(null)
							 .Verifiable();

			mockStoryWorkItem.Setup(s => s.Type)
							 .Returns("story")
							 .Verifiable();

			mockStoryWorkItem.Setup(s => s.Id)
							 .Returns(90)
							 .Verifiable();

			// Execute

			ITicketEventStrategy strategy = new CreateEventStrategy(
												DUMMYPAT,
												mockLogger.Object,
												mockWorkItemFactory.Object,
												mockEvent.Object);

			Task t = strategy.Execute();
			t.Wait();

			// Verify

			//the event is used as expected (query and logging)
			mockEvent.Verify(ev => ev.Href, Times.Exactly(2));

			// two work item events are fired
			mockWorkItemFactory.Verify(f => f.GetAzDoWorkItem(It.IsAny<string>(),
														It.IsAny<string>()), Times.Exactly(2));
			// task get is called once
			mockTaskWorkItem.Verify(t => t.Get(), Times.Once());

			// task Source is called once
			mockTaskWorkItem.Verify(t => t.Source, Times.Once());

			// task update is called never
			mockTaskWorkItem.Verify(t => t.Update(), Times.Never());

			// story get is called once
			mockStoryWorkItem.Verify(s => s.Get(), Times.Once());

			// story Source is called once
			mockStoryWorkItem.Verify(s => s.Source, Times.Once());

			// story update is called never
			mockStoryWorkItem.Verify(s => s.Update(), Times.Never());

			// check that logginfg is working correctly
			mockLogger.VerifyLogging("100 of type Task has been created with href dummyhref", LogLevel.Information, Times.Once())
					  .VerifyLogging("Using PAT Token : pafdj", LogLevel.Information, Times.Once())
					  .VerifyLogging("Parent work item 90 does not have a Source.", LogLevel.Information, Times.Once());
												
		}

		[Test]
		public void Given_ATaskWorkItemWithNullSource_AndParentHasSource_Then_UpdateTask_And_LogOutcome()
		{
			// Setup
			Mock<ILogger<ProcessAzDoWorkItemEvent>> mockLogger = new Mock<ILogger<ProcessAzDoWorkItemEvent>>();
			Mock<AzDoTicketCreateEvent> mockEvent = new Mock<AzDoTicketCreateEvent>();
			Mock<IAzDoWorkItemFactory> mockWorkItemFactory = new Mock<IAzDoWorkItemFactory>();
			Mock<IAzDoWorkItem> mockTaskWorkItem = new Mock<IAzDoWorkItem>();
			Mock<IAzDoWorkItem> mockUpdatedTaskWorkItem = new Mock<IAzDoWorkItem>();
			Mock<IAzDoWorkItem> mockStoryWorkItem = new Mock<IAzDoWorkItem>();

			// Expectations
			mockEvent.Setup(ev => ev.Href)
					 .Returns("dummyhref");

			mockEvent.SetupGet(e => e.WorkItemId)
					 .Returns(100)
					 .Verifiable();

			mockEvent.SetupGet(e => e.WorkItemType)
					 .Returns("Task")
					 .Verifiable();

			mockEvent.Setup(e => e.Source)
					 .Returns<string>(null)
					 .Verifiable();

			mockWorkItemFactory.Setup(f => f.GetAzDoWorkItem(It.Is<string>((value) => value == "dummyhref"),
								It.IsAny<string>()))
							   .Returns(mockTaskWorkItem.Object)
							   .Verifiable();

			mockWorkItemFactory.Setup(f => f.GetAzDoWorkItem(It.Is<string>((value) => value == "parent"),
														It.IsAny<string>()))
							   .Returns(mockStoryWorkItem.Object)
							   .Verifiable();

			mockTaskWorkItem.Setup(t => t.Get())
							.Verifiable();

			mockTaskWorkItem.Setup(t => t.ParentHref)
							.Returns("parent")
							.Verifiable();

			mockTaskWorkItem.Setup(t => t.Type)
							.Returns("Task")
							.Verifiable();

			mockTaskWorkItem.Setup(t => t.Source)
							.Returns<string>(null)
							.Verifiable();

			mockTaskWorkItem.Setup(t => t.Update())
							.Verifiable();

			mockTaskWorkItem.Setup(t => t.Update())
							.Verifiable();

			mockTaskWorkItem.Setup(t => t.Id)
							.Returns(100)
							.Verifiable();

			mockStoryWorkItem.Setup(s => s.Get())
							 .ReturnsAsync(true)
							 .Verifiable();

			mockStoryWorkItem.Setup(s => s.Update())
							 .Verifiable();

			mockStoryWorkItem.Setup(s => s.Source)
							 .Returns("Engineering")
							 .Verifiable();

			mockStoryWorkItem.Setup(s => s.Type)
							 .Returns("story")
							 .Verifiable();

			mockStoryWorkItem.Setup(s => s.Id)
							 .Returns(90)
							 .Verifiable();

			// Execute
			ITicketEventStrategy strategy = new CreateEventStrategy(
									DUMMYPAT,
									mockLogger.Object,
									mockWorkItemFactory.Object,
									mockEvent.Object);

			Task t = strategy.Execute();
			t.Wait();

			/* Verify
			 * task update called once
			 * task get called once
			 * task NewSource is called once (?)
			 * story get called once
			 * WorkItem Factory is called twice
			 * Logging messages
			 */

			mockTaskWorkItem.Verify(t => t.Update(), Times.Once());

			mockTaskWorkItem.Verify(t => t.Get(), Times.Once());

			mockStoryWorkItem.Verify(s => s.Get(), Times.Once());

			mockStoryWorkItem.Verify(s => s.Source, Times.Exactly(2));

			mockWorkItemFactory.Verify(f => f.GetAzDoWorkItem(It.IsAny<string>(),
														It.IsAny<string>()), Times.Exactly(2));

			mockLogger.VerifyLogging("100 of type Task has been created with href dummyhref", LogLevel.Information, Times.Once())
					  .VerifyLogging("Using PAT Token : pafdj", LogLevel.Information, Times.Once())
					  .VerifyLogging("Created Work Item 100 has had its Source set from Parent 90.", LogLevel.Information, Times.Once());

		}
	}
}