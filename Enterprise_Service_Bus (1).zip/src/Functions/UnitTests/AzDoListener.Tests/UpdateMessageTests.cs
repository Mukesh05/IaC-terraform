﻿using System.IO;
using AzDoListener.Events;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json.Linq;
using NUnit.Framework;

namespace AzDoListenerStateUpdateTests
{
	[TestFixture]
    public class UpdateMessageTests
    {
        [Test]
        public void UpdateWithValidMessageCreatesCorrectObject()
        {
            var messageAsText = File.ReadAllText("dummy-message.json");

            var message = JObject.Parse(messageAsText);

            Mock<ILogger> mockLogger = new Mock<ILogger>();

            var result = AzDoTicketUpdateEvent.TryParse(message, mockLogger.Object);

            Assert.IsNotNull(result);
            Assert.AreEqual(43146, result.WorkItemId, "work item number check");
            Assert.AreEqual("Task", result.WorkItemType, "work item type check");
            Assert.AreEqual("Proposed", result.OldState, "work item old state check");
            Assert.AreEqual("Active", result.NewState, "work item new state check");
            Assert.AreEqual(
                "https://newsigcode.visualstudio.com/f8287ead-8d77-4249-b430-6fef6fc3e559/_apis/wit/workItems/43146",
                result.Href,
                "work item link/ref/uri check");
        }

        [Test]
        public void UpdateWithValidMessageButDoesntCreateObjectDueToNoStateChange()
        {
            // Set upp
            var messageAsText = File.ReadAllText("dummy-message-skip.json");

            var message = JObject.Parse(messageAsText);

            var mockLogger = new Mock<ILogger<AzDoTicketUpdateEvent>>();

            // Act
            var result = AzDoTicketUpdateEvent.TryParse(message, mockLogger.Object);

            // Verify
            Assert.IsNull(result);

            mockLogger.VerifyLogging(
				"Task 43327 - Update/Delta event does not contain state change.",
				//"Unable to parse message into AzDoTicketStateUpdateEvent object, 'System.State' likely not changed",
				LogLevel.Information,
                Times.Exactly(1));
        }

        [Test]
        public void UpdateWithValidMessageButDoesntCreateObjectDueToWrongEventType()
        {
            // Set up
            var messageAsText = File.ReadAllText("dummy-message-skip-type.json");

            var message = JObject.Parse(messageAsText);

            var mockLogger = new Mock<ILogger<AzDoTicketUpdateEvent>>();

            // Act
            var result = AzDoTicketUpdateEvent.TryParse(message, mockLogger.Object);

            // Verify
            Assert.IsNull(result);

            mockLogger.VerifyLogging(
				"Task 43327 - Event received is not a Work Item Update.",
				//"Event received is not the type we are looking for",
                LogLevel.Information,
                Times.Exactly(1));
        }

        [Test]
        public void UpdateWithValidMessageButDoesntCreateObjectDueToBadMessage()
        {
            // Set up
            var message = (JObject)null;

            var mockLogger = new Mock<ILogger<AzDoTicketUpdateEvent>>();

            // Act
            var result = AzDoTicketUpdateEvent.TryParse(message, mockLogger.Object);

            // Verify
            Assert.IsNull(result);

            /*
            mockLogger.VerifyLogging(
                "Event received is not the type we are looking for",
                LogLevel.Information,
                Times.Exactly(1));
            */
        }

		// Test that story or other ticket type state transitions does not return an event object
		[Test]
		public void UpdateWithValidMessageButWorkItemTypeIsStory()
		{
			//Setup
			var messageAsText = File.ReadAllText("dummy-message-story.json");

			var message = JObject.Parse(messageAsText);

			var mockLogger = new Mock<ILogger<AzDoTicketUpdateEvent>>();

			//Action
			var result = AzDoTicketUpdateEvent.TryParse(message, mockLogger.Object);

			//Verify
			Assert.IsNull(result);

		}

		// Test that Task event for state change other than proposed -> active doesn`t create and event


    }
}