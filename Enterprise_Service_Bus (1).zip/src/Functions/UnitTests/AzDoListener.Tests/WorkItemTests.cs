﻿using AzDoListener.WorkItem;

namespace AzDoListenerStateUpdateTests
{
	using System;
	using System.IO;
	using System.Net;
	using System.Net.Http;
	using System.Threading;
	using System.Threading.Tasks;
	using AzDoListener;
	using Moq;
	using Moq.Protected;
	using Newtonsoft.Json.Linq;
	using NUnit.Framework;

	//TODO: remove all real HTTP requests - replace body with file as per final MOQ based test - DONE

	//TODO: test state property - DONE for Task

	//TODO: Test state update request method (you will create this method in the class under test : AzDoWorkItem)
	// Story/Bug `Proposed` -> `In Progress`

	[TestFixture]
	public class WorkItemTests
	{
		private static readonly string PAT = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";

		[Test]
		public async Task ReadTicketAndCheckType()
		{
			// setup
			//var wiUri = "https://newsigcode.visualstudio.com/f8287ead-8d77-4249-b430-6fef6fc3e559/_apis/wit/workItems/43146";
			var wiUri = "https://dummyuri-here.com/";

			var messageAsText = File.ReadAllText("dummy-EnrichedMessage-Task.json");

			var handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
			handlerMock
				.Protected()
				// Setup the PROTECTED method to mock
			   .Setup<Task<HttpResponseMessage>>(
				  "SendAsync",
				  ItExpr.IsAny<HttpRequestMessage>(),
				  ItExpr.IsAny<CancellationToken>()
			   )
			   // prepare the expected response of the mocked http call
			   .ReturnsAsync(new HttpResponseMessage()
			   {
				   StatusCode = HttpStatusCode.OK,
				   Content = new StringContent(messageAsText),
			   })
			   .Verifiable();
			//var wi = new AzDoWorkItem(wiUri,
			//					  PAT);

			var wi = new AzDoWorkItem(
					handlerMock.Object,
					wiUri,
					PAT);

			// execute
			await wi.Get();
			var type = wi.Type;

			// verify
			Assert.AreEqual("Task", type, "Type should be task");
		}

		[Test]
		public void ReadTicketWithoutGetAndFail()
		{
			// setup
			//var wiUri = "https://newsigcode.visualstudio.com/f8287ead-8d77-4249-b430-6fef6fc3e559/_apis/wit/workItems/43146";

			//var wi = new AzDoWorkItem(wiUri,
			//					  PAT);
			var wiUri = "https://dummyuri-here.com/";

			var messageAsText = File.ReadAllText("dummy-EnrichedMessage-Task.json");

			var handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
			handlerMock
				.Protected()
			   // Setup the PROTECTED method to mock
			   .Setup<Task<HttpResponseMessage>>(
				  "SendAsync",
				  ItExpr.IsAny<HttpRequestMessage>(),
				  ItExpr.IsAny<CancellationToken>()
			   )
			   // prepare the expected response of the mocked http call
			   .ReturnsAsync(new HttpResponseMessage()
			   {
				   StatusCode = HttpStatusCode.OK,
				   Content = new StringContent(messageAsText),
			   })
			   .Verifiable();
			//var wi = new AzDoWorkItem(wiUri,
			//					  PAT);

			var wi = new AzDoWorkItem(
					handlerMock.Object,
					wiUri,
					PAT);
			// execute

			// verify
			Assert.Throws<InvalidOperationException>(
				() => { var s = wi.Type; },
				"Exception is the wrong type or not thrown");
		}

		[Test]
		public async Task ReadTicketAndFindParentHref()
		{
			// setup
			//var wiUri = "https://newsigcode.visualstudio.com/f8287ead-8d77-4249-b430-6fef6fc3e559/_apis/wit/workItems/43146";
			var wiUri = "https://dummyuri-here.com/";

			var messageAsText = File.ReadAllText("dummy-EnrichedMessage-Task.json");

			var handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
			handlerMock
				.Protected()
			   // Setup the PROTECTED method to mock
			   .Setup<Task<HttpResponseMessage>>(
				  "SendAsync",
				  ItExpr.IsAny<HttpRequestMessage>(),
				  ItExpr.IsAny<CancellationToken>()
			   )
			   // prepare the expected response of the mocked http call
			   .ReturnsAsync(new HttpResponseMessage()
			   {
				   StatusCode = HttpStatusCode.OK,
				   Content = new StringContent(messageAsText),
			   })
			   .Verifiable();

			//var wi = new AzDoWorkItem(wiUri,
			//					  PAT);

			var wi = new AzDoWorkItem(
					handlerMock.Object,
					wiUri,
					PAT);

			// execute
			await wi.Get();

			// verify
			Assert.AreEqual(
				"https://newsigcode.visualstudio.com/f8287ead-8d77-4249-b430-6fef6fc3e559/_apis/wit/workItems/42585",
				wi.ParentHref,
				"Parent Uri not found");
		}

		[Test]
		public async Task ReadTicketAndFindParentHrefWhereTicketHasNoParent()
		{
			var wiUri = "https://dummyuri-here.com/";

			var messageAsText = File.ReadAllText("dummy-EnrichedMessage-NoParent.json");

			var handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
			handlerMock
				.Protected()
			   // Setup the PROTECTED method to mock
			   .Setup<Task<HttpResponseMessage>>(
				  "SendAsync",
				  ItExpr.IsAny<HttpRequestMessage>(),
				  ItExpr.IsAny<CancellationToken>()
			   )
			   // prepare the expected response of the mocked http call
			   .ReturnsAsync(new HttpResponseMessage()
			   {
				   StatusCode = HttpStatusCode.OK,
				   Content = new StringContent(messageAsText),
			   })
			   .Verifiable();

			//var wi = new AzDoWorkItem(wiUri,
			//					  PAT);

			var wi = new AzDoWorkItem(
					handlerMock.Object,
					wiUri,
					PAT);

			// execute
			await wi.Get();

			// verify
			Assert.AreEqual(
				null,
				wi.ParentHref,
				"Parent Uri not found");
		}

		[Test]
		public void ReadTicketParentHrefWithoutGetAndFail()
		{
			// setup
			//var wiUri = "https://newsigcode.visualstudio.com/f8287ead-8d77-4249-b430-6fef6fc3e559/_apis/wit/workItems/38467";

			//var wi = new AzDoWorkItem(wiUri,
			// PAT);

			var wiUri = "https://dummyuri-here.com/";

			var messageAsText = File.ReadAllText("dummy-EnrichedMessage-Task.json");

			var handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
			handlerMock
				.Protected()
			   // Setup the PROTECTED method to mock
			   .Setup<Task<HttpResponseMessage>>(
				  "SendAsync",
				  ItExpr.IsAny<HttpRequestMessage>(),
				  ItExpr.IsAny<CancellationToken>()
			   )
			   // prepare the expected response of the mocked http call
			   .ReturnsAsync(new HttpResponseMessage()
			   {
				   StatusCode = HttpStatusCode.OK,
				   Content = new StringContent(messageAsText),
			   })
			   .Verifiable();

			//var wi = new AzDoWorkItem(wiUri,
			//					  PAT);

			var wi = new AzDoWorkItem(
					handlerMock.Object,
					wiUri,
					PAT);
			// execute

			// verify
			Assert.Throws<InvalidOperationException>(
				() => { var s = wi.ParentHref; },
				"Exception is the wrong type or not thrown");
		}

		[Test]
		public async Task ReadTicketStateTask()
		{
			var wiUri = "https://dummyuri-here.com/";

			var messageAsText = File.ReadAllText("dummy-EnrichedMessage-Task.json");

			var handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
			handlerMock
				.Protected()
			   // Setup the PROTECTED method to mock
			   .Setup<Task<HttpResponseMessage>>(
				  "SendAsync",
				  ItExpr.IsAny<HttpRequestMessage>(),
				  ItExpr.IsAny<CancellationToken>()
			   )
			   // prepare the expected response of the mocked http call
			   .ReturnsAsync(new HttpResponseMessage()
			   {
				   StatusCode = HttpStatusCode.OK,
				   Content = new StringContent(messageAsText),
			   })
			   .Verifiable();

			//var wi = new AzDoWorkItem(wiUri,
			//					  PAT);

			var wi = new AzDoWorkItem(
					handlerMock.Object,
					wiUri,
					PAT);

			// execute
			await wi.Get();

			//Verify
			Assert.AreEqual(
				"Active",
				wi.State,
				"Item Type is not Active");

		}

		[Test]
		public async Task UseMoqToControlRequestHandling()
		{
			// setup
			var wiUri = "https://dummyuri-here.com/";
			var expectedUri = $"{wiUri}?$expand=All&api-version=6.0";

			var messageAsText = File.ReadAllText("dummy-EnrichedMessage-NoParent.json");

			// https://gingter.org/2018/07/26/how-to-mock-httpclient-in-your-net-c-unit-tests/

			var handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
			handlerMock
			   .Protected()
			   // Setup the PROTECTED method to mock
			   .Setup<Task<HttpResponseMessage>>(
				  "SendAsync",
				  ItExpr.IsAny<HttpRequestMessage>(),
				  ItExpr.IsAny<CancellationToken>()
			   )
			   // prepare the expected response of the mocked http call
			   .ReturnsAsync(new HttpResponseMessage()
			   {
				   StatusCode = HttpStatusCode.OK,
				   Content = new StringContent(messageAsText),
			   })
			   .Verifiable();

			// execute
			var wi = new AzDoWorkItem(
				handlerMock.Object,
				wiUri,
				PAT);

			await wi.Get();

			// verify
			Assert.AreEqual(
				null,
				wi.ParentHref,
				"Parent Uri not found");

			handlerMock.Protected().Verify(
							"SendAsync",
							Times.Exactly(1), // we expected a single external request
							ItExpr.Is<HttpRequestMessage>(req =>
								req.Method == HttpMethod.Get  // we expected a GET request
								&& req.RequestUri == new Uri(expectedUri) // to this uri
							),
							ItExpr.IsAny<CancellationToken>());
		}

		[Test]
		public async Task UpdateParentWorkItem()
		{
			var wiUri = "https://dummyuri-here.com/";

			var messageAsText = File.ReadAllText("dummy-EnrichedMessage-Story.json");
			var messageAsJObject = JObject.Parse(messageAsText);

			var updateAsText = File.ReadAllText("dummy-EnrichedMessage-Story(updated).json");

			// https://gingter.org/2018/07/26/how-to-mock-httpclient-in-your-net-c-unit-tests/

			var handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
			handlerMock
			   .Protected()
			   // Setup the PROTECTED method to mock
			   .Setup<Task<HttpResponseMessage>>(
				  "SendAsync",
				  //ItExpr.IsAny<HttpRequestMessage>(),
				  ItExpr.Is<HttpRequestMessage>(match: (x) => ( x.Method == HttpMethod.Get )),
				  ItExpr.IsAny<CancellationToken>()
			   )
			   // prepare the expected response of the mocked http call
			   .ReturnsAsync(new HttpResponseMessage()
			   {
				   StatusCode = HttpStatusCode.OK,
				   Content = new StringContent(messageAsText),
			   })
			   .Verifiable();

			handlerMock
			   .Protected()
			   // Setup the PROTECTED method to mock
			   .Setup<Task<HttpResponseMessage>>(
				  "SendAsync",
				  //ItExpr.IsAny<HttpRequestMessage>(),
				  ItExpr.Is<HttpRequestMessage>(match: (x) => (x.Method == HttpMethod.Patch)),
				  ItExpr.IsAny<CancellationToken>()
			   )
			   // prepare the expected response of the mocked http call
			   .ReturnsAsync(new HttpResponseMessage()
			   {
				   StatusCode = HttpStatusCode.OK,
				   Content = new StringContent(updateAsText),
			   })
			   .Verifiable();

			// execute

			var wiUpdate = new AzDoWorkItem(
				handlerMock.Object,
				wiUri,
				PAT);

			await wiUpdate.Get();

			await wiUpdate.Update();

			// Verify
			Assert.AreEqual("In Progress",
				wiUpdate.State,
				"State Update Failed");

		}
	}
}
