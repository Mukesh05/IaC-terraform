	using System.Threading.Tasks;

namespace AzDoListenerStateUpdateTests
{
	using AzDoListener;
	using AzDoListener.Events;
	using AzDoListener.Strategies;
	using AzDoListener.WorkItem;
	using Microsoft.Extensions.Logging;
	using Moq;
	using NUnit.Framework;

	[TestFixture]
	public class StateUpdateStrategyTests
	{
		private const string DUMMYPAT = "pafdjfkl;dsajfkl;dasjfl;kdsajflkdasjlfkdjasl;fdat";

		[Test]
		public void Given_ATaskWorkItemWithoutParent_WhenStateChangesToInProgress_Then_DoNothing_And_LogOutcome()
		{
			/*
			// SET UP
			*/

			Mock<ILogger<ProcessAzDoWorkItemEvent>> mockLogger = new Mock<ILogger<ProcessAzDoWorkItemEvent>>();
			Mock<AzDoTicketUpdateEvent> mockEvent = new Mock<AzDoTicketUpdateEvent>();
			Mock<IAzDoWorkItemFactory> mockWorkItemFactory = new Mock<IAzDoWorkItemFactory>();
			Mock<IAzDoWorkItem> mockTaskWorkItem = new Mock<IAzDoWorkItem>();
			Mock<IAzDoWorkItem> mockStoryWorkItem = new Mock<IAzDoWorkItem>();

			// expect event is queried to find the ticket id
			mockEvent.SetupGet(ev => ev.Href)
					 .Returns("dummyhref");

			// expect call to get work item id for task
			mockEvent.SetupGet(e => e.WorkItemId)
							.Returns(100)
							.Verifiable();

			// expect call to get work item initial state for task
			mockEvent.SetupGet(e => e.WorkItemType)
							.Returns("Task")
							.Verifiable();


			// expect call to get work item initial state for task
			mockEvent.SetupGet(e => e.OldState)
							.Returns("Proposed")
							.Verifiable();

			// expect call to get work item state for task
			mockEvent.SetupGet(e => e.NewState)
							.Returns("Active")
							.Verifiable();

			// expect the factory to be used to create a Task WorkItem Object
			mockWorkItemFactory.Setup(f => f.GetAzDoWorkItem(It.Is<string>((value) => value == "dummyhref"),
												       It.IsAny<string>()))
				         .Returns(mockTaskWorkItem.Object)
						 .Verifiable();

			// expect call to populate the Task ticket object
			mockTaskWorkItem.Setup(t => t.Get())
							.Verifiable();

			// expect call to get parent reference from first given task
			mockTaskWorkItem.Setup(t => t.ParentHref)
							.Returns<string>(null)
							.Verifiable();

			// expect call to get parent reference from first given task
			mockTaskWorkItem.Setup(t => t.Type)
							.Returns("Task")
							.Verifiable();

			/*
			// EXECUTE
			*/

			var strategy = new UpdateEventStrategy(DUMMYPAT,
												mockLogger.Object,
												mockWorkItemFactory.Object, mockEvent.Object);

			var t = strategy.Execute();
			t.Wait();

			/*
			// VERIFY
			*/

			// maybe verify that the event is used as expected (query and logging)
			mockEvent.Verify(ev => ev.Href, Times.Exactly(2));

			// two work item events are fired
			mockWorkItemFactory.Verify(f => f.GetAzDoWorkItem(It.IsAny<string>(),
													    It.IsAny<string>()),
								 Times.Exactly(1));

			// get is called once for each ticket
			mockTaskWorkItem.Verify(t => t.Get(), Times.Once());

			// no update is requested
			mockTaskWorkItem.Verify(t => t.Update(), Times.Never());

			// don't call get on Parent because it should be null
			mockStoryWorkItem.Verify(t => t.Get(), Times.Exactly(0));

			// check that logging is working correctly
			mockLogger.VerifyLogging("100 of type Task updated from Proposed to Active with href dummyhref", LogLevel.Information, Times.Once())
				      .VerifyLogging("Using PAT Token : pafdj", LogLevel.Information, Times.Once())
				      .VerifyLogging("Ticket does not have a parent", LogLevel.Information, Times.Once());

		}

		[Test]
		public void Given_ATaskWorkItemWithAParentNotActive_WhenStateChangesToInProgress_Then_UpdateParent_And_LogOutcome()
		{
			/*
			// SET UP
			*/

			var mockLogger = new Mock<ILogger<ProcessAzDoWorkItemEvent>>();
			Mock<AzDoTicketUpdateEvent> mockEvent = new Mock<AzDoTicketUpdateEvent>();
			Mock<IAzDoWorkItemFactory> mockWorkItemFactory = new Mock<IAzDoWorkItemFactory>();
			Mock<IAzDoWorkItem> mockTaskWorkItem = new Mock<IAzDoWorkItem>();
			Mock<IAzDoWorkItem> mockStoryWorkItem = new Mock<IAzDoWorkItem>();

			// expect event is queried to find the ticket id
			mockEvent.Setup(ev => ev.Href)
					 .Returns("dummyhref");

			// expect call to get work item id for task
			mockEvent.Setup(e => e.WorkItemId)
							.Returns(100)
							.Verifiable();

			// expect call to get work item initial state for task
			mockEvent.Setup(e => e.WorkItemType)
							.Returns("Task")
							.Verifiable();


			// expect call to get work item initial state for task
			mockEvent.Setup(e => e.OldState)
							.Returns("Proposed")
							.Verifiable();

			// expect call to get work item state for task
			mockEvent.Setup(e => e.NewState)
							.Returns("Active")
							.Verifiable();

			// expect the factory to be used to create a Task WorkItem Object
			mockWorkItemFactory.Setup(f => f.GetAzDoWorkItem(It.Is<string>((value) => value == "dummyhref"),
													   It.IsAny<string>()))
						 .Returns(mockTaskWorkItem.Object)
						 .Verifiable();

			// expect the factory to be used to create a Story WorkItem Object
			mockWorkItemFactory.Setup(f => f.GetAzDoWorkItem(It.Is<string>((value) => value == "parent"),
													   It.IsAny<string>()))
						 .Returns(mockStoryWorkItem.Object)
						 .Verifiable();

			// expect call to populate the Task ticket object
			mockTaskWorkItem.Setup(t => t.Get())
							.ReturnsAsync(true)
							.Verifiable();

			// expect call to get type from first given task
			mockTaskWorkItem.Setup(t => t.Type)
							.Returns("task")
							.Verifiable();

			// expect call to get parent reference from first given task
			mockTaskWorkItem.Setup(t => t.ParentHref)
							.Returns("parent")
							.Verifiable();

			// expect call to get parent reference from first given task
			mockTaskWorkItem.Setup(t => t.State)
							.Returns("Active")
							.Verifiable();

			// expect get call on story (parent work item)
			mockStoryWorkItem.Setup(s => s.Get())
						     .ReturnsAsync(true)
							 .Verifiable();

			// expect update call on story (parent work item)
			mockStoryWorkItem.Setup(s => s.Update())
							 .Verifiable();

			mockStoryWorkItem.Setup(s => s.State)
							 .Returns("Proposed")
							 .Verifiable();

			/*
			// EXECUTE
			*/

			ITicketEventStrategy strategy = new UpdateEventStrategy(
												DUMMYPAT,
												mockLogger.Object,
												mockWorkItemFactory.Object,
												mockEvent.Object);

			Task t = strategy.Execute();
			t.Wait();

			/*
			// VERIFY
			*/

			// maybe verify that the event is used as expected (query and logging)
			mockEvent.Verify(ev => ev.Href, Times.Exactly(2));

			// two work item events are fired
			mockWorkItemFactory.Verify(f => f.GetAzDoWorkItem(It.IsAny<string>(),
														It.IsAny<string>()),
								 Times.Exactly(2));

			// get is called once for task
			mockTaskWorkItem.Verify(t => t.Get(), Times.Once());

			// State is called once for task
			mockTaskWorkItem.Verify(t => t.State, Times.Once());

			// Update is not called for task
			mockTaskWorkItem.Verify(t => t.Update(), Times.Never());

			// calls get on Parent once
			mockStoryWorkItem.Verify(s => s.Get(), Times.Once());

			// State is called once for story
			mockStoryWorkItem.Verify(s => s.State, Times.Once());

			// Update is called once for story
			mockStoryWorkItem.Verify(s => s.Update(), Times.Once());

			// check that logging is working correctly
			mockLogger.VerifyLogging("100 of type Task updated from Proposed to Active with href dummyhref", LogLevel.Information, Times.Once())
					  .VerifyLogging("Using PAT Token : pafdj", LogLevel.Information, Times.Once())
					  .VerifyLogging("Parent Work Item has been moved to In Progress", LogLevel.Information, Times.Once());
		}

		[Test]
		public void Given_ATaskWorkItemWithAnActiveParent_WhenStateChangesToInProgress_Then_DoNothing_And_LogOutcome()
		{
			/*
			// SET UP
			*/

			var mockLogger = new Mock<ILogger<ProcessAzDoWorkItemEvent>>();
			Mock<AzDoTicketUpdateEvent> mockEvent = new Mock<AzDoTicketUpdateEvent>();
			Mock<IAzDoWorkItemFactory> mockWorkItemFactory = new Mock<IAzDoWorkItemFactory>();
			Mock<IAzDoWorkItem> mockTaskWorkItem = new Mock<IAzDoWorkItem>();
			Mock<IAzDoWorkItem> mockStoryWorkItem = new Mock<IAzDoWorkItem>();

			// expect event is queried to find the ticket id
			mockEvent.Setup(ev => ev.Href)
					 .Returns("dummyhref");

			// expect call to get work item id for task
			mockEvent.Setup(e => e.WorkItemId)
							.Returns(100)
							.Verifiable();

			// expect call to get work item initial state for task
			mockEvent.Setup(e => e.WorkItemType)
							.Returns("Task")
							.Verifiable();


			// expect call to get work item initial state for task
			mockEvent.Setup(e => e.OldState)
							.Returns("Proposed")
							.Verifiable();

			// expect call to get work item state for task
			mockEvent.Setup(e => e.NewState)
							.Returns("Active")
							.Verifiable();

			// expect the factory to be used to create a Task WorkItem Object
			mockWorkItemFactory.Setup(f => f.GetAzDoWorkItem(It.Is<string>((value) => value == "dummyhref"),
													   It.IsAny<string>()))
						 .Returns(mockTaskWorkItem.Object)
						 .Verifiable();

			// expect the factory to be used to create a Story WorkItem Object
			mockWorkItemFactory.Setup(f => f.GetAzDoWorkItem(It.Is<string>((value) => value == "parent"),
													   It.IsAny<string>()))
						 .Returns(mockStoryWorkItem.Object)
						 .Verifiable();

			// expect call to populate the Task ticket object
			mockTaskWorkItem.Setup(t => t.Get())
							.ReturnsAsync(true)
							.Verifiable();

			// expect call to get type from first given task
			mockTaskWorkItem.Setup(t => t.Type)
							.Returns("task")
							.Verifiable();

			// expect call to get parent reference from first given task
			mockTaskWorkItem.Setup(t => t.ParentHref)
							.Returns("parent")
							.Verifiable();

			// expect call to get parent reference from first given task
			mockTaskWorkItem.Setup(t => t.State)
							.Returns("Active")
							.Verifiable();

			// expect get call on story (parent work item)
			mockStoryWorkItem.Setup(s => s.Get())
						     .ReturnsAsync(true)
							 .Verifiable();

			// expect call for status of story
			mockStoryWorkItem.Setup(s => s.State)
							 .Returns("In Progress")
							 .Verifiable();

			/*
			// EXECUTE
			*/

			ITicketEventStrategy strategy = new UpdateEventStrategy(
												DUMMYPAT,
												mockLogger.Object,
												mockWorkItemFactory.Object,
												mockEvent.Object);

			Task t = strategy.Execute();
			t.Wait();

			/*
			// VERIFY
			*/

			// maybe verify that the event is used as expected (query and logging)
			mockEvent.Verify(ev => ev.Href, Times.Exactly(2));

			// two work item events are fired
			mockWorkItemFactory.Verify(f => f.GetAzDoWorkItem(It.IsAny<string>(),
														It.IsAny<string>()),
								 Times.Exactly(2));

			// get is called once for task
			mockTaskWorkItem.Verify(t => t.Get(), Times.Once());

			// State is called once for task
			mockTaskWorkItem.Verify(t => t.State, Times.Once());

			// Update is not called for task
			mockTaskWorkItem.Verify(t => t.Update(), Times.Never());

			// calls get on Parent once
			mockStoryWorkItem.Verify(s => s.Get(), Times.Once());

			// State is called once for story
			mockStoryWorkItem.Verify(s => s.State, Times.Once());

			// Update is called once for story
			mockStoryWorkItem.Verify(s => s.Update(), Times.Never());

			// check that logging is working correctly
			mockLogger.VerifyLogging("100 of type Task updated from Proposed to Active with href dummyhref", LogLevel.Information, Times.Once())
					  .VerifyLogging("Using PAT Token : pafdj", LogLevel.Information, Times.Once())
					  .VerifyLogging("Child and parent states don't require action", LogLevel.Information, Times.Once());

		}
	}


}