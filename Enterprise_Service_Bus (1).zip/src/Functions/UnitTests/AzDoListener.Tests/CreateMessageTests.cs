﻿using System;
using System.Collections.Generic;
using System.Text;
using Moq;
using NUnit.Framework;
using System.IO;
using Newtonsoft.Json.Linq;
using Microsoft.Extensions.Logging;
using AzDoListener.Events;

namespace AzDoListenerStateUpdateTests
{
	[TestFixture]
	class CreateMessageTests
	{
		[Test]
		public void CreateEventWithoutSourceWithValidMessageCreatesCorrectObject()
		{
			var messageAsText = File.ReadAllText("dummy-create-message.json");
			var message = JObject.Parse(messageAsText);

			Mock<ILogger> mockLogger = new Mock<ILogger>();

			var result = AzDoTicketCreateEvent.TryParse(message, mockLogger.Object);

			Assert.IsNotNull(result);
			Assert.AreEqual(73, result.WorkItemId, "Work Item ID check");
			Assert.AreEqual("Task", result.WorkItemType, "Work Item Type check");
			Assert.IsNull(result.Source);
			Assert.AreEqual("https://dev.azure.com/newsigcodedev/da38a69b-860c-47e6-8563-0b7a88dcbc83/_apis/wit/workItems/73",
							result.Href,
							"Work Item HRef check");
		}

		[Test]
		public void CreateEventWithSourceWithValidMessageCreatesCorrectObject()
		{
			var message = JObject.Parse(File.ReadAllText("dummy-create-message-withsource.json"));

			Mock<ILogger> mockLogger = new Mock<ILogger>();

			var result = AzDoTicketCreateEvent.TryParse(message, mockLogger.Object);

			Assert.IsNotNull(result);
			Assert.AreEqual(73, result.WorkItemId, "Work Item ID check");
			Assert.AreEqual("Task", result.WorkItemType, "Work Item Type check");
			Assert.AreEqual("Engineering", result.Source, "Work Item Source check");
			Assert.AreEqual("https://dev.azure.com/newsigcodedev/da38a69b-860c-47e6-8563-0b7a88dcbc83/_apis/wit/workItems/73",
							result.Href,
							"Work Item HRef check");
		}
	}
}
