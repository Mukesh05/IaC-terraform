﻿using System;
using System.IO;
using Azure.Identity;
using Common.ESB;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.DependencyInjection;

[assembly: FunctionsStartup(typeof(LogAnalyticsApi.Startup))]
namespace LogAnalyticsApi
{
	class Startup : FunctionsStartup
	{
		public override void Configure(IFunctionsHostBuilder builder)
		{
			IConfigurationRefresher configRefresher = null;

			var appconfigConnectionString = Environment.GetEnvironmentVariable("appconfigconnectionstring");

			//Basic config setup
			var configBuilder = new ConfigurationBuilder()
				.SetBasePath(Directory.GetCurrentDirectory())
				.AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
				.AddEnvironmentVariables();

			//Azure App config setup
			configBuilder.AddAzureAppConfiguration(options =>
			{
				options.Connect(appconfigConnectionString)
				.Select("LogAnalyticsApi:*")
				.Select("ServiceNow:*")
				.ConfigureKeyVault(kv =>
				{
					kv.SetCredential(new DefaultAzureCredential()); //NuGet Azure.Identity
				});
				configRefresher = options.GetRefresher();
			});

			IConfiguration config = configBuilder.Build();

			// Register Config services
			builder.Services.AddSingleton<IConfiguration>((services) =>
			{
				return config;
			});

			builder.Services.AddSingleton<IConfigurationRefresher>((services) =>
			{
				return configRefresher;
			});

			// Registering services
			builder
				.Services
				.AddSingleton<ISecurity, Security>();

			builder
				.Services
				.AddSingleton<IFetchLogAnalyticsData, FetchLogAnalyticsData>();

			builder
				.Services
				.AddSingleton<IServiceNowAccounts, ServiceNowAccounts>();

			builder
				.Services
				.AddSingleton<IServiceNowTableQuery, ServiceNowTableQuery>();

			builder
				.Services.AddScoped<ILogAnalyticsProcessor, LogAnalyticsProcessor>();

			builder
				.Services.AddHttpClient<ILogAnalyticsProcessor, LogAnalyticsProcessor>();
		}
	}
}
