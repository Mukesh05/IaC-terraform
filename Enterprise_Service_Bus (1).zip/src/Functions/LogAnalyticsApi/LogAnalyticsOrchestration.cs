using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Common.ESB;
using DurableTask.Core;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.DurableTask;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace LogAnalyticsApi
{
    public class LogAnalyticsOrchestration
	{
		IConfiguration _config;
		IServiceNowTableQuery _serviceNowTableQuery;
		ILogger<LogAnalyticsOrchestration> _logger;
		ILogAnalyticsProcessor _logAnalyticsProcessor;
		
		public LogAnalyticsOrchestration(ILogger<LogAnalyticsOrchestration> logger,
										 IConfiguration config,
										 IServiceNowTableQuery serviceNowTableQuery,
										 ILogAnalyticsProcessor logAnalyticsProcessor)
		{
			_logger = logger;
			_config = config;
			_serviceNowTableQuery = serviceNowTableQuery;
			_logAnalyticsProcessor = logAnalyticsProcessor;
		}

		[FunctionName("Orchestration")]
        public async Task<Root> RunOrchestrator([OrchestrationTrigger] IDurableOrchestrationContext context)
        {
			var outputs = new List<Task<Root>>();
			var input = context.GetInput<OrchestrationInputParamerter>();
			foreach(var item in input.GetServiceNowAccountResult.ServiceNowAccounts)
			{
				var result = context.CallActivityAsync<Root>("Orchestration_CallLogAnalytics", new AccountQueryParameter()
				{
					serviceNowAccount = item,
					Query = input.Query
				});

				outputs.Add(result);
			}

			await Task.WhenAll(outputs);

			//Create a list of roots from each run.
			List<Root> roots = new List<Root>();
			foreach(var item in outputs)
			{
				if(item.Result != null)
				{
					roots.Add(item.Result);
				}
			}

			var combindRoots = CombinedRoots(roots);

			return combindRoots;
        }

		private Root CombinedRoots(IList<Root> roots)
		{
			//First root object will have columns.
			Root combindRoots = roots[0];

			//combind all rows of all roots
			for (int i = 1; i < roots.Count; i++)
			{
				foreach(var table in roots[i].tables)
				{
					combindRoots.tables.Find(tbl => tbl.name == table.name).rows.AddRange(table.rows);
				}
			}

			return combindRoots;
		}

		[FunctionName("Orchestration_CallLogAnalytics")]
		public async Task<Root> CallLogAnalytics([ActivityTrigger] AccountQueryParameter input)
		{
			_logger.LogInformation($"Initiate processing of account {input.serviceNowAccount.Account_name}.");

			var accountName = input.serviceNowAccount.Account_name;
			var tenantId = input.serviceNowAccount.Tenant_ids;
			var workspaceIds = input.serviceNowAccount.LA_WorkspaceIds.Split(',');
			var result = await _logAnalyticsProcessor.RunAsync(accountName, tenantId, workspaceIds, input.Query);
			return result;
		}

		[FunctionName("LogAnalytics")]
		public async Task<HttpResponseMessage> HttpStart([HttpTrigger(AuthorizationLevel.Anonymous, "get", "post")] HttpRequestMessage req,
														 [DurableClient] IDurableOrchestrationClient starter)
		{
			//Json payload expected. Parse out the kusto query.
			var jsonBody = await req.Content.ReadAsStringAsync();
			var payload = JObject.Parse(jsonBody);
			_logger.LogInformation($"Query to process {(string)payload["query"]}");
			
			//Get client details from Service Now. This will provide information required to call log analytics api.
			_logger.LogInformation("Retrieve accounts to run log analytics queries against from Service Now.");
			var serviceNowAccounts =
				await _serviceNowTableQuery.GetServiceNowTableData<ServiceNowAccountResult>("u_account_azure_event_mapping",
				"sysparm_query=u_workspace_idsISNOTEMPTY^u_disable_esb_reporting=false&sysparm_fields=u_account.name,u_tenant_ids,u_workspace_ids");

			//Start orchestration with service now accounts.
			OrchestrationInputParamerter paramerter = new OrchestrationInputParamerter()
			{
				GetServiceNowAccountResult = serviceNowAccounts,
				Query = payload.ToString()
			};

			string instanceId = await starter.StartNewAsync("Orchestration", null, paramerter);
			_logger.LogInformation($"Started orchestration with ID = '{instanceId}'.");

			//Keep running until orchestration has completed.
			DurableOrchestrationStatus orchestrationStatus = await starter.GetStatusAsync(instanceId);
			while (orchestrationStatus.RuntimeStatus != OrchestrationRuntimeStatus.Completed)
			{
				orchestrationStatus = await starter.GetStatusAsync(instanceId);
				var status = orchestrationStatus.RuntimeStatus;

				if (status != OrchestrationRuntimeStatus.Running &&
				   status != OrchestrationRuntimeStatus.Pending &&
				   status != OrchestrationRuntimeStatus.Completed)
				{
					throw new System.Exception($"Something unexected happened. {status}");
				}

				await Task.Delay(2000);
			}

			//Get the results of the orchestration. 
			var output = orchestrationStatus.Output.ToString(Formatting.Indented);

			return new HttpResponseMessage(System.Net.HttpStatusCode.OK)
			{
				Content = new StringContent(output)
			};
		}

		[FunctionName("PurgeAll")]
		public async Task<HttpResponseMessage> PurgeAll([HttpTrigger(AuthorizationLevel.Anonymous, "delete")] HttpRequestMessage req,
														[DurableClient] IDurableOrchestrationClient durableOrchestrationClient)
		{
			var orchestrationStatusList = new List<OrchestrationStatus> { OrchestrationStatus.Completed,
																		  OrchestrationStatus.Canceled,
																		  OrchestrationStatus.Failed,
																		  OrchestrationStatus.Terminated,
																		  OrchestrationStatus.Pending,
																		  OrchestrationStatus.ContinuedAsNew
																		};

			var purgeHistoryResult = await durableOrchestrationClient.PurgeInstanceHistoryAsync(DateTime.MinValue, null, orchestrationStatusList);

			return new HttpResponseMessage(System.Net.HttpStatusCode.OK)
			{
				Content = new StringContent($"{purgeHistoryResult.InstancesDeleted} instances were delete.")
			};
		}
	}
}