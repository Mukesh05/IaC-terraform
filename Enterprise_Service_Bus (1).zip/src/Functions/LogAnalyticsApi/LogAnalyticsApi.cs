using System.IO;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Net.Http;
using System.Net;
using System.Text;

namespace LogAnalyticsApi
{
	public class LogAnalyticsApi
    {
		IFetchLogAnalyticsData _fetchLogAnalyticsData;
		HttpClient _httpClient = new HttpClient();

		public LogAnalyticsApi(IFetchLogAnalyticsData fetchLogAnalyticsData)
		{
			_fetchLogAnalyticsData = fetchLogAnalyticsData;
		}

        [FunctionName("LogAnalytics_old")]
        public async Task<HttpResponseMessage> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function started processing a request.");

			string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
			var finalResponse = await _fetchLogAnalyticsData.GetLogAnalyticsData(_httpClient, requestBody);
			var response = new HttpResponseMessage(HttpStatusCode.OK);
			response.Content = new StringContent(finalResponse, Encoding.UTF8, "application/json");

			return response;
        }
    }
}
