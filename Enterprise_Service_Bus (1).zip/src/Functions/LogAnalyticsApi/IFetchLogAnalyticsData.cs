﻿using System.Net.Http;
using System.Threading.Tasks;

namespace LogAnalyticsApi
{
	public interface IFetchLogAnalyticsData
	{
		Task<string> GetLogAnalyticsData(HttpClient httpClient, string query);
	}
}