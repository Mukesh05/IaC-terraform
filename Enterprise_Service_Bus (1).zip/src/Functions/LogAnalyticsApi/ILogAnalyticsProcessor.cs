﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace LogAnalyticsApi
{
	public interface ILogAnalyticsProcessor
	{
		Task<Root> RunAsync(string accountName, string tenantId, IList<string> workspaceIds, string query);
	}
}
