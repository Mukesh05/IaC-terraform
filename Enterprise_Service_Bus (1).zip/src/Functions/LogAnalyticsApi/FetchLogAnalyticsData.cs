﻿using System;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Common.ESB;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace LogAnalyticsApi
{
	public class FetchLogAnalyticsData : IFetchLogAnalyticsData
	{

		ISecurity _security;
		IConfiguration _config;
		IServiceNowTableQuery _serviceNowTableQuery;
		ILogger<FetchLogAnalyticsData> _logger;

		public FetchLogAnalyticsData(IServiceNowTableQuery serviceNowTableQuery, ISecurity security, IConfiguration config, ILogger<FetchLogAnalyticsData> logger)
		{
			_serviceNowTableQuery = serviceNowTableQuery;
			_security = security;
			_config = config;
			_logger = logger;
		}

		private UriBuilder BuildUrl(string logAnalyticsWorkspaceId)
		{
			var uriBuilder = new UriBuilder($"https://api.loganalytics.io/v1/workspaces/{logAnalyticsWorkspaceId}/query");

			return uriBuilder;
		}

		public async Task<string> GetLogAnalyticsData(HttpClient httpClient, string query)
		{
			_logger.LogInformation($"Processing kusto query {query}");
			Root accumulatedRootForAllLAWorkspaces = null;
			var serviceNowAccounts = await _serviceNowTableQuery.GetServiceNowTableData<ServiceNowAccountResult>("u_account_azure_event_mapping", "sysparm_query=u_workspace_idsISNOTEMPTY&sysparm_fields=u_account.name,u_tenant_ids,u_workspace_ids");
			foreach (var account in serviceNowAccounts.ServiceNowAccounts)
			{
				try
				{
					if (string.IsNullOrEmpty(account.LA_WorkspaceIds) || string.IsNullOrEmpty(account.Tenant_ids) || string.IsNullOrEmpty(account.Account_name))
					{
						continue;
					}

					string tenantId = account.Tenant_ids;
					string accountname = account.Account_name;

					var accessToken = await _security.GetAuthToken(tokenAudience: "https://api.loganalytics.io", tenantId, _config["LogAnalyticsApi:Secret"], _config["LogAnalyticsApi:ClientId"]);
					var workspaceIds = account.LA_WorkspaceIds?.Split(",");
					foreach (var workspaceId in workspaceIds)
					{
						_logger.LogInformation($"Processing workspace {workspaceId} from {account.Account_name}.");

						var uriBuilder = BuildUrl(workspaceId);
						httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
						var content = new StringContent(query, Encoding.UTF8, "application/json");
						HttpResponseMessage response = await httpClient.PostAsync(uriBuilder.Uri, content);
						var responseContentFromApi = await response.Content.ReadAsStringAsync();

						//If not successful, log api error response and move on to next client.
						if (!response.IsSuccessStatusCode)
						{
							var message = await response.Content.ReadAsStringAsync();
							_logger.LogError($"Failed to call Log Analytics API for {account.Account_name}({account.Tenant_ids}). {response.ReasonPhrase} : {message})");
							continue;
						}

						//We need to accumulate the response for each account into one final response

						Root deserializedRootContent = JsonConvert.DeserializeObject<Root>(responseContentFromApi);
						var tenantHeaderColumn = new Column { name = "TenantId", type = "string" };
						var workSpaceIdHeaderColumn = new Column { name = "WorkSpaceId", type = "string" };
						var accountNameHeaderColumn = new Column { name = "AccountName", type = "string" };
						foreach (var table in deserializedRootContent.tables)
						{
							table.columns.Add(tenantHeaderColumn);
							table.columns.Add(workSpaceIdHeaderColumn);
							table.columns.Add(accountNameHeaderColumn);

							foreach (var row in table.rows)
							{
								row.Add(tenantId);
								row.Add(workspaceId);
								row.Add(accountname);
							}

							if (accumulatedRootForAllLAWorkspaces != null)
							{
								accumulatedRootForAllLAWorkspaces.tables.Find(tbl => tbl.name == table.name).rows.AddRange(table.rows);
							}
						}

						if(accumulatedRootForAllLAWorkspaces == null)
						{
							accumulatedRootForAllLAWorkspaces = deserializedRootContent;
						}

						_logger.LogInformation($"Finished processing workspace {workspaceId} from {account.Account_name}. {deserializedRootContent.tables[0].rows.Count} rows retrieved.");
					}
				}
				catch (Exception ex)
				{
					//Log error and move on to processing the next client.
					_logger.LogError(ex, $"Failed to process data for {account.Account_name}({account.Tenant_ids}).");
				}
			}

			_logger.LogInformation($"Retrieved {accumulatedRootForAllLAWorkspaces.tables[0].rows.Count} rows in total.");

			var returnJson = JsonConvert.SerializeObject(accumulatedRootForAllLAWorkspaces);
			return returnJson;
		}
	}
}
