﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Common.ESB;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace LogAnalyticsApi
{
	public class LogAnalyticsProcessor : ILogAnalyticsProcessor
	{
		IConfiguration _configuration;
		ILogger<LogAnalyticsProcessor> _logger;
		ISecurity _security;
		HttpClient _httpClient;

		public LogAnalyticsProcessor(IConfiguration configuration, ILogger<LogAnalyticsProcessor> logger, ISecurity security, HttpClient httpClient)
		{
			_configuration = configuration;
			_logger = logger;
			_security = security;
			_httpClient = httpClient;
		}

		/// <summary>
		/// Process kusto queries against the specificed workspaces.
		/// </summary>
		/// <param name="accountName"></param>
		/// <param name="tenantId"></param>
		/// <param name="workspaceIds"></param>
		/// <param name="query"></param>
		/// <returns></returns>
		public async Task<Root> RunAsync(string accountName, string tenantId, IList<string> workspaceIds, string query)
		{
			_logger.LogInformation($"Processing query to Log Analytics for {accountName} (TenantId : {tenantId}).");

			Root accumulatedRoots = null;

			string token;
			//Retrieve the bear token to make api call.
			try
			{
				token = await _security.GetAuthToken("https://api.loganalytics.io",
														 tenantId,
														 _configuration["LogAnalyticsApi:Secret"],
														 _configuration["LogAnalyticsApi:ClientId"]);
			}
			catch(Exception ex)
			{
				_logger.LogError($"Failed to retreive token for {tenantId}. ({ex.Message})");
				return null;
			}

			//Go through each workspace specified and collect the query result data.
			foreach(var workspaceId in workspaceIds)
			{
				try
				{
					//Make the api call to the workspace.
					Uri uri = new Uri($"https://api.loganalytics.io/v1/workspaces/{workspaceId}/query");
					_httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
					var content = new StringContent(query, Encoding.UTF8, "application/json");
					HttpResponseMessage response = await _httpClient.PostAsync(uri, content);
					var responseContentFromApi = await response.Content.ReadAsStringAsync();

					//If not successful, log api error response and move on to the next workspace
					if (!response.IsSuccessStatusCode)
					{
						var message = await response.Content.ReadAsStringAsync();
						_logger.LogError($"Failed to call Log Analytics API for {accountName} (TenantId : {tenantId}, WorkspaceId : {workspaceId}). {response.ReasonPhrase} : {message})");
						continue;
					}

					//Add and enrich the next set of results
					Root deserializedRootContent = JsonConvert.DeserializeObject<Root>(responseContentFromApi);
					var tenantHeaderColumn = new Column { name = "TenantId", type = "string" };
					var workSpaceIdHeaderColumn = new Column { name = "WorkSpaceId", type = "string" };
					var accountNameHeaderColumn = new Column { name = "AccountName", type = "string" };
					foreach (var table in deserializedRootContent.tables)
					{
						table.columns.Add(tenantHeaderColumn);
						table.columns.Add(workSpaceIdHeaderColumn);
						table.columns.Add(accountNameHeaderColumn);

						foreach (var row in table.rows)
						{
							row.Add(tenantId);
							row.Add(workspaceId);
							row.Add(accountName);
						}

						if (accumulatedRoots != null)
						{
							accumulatedRoots.tables.Find(tbl => tbl.name == table.name).rows.AddRange(table.rows);
						}
					}

					if (accumulatedRoots == null)
					{
						accumulatedRoots = deserializedRootContent;
					}
				}
				catch(Exception ex)
				{
					_logger.LogError(ex, $"Failed to process data for {accountName} (TenantId : {tenantId}, WorkspaceId : {workspaceId}).");
				}
			}

			if(accumulatedRoots == null)
			{
				_logger.LogInformation($"Could not retrieve data for {accountName} (TenantId : {tenantId}).");
				return null;
			}
			else
			{
				_logger.LogInformation($"Retrieved {accumulatedRoots.tables[0].rows.Count} rows for {accountName} (TenantId : {tenantId}).");
				return accumulatedRoots;
			}
		}
	}
}