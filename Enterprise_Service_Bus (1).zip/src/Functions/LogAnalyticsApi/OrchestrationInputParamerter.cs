﻿using System;
using System.Collections.Generic;
using System.Text;
using Common.ESB;

namespace LogAnalyticsApi
{
	public class OrchestrationInputParamerter
	{
		public ServiceNowAccountResult GetServiceNowAccountResult { get; set; }
		public string Query { get; set; }
	}
}
