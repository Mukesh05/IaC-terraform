using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Moq.Protected;
using Common.ESB;
using InTuneExtractSchedule.Models;
using InTuneExtractSchedule.Services;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Text;
using Microsoft.Azure.ServiceBus;
using Microsoft.AspNetCore.Mvc;

namespace InTuneExtractScheduleTests
{
	[ExcludeFromCodeCoverage]
	[TestClass]
	public class InTuneExtractScheduleTests
	{
		Mock<IConfigurationRefresher> _mockConfigRefresher;
		Mock<IConfiguration> _mockConfigReport;
		Mock<ILogger<InTuneExtractSchedule.InTuneExtractSchedule>> _mockLogger;
		Mock<IServiceNowClient> _mockServiceNowClient;
		Mock<IScheduleRepositoryService> _mockScheduleRepositoryService;
		Mock<IESBSender> eSBSendersList;
		Mock<IESBSender> _mockeSBReportSender;
		Mock<IESBSender> _mockeSBAlertSender;
		Mock<IIntuneDataService> _mockIntuneDataService;
		Mock<ICronExpressionCalculatorService> _mockCronExpressionCalculatorService;

		[TestInitialize]
		public void Setup()
		{
			//Setup IConfigurationRefresher
			_mockConfigRefresher = new Mock<IConfigurationRefresher>();
			_mockConfigRefresher.Setup(x => x.TryRefreshAsync()).ReturnsAsync(true);

			//Setup IConfiguration
			_mockConfigReport = new Mock<IConfiguration>();
			_mockConfigReport.Setup(x => x["IntuneReport:TopicName"]).Returns("reportTopicName");
			_mockConfigReport.Setup(x => x["IntuneReport:AlertTopicName"]).Returns("alertTopicName");

			//Setup ILogger
			_mockLogger = new Mock<ILogger<InTuneExtractSchedule.InTuneExtractSchedule>>();

			//Setup IESBSender
			_mockeSBReportSender = new Mock<IESBSender>();
			_mockeSBReportSender.SetupGet(x => x.Name).Returns("report");
			
			_mockeSBAlertSender = new Mock<IESBSender>();
			_mockeSBAlertSender.SetupGet(x => x.Name).Returns("alert");
			

			//Setup IServiceNowClient
			var dummyServiceNowResponse = File.ReadAllText("dummy_servicenow_response.json");
			_mockServiceNowClient = new Mock<IServiceNowClient>();
			_mockServiceNowClient.Setup(x => x.QueryTable(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(dummyServiceNowResponse);


			//Setup IInTuneDataService
			ReportData mockReportData = new ReportData
			{
				ReportId = "defenderagents_61946672-c3ba-4c2f-9ca7-a1a62e94449f",
				ReportName = "defenderagents",
				Format = "csv",
				Status = "notStarted",
				RequestDateTime = "2021-03-19T02:01:47.5113087Z",
				ExpirationDateTime = "0001-01-01T00:00:00Z"
			};

			_mockIntuneDataService = new Mock<IIntuneDataService>();
			_mockIntuneDataService.Setup(x => x.GetDataAsync(It.IsAny<string>(),
															 It.IsAny<string>(),
															 It.IsAny<string[]>(),
															 It.IsAny<string>(),
															 It.IsAny<string>()))
				                     .ReturnsAsync(mockReportData);
		}


		[TestMethod]
		public void Run_TimerTriggerFunction_NoSchedulesToProcess()
		{
			//Setup IScheduleRepositoryService

			QuerySchedule mockQuerySchedule = new QuerySchedule()
			{
				ETag = "W /\"datetime'2021-03-19T01%3A35%3A13.4779179Z'\"",
				PartitionKey = "Query",
				ReportName = "defenderagents",
				RowKey = "defenderagents",
				Schedule = "40 0/1 ? * *",
				Select = "DeviceName,DeviceState,AntiMalwareVersion,CriticalFailure,ProductStatus," +
						 "TamperProtectionEnabled,IsVirtualMachine,EngineVersion,FullScanOverdue,FullScanRequired," +
						 "LastFullScanDateTime,LastQuickScanDateTime,LastQuickScanSignatureVersion," +
						 "LastReportedDateTime,MalwareProtectionEnabled,NetworkInspectionSystemEnabled," +
						 "PendingFullScan,PendingManualSteps,PendingOfflineScan,PendingReboot,QuickScanOverdue," +
						 "RealTimeProtectionEnabled,RebootRequired,SignatureUpdateOverdue,SignatureVersion,UPN" +
						 ",UserEmail,UserName",
				Timestamp = new DateTime(2021, 03, 18, 9, 35, 13, DateTimeKind.Utc), //"18/03/2021 9:35:13 PM -04:00"
				ScheduleType = "report"  
			};

			_mockScheduleRepositoryService = new Mock<IScheduleRepositoryService>();
			_mockScheduleRepositoryService.Setup(x => x.List()).Returns(new List<QuerySchedule>() { mockQuerySchedule });

			//Setup ICronExpressionCalculatorService
			Mock<ICronExpressionCalculatorService> _mockCronExpressionCalculatorService;
			_mockCronExpressionCalculatorService = new Mock<ICronExpressionCalculatorService>();
			_mockCronExpressionCalculatorService.Setup(
				x => x.IsCronExpressionWithinCurrentTime(It.IsAny<string>(),
														 It.IsAny<int>()))
														.Returns(false);

			List<IESBSender> eSBSendersList = new List<IESBSender>();
			eSBSendersList.Add(_mockeSBAlertSender.Object);
			eSBSendersList.Add(_mockeSBReportSender.Object);

			var inTuneExtractSchedule = new InTuneExtractSchedule.InTuneExtractSchedule(_mockConfigReport.Object,
																						_mockConfigRefresher.Object,
																						_mockLogger.Object,
																						_mockServiceNowClient.Object,
																						_mockScheduleRepositoryService.Object,
																						 eSBSendersList,
																						_mockIntuneDataService.Object,
																						_mockCronExpressionCalculatorService.Object);


			inTuneExtractSchedule.Run(null, null);

			// negative test
			
			_mockServiceNowClient.VerifyNoOtherCalls();
			_mockIntuneDataService.VerifyNoOtherCalls();
			_mockCronExpressionCalculatorService.Verify();

			_mockLogger.VerifyLogging("There are no InTune report schedules to run at this time.", LogLevel.Information);
		}

		[TestMethod]
		public void Run_TimerTriggerFunction_SchedulesToProcess()
		{
			//Setup IScheduleRepositoryService

			QuerySchedule mockQuerySchedule = new QuerySchedule()
			{
				ETag = "W /\"datetime'2021-03-19T01%3A35%3A13.4779179Z'\"",
				PartitionKey = "Query",
				ReportName = "defenderagents",
				RowKey = "defenderagents",
				Schedule = "40 0/1 ? * *",
				Select = "DeviceName,DeviceState,AntiMalwareVersion,CriticalFailure,ProductStatus," +
						 "TamperProtectionEnabled,IsVirtualMachine,EngineVersion,FullScanOverdue,FullScanRequired," +
						 "LastFullScanDateTime,LastQuickScanDateTime,LastQuickScanSignatureVersion," +
						 "LastReportedDateTime,MalwareProtectionEnabled,NetworkInspectionSystemEnabled," +
						 "PendingFullScan,PendingManualSteps,PendingOfflineScan,PendingReboot,QuickScanOverdue," +
						 "RealTimeProtectionEnabled,RebootRequired,SignatureUpdateOverdue,SignatureVersion,UPN" +
						 ",UserEmail,UserName",
				Timestamp = new DateTime(2021, 03, 18, 9, 35, 13, DateTimeKind.Utc), //"18/03/2021 9:35:13 PM -04:00"
				ScheduleType = "report" // this will be different in each test depending on the 
			};

			_mockScheduleRepositoryService = new Mock<IScheduleRepositoryService>();
			_mockScheduleRepositoryService.Setup(x => x.List()).Returns(new List<QuerySchedule>() { mockQuerySchedule });


			//Setup ICronExpressionCalculatorService

			Mock<ICronExpressionCalculatorService> _mockCronExpressionCalculatorService;
			_mockCronExpressionCalculatorService = new Mock<ICronExpressionCalculatorService>();
			_mockCronExpressionCalculatorService.Setup(x => x.IsCronExpressionWithinCurrentTime(
																	It.IsAny<string>(),
																	It.IsAny<int>()))
												.Returns(true);


			List<IESBSender> eSBSendersList = new List<IESBSender>();
			eSBSendersList.Add(_mockeSBAlertSender.Object);
			eSBSendersList.Add(_mockeSBReportSender.Object);
			

			var inTuneExtractSchedule = new InTuneExtractSchedule.InTuneExtractSchedule(_mockConfigReport.Object,
																						_mockConfigRefresher.Object,
																						_mockLogger.Object,
																						_mockServiceNowClient.Object,
																						_mockScheduleRepositoryService.Object,
																						eSBSendersList,
																						_mockIntuneDataService.Object,
																						_mockCronExpressionCalculatorService.Object);

			inTuneExtractSchedule.Run(null, null);


			_mockLogger.VerifyLogging("Processed scheduled report 'defenderagents' for account 'NS Development' (cc168f1f-1c24-4c5d-863c-957555b5593c)",
									  LogLevel.Information);

		}
		

		[TestMethod]
		public async Task RunAsync_msgShouldGoOn_ReportTopicName()
		{
			
			List<IESBSender> eSBSendersList = new List<IESBSender>();
			eSBSendersList.Add(_mockeSBReportSender.Object);
			eSBSendersList.Add(_mockeSBAlertSender.Object);


			QuerySchedule mockQuerySchedule = new QuerySchedule()
			{
				ETag = "W /\"datetime'2021-03-19T01%3A35%3A13.4779179Z'\"",
				PartitionKey = "Query",
				ReportName = "defenderagents",
				RowKey = "defenderagents",
				Schedule = "40 0/1 ? * *",
				Select = "DeviceName,DeviceState,AntiMalwareVersion,CriticalFailure,ProductStatus," +
						 "TamperProtectionEnabled,IsVirtualMachine,EngineVersion,FullScanOverdue,FullScanRequired," +
						 "LastFullScanDateTime,LastQuickScanDateTime,LastQuickScanSignatureVersion," +
						 "LastReportedDateTime,MalwareProtectionEnabled,NetworkInspectionSystemEnabled," +
						 "PendingFullScan,PendingManualSteps,PendingOfflineScan,PendingReboot,QuickScanOverdue," +
						 "RealTimeProtectionEnabled,RebootRequired,SignatureUpdateOverdue,SignatureVersion,UPN" +
						 ",UserEmail,UserName",
				Timestamp = new DateTime(2021, 03, 18, 9, 35, 13, DateTimeKind.Utc), //"18/03/2021 9:35:13 PM -04:00"
				ScheduleType = "report" 
			};

			_mockScheduleRepositoryService = new Mock<IScheduleRepositoryService>();
			_mockScheduleRepositoryService.Setup(x => x.List()).Returns(new List<QuerySchedule>() { mockQuerySchedule });

			_mockCronExpressionCalculatorService = new Mock<ICronExpressionCalculatorService>();
			_mockCronExpressionCalculatorService.Setup(x => x.IsCronExpressionWithinCurrentTime(It.IsAny<string>(), It.IsAny<int>())).Returns(true);

			var inTuneExtractSchedule = new InTuneExtractSchedule.InTuneExtractSchedule(_mockConfigReport.Object,
																						_mockConfigRefresher.Object,
																						_mockLogger.Object,
																						_mockServiceNowClient.Object,
																						_mockScheduleRepositoryService.Object,
																						eSBSendersList,
																						_mockIntuneDataService.Object,
																						_mockCronExpressionCalculatorService.Object);

			//Act
			await inTuneExtractSchedule.RunAsync();


			//Assert
			_mockIntuneDataService.Verify(x => x.GetDataAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string[]>(), "report", It.IsAny<string>()));

			_mockeSBReportSender.Verify(sender => sender.SendMessageAsync(
												It.Is<string>(topic => (topic == "reportTopicName")),
												It.Is<string>(message => message.Contains("\"scheduleType\": \"report\""))),
										        Times.Exactly(2));

			_mockLogger.VerifyLogging("Processed scheduled report 'defenderagents' for account 'NS Development' (cc168f1f-1c24-4c5d-863c-957555b5593c)", LogLevel.Information);
			_mockLogger.VerifyLogging("Processed scheduled report 'defenderagents' for account 'NS Development' (56c90202-7b8c-492e-bcae-01c71d54d60a)", LogLevel.Information);
		
	}



		[TestMethod]
		public async Task RunAsync_SingleAlertScheduleExpectMessagesOnAlertTopic()
		{
			List<IESBSender> eSBSendersList = new List<IESBSender>();
			eSBSendersList.Add(_mockeSBAlertSender.Object);
			eSBSendersList.Add(_mockeSBReportSender.Object);


			QuerySchedule mockQuerySchedule = new QuerySchedule()
			{
				ETag = "W /\"datetime'2021-03-19T01%3A35%3A13.4779179Z'\"",
				PartitionKey = "Query",
				ReportName = "defenderagents",
				RowKey = "defenderagents",
				Schedule = "40 0/1 ? * *",
				Select = "DeviceName,DeviceState,AntiMalwareVersion,CriticalFailure,ProductStatus," +
						 "TamperProtectionEnabled,IsVirtualMachine,EngineVersion,FullScanOverdue,FullScanRequired," +
						 "LastFullScanDateTime,LastQuickScanDateTime,LastQuickScanSignatureVersion," +
						 "LastReportedDateTime,MalwareProtectionEnabled,NetworkInspectionSystemEnabled," +
						 "PendingFullScan,PendingManualSteps,PendingOfflineScan,PendingReboot,QuickScanOverdue," +
						 "RealTimeProtectionEnabled,RebootRequired,SignatureUpdateOverdue,SignatureVersion,UPN" +
						 ",UserEmail,UserName",
				Timestamp = new DateTime(2021, 03, 18, 9, 35, 13, DateTimeKind.Utc), //"18/03/2021 9:35:13 PM -04:00"
				ScheduleType = "alert"  
			};

			_mockScheduleRepositoryService = new Mock<IScheduleRepositoryService>();
			_mockScheduleRepositoryService.Setup(x => x.List()).Returns(new List<QuerySchedule>() { mockQuerySchedule });

			var message = new
			{

				tenantId = "cc168f1f-1c24-4c5d-863c-957555b5593c",
				accountName = "NS Development",
				reportId = "defenderagents_61946672-c3ba-4c2f-9ca7-a1a62e94449f",
				reportName = "defenderagents",
				requestDateTime = "2021-03-19T02:01:47.5113087Z",
				expirationDateTime = "0001-01-01T00:00:00Z",
				status = "notStarted",
				format = "csv",
				selectFields = "schedule.Select.Split(',')",
				scheduleType = "alert"

			};
			var dummyjsonMessage = JObject.FromObject(message).ToString(Formatting.Indented);

			_mockCronExpressionCalculatorService = new Mock<ICronExpressionCalculatorService>();
			_mockCronExpressionCalculatorService.Setup(x => x.IsCronExpressionWithinCurrentTime(It.IsAny<string>(), It.IsAny<int>())).Returns(true);

			var inTuneExtractSchedule = new InTuneExtractSchedule.InTuneExtractSchedule(_mockConfigReport.Object,
																						_mockConfigRefresher.Object,
																						_mockLogger.Object,
																						_mockServiceNowClient.Object,
																						_mockScheduleRepositoryService.Object,
																						eSBSendersList,
																						_mockIntuneDataService.Object,
																						_mockCronExpressionCalculatorService.Object);

			//Act
			await inTuneExtractSchedule.RunAsync();

			//Assert
			_mockIntuneDataService.Verify(x => x.GetDataAsync(It.IsAny<string>(),
															  It.IsAny<string>(),
															  It.IsAny<string[]>(),
															  "alert",
															  It.IsAny<string>()));


			// TODO: verify correct message bus message is sent
			_mockeSBAlertSender.Verify(sender => sender.SendMessageAsync(
										It.Is<string>(topic => (topic == "alertTopicName")),
										It.Is<string>(message => message.Contains("\"scheduleType\": \"alert\"") )),
									    Times.Exactly(2)
									   );

			_mockLogger.VerifyLogging("Processed scheduled alert 'defenderagents' for account 'NS Development' (cc168f1f-1c24-4c5d-863c-957555b5593c)", LogLevel.Information);
		    _mockLogger.VerifyLogging("Processed scheduled alert 'defenderagents' for account 'NS Development' (56c90202-7b8c-492e-bcae-01c71d54d60a)", LogLevel.Information);
		}

		public static HttpClient GetMockedHttpClient(string responseContent)
		{
			var handlerMock = new Mock<HttpMessageHandler>();
			var response = new HttpResponseMessage
			{
				StatusCode = HttpStatusCode.OK,
				Content = new StringContent(responseContent),
			};

			handlerMock
				.Protected()
				.Setup<Task<HttpResponseMessage>>(
					"SendAsync",
					ItExpr.IsAny<HttpRequestMessage>(),
					ItExpr.IsAny<CancellationToken>())
				.ReturnsAsync(response);
			var httpClient = new HttpClient(handlerMock.Object);
			return httpClient;
		}
	}
}
