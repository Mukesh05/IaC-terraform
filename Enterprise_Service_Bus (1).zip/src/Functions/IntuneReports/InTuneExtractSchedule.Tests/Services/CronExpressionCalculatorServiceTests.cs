﻿using System;
using System.Diagnostics.CodeAnalysis;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using InTuneExtractSchedule.Services;

namespace InTuneExtractScheduleTests.Services
{
	[ExcludeFromCodeCoverage]
	[TestClass]
	public class CronExpressionCalculatorServiceTests
	{
		[ExcludeFromCodeCoverage]
		[TestMethod]
		public void IsCronExpressionWithinCurrentTime_WithinCurrentTime_ReturnsTrue()
		{
			var minuteWithin5Min = 2;
			var currentDateTime = DateTime.UtcNow;
			var mockMinute = DateTime.UtcNow.Minute + minuteWithin5Min;

			if (mockMinute > 59)
			{
				mockMinute -= 60;
			}

			var cronExpressionToTest = $"{mockMinute} 0/1 ? * *";

			ICronExpressionCalculatorService cronExpressionCalculatorService = new CronExpressionCalculatorService();
			bool result = cronExpressionCalculatorService.IsCronExpressionWithinCurrentTime(cronExpressionToTest, 5);

			Assert.IsTrue(result, $"{cronExpressionToTest} is within 5 minutes of {currentDateTime}.");
		}

		[TestMethod]
		public void IsCronExpressionWithinCurrentTime_NotWithinCurrentTime_ReturnsFalse()
		{
			var currentMinuteNotWithin5Min = 15;
			var currentDateTime = DateTime.UtcNow;
			var mockMinute = DateTime.UtcNow.Minute + currentMinuteNotWithin5Min;

			if (mockMinute > 59)
			{
				mockMinute -=60;
			}

			var cronExpressionToTest = $"{mockMinute} 0/1 ? * *";

			ICronExpressionCalculatorService cronExpressionCalculatorService = new CronExpressionCalculatorService();
			bool result = cronExpressionCalculatorService.IsCronExpressionWithinCurrentTime(cronExpressionToTest, 5);

			Assert.IsFalse(result, $"{cronExpressionToTest} is not within 5 minutes of {currentDateTime}.");
		}

	}
}
