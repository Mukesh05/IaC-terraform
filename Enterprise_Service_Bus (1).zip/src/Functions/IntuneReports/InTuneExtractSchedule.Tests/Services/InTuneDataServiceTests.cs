﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Common.ESB;
using InTuneExtractSchedule.Models;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Moq.Protected;
using Newtonsoft.Json.Linq;
using InTuneExtractSchedule.Services;
using Microsoft.Extensions.Configuration;

namespace InTuneExtractScheduleTests.Services
{
	[ExcludeFromCodeCoverage]
	[TestClass]
	public class InTuneDataServiceTests
	{
		Mock<IConfiguration> _mockConfiguration;
		Mock<ILogger<InTuneDataService>> _mockLogger;
		Mock<ISecurity> _mockSecurity;
		Mock<ISecurity> _mockBadSecurity;
		
		[TestInitialize]
		public void Initalize()
		{
			_mockConfiguration = new Mock<IConfiguration>();
			_mockConfiguration.Setup(x => x["IntuneReport:intunereport-sp-id"]).Returns("123ABC");
			_mockConfiguration.Setup(x => x["IntuneReport:intunereport-sp-secret"]).Returns("8910XYZ");

			_mockLogger = new Mock<ILogger<InTuneDataService>>();

			_mockSecurity = new Mock<ISecurity>();
			_mockSecurity.Setup(x => x.GetAuthToken(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
						 .ReturnsAsync("valid-token");

			_mockBadSecurity = new Mock<ISecurity>();
			_mockBadSecurity.Setup(x => x.GetAuthToken(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
						    .Throws(new Exception("Failed to retrieve a valid token."));
		}

		[TestMethod]
		public async Task GetDataAsync_CallApiInvalidToken_ReturnNull()
		{
			var dummyResponse = File.ReadAllText("dummy_graphreport_response.json");
			HttpClient mockHttpClient = InTuneDataServiceTests.GetMockedHttpClient(dummyResponse);

			IIntuneDataService intuneDataService = new InTuneDataService(_mockConfiguration.Object,
																		 _mockLogger.Object,
																		 _mockBadSecurity.Object,
																		 mockHttpClient);

			var result = await intuneDataService.GetDataAsync("111XXX", "defenderagents", new string[] { }, "report"); // made some change

			_mockLogger.VerifyLogging("Error retrieving token in tenant 111XXX with clientId 123ABC. (Failed to retrieve a valid token.)", LogLevel.Error);
			
			Assert.AreEqual(null, result, "Expected an null DataReport.");
		}

		[TestMethod]
		public async Task GetDataAsync_CallApiOk_ReturnReportData()
		{
			var dummyResponse = File.ReadAllText("dummy_graphreport_response.json");
			HttpClient mockHttpClient = InTuneDataServiceTests.GetMockedHttpClient(dummyResponse);

			IIntuneDataService intuneDataService = new InTuneDataService(_mockConfiguration.Object,
																		 _mockLogger.Object,
																		 _mockSecurity.Object,
																		 mockHttpClient);

			var result = await intuneDataService.GetDataAsync("tenantId", "defenderagents", new string[] { },"report");
			


			var testReportData = new ReportData()
			{
				ReportId = "defenderagents_00b47af0-a929-4e9f-9b60-567631590162",
				ReportName = "defenderagents",
				Format = "csv",
				Status = "notStarted",
				RequestDateTime = "2021-03-18T16:31:05.2950323Z",
				ExpirationDateTime = "0001-01-01T00:00:00Z",
				
			};

			var expectedResult = JObject.FromObject(testReportData).ToString();
			var actualResult = JObject.FromObject(result).ToString();

			Assert.AreEqual(expectedResult, actualResult, "Acutal report data did not match expected report data.");
		}


		public static HttpClient GetMockedHttpClient(string responseContent)
		{
			var handlerMock = new Mock<HttpMessageHandler>();
			var response = new HttpResponseMessage
			{
				StatusCode = HttpStatusCode.OK,
				Content = new StringContent(responseContent),
			};

			handlerMock
				.Protected()
				.Setup<Task<HttpResponseMessage>>(
					"SendAsync",
					ItExpr.IsAny<HttpRequestMessage>(),
					ItExpr.IsAny<CancellationToken>())
				.ReturnsAsync(response);
			var httpClient = new HttpClient(handlerMock.Object);
			return httpClient;
		}
	}
}
