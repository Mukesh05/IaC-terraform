﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace InTuneExtractSchedule.Models
{
	public class ReportData
	{
		[JsonProperty("id")]
		public string ReportId { get; set; }

		[JsonProperty("reportName")]
		public string ReportName { get; set; }

		[JsonProperty("format")]
		public string Format { get; set; }

		[JsonProperty("status")]
		public string Status { get; set; }

		[JsonProperty("requestDateTime")]
		public string RequestDateTime { get; set; }

		[JsonProperty("expirationDateTime")]
		public string ExpirationDateTime { get; set; }
	}
}
