﻿using Microsoft.Azure.Cosmos.Table;

namespace InTuneExtractSchedule.Models
{
	public class QuerySchedule : TableEntity
	{
		string _reportName;

		public QuerySchedule()
		{
			PartitionKey = "Query";
			
		}

		public string ReportName
		{
			get
			{
				return _reportName;
			}
			set
			{
				RowKey =  _reportName = value.ToLower();
			}
		}
		public string Select { get; set; }
		public string Schedule { get; set; }
		public string Filter { get; set; }
		public string ScheduleType { get; set; }
		public string RestrictedToTenantId { get; set; }
	}
}
