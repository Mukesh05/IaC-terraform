using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Common.ESB;
using InTuneExtractSchedule.Models;
using InTuneExtractSchedule.Services;


namespace InTuneExtractSchedule
{
	public class InTuneExtractSchedule
	{
		IConfigurationRefresher _configRefresher;
		IConfiguration _config;
		ILogger<InTuneExtractSchedule> _logger;
		IServiceNowClient _serviceNowClient;
		IScheduleRepositoryService _scheduleRepositoryService;		
		IESBSender _eSBReportSender;
		IESBSender _eSBAlertSender;
		IIntuneDataService _intuneDataService;
		ICronExpressionCalculatorService _cronExpressionCalculatorService;

		public InTuneExtractSchedule(IConfiguration config,
									 IConfigurationRefresher configRefresher,
									 ILogger<InTuneExtractSchedule> logger,
									 IServiceNowClient serviceNowClient,
									 IScheduleRepositoryService scheduleRepositoryService,
									 IEnumerable<IESBSender> eSBSendersList, // IESBSender esbSender,
									 IIntuneDataService intuneDataService,
									 ICronExpressionCalculatorService cronExpressionCalculatorService)
		{
			_configRefresher = configRefresher;
			_config = config;
			_logger = logger;
			_serviceNowClient = serviceNowClient;
			_scheduleRepositoryService = scheduleRepositoryService;
			_eSBReportSender = eSBSendersList.Where(x => x.Name == "report").First();
			_eSBAlertSender = eSBSendersList.Where(x => x.Name == "alert").First();
			_intuneDataService = intuneDataService;
			_cronExpressionCalculatorService = cronExpressionCalculatorService;
		}

		[FunctionName("InTuneExtractOnDemand")]

		public async Task<IActionResult> OnDemandAsync([HttpTrigger(AuthorizationLevel.Function, "post", Route = "ondemand")] HttpRequest req)
		{
			await _configRefresher.TryRefreshAsync();

			_logger.LogInformation($"Running scheduled reports on demand at: {DateTime.Now}");
			var numberOfMessagesSent = await RunAsync();


			return new OkObjectResult(new
			{
				message = $"Scheduled reports processed. Number of messages sent {numberOfMessagesSent}."
			});

		}

		[FunctionName("InTuneExtractSchedule")]

		public async Task Run([TimerTrigger("%TimerSchedule%")] TimerInfo myTimer,
							  ExecutionContext context)
		{
			await _configRefresher.TryRefreshAsync();

			_logger.LogInformation($"Running scheduled reports via timer trigger at: {DateTime.Now}");
			await RunAsync();
		}


		/// <summary>
		/// Run the scheduled reports
		/// </summary>
		/// <returns></returns>
		public async Task<int> RunAsync()
		{
			var schedules = GetSchedulesToRun();

			if (schedules.Count() == 0)
			{
				_logger.LogInformation("There are no InTune report schedules to run at this time.");
				return 0;
			}

			var numberOfMessagesSent = 0;
			var accountsForReports = await GetAccountsFromServiceAsync("report");
			var accountsForAlerts = await GetAccountsFromServiceAsync("alert");

			foreach (var account in accountsForReports.Union(accountsForAlerts))
			{
				var allSchedules = schedules.Where(x => x.ScheduleType.ToLower() == "report")
					.Union(schedules.Where(x => x.ScheduleType.ToLower() == "alert"));

				foreach (var schedule in allSchedules)
				{
					try
					{
						// Check if this query schedule is restricted to specific tenantId.
						var restrictedTenantId = schedule.RestrictedToTenantId;
						var currentTenantId = (string)account.tenantId;
						if(!string.IsNullOrEmpty(restrictedTenantId) &&
							string.Compare(restrictedTenantId, currentTenantId, StringComparison.OrdinalIgnoreCase) != 0)
						{
							continue; //Don't process.
						}

						ReportData reportData = await _intuneDataService.GetDataAsync(account.tenantId,
							schedule.ReportName,
							schedule.Select.Split(","),
							schedule.ScheduleType,
							schedule.Filter);

						if (reportData == null)
						{
							_logger.LogWarning($"There is no data available for scheduled alerting of {schedule.ReportName} for account {account.name} ({account.tenantId})");
							continue;
						}

						var message = new
						{
							tenantId = account.tenantId,
							accountName = account.name,
							reportId = reportData.ReportId,
							reportName = reportData.ReportName,
							requestDateTime = reportData.RequestDateTime,
							expirationDateTime = reportData.ExpirationDateTime,
							status = reportData.Status,
							format = reportData.Format,
							selectFields = schedule.Select.Split(','),
							scheduleType = schedule.ScheduleType,
							filter = schedule.Filter
						};

						var jsonMessage = JObject.FromObject(message).ToString(Formatting.Indented);

						if (message.scheduleType == "report")
						{
							await _eSBReportSender.SendMessageAsync(_config["IntuneReport:TopicName"], jsonMessage);
							_logger.LogInformation($"Processed scheduled report '{schedule.ReportName}' for account '{account.name}' ({account.tenantId})");
							_logger.LogInformation(jsonMessage);
						}
						else
						{
							await _eSBAlertSender.SendMessageAsync(_config["IntuneReport:AlertTopicName"], jsonMessage);
							_logger.LogInformation($"Processed scheduled alert '{schedule.ReportName}' for account '{account.name}' ({account.tenantId})");
						}

						numberOfMessagesSent += 1;
					}

					catch (Exception ex)
					{
						_logger.LogError($"Failed processing scheduled report '{schedule.ReportName}' for account '{account.name}' ({account.tenantId}). ({ex.Message})");
					}
				}
			}

			return numberOfMessagesSent;
		}

		/// <summary>
		/// Return a list of schedules to run if cron expression is within 5 minutes of current time.
		/// </summary>
		/// <returns></returns>
		private IEnumerable<QuerySchedule> GetSchedulesToRun()
		{
			List<QuerySchedule> list = new List<QuerySchedule>();

			var schedules = _scheduleRepositoryService.List().ToList();

			foreach(var schedule in schedules)
			{
				var run = _cronExpressionCalculatorService.IsCronExpressionWithinCurrentTime(schedule.Schedule, 5);
				if (run)
				{
					list.Add(schedule);
				}
			}

			return list;
		}

		/// <summary>
		/// Return a list of account details from Service Now that have InTune reports enabled.
		/// </summary>
		/// <returns></returns>
		private async Task<IEnumerable<dynamic>> GetAccountsFromServiceAsync(string reportType)
		{

			string tableQuery;
			List<dynamic> accountList = new List<dynamic>();

			if (reportType.ToLower() == "report")
			{
				 tableQuery = "sysparm_query=u_tenant_idsISNOTEMPTY^u_enable_intune_reports=true^u_disable_esb_reporting=false&sysparm_fields=u_account.name,u_tenant_ids";

			}
			else if (reportType.ToLower() == "alert")
			{
				 tableQuery = "sysparm_query=u_tenant_idsISNOTEMPTY^u_enable_intune_alerting=true^u_disable_esb_reporting=false&sysparm_fields=u_account.name,u_tenant_ids";

			}

			else
			{
				throw new ArgumentException("Your account is not enabled for reporting or alerting");
			}
			
			var queryResults = await _serviceNowClient.QueryTable("u_account_azure_event_mapping", tableQuery);

				var accounts = JObject.Parse(queryResults);
				
				foreach (var account in accounts["result"])
				{
					var tenantIds = ((string)account["u_tenant_ids"]).Split(",");
					var name = (string)account["u_account.name"];

					foreach (var id in tenantIds)
					{
						accountList.Add(new
						{
							tenantId = id,
							name = name
						});
					}
				}

			return accountList;
		}
	}
}