﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using InTuneExtractSchedule.Models;
using Microsoft.Azure.Cosmos.Table;

namespace InTuneExtractSchedule.Services
{
	/// <summary>
	/// Exclude from coverage - this is IoC code and can't be tested efficiently
	/// </summary>
	[ExcludeFromCodeCoverage]
	public class ScheduleRepositoryService : IScheduleRepositoryService
	{
		readonly string _tableName = "schedule";
		readonly string _partitionKey = "Query";
		CloudTable _cloudTable;

		public ScheduleRepositoryService(string storageConnString)
		{
			string _storageConnString = storageConnString;
			CloudStorageAccount storageAccount = CloudStorageAccount.Parse(_storageConnString);
			CloudTableClient tableClient = storageAccount.CreateCloudTableClient(new TableClientConfiguration());
			_cloudTable = tableClient.GetTableReference(_tableName);
		}

		/// <summary>
		/// Return the schedule for the specified report.
		/// </summary>
		/// <param name="reportName"></param>
		/// <returns></returns>
		public async Task<QuerySchedule> GetAsync(string reportName)
		{
			TableOperation tableOperation = TableOperation.Retrieve<QuerySchedule>(_tableName, reportName.ToLower());
			TableResult tableResult = await _cloudTable.ExecuteAsync(tableOperation);

			return tableResult.Result as QuerySchedule;
		}

		/// <summary>
		/// Return a list of schedules from storage table.
		/// </summary>
		/// <returns></returns>
		public IEnumerable<QuerySchedule> List()
		{
			var filter = TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, _partitionKey);

			TableQuery<QuerySchedule> query = new TableQuery<QuerySchedule>();
			var tableQuery = query.Where(filter);
			var result = _cloudTable.ExecuteQuery<QuerySchedule>(tableQuery);

			return result;
		}

		public async Task<QuerySchedule> InsertAsync(QuerySchedule schedule)
		{
			TableOperation tableOperation = TableOperation.InsertOrMerge(schedule);

			TableResult tableResult = await _cloudTable.ExecuteAsync(tableOperation);
			QuerySchedule scheduleResult = tableResult.Result as QuerySchedule;

			return scheduleResult;
		}

		public async Task DeleteAsync(QuerySchedule schedule)
		{
			TableOperation tableOperation = TableOperation.Delete(schedule);
			await _cloudTable.ExecuteAsync(tableOperation);
		}
	}
}
