﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using InTuneExtractSchedule.Models;

namespace InTuneExtractSchedule.Services
{
	public interface IIntuneDataService
	{
		Task<ReportData> GetDataAsync(string tenantId, string reportName, string[] select,string ScheduleType, string filter = "");
	}
}
