﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using InTuneExtractSchedule.Models;

namespace InTuneExtractSchedule.Services
{
	public interface IScheduleRepositoryService
	{
		Task<QuerySchedule> GetAsync(string reportName);
		IEnumerable<QuerySchedule> List();
		Task<QuerySchedule> InsertAsync(QuerySchedule schedule);
		public Task DeleteAsync(QuerySchedule schedule);
	}
}
