﻿using System;
using System.Collections.Generic;
using System.Text;
using Cronos;

namespace InTuneExtractSchedule.Services
{
	public class CronExpressionCalculatorService : ICronExpressionCalculatorService
	{
		public bool IsCronExpressionWithinCurrentTime(string cronExpression, int timeDifferenceInMinutes)
		{

			CronExpression expression = CronExpression.Parse(cronExpression);
			DateTime? nextUtc = expression.GetNextOccurrence(DateTime.UtcNow);

			if (nextUtc != null)
			{
				TimeSpan diff = (DateTime)nextUtc - DateTime.UtcNow;
				if (diff.TotalSeconds <= timeDifferenceInMinutes * 60)
				{
					return true;
				}
			}

			return false;
		}
	}
}
