﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Common.ESB;
using InTuneExtractSchedule.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace InTuneExtractSchedule.Services
{
	public class InTuneDataService : IIntuneDataService
	{
		HttpClient					_httpClient;
		IConfiguration				_config;
		ILogger<InTuneDataService>  _logger;
		ISecurity					_security;
		string						_clientId;
		string						_clientSecret;

		public InTuneDataService(IConfiguration config,
								 ILogger<InTuneDataService> logger,
								 ISecurity security,
								 HttpClient httpClient)
		{
			_httpClient		= httpClient;
			_config			= config;
			_logger			= logger;
			_security		= security;
			_clientId		= config["IntuneReport:intunereport-sp-id"];
			_clientSecret	= config["IntuneReport:intunereport-sp-secret"];
		}

		public async Task<ReportData> GetDataAsync(string tenantId, string reportName, string[] select, string ScheduleType, string filter = "")
		{
			string token;
			try
			{
				token = await _security.GetAuthToken("https://graph.microsoft.com/",
														 tenantId,
														 _clientSecret,
														 _clientId);
			}
			catch(Exception ex)
			{
				_logger.LogError($"Error retrieving token in tenant {tenantId} with clientId {_clientId}. ({ex.Message})");
				return null;
			}
			
			//Create payload
			var payload = new
			{
				reportName = reportName,
				filter = filter,
				select = select,
				scheduletype = ScheduleType

			};

			var jsonPayload = JObject.FromObject(payload).ToString(Formatting.Indented);

			UriBuilder uriBuilder = new UriBuilder("https://graph.microsoft.com/beta/deviceManagement/reports/exportJobs");
			_httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
			var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");
			HttpResponseMessage response = await _httpClient.PostAsync(uriBuilder.Uri, content);
			var jsonResponse = await response.Content.ReadAsStringAsync();

			//Check if call was successfull
			if (!response.IsSuccessStatusCode)
			{
				var message = await response.Content.ReadAsStringAsync();
				_logger.LogError($"Failed to call Intune Reports Graph APIs for {reportName} (TenantId : {tenantId})). {response.ReasonPhrase} : {message})");
				return null;
			}

			var result = JsonConvert.DeserializeObject<ReportData>(jsonResponse);

			return result;
		}

	}
}
