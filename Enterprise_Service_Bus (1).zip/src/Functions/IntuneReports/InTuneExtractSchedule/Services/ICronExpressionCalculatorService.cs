﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InTuneExtractSchedule.Services
{
	public interface ICronExpressionCalculatorService
	{
		bool IsCronExpressionWithinCurrentTime(string cronExpression, int timeDifferenceInMinutes);
	}
}
