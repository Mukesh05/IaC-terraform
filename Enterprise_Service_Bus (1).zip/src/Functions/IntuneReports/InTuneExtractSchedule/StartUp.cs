﻿using System;
using System.IO;
using System.Net.Http;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Azure.Identity;

using Common.ESB;
using InTuneExtractSchedule.Services;
using System.Diagnostics.CodeAnalysis;

[assembly: FunctionsStartup(typeof(InTuneExtractSchedule.Startup))]
namespace InTuneExtractSchedule
{
	/// <summary>
	/// Exclude from coverage - this is IoC code and can't be tested efficiently
	/// </summary>
	[ExcludeFromCodeCoverage]
	public class Startup : FunctionsStartup
	{
		public override void Configure(IFunctionsHostBuilder builder)
		{
			IConfigurationRefresher configRefresher = null;
			var appconfigConnectionString = Environment.GetEnvironmentVariable("appconfigconnectionstring");

			//Basic config setup
			var configBuilder = new ConfigurationBuilder()
				.SetBasePath(Directory.GetCurrentDirectory())
				.AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
				.AddEnvironmentVariables();

			// code snippet for VS credentials 

			Azure.Core.TokenCredential creds = new DefaultAzureCredential();
			var environment = Environment.GetEnvironmentVariable("AZURE_FUNCTIONS_ENVIRONMENT");
			if (string.Compare(environment, "development", true) == 0)
			{
				creds = new SharedTokenCacheCredential(new SharedTokenCacheCredentialOptions()
				{ TenantId = "a1a2578a-8fd3-4595-bb18-7d17df8944b0" });
			}

			//Azure App config setup
			configBuilder.AddAzureAppConfiguration(options =>
			{
				options.Connect(appconfigConnectionString)
				.Select("Common:*")
				.Select("ServiceNow:*")
				.Select("IntuneReport:*")
				.ConfigureKeyVault(kv =>
				{
					kv.SetCredential(creds); //NuGet Azure.Identity
				});
				configRefresher = options.GetRefresher();
			});

			IConfiguration config = configBuilder.Build();

			// Register Config services

			builder.Services.AddSingleton<IConfiguration>((services) =>
			{
				return config;
			});

			builder.Services.AddSingleton<IConfigurationRefresher>((services) =>
			{
				return configRefresher;
			});

			// Registering services

			builder
			   .Services
			   .AddSingleton<IESBSender>(new ESBSender(config["IntuneReport:intunereporttopic-writersas"],"report"));

			builder
			   .Services

				 .AddSingleton<IESBSender>(new ESBSender(config["IntuneReport:intunealerttopic-writersas"], "alert"));   // adding new snippet


			var storageConnectionString = config["IntuneReport:intunereport-st-cn-string"];
			builder.Services.AddSingleton<IScheduleRepositoryService>((service) =>
			{
				return new ScheduleRepositoryService(storageConnectionString);
			});

			builder
				.Services
				.AddSingleton<IServiceNowOauthTokenProvider, ServiceNowOauthTokenProvider>((service) =>
				{
					var instance = config["ServiceNow:Instance"];
					var clientId = config["ServiceNow:ClientId"];
					var clientSecret = config["ServiceNow:Secret"];
					var userId = config["ServiceNow:UserId"];
					var pw = config["ServiceNow:UserPassword"];

					return new ServiceNowOauthTokenProvider(instance, clientId, clientSecret, userId, pw);
				});

			builder
				.Services
				.AddSingleton<IServiceNowClient, ServiceNowClient>();

			builder.Services.AddHttpClient<IIntuneDataService, InTuneDataService>(client =>
			{
				client.BaseAddress = new Uri(config[""]);
			});

			builder
				.Services
				.AddSingleton<IIntuneDataService, InTuneDataService>();

			builder
				.Services
				.AddSingleton<ISecurity, Security>();

			builder
				.Services
				.AddSingleton<ICronExpressionCalculatorService, CronExpressionCalculatorService>();
		}
	}
}
