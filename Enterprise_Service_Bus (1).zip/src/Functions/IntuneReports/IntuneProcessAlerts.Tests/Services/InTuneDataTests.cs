using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using InTuneProcessAlerts.Models;
using InTuneProcessAlerts.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestPlatform.ObjectModel.Adapter;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Moq.Protected;
using NuGet.Frameworks;

namespace InTuneProcessAlerts.Tests.Services
{
	[TestClass]
	public class InTuneDateTests
	{
		Mock<IConfiguration> _mockConfig;
		Mock<ILogger<InTuneData>> _mockLogger;
        Mock<IInTuneDataAuth> _mockInTuneDataAuth;

		[TestInitialize]
		public void TestInitialize()
		{
			//Mock IConfiguraiton
			_mockConfig = new Mock<IConfiguration>();
			_mockConfig.Setup(x => x["Intune:ReportDownloadPollRetries"]).Returns("5");
			_mockConfig.Setup(x => x["Intune:ReportDownloadPollDelaySeconds"]).Returns("5");

			//Mock ILogger
			_mockLogger = new Mock<ILogger<InTuneData>>();

            //Mock IInTuneDataAuth
            _mockInTuneDataAuth = new Mock<IInTuneDataAuth>();
			_mockInTuneDataAuth.Setup(x => x.GetBearerTokenAysnc(It.IsAny<string>())).ReturnsAsync("fake_token");

		}

		[TestMethod]
		public async Task GetReportAsync_StatusCompleted_MessageSent()
		{
		    //read in zip file to use as fake strewam
			FileStream fileStream = File.Open("TestFiles\\response.zip", FileMode.Open);

			//mock IHttpClientFactory with that will return expected response
			var mockHandler = new Mock<HttpMessageHandler>();
			mockHandler.Protected()
					   .SetupSequence<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>())
					   .ReturnsAsync(new HttpResponseMessage()
					   {
						   StatusCode = HttpStatusCode.OK,
						   Content = new StringContent(responsePayload)
					   })
					   .ReturnsAsync(new HttpResponseMessage()
					   {
						   StatusCode = HttpStatusCode.OK,
						   Content = new StreamContent(fileStream)
					   });

			var mockHttpClient = new HttpClient(mockHandler.Object);
			var mockHttpClientFactory = new Mock<IHttpClientFactory>();
			mockHttpClientFactory.Setup(_ => _.CreateClient(It.IsAny<string>())).Returns(mockHttpClient);

			//Call method being tested with mock setup
			InTuneData inTuneData = new InTuneData(_mockConfig.Object, _mockLogger.Object, mockHttpClientFactory.Object, _mockInTuneDataAuth.Object);

			//Fake report job message
			var fakeMessage = new ReportJobMessage()
			{
				TenantId = "cc168f1f-1c24-4c5d-863c-957555b5593c",
				AccountName = "NS Development",
				ReportId = "DeviceNonCompliance_e149e9d9-6d72-47ec-844a-869456abbcfe",
				ReportName = "devicenoncompliance",
				RequestDateTime = "2021-03-18T16:31:05.2950323Z",
				ExpirationDateTime = "0001-01-01T00:00:00Z",
				Status = "notStarted",
				Format = "csv",
				SelectFields = new List<string>() { "DeviceId", "DeviceName", "DeviceType", "UserName", "UserEmail", "ComplianceState", "DeviceHealthThreatLevel", "OS" }
			};

			try
			{
				var result = await inTuneData.GetReportAsync(fakeMessage);

				Assert.AreEqual<int>(5, result.Count, $"Result contained {result.Count} but expected was 5.");
                Assert.IsNotNull(result[0]["tenantId"], "tenantId expected in results");
                Assert.IsNotNull(result[0]["accountName"], "accountName expected in results");
                Assert.IsNotNull(result[0]["reportName"], "reportName expected in results");
			}
			catch (Exception ex)
			{
				Assert.Fail($"Failed to get results. {ex.Message}");
			}
		}

		[TestMethod]
		public async Task GetReportAsync_StatusFailed_ExceptionThrown()
		{
            var mockHandler = new Mock<HttpMessageHandler>();
			mockHandler.Protected()
                       .Setup<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>())
					   .ReturnsAsync(new HttpResponseMessage()
					   {
						   StatusCode = HttpStatusCode.OK,
						   Content = new StringContent(failedResponsePayload)
					   });

            var mockHttpClient = new HttpClient(mockHandler.Object);
			var mockHttpClientFactory = new Mock<IHttpClientFactory>();
			mockHttpClientFactory.Setup(_ => _.CreateClient(It.IsAny<string>())).Returns(mockHttpClient);

			//Call method being tested with mock setup
			InTuneData inTuneData = new InTuneData(_mockConfig.Object, _mockLogger.Object, mockHttpClientFactory.Object, _mockInTuneDataAuth.Object);

			//Fake report job message
			var fakeMessage = new ReportJobMessage()
			{
				TenantId = "cc168f1f-1c24-4c5d-863c-957555b5593c",
				AccountName = "NS Development",
				ReportId = "DeviceNonCompliance_e149e9d9-6d72-47ec-844a-869456abbcfe",
				ReportName = "devicenoncompliance",
				RequestDateTime = "2021-03-18T16:31:05.2950323Z",
				ExpirationDateTime = "0001-01-01T00:00:00Z",
				Status = "notStarted",
				Format = "csv",
				SelectFields = new List<string>() { "DeviceId", "DeviceName", "DeviceType", "UserName", "UserEmail", "ComplianceState", "DeviceHealthThreatLevel", "OS" }
			};

			try
			{
				var result = await inTuneData.GetReportAsync(fakeMessage);
                Assert.Fail("Expected exception result testing a filed job status.");
			}
			catch (Exception ex)
			{
				Assert.AreEqual<string>("Report job is in failed state for DeviceNonCompliance_e149e9d9-6d72-47ec-844a-869456abbcfe.",
                                         ex.Message,
                                        "Not the expected exception message when testing for failed job status.");
			}
		}

		static readonly string responsePayload = @"
        {
            ""@odata.context"": ""https://graph.microsoft.com/beta/$metadata#deviceManagement/reports/exportJobs/$entity"",
            ""id"": ""DeviceNonCompliance_3a980de1-2832-4655-bf23-e2bce6c697eb"",
            ""reportName"": ""DeviceNonCompliance"",
            ""filter"": """",
            ""select"": [
                ""DeviceId"",
                ""DeviceName"",
                ""DeviceType"",
                ""UserName"",
                ""UserEmail"",
                ""ComplianceState"",
                ""DeviceHealthThreatLevel"",
                ""OS""
            ],
            ""format"": ""csv"",
            ""snapshotId"": null,
            ""localizationType"": ""localizedValuesAsAdditionalColumn"",
            ""status"": ""completed"",
            ""url"": ""https://amsua0102repexpstorage.blob.core.windows.net/fde1465c-07c5-459f-bbe0-46fc8e8ad1e6/DeviceNonCompliance_3a980de1-2832-4655-bf23-e2bce6c697eb.zip?sv=2019-07-07&sr=b&sig=Rka5YQtURkZHgxhqxDiL%2FMivepEg5qUp8G0Gu5zwKYc%3D&skoid=1db6df02-4c8b-4cb3-8394-7ac2390642f8&sktid=72f988bf-86f1-41af-91ab-2d7cd011db47&skt=2021-05-03T18%3A41%3A09Z&ske=2021-05-04T00%3A40%3A04Z&sks=b&skv=2019-07-07&se=2021-05-04T00%3A40%3A04Z&sp=r"",
            ""requestDateTime"": ""2021-05-03T18:39:48.4420206Z"",
            ""expirationDateTime"": ""2021-05-04T00:40:04.8227309Z""
        }";

        static readonly string failedResponsePayload = @"
        {
            ""@odata.context"": ""https://graph.microsoft.com/beta/$metadata#deviceManagement/reports/exportJobs/$entity"",
            ""id"": ""DeviceNonCompliance_3a980de1-2832-4655-bf23-e2bce6c697eb"",
            ""reportName"": ""DeviceNonCompliance"",
            ""filter"": """",
            ""select"": [
                ""DeviceId"",
                ""DeviceName"",
                ""DeviceType"",
                ""UserName"",
                ""UserEmail"",
                ""ComplianceState"",
                ""DeviceHealthThreatLevel"",
                ""OS""
            ],
            ""format"": ""csv"",
            ""snapshotId"": null,
            ""localizationType"": ""localizedValuesAsAdditionalColumn"",
            ""status"": ""failed"",
            ""url"": """",
            ""requestDateTime"": ""2021-05-03T18:39:48.4420206Z"",
            ""expirationDateTime"": ""2021-05-04T00:40:04.8227309Z""
        }";
	}
}