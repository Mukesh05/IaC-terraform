using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace InTuneProcessAlerts.Tests
{
    [TestClass]
    public class IntuneProcessAlertsTests
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
