﻿using System;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.WindowsAzure.Storage;

namespace InTuneExtractReport.AzureStorage.Common
{
	public class CommonStorageUtils : ICommonStorageUtils
	{
		IConfiguration _config;
		ILogger<CommonStorageUtils> _logger;

		public CommonStorageUtils(ILogger<CommonStorageUtils> logger, IConfiguration config)
		{
			_logger = logger;
			_config = config;
		}
		/// <summary>
		/// Validate the connection string information in app.config and throws an exception if it looks like 
		/// the user hasn't updated this to valid values. 
		/// </summary>
		/// <param name="storageConnectionString">Connection string for the storage service or the emulator</param>
		/// <returns>CloudStorageAccount object</returns>
		public CloudStorageAccount CreateStorageAccountFromConnectionString(string storageConnectionString)
		{
			CloudStorageAccount storageAccount;
			try
			{
				storageAccount = CloudStorageAccount.Parse(storageConnectionString);
			}
			catch (FormatException)
			{
				Console.WriteLine("Invalid storage account information provided. Please confirm the AccountName and AccountKey are valid in the app.config file - then restart the application.");
				throw;
			}
			catch (ArgumentException)
			{
				Console.WriteLine("Invalid storage account information provided. Please confirm the AccountName and AccountKey are valid in the app.config file - then restart the sample.");
				Console.ReadLine();
				throw;
			}

			return storageAccount;
		}
	}
}
