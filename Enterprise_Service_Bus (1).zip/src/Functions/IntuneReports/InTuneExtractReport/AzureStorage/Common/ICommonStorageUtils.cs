﻿using Microsoft.WindowsAzure.Storage;

namespace InTuneExtractReport.AzureStorage.Common
{
	public interface ICommonStorageUtils
	{
		CloudStorageAccount CreateStorageAccountFromConnectionString(string storageConnectionString);
	}
}