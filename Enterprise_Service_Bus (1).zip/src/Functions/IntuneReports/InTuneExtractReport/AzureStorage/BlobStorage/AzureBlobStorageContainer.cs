﻿using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Microsoft.Extensions.Logging;
using InTuneExtractReport.AzureStorage.Common;

namespace InTuneExtractReport.AzureStorage.BlobStorage
{
	public class AzureBlobStorageContainer : IAzureBlobStorageContainer
	{

		ICommonStorageUtils _commonStorageUtils;
		IConfiguration _config;
		ILogger<AzureBlobStorageContainer> _logger;

		public AzureBlobStorageContainer(ICommonStorageUtils commonStorageUtils,
										 IConfiguration config,
										 ILogger<AzureBlobStorageContainer> logger)
		{
			_config = config;
			_commonStorageUtils = commonStorageUtils;
			_logger = logger;
		}

		public async Task<ICloudBlob> UploadFromStreamAsync(string containerName, string blobName, Stream data, string contentType)
		{
			CloudStorageAccount account = _commonStorageUtils.CreateStorageAccountFromConnectionString(_config["IntuneReport:intunereport-st-cn-string"]);
			CloudBlobClient client = account.CreateCloudBlobClient();
			CloudBlobContainer container = client.GetContainerReference(containerName.ToLower());
			await container.CreateIfNotExistsAsync();
			var blob = container.GetBlockBlobReference(blobName);
			_logger.LogInformation($"Uploading stream at {containerName}{blobName}");
			await blob.UploadFromStreamAsync(data);
			_logger.LogInformation($"Uploaded stream at {containerName}{blobName}");
			return blob;
		}

		
	}
}
