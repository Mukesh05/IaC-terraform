﻿using System.IO;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.Storage.Blob;

namespace InTuneExtractReport.AzureStorage.BlobStorage
{
	public interface IAzureBlobStorageContainer
	{
		Task<ICloudBlob> UploadFromStreamAsync(string containerName, string blobName, Stream data, string contentType);
	}
}
