﻿using System.Threading.Tasks;
using InTuneExtractReport.Model;

namespace InTuneExtractReport.Service
{
	public interface IDownloadAndStoreReport
	{
		Task DownloadReport(IntuneReportExtractTopicMessage message);
	}
}