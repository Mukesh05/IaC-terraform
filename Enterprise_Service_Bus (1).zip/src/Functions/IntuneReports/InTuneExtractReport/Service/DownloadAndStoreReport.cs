﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using Common.ESB;
using InTuneExtractReport.HttpHandler;
using InTuneExtractReport.Model;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.IO;
using InTuneExtractReport.CsvToJson;
using InTuneExtractReport.AzureStorage.BlobStorage;
using Microsoft.Extensions.Logging;
using System.Text;
using InTuneExtractReport.ExctractReportFile;

namespace InTuneExtractReport.Service
{
	public class DownloadAndStoreReport : IDownloadAndStoreReport
	{
		ISecurity _security;
		IConfiguration _config;
		IHttpClientHandler _httpClientHandler;
		IConvertCsvToJson _convertCsvToJson;
		IAzureBlobStorageContainer _azureBlobStorageContainer;
		ILogger<InTuneExtractReport> _logger;
		IExtractReport _extractReport;
		public DownloadAndStoreReport(IHttpClientHandler httpClientHandler, ISecurity security, IConfiguration config,
			IConvertCsvToJson convertCsvToJson, IAzureBlobStorageContainer azureBlobStorageContainer, ILogger<InTuneExtractReport> logger,
			IExtractReport extractReport)
		{
			_security = security;
			_config = config;
			_httpClientHandler = httpClientHandler;
			_convertCsvToJson = convertCsvToJson;
			_azureBlobStorageContainer = azureBlobStorageContainer;
			_logger = logger;
			_extractReport = extractReport; 
		}

		private UriBuilder BuildUrl(IntuneReportExtractTopicMessage message)
		{
			string _reportUrl = "https://graph.microsoft.com/beta/deviceManagement/reports/exportJobs('" + message.Reportid + "')";
			var uriBuilder = new UriBuilder(_reportUrl);

			return uriBuilder;
		}

		private async Task<string> GetAccessToken(IntuneReportExtractTopicMessage message)
		{
			_logger.LogInformation("Fetching Access Token");
			var accessToken = await _security.GetAuthToken(tokenAudience: "https://graph.microsoft.com/", message.TenantId, _config["IntuneReport:intunereport-sp-secret"], _config["IntuneReport:intunereport-sp-id"]);
			_logger.LogInformation("Fetching Access Token sucessful");
			return accessToken;
		}

		public async Task DownloadReport(IntuneReportExtractTopicMessage message)
		{
			var reportUri = BuildUrl(message);
			var accessTokens = await GetAccessToken(message);
			ExportReportPollStatus exportReportPollStatus = null;
			int retry = 0;
			_logger.LogInformation("Starting Polling..");
			do
			{
				HttpResponseMessage response = await _httpClientHandler.GetAsync(reportUri.ToString(), accessTokens);
				var responseContentFromApi = await response.Content.ReadAsStringAsync();
				_logger.LogInformation($"{responseContentFromApi}");
				exportReportPollStatus = JsonConvert.DeserializeObject<ExportReportPollStatus>(responseContentFromApi);
				_logger.LogInformation($"Continue Polling as status: {exportReportPollStatus.Status} and url {exportReportPollStatus.Url}");
				TerminateProcessingIfReportStatusIsFailed(message, exportReportPollStatus);
				//If the report is not prepared wait for 2 sec
				await Task.Delay(Convert.ToInt32(_config["Intune:ReportDownloadPollDelaySeconds"]) * 1000);
				retry++;
			}
			while (exportReportPollStatus.Status.ToLower() != "completed" && retry <= Convert.ToInt32(Convert.ToInt32(_config["Intune:ReportDownloadPollRetries"])));
			_logger.LogInformation("Polling finished.. Now starting Upload");
			await UploadCompletedReport(message, exportReportPollStatus);
		}

		private static void TerminateProcessingIfReportStatusIsFailed(IntuneReportExtractTopicMessage message, ExportReportPollStatus exportReportPollStatus)
		{
			if (exportReportPollStatus.Status.ToLower() == "failed")
			{
				throw new FileNotFoundException($"Report File {message.Reportid} is in failed State or Url is invalid");
			}
		}

		private async Task UploadCompletedReport(IntuneReportExtractTopicMessage message, ExportReportPollStatus exportReportPollStatus)
		{
			if (exportReportPollStatus.Status.ToLower() == "completed")
			{
				_logger.LogInformation("Downloading Zip file report");
				var csvFilePath =_extractReport.DownandExtractReportFile(message, exportReportPollStatus.Url);
				_logger.LogInformation($"Converting csv file to Json Object");
				var json = _convertCsvToJson.ConvertCsvFileToJsonObject(csvFilePath, message);

				// convert string to stream
				byte[] byteArray = Encoding.UTF8.GetBytes(json);

				using (MemoryStream uploadFileStream = new MemoryStream(byteArray))
				{
					_logger.LogInformation($"Starting Json upload");
					await _azureBlobStorageContainer.UploadFromStreamAsync("reports",
						message.ReportName + "_" + message.TenantId + "_" + Guid.NewGuid() + ".json", uploadFileStream, "Json");
				}

				_extractReport.CleanupCsvFile(csvFilePath);
				
			}
			else
			{
				//report is not prepared yet.
				throw new FileNotFoundException($"Report File {message.Reportid} is in wait inProgress/notStarted State");
			}
		}
	}
}
