﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace InTuneExtractReport
{
	public class FinalIntuneReportResponse
	{
		[JsonProperty("query")]
		public string Query { get; set; }
		[JsonProperty("reportId")]
		public string ReportId { get; set; }
		[JsonProperty("requestTime")]
		public string RequestTime { get; set; }
		[JsonProperty("expirationDateTime")]
		public string ExpirationDateTime { get; set; }
		[JsonProperty("tenantId")]
		public string TenantId { get; set; }
		[JsonProperty("selectFields")]
		public string[] SelectFields { get; set; }
		[JsonProperty("data")]
		public List<Dictionary<string, string>> Data { get; set; }

	}
}
