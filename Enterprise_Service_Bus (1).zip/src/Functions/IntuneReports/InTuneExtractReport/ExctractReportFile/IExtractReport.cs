﻿using InTuneExtractReport.Model;

namespace InTuneExtractReport.ExctractReportFile
{
	public interface IExtractReport
	{
		string DownandExtractReportFile(IntuneReportExtractTopicMessage message, string Url);
		void CleanupCsvFile(string csvFilePath);
	}
}