﻿using System.IO;
using System.IO.Compression;
using System.Net;
using InTuneExtractReport.Model;
using Microsoft.Extensions.Logging;

namespace InTuneExtractReport.ExctractReportFile
{
	public class ExtractReport : IExtractReport
	{
		ILogger<InTuneExtractReport> _logger;
		public ExtractReport(ILogger<InTuneExtractReport> logger)
		{
			_logger = logger;
		}

		public string DownandExtractReportFile(IntuneReportExtractTopicMessage message, string Url)
		{
			WebRequest objRequest = System.Net.HttpWebRequest.Create(Url);
			var objResponse = objRequest.GetResponse();
			byte[] buffer = new byte[objResponse.ContentLength];
			var zipFileName = Path.GetTempPath() + message.Reportid + ".zip";
			CleanupZipFile(zipFileName);
			using (Stream input = objResponse.GetResponseStream())
			{
				using (FileStream output = new FileStream(zipFileName, FileMode.CreateNew))
				{
					int bytesRead;

					while ((bytesRead = input.Read(buffer, 0, buffer.Length)) > 0)
					{
						output.Write(buffer, 0, bytesRead);
					}
				}
			}
			var extractPath = Path.GetTempPath() + "Extract";
			_logger.LogInformation($"Extracting Zip file at {extractPath}");
			string csvFilePath = extractPath + "\\" + message.Reportid + "." + message.Format;
			CleanupCsvFile(csvFilePath);
			ZipFile.ExtractToDirectory(zipFileName, extractPath);
			CleanupZipFile(zipFileName);

			return csvFilePath;

		}


		public void CleanupCsvFile(string csvFilePath)
		{
			if (File.Exists(csvFilePath))
			{
				File.Delete(csvFilePath);
			}
		}

		private void CleanupZipFile(string zipFileName)
		{
			if (File.Exists(zipFileName))
			{
				File.Delete(zipFileName);
			}
		}
	}
}
