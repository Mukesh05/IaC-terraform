using System;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using InTuneExtractReport.Model;
using InTuneExtractReport.Service;

namespace InTuneExtractReport
{
	public class InTuneExtractReport
	{
		IConfigurationRefresher _configRefresher;
		IConfiguration _config;
		ILogger<InTuneExtractReport> _logger;
		IDownloadAndStoreReport _downloadReport;

		public InTuneExtractReport(IConfiguration config,
									 IConfigurationRefresher configRefresher,
									 ILogger<InTuneExtractReport> logger,
									 IDownloadAndStoreReport downloadReport
									 )
		{
			_configRefresher = configRefresher;
			_config = config;
			_logger = logger;
			_downloadReport = downloadReport;
		}


		[FunctionName("InTuneExtractReport")]
        public async Task Run(
			[ServiceBusTrigger("%TopicName%", "%SubscriptionName%")]string mySbMsg,
			ExecutionContext context)
        {
			try
			{
				_logger.LogInformation($"Exracting InTune Report at {DateTime.UtcNow}");
				await _configRefresher.TryRefreshAsync();

				var intuneReportExtractTopicMessage = JsonConvert.DeserializeObject<IntuneReportExtractTopicMessage>(mySbMsg);
				await _downloadReport.DownloadReport(intuneReportExtractTopicMessage);


				_logger.LogInformation($"InTuneExtractReport function executed at: {DateTime.UtcNow}");
				_logger.LogInformation(
					$"C# ServiceBus topic trigger function processed message: {mySbMsg}");
			}
			catch(Exception ex)
			{
				_logger.LogError($"Excpetion {ex.Message} occured whilst processing InTuneExtractReport service bus message: {mySbMsg}");
			}
        }
    }
}
