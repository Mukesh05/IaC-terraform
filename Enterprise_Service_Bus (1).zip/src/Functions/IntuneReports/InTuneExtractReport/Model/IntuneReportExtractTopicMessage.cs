﻿namespace InTuneExtractReport.Model
{
	public class IntuneReportExtractTopicMessage
	{
		public string Reportid { get; set; }
		public string ReportName { get; set; }
		public string AccountName { get; set; }
		public string TenantId { get; set; }
		public string Corelationid { get; set; }
		public string RequestDateTime { get; set; }
		public string ExpirationDateTime { get; set; }
		public string Status{ get; set; }
		public string Format { get; set; }
		public string[] SelectFields  { get; set; }
		public string Filter { get; set; }
	}
}
