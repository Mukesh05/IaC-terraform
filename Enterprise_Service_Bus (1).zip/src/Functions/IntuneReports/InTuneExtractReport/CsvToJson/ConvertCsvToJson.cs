﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using InTuneExtractReport.Model;
using Newtonsoft.Json;

namespace InTuneExtractReport.CsvToJson
{
	public class ConvertCsvToJson : IConvertCsvToJson
	{
		public ConvertCsvToJson()
		{

		}

		public string ConvertCsvFileToJsonObject(string path, IntuneReportExtractTopicMessage message)
		{
			var finalIntuneReportResponse = new FinalIntuneReportResponse();
			finalIntuneReportResponse.Query = message.ReportName;
			finalIntuneReportResponse.ReportId = message.Reportid;
			finalIntuneReportResponse.SelectFields = message.SelectFields;
			finalIntuneReportResponse.TenantId = message.TenantId;
			finalIntuneReportResponse.RequestTime = message.RequestDateTime;
			finalIntuneReportResponse.ExpirationDateTime = message.ExpirationDateTime;
			
			var csv = new List<string[]>();
			var lines = File.ReadAllLines(path);

			foreach (string line in lines)
				csv.Add(line.Split(','));

			var properties = lines[0].Split(',');

			var listObjResult = new List<Dictionary<string, string>>();

			for (int i = 1; i < lines.Length; i++)
			{
				var objResult = new Dictionary<string, string>();
				for (int j = 0; j < properties.Length; j++)
				{
					objResult.Add(properties[j].Replace("\"", string.Empty), csv[i][j].Replace("\"", string.Empty));
				}
				objResult.Add("AccountName", message.AccountName);

				listObjResult.Add(objResult);
			}

			finalIntuneReportResponse.Data = listObjResult;

			return JsonConvert.SerializeObject(finalIntuneReportResponse);
		}
	}
}
