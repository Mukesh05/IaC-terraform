﻿using InTuneExtractReport.Model;

namespace InTuneExtractReport.CsvToJson
{
	public interface IConvertCsvToJson
	{
		string ConvertCsvFileToJsonObject(string path, IntuneReportExtractTopicMessage message);
	}
}