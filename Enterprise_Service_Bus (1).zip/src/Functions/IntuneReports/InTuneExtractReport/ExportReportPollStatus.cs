﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InTuneExtractReport
{
	public class ExportReportPollStatus
	{
		public string Url { get; set; }
		public string Status { get; set; }
	}
}
