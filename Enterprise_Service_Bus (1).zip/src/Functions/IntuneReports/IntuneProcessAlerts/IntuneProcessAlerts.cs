using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using InTuneProcessAlerts.Models;
using Microsoft.Extensions.Configuration;
using InTuneProcessAlerts.Services;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace InTuneProcessAlerts
{
	public class InTuneProcessAlerts
    {
		ILogger<InTuneProcessAlerts> _logger;
        IInTuneData _inTuneData;
        IServiceNowClient _serviceNowClient;

		public InTuneProcessAlerts(ILogger<InTuneProcessAlerts> logger, 
                                   IInTuneData inTuneData,
                                   IServiceNowClient serviceNowClient)
		{
			_logger = logger;
            _inTuneData = inTuneData;
            _serviceNowClient = serviceNowClient;
		}

        [FunctionName("IntuneProcessAlerts")]
        public async Task RunAsync([ServiceBusTrigger("%TopicName%", "%SubscriptionName%")]string message)
        {
            _logger.LogInformation($"Start processing message.");
            _logger.LogTrace($"RunAsync : message {message}");

            var reportMessage = JsonConvert.DeserializeObject<ReportJobMessage>(message);
            var reportData =  await _inTuneData.GetReportAsync(reportMessage);
            var result = await _serviceNowClient.SendAlertsAsync(reportData);

            _logger.LogInformation("Completed processing message.");
        }
    }
}