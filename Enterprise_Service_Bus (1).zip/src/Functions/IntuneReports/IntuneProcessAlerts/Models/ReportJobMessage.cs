using System.Collections.Generic;
using Newtonsoft.Json;

namespace InTuneProcessAlerts.Models
{
    public class ReportJobMessage
    {
        [JsonProperty("tenantId")]
        public string TenantId { get; set; }
        [JsonProperty("accountName")]
        public string AccountName { get; set; }
        [JsonProperty("reportId")]
        public string ReportId { get; set; }
        [JsonProperty("reportName")]
        public string ReportName { get; set; }
        [JsonProperty("requetDateTime")]
        public string RequestDateTime { get; set; }
        [JsonProperty("expirationDateTime")]
        public string ExpirationDateTime { get; set; }
        [JsonProperty("status")]
        public string Status { get; set; }
        [JsonProperty("format")]
        public string Format { get; set; }
        [JsonProperty("selectFields")]
        public IEnumerable<string> SelectFields { get; set; }
    }
}