using Newtonsoft.Json;

namespace InTuneProcessAlerts.Models
{
	public class ReportJobResponse
	{
		[JsonProperty("url")]
		public string Url { get; set; }
        [JsonProperty("status")]
        public string Status { get; set; }
        
	}
}