﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Net.Http;
using Azure.Identity;
using InTuneProcessAlerts;
using InTuneProcessAlerts.Services;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.DependencyInjection;

[assembly: FunctionsStartup(typeof(Startup))]
namespace InTuneProcessAlerts
{
	[ExcludeFromCodeCoverage]
	public class Startup : FunctionsStartup
	{
		public override void Configure(IFunctionsHostBuilder builder)
		{
			IConfigurationRefresher configRefresher = null;

			//Basic config setup
			var configBuilder = new ConfigurationBuilder()
				.SetBasePath(Directory.GetCurrentDirectory())
				.AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
				.AddEnvironmentVariables();

			var appconfigConnectionString = Environment.GetEnvironmentVariable("appconfigconnectionstring", EnvironmentVariableTarget.Process);

			// code snippet for VS credentials 

			Azure.Core.TokenCredential creds = new DefaultAzureCredential();
			var environment = Environment.GetEnvironmentVariable("AZURE_FUNCTIONS_ENVIRONMENT");
			if (string.Compare(environment, "development", true) == 0)
			{
				creds = new SharedTokenCacheCredential(new SharedTokenCacheCredentialOptions()
				{ TenantId = "a1a2578a-8fd3-4595-bb18-7d17df8944b0" });
			}

			//Azure App config setup
			configBuilder.AddAzureAppConfiguration(options =>
			{
				options.Connect(appconfigConnectionString)
				.Select("Common:*")
				.Select("ServiceNow:*")
				.Select("IntuneReport:*")
				.Select("Intune:*")
				.ConfigureKeyVault(kv =>
				{
					kv.SetCredential(creds); //NuGet Azure.Identity
				});
				configRefresher = options.GetRefresher();
			});

			// Required to put back default function configuration. Cannot use
			// host.json to configuration function settings without this.
			var serviceProvider = builder.Services.BuildServiceProvider();
			var configurationRoot = serviceProvider.GetService<IConfiguration>();
			configBuilder.AddConfiguration(configurationRoot);

			IConfiguration config = configBuilder.Build();

			// Register Config services

			builder.Services.AddSingleton<IConfiguration>((services) =>
			{
				return config;
			});

			builder.Services.AddSingleton<IConfigurationRefresher>((services) =>
			{
				return configRefresher;
			});

			// Registering services
			builder.Services.AddHttpClient("default");
			builder.Services.AddHttpClient("snAuth").ConfigurePrimaryHttpMessageHandler(() =>
			{
				return new HttpClientHandler()
				{
					UseCookies = false
				};
			});

			builder.Services.AddSingleton<IServiceNowClientAuth, ServiceNowClientAuth>();
			builder.Services.AddSingleton<IServiceNowClient, ServiceNowClient>();
			builder.Services.AddSingleton<IInTuneDataAuth, InTuneDataAuth>();
			builder.Services.AddSingleton<IInTuneData, InTuneData>();
		}
	}
}
