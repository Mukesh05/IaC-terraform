using System.Threading.Tasks;

namespace InTuneProcessAlerts.Services
{
	public interface IInTuneDataAuth
	{
		Task<string> GetBearerTokenAysnc(string tenantId);
	}
}