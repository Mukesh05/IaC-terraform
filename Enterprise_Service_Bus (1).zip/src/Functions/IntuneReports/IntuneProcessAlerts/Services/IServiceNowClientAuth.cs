using System.Threading.Tasks;

namespace InTuneProcessAlerts.Services
{
	public interface IServiceNowClientAuth
	{
		public Task<string> GetBearerTokenAsync();
	}
}