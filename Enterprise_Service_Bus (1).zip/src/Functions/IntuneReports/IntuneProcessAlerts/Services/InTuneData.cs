using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using InTuneProcessAlerts.Models;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace InTuneProcessAlerts.Services
{
	public class InTuneData : IInTuneData
	{
		IConfiguration _config;
		ILogger<InTuneData> _logger;
		HttpClient _httpClient;
		IInTuneDataAuth _auth;

		public InTuneData(IConfiguration config,
						  ILogger<InTuneData> logger,
						  IHttpClientFactory httpClientFactory,
						  IInTuneDataAuth auth)
		{
			_config = config;
			_logger = logger;
			_httpClient = httpClientFactory.CreateClient("default");
			_auth = auth;
		}

		/// <summary>
		/// Entry point to get the report data. The message contains the report job information.
		/// </summary>
		public async Task<JArray> GetReportAsync(ReportJobMessage message)
		{
			var token = await _auth.GetBearerTokenAysnc(message.TenantId);
			_logger.LogTrace("GetReportAsync : Bearer token was retrieved ok.");

			var reportUrl = await RetrieveCompletedReportAsync(token, message.ReportId);
			var data = await GetReportAsync(reportUrl);

			//Enrich the results
			foreach (var entry in data)
			{
				((JObject)entry).Add("tenantId", message.TenantId);
				((JObject)entry).Add("accountName", message.AccountName);
				((JObject)entry).Add("reportName", message.ReportName);
			}

			_logger.LogInformation($"Report retieved for {message.AccountName} ({message.TenantId}). Report id : {message.ReportId}, Report Name : {message.ReportName}.");

			return data;
		}

		/// <summary>
		/// Makes the call out to the report api to get the report data.
		/// </summary>
		private async Task<string> RetrieveCompletedReportAsync(string token, string reportId)
		{
			int maxRetries = 0;
			if (!int.TryParse(_config["Intune:ReportDownloadPollRetries"], out maxRetries))
			{
				_logger.LogTrace("RetriveCompletedReportAsync : Could not parse config Intune:ReportDownloadPollRetries, defaulting to 10.");
				maxRetries = 10;
			}

			int delayBetweenRetries = 0;
			if (!int.TryParse(_config["Intune:ReportDownloadPollDelaySeconds"], out delayBetweenRetries))
			{
				_logger.LogTrace("RetriveCompletedReportAsync : Could not parse config Intune:ReportDownloadPollDelaySeconds, defaulting to 10.");
				delayBetweenRetries = 10;
			}

			string reportUrl = null;
			int retries = 0;
			do
			{
				_logger.LogTrace($"RetriveCompletedReportAsync : Retry attempt {retries}.");

				var reportJobResponse = await GetReportJobResponseAsync(token, reportId);
				if (reportJobResponse.Status.ToLower() == "failed")
				{
					var message = $"Report job is in failed state for {reportId}.";
					_logger.LogError(message);
					throw new Exception(message);
				}
				else if (reportJobResponse.Status.ToLower() == "completed")
				{
					reportUrl = reportJobResponse.Url;
					if (string.IsNullOrEmpty(reportUrl))
					{
						var message = $"Read a completed status but the report url is empty.";
						_logger.LogError(message);
						throw new Exception(message);
					}

					//Status ok
					break;
				}

				retries++;
				await Task.Delay(delayBetweenRetries * 1000);

			} while (retries < maxRetries);

			if (retries >= maxRetries)
			{
				var message = $"Failed to get report url. Exceeded the max retry count.";
				_logger.LogError(message);
				throw new Exception(message);
			}

			_logger.LogTrace($"RetriveCompletedReportAsync : Report url is {reportUrl}");
			return reportUrl;
		}

		/// <summarn>
		/// The api needs to be polled until a completed or error state is retrieved. This
		/// call gets the report status response.
		/// </summary>
		private async Task<ReportJobResponse> GetReportJobResponseAsync(string token, string reportId)
		{
			//Setup requet to request information about report job
			var url = $"https://graph.microsoft.com/beta/deviceManagement/reports/exportJobs('{reportId}')";
			_logger.LogTrace($"GetReportJobResponseAsync : Report url is {url}");
			var httpMessage = new HttpRequestMessage(HttpMethod.Get, url);

			httpMessage.Headers.Clear();
			httpMessage.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
			httpMessage.Headers.Authorization = new AuthenticationHeaderValue("bearer", token);

			//Send request and validate success
			var result = await _httpClient.SendAsync(httpMessage);
			if (result.StatusCode != HttpStatusCode.OK)
			{
				var errorPayload = await result.Content.ReadAsStringAsync();
				string message = $@"Failed to check report job {reportId} status. (StatusCode : {result.StatusCode}, Response : {errorPayload})";
				_logger.LogError(message);
				throw new Exception(message);
			}

			//Retreive content and extract the job report info
			var payload = await result.Content.ReadAsStringAsync();
			var reportJobResponse = JsonConvert.DeserializeObject<ReportJobResponse>(payload);

			return reportJobResponse;
		}

		/// <summary>
		/// This call will retrieve the actuall report data which is returned as a zip file.
		/// The url comes the report response after status is completed.
		/// </summary>
		private async Task<JArray> GetReportAsync(string url)
		{
			//Setup requet to request information about report job
			var httpMessage = new HttpRequestMessage(HttpMethod.Get, url);

			httpMessage.Headers.Clear();
			httpMessage.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/octet-stream"));

			//Send request and validate success
			var result = await _httpClient.SendAsync(httpMessage);
			if (result.StatusCode != HttpStatusCode.OK)
			{
				var errorPayload = await result.Content.ReadAsStringAsync();

				string message = $@"Failed to retrieve report. (StatusCode : {result.StatusCode}, Response : {errorPayload})";
				_logger.LogError(message);
				throw new Exception(message);
			}

			//Retreive content and extract the job report info
			using (Stream stream = await result.Content.ReadAsStreamAsync())
			{
				using (var zip = new ZipArchive(stream, ZipArchiveMode.Read))
				{
					if (zip.Entries.Count == 0)
					{
						_logger.LogTrace("GetReportAsync : There are no entries return in zip extract.");
						return new JArray();
					}

					using (Stream zipStream = zip.Entries[0].Open())
					{
						using (var sr = new StreamReader(zipStream))
						{
							var csvData = await sr.ReadToEndAsync();
							_logger.LogTrace("GetReportAsync : Read zip stream.");
							return ConvertCSVtoJSON(csvData);
						}
					}
				}
			}
		}

		/// <summary>
		/// Report data is in CSV. Convert to data to json.
		/// </summary>
		private JArray ConvertCSVtoJSON(string csv)
		{
			var lines = csv.Replace("\"", "").Split("\r\n");
			var lineCount = csv.EndsWith("\r\n") ? lines.Count() - 1 : lines.Count();

			JArray jArray = new JArray();
			var headers = lines[0].Split(',');
			for (int i = 1; i < lineCount; i++)
			{
				var data = lines[i].Split(',');
				var dataWithHeader = headers.Zip(data, (h, v) => new KeyValuePair<string, string>(h, v));
				jArray.Add(new JObject(dataWithHeader.Select(j => new JProperty(j.Key, j.Value))));
			}

			_logger.LogTrace("ConvertCSVtoJSON : Converted csv to json (JArray)");
			return jArray;
		}
	}
}

//https://docs.microsoft.com/en-us/mem/intune/fundamentals/reports-export-graph-apis