using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;

namespace InTuneProcessAlerts.Services
{

	[ExcludeFromCodeCoverage]
	public class InTuneDataAuth : IInTuneDataAuth
	{
		IConfiguration _config;
		ILogger<InTuneDataAuth> _logger;
		HttpClient _httpClient;
		string _clientId;
		string _clientSecret;

		public InTuneDataAuth(IConfiguration config, ILogger<InTuneDataAuth> logger, IHttpClientFactory httpClientFactory)
		{
			_config = config;
			_logger = logger;
			_httpClient = httpClientFactory.CreateClient("default");
			_clientId = config["IntuneReport:intunereport-sp-id"];
			_clientSecret = config["IntuneReport:intunereport-sp-secret"];
		}
		public async Task<string> GetBearerTokenAysnc(string tenantId)
		{
			IDictionary<string, string> authData = new Dictionary<string, string>();
			authData.Add("grant_type", "client_credentials");
			authData.Add("client_id", _clientId);
			authData.Add("client_secret", _clientSecret);
			authData.Add("resource", "https://graph.microsoft.com");
			
			//Setup the request to retrieve token
			string url = $"https://login.microsoftonline.com/{tenantId}/oauth2/token";
			_logger.LogTrace($"Auth request url is {url}");
			var requestMessage = new HttpRequestMessage(HttpMethod.Post, url)
			{
				Content = new FormUrlEncodedContent(authData)
			};
			requestMessage.Content.Headers.Clear();
			requestMessage.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/x-www-form-urlencoded");

			_httpClient.DefaultRequestHeaders.Clear();
			_httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

			//Send request and validate success.			
			var result = await _httpClient.SendAsync(requestMessage);
			_logger.LogTrace("Request for authorization was sent ok.");
			if (result.StatusCode != HttpStatusCode.OK)
			{
				var errorPayload = await result.Content.ReadAsStringAsync();

				string message = $@"Failed to retrieve bearer token for {tenantId}. (StatusCode : {result.StatusCode}, Response : {errorPayload})";
				_logger.LogError(message);
				throw new Exception(message);
			}

			//Retrieve the content payload for the response and extract the beare token
			var payload = await result.Content.ReadAsStringAsync();
			_logger.LogTrace("Response payload was read ok.");
			JObject jsonObject;
			try
			{
                //We are expecting a json response so JObject.Parse should have not trouble parsing
				jsonObject = JObject.Parse(payload);
				_logger.LogTrace("Json payload was parsed ok.");
			}
			catch
			{
				string message = $"Failed to retrieve bearer token for {tenantId}. Call was successful but response was not json.";
				_logger.LogError(message);
				throw new Exception(message);
			}
			var accessToken = (string)jsonObject["access_token"];
			_logger.LogInformation($"Successfully retrieved bearer token for {tenantId}");

            return accessToken;
		}
	}
}