using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace InTuneProcessAlerts.Services
{
	public interface IServiceNowClient
	{
        Task<string> SendAlertsAsync(JArray alerts);
	}
}