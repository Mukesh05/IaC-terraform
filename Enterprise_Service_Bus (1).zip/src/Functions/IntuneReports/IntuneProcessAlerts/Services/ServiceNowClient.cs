using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace InTuneProcessAlerts.Services
{
	public class ServiceNowClient : IServiceNowClient
	{
		IConfiguration _config;
		ILogger<ServiceNowClient> _logger;
		HttpClient _httpClient;
		IServiceNowClientAuth _auth;

		public ServiceNowClient(IConfiguration config,
								ILogger<ServiceNowClient> logger,
								IHttpClientFactory httpClientFactory,
								IServiceNowClientAuth auth)
		{
			_config = config;
			_logger = logger;
			_httpClient = httpClientFactory.CreateClient("default");
			_auth = auth;
		}

		public async Task<string> SendAlertsAsync(JArray alerts)
		{
			var token = await _auth.GetBearerTokenAsync();
			var result = await FormatAndSendAlertsAsync(token, alerts);
			return result;
		}

		private async Task<string> FormatAndSendAlertsAsync(string token, JArray alerts)
		{
			string instance = _config["ServiceNow:Instance"];
			string url = $"https://{instance}/api/x_nesi_esb/esb/intuneevents";
			_logger.LogTrace($"FormatAndSendAlertAsync : Service Now url {url}");

			var payload = CreatePayload(alerts);
			
			var httpMessage = new HttpRequestMessage(HttpMethod.Post, url)
			{
				Content = new StringContent(payload),
			};
			httpMessage.Headers.Clear();
			httpMessage.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
			httpMessage.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
			httpMessage.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

			//Send request and validate success
			var result = await _httpClient.SendAsync(httpMessage);
			if (result.StatusCode != HttpStatusCode.OK)
			{
				var errorPayload = await result.Content.ReadAsStringAsync();
				string message = $"Failed to send alerts to Service Now ({instance}). (StatusCode : {result.StatusCode}, Response : {errorPayload})";
				_logger.LogError(message);
				throw new Exception(message);
			}

			//Retreive content and extract the job report info
			var resultPayload = await result.Content.ReadAsStringAsync();
			_logger.LogTrace($"FormatAndSendAlertAsync : Response -> {resultPayload}");

			_logger.LogInformation($"Alerts sent to Service Name {instance}.");
			return resultPayload;
		}

		private string CreatePayload(JArray alerts)
		{
            List<dynamic> convertedRecords = new List<dynamic>();
			foreach (var alert in alerts)
			{
                var description = $"Intune alert for device {(string)alert["DeviceName"]}";
                convertedRecords.Add(new 
                {
                    tenantId = (string)alert["tenantId"],
                    deviceName = (string)alert["DeviceName"],
                    type = (string)alert["reportName"],
                    description = description,
                    additionalInfo = alert.ToString(Formatting.None)
                });
			}

			var payload = JObject.FromObject(new
			{
				records = convertedRecords
			});

			_logger.LogTrace($"CreatePayLoad : payload created with {alerts.Count} records");
			return payload.ToString(Formatting.Indented);
		}
	}
}