using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;

namespace InTuneProcessAlerts.Services
{
	[ExcludeFromCodeCoverage]
	public class ServiceNowClientAuth : IServiceNowClientAuth
	{
		IConfiguration _config;
		ILogger<ServiceNowClientAuth> _logger;
		HttpClient _httpClient;

		public ServiceNowClientAuth(IConfiguration config,
									ILogger<ServiceNowClientAuth> logger,
									IHttpClientFactory httpClientFactory)
		{
			_config = config;
			_logger = logger;
			_httpClient = httpClientFactory.CreateClient("snAuth");
		}

		public async Task<string> GetBearerTokenAsync()
		{
			string clientId = _config["ServiceNow:ClientId"];
			string clientSecret = _config["ServiceNow:Secret"];
			string userId = _config["ServiceNow:UserId"];
			string userPw = _config["ServiceNow:UserPassword"];
			string instance = _config["ServiceNow:Instance"];

			IDictionary<string, string> keyValuePairs = new Dictionary<string, string>();
			keyValuePairs.Add("grant_type", "password");
			keyValuePairs.Add("client_id", clientId);
			keyValuePairs.Add("client_secret", clientSecret);
			keyValuePairs.Add("username", userId);
			keyValuePairs.Add("password", userPw);

			string url = $"https://{instance}/oauth_token.do";
			_logger.LogTrace($"GetBearerTokenAsync : Service Now auth url {url}");
			var request = new HttpRequestMessage(HttpMethod.Post, url)
			{
				Content = new FormUrlEncodedContent(keyValuePairs),
			};
			request.Content.Headers.Clear();
			request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/x-www-form-urlencoded");
			
			_httpClient.DefaultRequestHeaders.Clear();
			_httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
			
			var result = await _httpClient.SendAsync(request, HttpCompletionOption.ResponseContentRead);
			if (result.StatusCode != System.Net.HttpStatusCode.OK)
			{
				string message = $"Failed to retrieve bearer token. (StatusCode : {result.StatusCode}, ReasonPhrase: {result.ReasonPhrase})";
				_logger.LogError(message);
				throw new Exception(message);
			}

			result.Headers.Clear();

			var responsePayload = await result.Content.ReadAsStringAsync();

			JObject json;
			try
			{
				json = JObject.Parse(responsePayload);
				_logger.LogTrace("GetBearerTokenAsync : Beare token retrieved ok.");
			}
			catch
			{
				string message = $"Failed to retrieve bearer token. Call was successful but response was not json.";
				_logger.LogError(message);
				throw new Exception(message);
			}

			var accessToken = (string)json["access_token"];
			if (string.IsNullOrEmpty(accessToken))
			{
				string message = "Access token was null or empty. Unknown error.";
				_logger.LogError(message);
				throw new Exception(message);
			}

			_logger.LogInformation($"Retreived bearer token for {clientId} for {instance}.");

			return accessToken;
		}
	}

}