using System.Threading.Tasks;
using InTuneProcessAlerts.Models;
using Newtonsoft.Json.Linq;

namespace InTuneProcessAlerts.Services
{
	public interface IInTuneData
	{
        Task<JArray> GetReportAsync(ReportJobMessage message);
	}
}