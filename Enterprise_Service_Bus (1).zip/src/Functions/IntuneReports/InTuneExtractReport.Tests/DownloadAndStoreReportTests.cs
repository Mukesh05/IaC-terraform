﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Common.ESB;
using InTuneExtractReport.AzureStorage.BlobStorage;
using InTuneExtractReport.CsvToJson;
using InTuneExtractReport.ExctractReportFile;
using InTuneExtractReport.HttpHandler;
using InTuneExtractReport.Model;
using InTuneExtractReport.Service;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace InTuneExtractReportTests
{
	[TestClass]
	public class DownloadAndStoreReportTests
	{
		Mock<ISecurity> _security;
		Mock<IConfiguration> _config;
		Mock<IHttpClientHandler> _httpClientHandler;
		Mock<IConvertCsvToJson> _convertCsvToJson;
		Mock<IAzureBlobStorageContainer> _azureBlobStorageContainer;
		Mock<ILogger<InTuneExtractReport.InTuneExtractReport>> _logger;
		Mock<IExtractReport> _extractReport;

		[TestInitialize]
		public void Startup()
		{
			_config = new Mock<IConfiguration>();
			_logger = TestHelper.GetMockedLoggerWithAutoSetup<InTuneExtractReport.InTuneExtractReport>();
			_security = new Mock<ISecurity>();
			_httpClientHandler = new Mock<IHttpClientHandler>();
			_convertCsvToJson = new Mock<IConvertCsvToJson>();
			_azureBlobStorageContainer = new Mock<IAzureBlobStorageContainer>();
			_extractReport = new Mock<IExtractReport>();
		}

		[TestMethod]
		public async Task AssertDownloadReportSuccessfullyDownloadsCompletedReport()
		{
			IntuneReportExtractTopicMessage message = new IntuneReportExtractTopicMessage
			{
				AccountName = "Brookfield.com",
				Reportid = "defender_1",
				ReportName = "defende",
				Status = "completed",
				TenantId = "tenanat_1"
			};
			var accessToken = "accesstoken";

			var response = new HttpResponseMessage(HttpStatusCode.OK);
			response.Content = new StringContent(@"{'Url':'Valid Url', 'status':'completed'}");

			_security.Setup(security => security.GetAuthToken(It.IsAny<String>(), message.TenantId, It.IsAny<String>(), It.IsAny<String>()))
					 .ReturnsAsync(accessToken);
			_httpClientHandler.Setup(httphandler => httphandler.GetAsync(It.IsAny<String>(), accessToken)).ReturnsAsync(response);

			var csvFilePath = "c:\\temp";
			_extractReport.Setup(extractreport => extractreport.DownandExtractReportFile(message, It.IsAny<string>())).Returns(csvFilePath);
			_extractReport.Setup(extractreport => extractreport.CleanupCsvFile(csvFilePath));
			_convertCsvToJson.Setup(csvtoJson => csvtoJson.ConvertCsvFileToJsonObject(csvFilePath, message)).Returns(@"{'Machine Name':'Azure PC', 'status':'No Issues'}");
			_azureBlobStorageContainer.Setup(blob => blob.UploadFromStreamAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<System.IO.Stream>(), It.IsAny<String>()));
			var _downloadReport = new DownloadAndStoreReport(_httpClientHandler.Object, _security.Object, _config.Object,
					_convertCsvToJson.Object, _azureBlobStorageContainer.Object, _logger.Object, _extractReport.Object);
			await _downloadReport.DownloadReport(message);

			_security.Verify();
			_httpClientHandler.Verify();
			_extractReport.Verify();
			_convertCsvToJson.Verify();
			_azureBlobStorageContainer.Verify();
		}

		[TestMethod]
		[ExpectedException(typeof(FileNotFoundException))]
		public async Task AssertDownloadReportThrowsErrorForFailedReport()
		{
			IntuneReportExtractTopicMessage message = new IntuneReportExtractTopicMessage
			{
				AccountName = "Brookfield.com",
				Reportid = "defender_1",
				ReportName = "defende",
				Status = "failed",
				TenantId = "tenanat_1"
			};
			var accessToken = "accesstoken";

			var response = new HttpResponseMessage(HttpStatusCode.OK);
			response.Content = new StringContent(@"{'Url':'Valid Url', 'status':'failed'}");

			_security.Setup(security => security.GetAuthToken(It.IsAny<String>(), message.TenantId, It.IsAny<String>(), It.IsAny<String>()))
					 .ReturnsAsync(accessToken);
			_httpClientHandler.Setup(httphandler => httphandler.GetAsync(It.IsAny<String>(), accessToken)).ReturnsAsync(response);

			var csvFilePath = "c:\\temp";
			_convertCsvToJson.Setup(csvtoJson => csvtoJson.ConvertCsvFileToJsonObject(csvFilePath, message)).Returns(@"{'Machine Name':'Azure PC', 'status':'No Issues'}");
			_azureBlobStorageContainer.Setup(blob => blob.UploadFromStreamAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<System.IO.Stream>(), It.IsAny<String>()));
			var _downloadReport = new DownloadAndStoreReport(_httpClientHandler.Object, _security.Object, _config.Object,
					_convertCsvToJson.Object, _azureBlobStorageContainer.Object, _logger.Object, _extractReport.Object);
			await _downloadReport.DownloadReport(message);

			_security.Verify();
			_httpClientHandler.Verify();
			_convertCsvToJson.Verify(csvtoJson => csvtoJson.ConvertCsvFileToJsonObject(csvFilePath, message), Times.Never);
			_azureBlobStorageContainer.Verify(blob => blob.UploadFromStreamAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<System.IO.Stream>(), It.IsAny<String>()), Times.Never);
		}

	}
}
