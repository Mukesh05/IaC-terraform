﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using InTuneExtractReport;
using InTuneExtractReport.CsvToJson;
using InTuneExtractReport.Model;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;

namespace InTuneExtractReportTests
{
	[TestClass]
	public class ConvertCsvToJsonTests
	{
		[TestMethod]
		public void AssertSucessConvertCsvFileToJsonObject()
		{
			ConvertCsvToJson ConvertCsvToJsonTests = new ConvertCsvToJson();
			IntuneReportExtractTopicMessage message = new IntuneReportExtractTopicMessage
			{
				ReportName = "reportName",
				Reportid = "reportid",
				SelectFields = new[] { "Fields1", "Field2" },
				TenantId = "tenant_1",
				RequestDateTime = DateTime.UtcNow.ToString(),
				ExpirationDateTime = DateTime.MinValue.ToString(),
				AccountName = "BrookField",
			};

			var jsonFromCsv = ConvertCsvToJsonTests.ConvertCsvFileToJsonObject(
						Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "\\data\\UnhealthyDefenderAgents.json", message);

			var jsonObject = JsonConvert.DeserializeObject<FinalIntuneReportResponse>(jsonFromCsv);
			Assert.IsNotNull(jsonObject.Data[0]["AccountName"]);
			Assert.AreEqual(message.AccountName, jsonObject.Data[0]["AccountName"]);
		}
	}
}
