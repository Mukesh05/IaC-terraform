using InTuneExtractReport.Service;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Newtonsoft.Json;
using InTuneExtractReport.Model;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Logging;
using InTuneExtractReport;
using System.Threading.Tasks;
using System;
using InTuneExtractReportTests;

namespace InTuneExtractScheduleTests
{
	[TestClass]
	public class InTuneExtractReportTests
	{
		Mock<IConfigurationRefresher> _configRefresher;
		Mock<IConfiguration> _config;
		Mock<ILogger<InTuneExtractReport.InTuneExtractReport>> _logger;
		Mock<IDownloadAndStoreReport> _downloadReport;
		string mySbMsg = "";
		
		[TestInitialize]
		public void Startup()
		{
			_configRefresher = new Mock<IConfigurationRefresher>();
			_configRefresher.Setup(cr => cr.TryRefreshAsync());
			_config = new Mock<IConfiguration>();
			_logger = TestHelper.GetMockedLoggerWithAutoSetup<InTuneExtractReport.InTuneExtractReport>();
			_downloadReport = new Mock<IDownloadAndStoreReport>();
			
		}

		[TestMethod]
		public async Task AssertInTuneExtractReportWillRun()
		{
			var intuneReportExtractTopicMessage = JsonConvert.DeserializeObject<IntuneReportExtractTopicMessage>(mySbMsg);
			_downloadReport = new Mock<IDownloadAndStoreReport>();
			_downloadReport.Setup(dr => dr.DownloadReport(intuneReportExtractTopicMessage));
			InTuneExtractReport.InTuneExtractReport inTuneExtractReport = new InTuneExtractReport.InTuneExtractReport(
													_config.Object, _configRefresher.Object, _logger.Object, _downloadReport.Object);

			await inTuneExtractReport.Run(mySbMsg, null);

			_downloadReport.Verify(dr => dr.DownloadReport(intuneReportExtractTopicMessage));
		}

		[TestMethod]
		public async Task AssertInTuneExtractReportHandlesExceptionIfOneOftheMethodsThrowsException()
		{
			var intuneReportExtractTopicMessage = JsonConvert.DeserializeObject<IntuneReportExtractTopicMessage>(mySbMsg);
			_downloadReport = new Mock<IDownloadAndStoreReport>();
			_downloadReport.Setup(dr => dr.DownloadReport(intuneReportExtractTopicMessage)).Throws(new Exception());
			InTuneExtractReport.InTuneExtractReport inTuneExtractReport = new InTuneExtractReport.InTuneExtractReport(
													_config.Object, _configRefresher.Object, _logger.Object, _downloadReport.Object);

			await inTuneExtractReport.Run(mySbMsg, null);
		}
	}
}
