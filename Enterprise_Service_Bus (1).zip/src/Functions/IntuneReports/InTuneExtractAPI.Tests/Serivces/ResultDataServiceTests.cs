﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using InTuneExtractAPI.Models;
using InTuneExtractAPI.Services;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace InTuneExtractAPI.Tests.Serivces
{
	[TestClass]
	public class ResultDataServiceTests
	{
		IEnumerable<ExtractResultDetails> _mockBlobList;
		ExtractResult _mockExtractResult;
		Mock<ILogger<ResultDataService>> _mockLogger;
		Mock<IStorageRepositoryService> _mockStorageRepositoryService;

		[TestInitialize]
		public void Initialize()
		{
			//Setup Mock ILogger
			_mockLogger = new Mock<ILogger<ResultDataService>>();

			//Setup Mock IStorageRepositoryService
			_mockBlobList = JsonConvert.DeserializeObject<IEnumerable<ExtractResultDetails>>(DummyJsonObjects.DummyBlobList);
			_mockExtractResult = JsonConvert.DeserializeObject<ExtractResult>(DummyJsonObjects.DummyBlobData);
			_mockStorageRepositoryService = new Mock<IStorageRepositoryService>();
			
		}

		[TestMethod]
		public async Task GetGetResultDataAsync_PageNumber1PageSize2_ReturnTwoTenantReportsData()
		{
			_mockStorageRepositoryService.Setup(x => x.GetBlobListAsync(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(_mockBlobList);
			_mockStorageRepositoryService.Setup(x => x.GetBlobStringDataAsync(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(_mockExtractResult);

			IResultDataService resultDataService = new ResultDataService(_mockLogger.Object, _mockStorageRepositoryService.Object);
			var result = await resultDataService.GetResultDataAsync("testreport1", 1, 2);

			Assert.AreEqual(2, result.Total);
			Assert.AreEqual(1, result.PageNumber);
			Assert.AreEqual(2, result.PageSize);

			//Page size are based on number of tenants not how many records in data.
			//For this test expecting 4 records.
			Assert.AreEqual(4, result.Data.Count); 
		}

		[TestMethod]
		public async Task GetGetResultDataAsync_RPageNumber1PageSize1_ReturnOneTenantReportsData()
		{
			_mockStorageRepositoryService.Setup(x => x.GetBlobListAsync(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(_mockBlobList);
			_mockStorageRepositoryService.Setup(x => x.GetBlobStringDataAsync(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(_mockExtractResult);

			IResultDataService resultDataService = new ResultDataService(_mockLogger.Object, _mockStorageRepositoryService.Object);
			var result = await resultDataService.GetResultDataAsync("testreport1", 1, 1);

			Assert.AreEqual(2, result.Total);
			Assert.AreEqual(1, result.PageNumber);
			Assert.AreEqual(1, result.PageSize);

			//Page size are based on number of tenants not how many records in data.
			//For this test expecting 2 records.
			Assert.AreEqual(2, result.Data.Count);
		}

		[TestMethod]
		public async Task GetGetResultDataAsync_NotFoundReport_ReturnNull()
		{
			_mockStorageRepositoryService.Setup(x => x.GetBlobListAsync(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(new List<ExtractResultDetails>());
			IResultDataService resultDataService = new ResultDataService(_mockLogger.Object, _mockStorageRepositoryService.Object);
			
			var result = await resultDataService.GetResultDataAsync("testreport1doesnotexist", 1, 2);

			Assert.AreEqual(null, result);
		}
	}
}
