﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InTuneExtractAPI.Tests
{
	public class DummyJsonObjects
	{
		public static string DummyBlobList = @"[
													{
														""Name"": ""testreport1_companyone_1EC93255-3938-41F5-9B54-0554258D56B7.json"",
														""CreatedOn"": ""2021-03-17T11:27:38Z"",
														""LastModified"": ""2021-03-17T11:42:32Z""
													},
													{
														""Name"": ""testreport1_companyone_D0DBB1ED-8449-4553-BD7C-A2890BCE73E3.json"",
														""CreatedOn"": ""2021-03-17T11:27:32Z"",
														""LastModified"": ""2021-03-17T11:42:48Z""
													},
													{
														""Name"": ""testreport1_companytwo_04F3C0EB-FED4-4BE6-8F11-8F53516A141F.json"",
														""CreatedOn"": ""2021-03-17T11:27:45Z"",
														""LastModified"": ""2021-03-17T11:42:41Z""

													},
													{
														""Name"": ""testreport1_companytwo_65D4C132-EDD3-4F4C-8010-652889BAB956.json"",
														""CreatedOn"": ""2021-03-17T11:27:53Z"",
														""LastModified"": ""2021-03-17T11:42:22Z""

													}
												]";


		public static string DummyBlobData = @"{
													""query"": ""reportName"",
													""reportId"": ""some_report_id"",
													""expiredTime"": ""0001-01-01T00: 00: 00Z"",
													""tenantId"": ""some guid"",
													""selectFields"": [
														""testFieldOne"",
														""testFieldTwo"",
														""testFilldThree""
													],
													""data"": [
														{
															""testFieldOne"": ""value1butdifferent"",
															""testFieldTwo"": ""value2butdifferent"",
															""testFilldThree"": ""value3butdifferent"",
															""companyName"": ""CompanyTwo""
														},
														{
															""testFieldOne"": ""value1xxxbutdifferent"",
															""testFieldTwo"": ""value2xxxbutdifferent"",
															""testFilldThree"": ""value3xxxbutdifferent"",
															""companyName"": ""CompanyTwo""
														}
													]
												}";

		public static string DummyResultDataPageNumberOnePageSize2 = @"{
																			""Data"": [
																				{
																					""testFieldOne"": ""value1butdifferent"",
																					""testFieldTwo"": ""value2butdifferent"",
																					""testFilldThree"": ""value3butdifferent"",
																					""companyName"": ""CompanyOne""
																				},
																				{
																					""testFieldOne"": ""value1xxxbutdifferent"",
																					""testFieldTwo"": ""value2xxxbutdifferent"",
																					""testFilldThree"": ""value3xxxbutdifferent"",
																					""companyName"": ""CompanyOne""
																				},
																				{
																					""testFieldOne"": ""value1butdifferent"",
																					""testFieldTwo"": ""value2butdifferent"",
																					""testFilldThree"": ""value3butdifferent"",
																					""companyName"": ""CompanyTwo""
																				},
																				{
																					""testFieldOne"": ""value1xxxbutdifferent"",
																					""testFieldTwo"": ""value2xxxbutdifferent"",
																					""testFilldThree"": ""value3xxxbutdifferent"",
																					""companyName"": ""CompanyTwo""
																				}
																			],
																			""Total"": 2,
																			""PageNumber"": 1,
																			""PageSize"": 2
																		}";

		public static string DummyResultDataPageNumberOnePageSize1 = @"{
																			""Data"": [
																				{
																					""testFieldOne"": ""value1butdifferent"",
																					""testFieldTwo"": ""value2butdifferent"",
																					""testFilldThree"": ""value3butdifferent"",
																					""companyName"": ""CompanyOne""
																				},
																				{
																					""testFieldOne"": ""value1xxxbutdifferent"",
																					""testFieldTwo"": ""value2xxxbutdifferent"",
																					""testFilldThree"": ""value3xxxbutdifferent"",
																					""companyName"": ""CompanyOne""
																				}
																			],
																			""Total"": 2,
																			""PageNumber"": 1,
																			""PageSize"": 1
																		}";
	}
}
