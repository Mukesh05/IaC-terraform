using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Internal;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using InTuneExtractAPI.Models;
using InTuneExtractAPI.Services;

namespace InTuneExtractAPI.Tests
{
	[ExcludeFromCodeCoverage]
	[TestClass]
    public class InTuneExtractAPITests
    {
		Mock<IConfigurationRefresher> _mockConfigRefresher;
		Mock<IConfiguration> _mockConfig;
		Mock<ILogger<InTuneExtractAPI>> _mockLogger;
		Mock<IResultDataService> _mockResultDataService;
		
		ResultData _mockResultDataPageNumberOnePageSize1;

		[TestInitialize]
		public void Initialize()
		{
			//Setup IConfigurationRefresher
			_mockConfigRefresher = new Mock<IConfigurationRefresher>();
			_mockConfigRefresher.Setup(x => x.TryRefreshAsync()).ReturnsAsync(true);

			//Setup IConfiguration
			_mockConfig = new Mock<IConfiguration>();
			_mockConfig.Setup(x => x["IntuneReport:TopicName"]).Returns("topicName");

			//Setup ILogger
			_mockLogger = new Mock<ILogger<InTuneExtractAPI>>();

			//Setup IResultDataService
			_mockResultDataPageNumberOnePageSize1 = JsonConvert.DeserializeObject<ResultData>(DummyJsonObjects.DummyResultDataPageNumberOnePageSize1);
			
			_mockResultDataService = new Mock<IResultDataService>();
		}

		[TestMethod]
		public async Task Run_PageNumber1PageSize2_ReturnNextPageEmptyPreviousAsync()
		{
			ResultData mockResultData =	JsonConvert.DeserializeObject<ResultData>(DummyJsonObjects.DummyResultDataPageNumberOnePageSize2);
			_mockResultDataService.Setup(x => x.GetResultDataAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).ReturnsAsync(mockResultData);

			InTuneExtractAPI inTuneExtractAPI = new InTuneExtractAPI(_mockConfig.Object,
																	 _mockConfigRefresher.Object,
																	 _mockLogger.Object,
																	 _mockResultDataService.Object);

			var request = new DefaultHttpContext().Request;
			var postParam = new Dictionary<string, StringValues>();
			postParam.Add("pagenumber", "1");
			postParam.Add("pagesize", "1");
			request.Query = new QueryCollection(postParam);
			request.Scheme = "https";
			request.Host = new HostString("testhost");
			request.Path = "/api/queryresult/data/testreport1";

			var result = (await inTuneExtractAPI.Run(request, "testreport1")) as ObjectResult;
			var resultValue = ((PagedResponse<JArray>)result.Value);

			Assert.IsNotNull(result);
			Assert.AreEqual(200, result.StatusCode);
			Assert.AreEqual(resultValue.NextPage, "https://testhost/api/queryresult/data/testreport1?pagenumber=2&pagesize=1");
			Assert.AreEqual(resultValue.PreviousPage, string.Empty);
		}

		[TestMethod]
		public async Task Run_PageNumber1PageSize1_ReturnEmptyNextEmptyPreviousPageAsync()
		{
			ResultData mockResultData = JsonConvert.DeserializeObject<ResultData>(DummyJsonObjects.DummyResultDataPageNumberOnePageSize1);
			_mockResultDataService.Setup(x => x.GetResultDataAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).ReturnsAsync(mockResultData);

			InTuneExtractAPI inTuneExtractAPI = new InTuneExtractAPI(_mockConfig.Object,
																	 _mockConfigRefresher.Object,
																	 _mockLogger.Object,
																	 _mockResultDataService.Object);

			var request = new DefaultHttpContext().Request;
			var postParam = new Dictionary<string, StringValues>();
			postParam.Add("pagenumber", "1");
			postParam.Add("pagesize", "2");
			request.Query = new QueryCollection(postParam);
			request.Scheme = "https";
			request.Host = new HostString("testhost");
			request.Path = "/api/queryresult/data/testreport1";

			var result = (await inTuneExtractAPI.Run(request, "testreport1")) as ObjectResult;
			var resultValue = ((PagedResponse<JArray>)result.Value);

			Assert.IsNotNull(result);
			Assert.AreEqual(200, result.StatusCode);
			Assert.AreEqual(resultValue.NextPage, string.Empty);
			Assert.AreEqual(resultValue.PreviousPage, string.Empty);
		}

		[TestMethod]
		public async Task Run_PageNumber1PageSize1_ReturnEmptyNextPreviousPageAsync()
		{
			ResultData mockResultData = JsonConvert.DeserializeObject<ResultData>(DummyJsonObjects.DummyResultDataPageNumberOnePageSize1);
			_mockResultDataService.Setup(x => x.GetResultDataAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).ReturnsAsync(mockResultData);

			InTuneExtractAPI inTuneExtractAPI = new InTuneExtractAPI(_mockConfig.Object,
																	 _mockConfigRefresher.Object,
																	 _mockLogger.Object,
																	 _mockResultDataService.Object);

			var request = new DefaultHttpContext().Request;
			var postParam = new Dictionary<string, StringValues>();
			postParam.Add("pagenumber", "2");
			postParam.Add("pagesize", "1");
			request.Query = new QueryCollection(postParam);
			request.Scheme = "https";
			request.Host = new HostString("testhost");
			request.Path = "/api/queryresult/data/testreport1";

			var result = (await inTuneExtractAPI.Run(request, "testreport1")) as ObjectResult;
			var resultValue = ((PagedResponse<JArray>)result.Value);

			Assert.IsNotNull(result);
			Assert.AreEqual(200, result.StatusCode);
			Assert.AreEqual(resultValue.NextPage, string.Empty);
			Assert.AreEqual(resultValue.PreviousPage, "https://testhost/api/queryresult/data/testreport1?pagenumber=1&pagesize=1");
		}


		[TestMethod]
		public async Task Run_NoResults_Return404NotFound()
		{
			ResultData mockResultData = JsonConvert.DeserializeObject<ResultData>(DummyJsonObjects.DummyResultDataPageNumberOnePageSize1);
			_mockResultDataService.Setup(x => x.GetResultDataAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).ReturnsAsync((ResultData)null);

			InTuneExtractAPI inTuneExtractAPI = new InTuneExtractAPI(_mockConfig.Object,
																	 _mockConfigRefresher.Object,
																	 _mockLogger.Object,
																	 _mockResultDataService.Object);

			var request = new DefaultHttpContext().Request;
			var postParam = new Dictionary<string, StringValues>();
			postParam.Add("pagenumber", "2");
			postParam.Add("pagesize", "1");
			request.Query = new QueryCollection(postParam);
			request.Scheme = "https";
			request.Host = new HostString("testhost");
			request.Path = "/api/queryresult/data/testreport1";

			var result = (await inTuneExtractAPI.Run(request, "testreport1")) as ObjectResult;
			
			Assert.IsNotNull(result);
			Assert.AreEqual(404, result.StatusCode);
			Assert.AreEqual("{ message = Data for report 'testreport1' not found. }", result.Value.ToString());
			
		}

		[TestMethod]
        public void TestMethod1()
        {
			Assert.IsTrue(true);
        }
    }
}
