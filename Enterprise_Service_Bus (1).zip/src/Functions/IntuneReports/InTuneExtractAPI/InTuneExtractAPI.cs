using System;
using System.Threading.Tasks;
using InTuneExtractAPI.Models;
using InTuneExtractAPI.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;

namespace InTuneExtractAPI
{
	public class InTuneExtractAPI
	{
		IConfiguration _config;
		IConfigurationRefresher _configRefresher;
		ILogger<InTuneExtractAPI> _logger;
		IResultDataService _resultDataService;

		public InTuneExtractAPI(IConfiguration config,
								IConfigurationRefresher configRefresher,
								ILogger<InTuneExtractAPI> logger,
								IResultDataService resultDataService)
		{
			_configRefresher = configRefresher;
			_config = config;
			_logger = logger;
			_resultDataService = resultDataService;
		}

		[FunctionName("InTuneExtractTotalPagesAPI")]
		public async Task<IActionResult> GetTotalPages(
			[HttpTrigger(AuthorizationLevel.Function, "get", Route = "queryresult/data/pagecount/{reportName}")] HttpRequest req,
			string reportName)
		{
			await _configRefresher.TryRefreshAsync();
			var result = await _resultDataService.GetTotalPagesAsync(reportName);

			return new OkObjectResult(new
			{
				TotalPages = result
			});
		}

		[FunctionName("InTuneExtractAPI")]
		public async Task<IActionResult> Run(
			[HttpTrigger(AuthorizationLevel.Function, "get", Route = "queryresult/data/{reportName}")] HttpRequest req,
			string reportName)
		{
			await _configRefresher.TryRefreshAsync();

			_logger.LogInformation("C# HTTP trigger function processed a request.");

			//Try to convert query parameter to an int. Set default if it doesn't convert
			Func<string, int> tryConvert = (string x) =>
			{
				int num;
				if (!int.TryParse(x, out num))
				{
					return 0;
				}
				return num;
			};

			//get pagination query parameters
			var pageSizeParam = req.Query["pagesize"];
			var pageNumberParam = req.Query["pagenumber"];
			int pageSize = tryConvert(pageSizeParam);
			int pageNumber = tryConvert(pageNumberParam);

			//get the report requested
			var result = await _resultDataService.GetResultDataAsync(reportName, pageNumber, pageSize);
			if(result == null)
			{
				return new NotFoundObjectResult(new { message = $"Data for report '{reportName}' not found." });
			}

			PagedResponse<JArray> response;
			if(pageSize > 0)
			{
				//create the pagination response
				int totalPages = (int)Math.Ceiling((decimal)result.Total / (decimal)pageSize);
				int maxPageNumber = pageNumber > totalPages ? totalPages : pageNumber;
				string url = $"{req.HttpContext.Request.Scheme}://{req.HttpContext.Request.Host}{req.HttpContext.Request.Path}";

				response = new PagedResponse<JArray>()
				{
					Data = result.Data,
					TotalPages = totalPages,
					PageNumber = maxPageNumber,
					PageSize = pageSize,
					TotalClients = result.Total,
					NextPage = maxPageNumber + 1 > totalPages ? string.Empty : $"{url}?pagenumber={maxPageNumber + 1}&pagesize={pageSize}",
					PreviousPage = pageNumber - 1 <= 0 ? string.Empty : $"{url}?pagenumber={maxPageNumber - 1}&pagesize={pageSize}"
				};
			}
			else
			{
				response = new PagedResponse<JArray>()
				{
					Data = result.Data,
					TotalPages = 0,
					PageNumber = 0,
					PageSize = 0,
					TotalClients = result.Total,
					NextPage = string.Empty,
					PreviousPage = string.Empty
				};
			}

			return new OkObjectResult(response);
		}
	}
}