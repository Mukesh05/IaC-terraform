﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace InTuneExtractAPI.Models
{
	public class ExtractResult
	{
		[JsonProperty("query")]
		public string Query { get; set; }

		[JsonProperty("reportId")]
		public string ReportId { get; set; }

		[JsonProperty("expiredTime")]
		public DateTime ExpiredTime { get; set; }

		[JsonProperty("tenantId")]
		public string TenantId { get; set; }

		[JsonProperty("selectFields")]
		public IEnumerable<string> SelectFields { get; set; }

		[JsonProperty("data")]
		public JArray Data { get; set; }
	}
}
