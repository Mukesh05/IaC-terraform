﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InTuneExtractAPI.Models
{
	public class PagedResponse<T>
	{
		public T Data { get; set; }
		public int? TotalPages { get; set; }
		public int? PageNumber { get; set; }
		public int? PageSize { get; set; }
		public int? TotalClients { get; set; }
		public string NextPage { get; set; }
		public string PreviousPage { get; set; }
	}
}
