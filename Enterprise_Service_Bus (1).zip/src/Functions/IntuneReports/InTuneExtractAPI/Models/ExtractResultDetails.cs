﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InTuneExtractAPI.Models
{
    public class ExtractResultDetails
    {
		public string Name { get; set; }
		public DateTime? CreatedOn { get; set; }
		public DateTime? LastModified { get; set; }
    }
}
