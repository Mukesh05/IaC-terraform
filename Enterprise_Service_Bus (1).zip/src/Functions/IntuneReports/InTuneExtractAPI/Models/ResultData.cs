﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json.Linq;

namespace InTuneExtractAPI.Models
{
	public class ResultData
	{
		public JArray Data { get; set; }

		public int Total { get; set; }
		public int PageNumber { get; set; }
		public int PageSize { get; set; }
	}
}
