﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using InTuneExtractAPI.Models;

namespace InTuneExtractAPI.Services
{
    public interface IResultDataService
    {
		Task<ResultData> GetResultDataAsync(string reportName, int pageNumber = 0, int PageSize = 0);
		Task<int> GetTotalPagesAsync(string reportName);
	}
}
