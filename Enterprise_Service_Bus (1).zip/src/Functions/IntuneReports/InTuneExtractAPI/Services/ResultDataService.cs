﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InTuneExtractAPI.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;

namespace InTuneExtractAPI.Services
{
	public class ResultDataService : IResultDataService
	{
		IStorageRepositoryService _storageRepositoryService;
		ILogger<ResultDataService> _logger;

		readonly string _containerName = "reports"; //should we get this from configuration?

		public ResultDataService(ILogger<ResultDataService> logger,
								 IStorageRepositoryService storageRepositoryService)
		{
			_logger = logger;
			_storageRepositoryService = storageRepositoryService;
		}
		
		public async Task<ResultData> GetResultDataAsync(string reportName, int pageNumber = 0, int pageSize = 0)
		{
			_logger.LogInformation($"Retrieving most recent data for report '{reportName}'. (pageName = {pageNumber}, pageSize = {pageSize})");
			var blobList = await _storageRepositoryService.GetBlobListAsync("reports", reportName);

			if(blobList.Count() == 0)
			{
				return null;
			}

			//Take the most recent blob for the specified report for each tenantId.
			//{reportName}-{tenantId}-[we don't care about this part].json (select by last modified data)
			Func<ExtractResultDetails, string> ParseName = (x =>
			{
				var parts = x.Name.Split('_');
				return $"{parts[0]}_{parts[1]}";
			});

			var result = blobList.GroupBy(x => ParseName(x))
								 .Select(x => x.OrderByDescending(y => y.LastModified).FirstOrDefault())
								 .OrderBy(x => x.Name)
								 .ToList();

			List<ExtractResultDetails> extractResultDetails = new List<ExtractResultDetails>();
			if(pageSize == 0 || pageNumber == 0)
			{
				extractResultDetails = result;
			}
			else
			{
				extractResultDetails = result.Skip(pageNumber - 1).Take(pageSize).ToList();
			}

			//A page size represents a blob (not data within blob)
			JArray allData = new JArray();
			foreach(var blob in extractResultDetails)
			{
				var data = await _storageRepositoryService.GetBlobStringDataAsync(_containerName, blob.Name);
				_logger.LogInformation($"Retrieved blob {blob.Name}, with last modified data of {blob.LastModified}.");

				allData.Merge(data.Data);
			}

			return new ResultData()
			{
				Data = allData,
				PageNumber = pageNumber,
				PageSize = pageSize,
				Total = result.Count
			};
		}

		public async Task<int> GetTotalPagesAsync(string reportName)
		{
			_logger.LogInformation($"Retrieving total available pages for '{reportName}'.");
			var blobList = await _storageRepositoryService.GetBlobListAsync("reports", reportName);

			if (blobList.Count() == 0)
			{
				return 0;
			}

			//Take the most recent blob for the specified report for each tenantId.
			//{reportName}-{tenantId}-[we don't care about this part].json (select by last modified data)
			Func<ExtractResultDetails, string> ParseName = (x =>
			{
				var parts = x.Name.Split('_');
				return $"{parts[0]}_{parts[1]}";
			});

			var result = blobList.GroupBy(x => ParseName(x))
								 .Select(x => x.OrderByDescending(y => y.LastModified).FirstOrDefault())
								 .OrderBy(x => x.Name)
								 .ToList();

			return result.Count;
		}
	}
}
