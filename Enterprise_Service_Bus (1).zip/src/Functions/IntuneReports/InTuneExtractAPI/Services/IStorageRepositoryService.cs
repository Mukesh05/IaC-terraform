﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using InTuneExtractAPI.Models;

namespace InTuneExtractAPI.Services
{
	public interface IStorageRepositoryService
	{
		Task<ExtractResult> GetBlobStringDataAsync(string containerName, string blobName);

		Task<IEnumerable<ExtractResultDetails>> GetBlobListAsync(string containerName, string reportName);
	}
}
