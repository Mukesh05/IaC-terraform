﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using InTuneExtractAPI.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace InTuneExtractAPI.Services
{

	/// <summary>
	/// Exclude from coverage - no business logic
	/// </summary>
	[ExcludeFromCodeCoverage]
	public class StorageRepositoryService : IStorageRepositoryService
	{
		string _connectionString;

		public StorageRepositoryService(string connectionString)
		{
			_connectionString = connectionString;
		}

		public async Task<IEnumerable<ExtractResultDetails>> GetBlobListAsync(string containterName, string reportNamed = null)
		{
			List<ExtractResultDetails> details = new List<ExtractResultDetails>();

			var blobContainer = new BlobContainerClient(_connectionString, containterName);
			await foreach (BlobItem blob in blobContainer.GetBlobsAsync(prefix: reportNamed))
			{
				details.Add(new ExtractResultDetails()
				{
					Name = blob.Name,
					CreatedOn = blob.Properties.CreatedOn.HasValue ? (DateTime?)blob.Properties.CreatedOn.Value.UtcDateTime : null,
					LastModified = blob.Properties.CreatedOn.HasValue ? (DateTime?)blob.Properties.LastModified.Value.UtcDateTime : DateTime.MinValue
				});
			}

			return details;
		}

		public async Task<ExtractResult> GetBlobStringDataAsync(string containerName, string blobName)
		{
			ExtractResult extractResult;

			var blobContainer = new BlobContainerClient(_connectionString, containerName);
			var blobClient = blobContainer.GetBlobClient(blobName);

			using (var stream = new StreamReader(await blobClient.OpenReadAsync()))
			{
				using (var jsonReader = new JsonTextReader(stream))
				{
					var jsonSerializer = new JsonSerializer();
					extractResult = jsonSerializer.Deserialize<ExtractResult>(jsonReader);
				}
			}

			return extractResult;
		}
	}
}
