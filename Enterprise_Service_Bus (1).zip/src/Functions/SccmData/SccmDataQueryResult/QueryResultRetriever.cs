﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using SccmData.QueryResultRepository;
using SccmData.QueryResult.Models;

namespace SccmData.QueryResult
{
	public class QueryResultRetriever : IQueryResultRetriever
	{
		IConfiguration _config;
		ILogger<QueryResultRetriever> _logger;
		IQueryResultRepository _repository;

		public QueryResultRetriever(IConfiguration config, ILogger<QueryResultRetriever> logger, IQueryResultRepository repository)
		{
			_config = config;
			_logger = logger;
			_repository = repository;
		}

		/// <summary>
		/// Return query results data.
		/// </summary>
		/// <param name="queryName"></param>
		/// <param name="clientCode"></param>
		/// <param name="pageNumber"></param>
		/// <param name="pageSize"></param>
		/// <returns></returns>
		public async Task<QueryResultData> GetQueryResultsAsync(string queryName, string clientCode = null, int pageNumber = 0, int pageSize = 0)
		{
			if (clientCode != null)
			{
				//Return results for the client specified
				_logger.LogInformation($"Retrieving results for single client {clientCode}.");
				var resultForSingle = await GetQueryResultsForSingleAsync(queryName, clientCode);
				return resultForSingle;
			}
			else
			{
				if (pageNumber < 0 || pageSize < 0)
				{
					throw new System.ArgumentException($"Invalid pageNumber and/or pageSize");
				}

				//No client specified, return results for all clients.
				_logger.LogInformation($"Retrieving results for all clients. PageNumber = {pageNumber}, PageSize = {pageSize}");
				var resultForAll = await GetQueryResultsForAllAsync(queryName, pageNumber, pageSize);
				return resultForAll;
			}
		}

		/// <summary>
		/// Get the query results for the specificed query and client code.
		/// </summary>
		/// <param name="queryName"></param>
		/// <param name="clientCode"></param>
		/// <returns></returns>
		private async Task<QueryResultData> GetQueryResultsForSingleAsync(string queryName, string clientCode)
		{
			//Get the most recent query result for the client.
			var results = await _repository.GetQueryResultDetailsAsync(clientCode, queryName);
			var mostRecentResult = results.Aggregate((x, y) => x.CreatedOn > y.CreatedOn ? x : y);
			var data = await _repository.GetQueryResultAsync(mostRecentResult.ContainerName, mostRecentResult.Name);

			//Enrich the results
			foreach (var entity in data.Data)
			{
				((JObject)entity).Add("clientCode", clientCode);
				((JObject)entity).Add("queryResultCreatedOn", results.First().CreatedOn);
				((JObject)entity).Add("queryName", queryName);
			}

			var jArray = new JArray();
			jArray.Merge(data.Data);
			return new QueryResultData()
			{
				Data = jArray,
				Total = 1,
				PageNumber = 1,
				PageSize = 1
			};
		}

		/// <summary>
		/// Get the query results for the specificed query and client code.
		/// </summary>
		/// <param name="queryName"></param>
		/// <param name="pageNumber"></param>
		/// <param name="pageSize"></param>
		/// <returns></returns>
		private async Task<QueryResultData> GetQueryResultsForAllAsync(string queryName, int pageNumber = 0, int pageSize = 0)
		{
			List<QueryResultDetails> queryResultDetails = new List<QueryResultDetails>();
			var containerList = await _repository.ListContainersAsync();
			foreach (var containerName in containerList)
			{
				var results = await _repository.GetQueryResultDetailsAsync(containerName, queryName);
				if (results.Count() == 0)
				{
					//This container has no blobs that match query so do not add to result.
					continue;
				}

				//We only want the most recent query result.
				var mostRecentResult = results.Aggregate((x, y) => x.CreatedOn > y.CreatedOn ? x : y);
				queryResultDetails.Add(mostRecentResult);
				_logger.LogInformation($"Reteived most recent query results for {containerName}. Query result in {mostRecentResult.Name} with date {mostRecentResult.CreatedOn}");
			}

			//Return the data foreach of the query result. Since these results can be large, we
			//will paginate client (container).
			JArray allData = new JArray();
			var orderedQueryResultDetails = queryResultDetails.OrderBy(x => x.ContainerName);

			List<QueryResultDetails> queryResults = new List<QueryResultDetails>();
			if(pageNumber == 0 || pageSize == 0)
			{
				queryResults = orderedQueryResultDetails.ToList();
			}
			else
			{
				queryResults = orderedQueryResultDetails.Skip(pageNumber - 1).Take(pageSize).ToList();
			}

			foreach (var item in queryResults)
			{
				var data = await _repository.GetQueryResultAsync(item.ContainerName, item.Name);

				//Enrich the results
				foreach (var entity in data.Data)
				{
					((JObject)entity).Add("clientCode", item.ContainerName);
					((JObject)entity).Add("queryResultCreatedOn", item.CreatedOn);
					((JObject)entity).Add("queryName", queryName);
				}

				allData.Merge(data.Data);
			}

			return new QueryResultData()
			{
				Data = allData,
				PageNumber = pageNumber,
				PageSize = pageSize,
				Total = queryResultDetails.Count()
			};
		}

		public async Task<int> GetTotalPagesAsync(string queryName)
		{
			List<QueryResultDetails> queryResultDetails = new List<QueryResultDetails>();
			var containerList = await _repository.ListContainersAsync();
			foreach (var containerName in containerList)
			{
				var results = await _repository.GetQueryResultDetailsAsync(containerName, queryName);
				if (results.Count() == 0)
				{
					//This container has no blobs that match query so do not add to result.
					continue;
				}

				//We only want the most recent query result.
				var mostRecentResult = results.Aggregate((x, y) => x.CreatedOn > y.CreatedOn ? x : y);
				queryResultDetails.Add(mostRecentResult);
			}

			return queryResultDetails.Count;
		}
	}
}