﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Azure.Identity;
using Microsoft.ApplicationInsights.Channel;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.DependencyInjection;
using SccmData.QueryResultRepository;
using Microsoft.Extensions.Logging;

[assembly: FunctionsStartup(typeof(SccmData.QueryResult.Startup))]
namespace SccmData.QueryResult
{
	public class Startup : FunctionsStartup
	{
		public override void Configure(IFunctionsHostBuilder builder)
		{
			var appconfigConnectionString = Environment.GetEnvironmentVariable("appconfigconnectionstring");

			//Basic config setup
			var configBuilder = new ConfigurationBuilder()
				.SetBasePath(Directory.GetCurrentDirectory())
				.AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
				.AddEnvironmentVariables();

			//Azure App config setup
			IConfigurationRefresher configRefresher = null;
			configBuilder.AddAzureAppConfiguration(options =>
			{
				options.Connect(appconfigConnectionString)
			   .Select("SccmData:*")
			   .ConfigureKeyVault(kv =>
			   {
				   kv.SetCredential(new DefaultAzureCredential()); //NuGet Azure.Identity
			   });
				configRefresher = options.GetRefresher();
			});

			//Register configuraiton
			IConfiguration config = configBuilder.Build();
			builder.Services.AddSingleton<IConfiguration>((services) =>
			{
				return config;
			});

			// Registering storage repository services
			var connectionString = config["SccmData:StorageConnectionString"];
			builder.Services.AddSingleton<IQueryResultRepository>((services) =>
			{
				return new AzureStorageQueryResultRepository(connectionString); //ToDo : Remember to setup dependency properly after other branch set in master.
			});

			builder.Services.AddSingleton<IQueryResultRetriever, QueryResultRetriever>();
		}
	}
}
