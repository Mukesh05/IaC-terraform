﻿using Newtonsoft.Json.Linq;

namespace SccmData.QueryResult.Models
{
	public class QueryResultData
	{
		public JArray Data;

		public int Total { get; set; }
		public int PageNumber { get; set; }
		public int PageSize { get; set; }
	}
}
