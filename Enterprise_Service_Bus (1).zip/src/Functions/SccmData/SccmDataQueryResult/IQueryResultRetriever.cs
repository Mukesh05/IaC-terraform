﻿using System.Threading.Tasks;
using SccmData.QueryResult.Models;

namespace SccmData.QueryResult
{
	public interface IQueryResultRetriever
	{
		Task<QueryResultData> GetQueryResultsAsync(string queryName, string clientCode = null, int pageNumber = 1, int pageSize = 1);
		Task<int> GetTotalPagesAsync(string reportName);
	}
}
