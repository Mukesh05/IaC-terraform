using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using SccmData.QueryResult.Models;
using Newtonsoft.Json.Linq;

namespace SccmData.QueryResult
{
	public class SccmDataQueryResult
    {
		ILogger<SccmDataQueryResult> _logger;
		IQueryResultRetriever _queryResultRetriever;

		public SccmDataQueryResult(ILogger<SccmDataQueryResult> logger, IQueryResultRetriever queryResultRetriever)
		{
			_logger = logger;
			_queryResultRetriever = queryResultRetriever;
		}

		[FunctionName("SccmDataQueryResultTotalPages")]
		public async Task<IActionResult> GetTotalPages(
			[HttpTrigger(AuthorizationLevel.Function, "get", Route = "queryresult/data/pagecount/{reportName}")] HttpRequest req,
			string reportName)
		{
			var result = await _queryResultRetriever.GetTotalPagesAsync(reportName);
			return new OkObjectResult(new
			{
				TotalPages = result
			});
		}

		[FunctionName("SccmDataQueryResultGet")]
        public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "get", Route = "queryresult/data/{queryName}")] HttpRequest req, string queryName)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");

			//Try to convert query parameter to an int. Set default if it doesn't convert
			Func<string, int> tryConvert = (string x) =>
			{
				int num;
				if(!int.TryParse(x, out num))
				{
					return 0;
				}
				return num;
			};

			string clientCode = req.Query["clientcode"];
			var pageSizeParam = req.Query["pagesize"];
			var pageNumberParam = req.Query["pageNumber"];

			PagedResponse<JArray> response;
			//If the client code is available, only return data for requested client.
			if (!string.IsNullOrWhiteSpace(clientCode))
			{
				var result = await _queryResultRetriever.GetQueryResultsAsync(queryName, clientCode);

				response = new PagedResponse<JArray>()
				{
					Data = result.Data,
					TotalPages = null,
					PageNumber = null,
					PageSize = null,
					TotalClients = null,
					NextPage = string.Empty,
					PreviousPage = string.Empty
				};
			}
			else
			{
				int pageSize = tryConvert(pageSizeParam);
				int pageNumber = tryConvert(pageNumberParam);

				var result = await _queryResultRetriever.GetQueryResultsAsync(queryName, clientCode: null, pageNumber: pageNumber, pageSize: pageSize);

				if (pageSize > 0)
				{
					//Generate response with pagination information
					int totalPages = (int)Math.Ceiling((decimal)result.Total / (decimal)pageSize);
					int maxPageNumber = pageNumber > totalPages ? totalPages : pageNumber;
					string url = $"{req.HttpContext.Request.Scheme}://{req.HttpContext.Request.Host}{req.HttpContext.Request.Path}";

					response = new PagedResponse<JArray>()
					{
						Data = result.Data,
						TotalPages = totalPages,
						PageNumber = maxPageNumber,
						PageSize = pageSize,
						TotalClients = result.Total,
						NextPage = maxPageNumber + 1 > totalPages ? string.Empty : $"{url}?pagenumber={maxPageNumber + 1}&pageSize={pageSize}",
						PreviousPage = pageNumber - 1 <= 0 ? string.Empty : $"{url}?pagenumber={maxPageNumber - 1}&pagesize={pageSize}"
					};
				}
				else
				{
					//all data was returned,
					response = new PagedResponse<JArray>()
					{
						Data = result.Data,
						TotalPages = 0,
						PageNumber = 0,
						PageSize = pageSize,
						TotalClients = result.Total,
						NextPage = string.Empty,
						PreviousPage = string.Empty
					};
				}
			}

			return new OkObjectResult(response);
		}
    }
}
