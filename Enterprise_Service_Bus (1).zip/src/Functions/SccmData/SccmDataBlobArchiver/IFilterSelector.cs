﻿using System;
using System.Collections.Generic;

namespace SccmDataBlobArchiver
{
	public interface IFilterSelector
	{
		List<string> SelectFilter(Dictionary<string, DateTimeOffset?> blobDetails);
	}
}