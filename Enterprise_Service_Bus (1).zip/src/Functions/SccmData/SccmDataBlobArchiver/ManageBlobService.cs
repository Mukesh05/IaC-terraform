﻿using System;
using System.Collections.Generic;
using System.Linq;
using Azure.Storage.Blobs.Models;
using Microsoft.Azure.Storage;
using Microsoft.Azure.Storage.Blob;
using Microsoft.Azure.Storage.RetryPolicies;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace SccmDataBlobArchiver
{
	public partial class ManageBlobService : IManageBlobService
	{
		IBlobServiceClientAuthenticatedConnectionGenerator _BlobServiceClientAuthenticatedConnectionGenerator;
		IFilterSelector _filterSelector;
		IConfiguration _config;
		ILogger<ManageBlobService> _logger;
		string _connectionstring;

		public ManageBlobService(IBlobServiceClientAuthenticatedConnectionGenerator BlobServiceClientAuthenticatedConnectionGenerator, IFilterSelector filterSelector, IConfiguration config, ILogger<ManageBlobService> logger)
		{
			_BlobServiceClientAuthenticatedConnectionGenerator = BlobServiceClientAuthenticatedConnectionGenerator;
			_filterSelector = filterSelector;
			_config = config;
			_logger = logger;
			_connectionstring = _config["SccmData:StorageConnectionString"];
		}

		public List<string> GetBlobContainersAsync()
		{
			try
			{
				var blobServiceClient = _BlobServiceClientAuthenticatedConnectionGenerator.GetBlobServiceClientWithConnectionStringAuth(_connectionstring);
				List<string> containers = new List<string>();
				var resultSegment = blobServiceClient.GetBlobContainers(BlobContainerTraits.None, BlobContainerStates.None, null);

				// Enumerate the blobs returned for each page.
				foreach (var container in resultSegment)
				{
					if (!(container.Name.StartsWith("azure")))
					{
						containers.Add(container.Name);
					}
				}
				return containers;
			}
			catch (Exception ex)
			{
				_logger.LogError($"Exception occured in GetBlobContainersAsync at {DateTime.Now} due to {ex.Message} and {ex.InnerException}");
				return null;
			}
		}

		public Dictionary<string, DateTimeOffset?> GetBlobsAsync()
		{
			try
			{
				List<string> containers = GetBlobContainersAsync();
				CloudStorageAccount backupStorageAccount = CloudStorageAccount.Parse(_connectionstring);
				var backupBlobClient = backupStorageAccount.CreateCloudBlobClient();
				Dictionary<string, DateTimeOffset?> blobDetails = new Dictionary<string, DateTimeOffset?>();
				foreach (var container in containers)
				{
					var backupContainer = backupBlobClient.GetContainerReference(container);
					var list = backupContainer.ListBlobs(null, true).ToList();
					Dictionary<string, DateTimeOffset?> containerblobs = list.OfType<CloudBlockBlob>().ToDictionary(b => b.Name, b => b.Properties.LastModified);
					foreach (var containerblob in containerblobs)
					{
						blobDetails.Add(containerblob.Key, containerblob.Value);
					}
				}

				return blobDetails.OrderByDescending(blob => blob.Value).ToDictionary(b => b.Key, b => b.Value);
			}
			catch (Exception ex)
			{
				_logger.LogError($"Exception occured in GetBlobsAsync at {DateTime.Now} due to {ex.Message} and {ex.InnerException}");
				return null;
			}
		}

		public bool DeleteListOfOldBlobsAsync()
		{
			try
			{
				_logger.LogInformation($"DeleteListOfOldBlobsAsync: {DateTime.Now}");
				List<string> containers = GetBlobContainersAsync();
				var blobClient = GetCloudBlobClient();
				List<string> blobsTobeDeletedFinal = _filterSelector.SelectFilter(GetBlobsAsync());
				
				foreach (var blob in blobsTobeDeletedFinal)
				{
					var containerName = blob.Split("-")[0];
					CloudBlobContainer container = blobClient.GetContainerReference(containerName);
					CloudBlockBlob blockBlob = container.GetBlockBlobReference(blob);
					blockBlob.Delete(Microsoft.Azure.Storage.Blob.DeleteSnapshotsOption.IncludeSnapshots);
				}

				return true;
			}
			catch(Exception ex)
			{
				_logger.LogError($"Exception occured in DeleteListOfOldBlobsAsync at {DateTime.Now} due to {ex.Message} and {ex.InnerException}");
				return false;
			}
		}


		// Helper method to retrieve retrieve the CloudBlobClient object in order to interact with the storage account.
		// The retry policy on the CloudBlobClient object is set to an Exponential retry policy with a back off of 2 seconds
		// and a max attempts of 10 times.
		private CloudBlobClient GetCloudBlobClient()
		{
			try
			{
				CloudStorageAccount storageAccount = CloudStorageAccount.Parse(_connectionstring);
				CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
				IRetryPolicy exponentialRetryPolicy = new ExponentialRetry(TimeSpan.FromSeconds(2), 10);
				blobClient.DefaultRequestOptions.RetryPolicy = exponentialRetryPolicy;
				return blobClient;
			}
			catch (StorageException ex)
			{
				_logger.LogError($"Exception occured in GetCloudBlobClient at {DateTime.Now} due to {ex.Message} and {ex.InnerException}");
				throw;
			}
		}
	}
}
