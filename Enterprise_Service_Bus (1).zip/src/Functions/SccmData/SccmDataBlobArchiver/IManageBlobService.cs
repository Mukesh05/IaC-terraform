﻿using System;
using System.Collections.Generic;

namespace SccmDataBlobArchiver
{
	public interface IManageBlobService
	{
		List<string> GetBlobContainersAsync();
		Dictionary<string, DateTimeOffset?> GetBlobsAsync();
		bool DeleteListOfOldBlobsAsync();
	}
}