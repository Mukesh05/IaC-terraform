﻿using System.IO;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using System;
using Azure.Identity;
using Microsoft.Extensions.Logging;

[assembly: FunctionsStartup(typeof(SccmDataBlobArchiver.Startup))]
namespace SccmDataBlobArchiver
{
	public class Startup : FunctionsStartup
	{
		public override void Configure(IFunctionsHostBuilder builder)
		{
			IConfigurationRefresher configRefresher = null;
			var appconfigConnectionString = Environment.GetEnvironmentVariable("appconfigconnectionstring");

			//Basic config setup
			var configBuilder = new ConfigurationBuilder()
				.SetBasePath(Directory.GetCurrentDirectory())
				.AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
				.AddEnvironmentVariables();

			//Azure App config setup
			configBuilder.AddAzureAppConfiguration(options =>
			{
				options.Connect(appconfigConnectionString)
				.Select("Common:*")
				.Select("SccmData:*")
				.ConfigureKeyVault(kv =>
				{
					kv.SetCredential(new DefaultAzureCredential()); //NuGet Azure.Identity
				});
				configRefresher = options.GetRefresher();
			});

			IConfiguration config = configBuilder.Build();

			// Register Config services

			builder.Services.AddSingleton<IConfiguration>((services) =>
			{
				return config;
			});

			builder.Services.AddSingleton<IConfigurationRefresher>((services) =>
			{
				return configRefresher;
			});

			// Registering services

			builder
				.Services
				.AddSingleton<IBlobServiceClientAuthenticatedConnectionGenerator, BlobServiceClientAuthenticatedConnectionGenerator>();

			builder
				.Services
				.AddSingleton<IFilterBlobForTimeSeries, FilterBlobForTimeSeries>();

			builder
				.Services
				.AddSingleton<IManageBlobService, ManageBlobService>();

			builder
				.Services
				.AddSingleton<IFilterSelector, FilterSelector>();

		}
	}
}
