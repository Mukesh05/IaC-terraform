﻿using Azure.Storage.Blobs;

namespace SccmDataBlobArchiver
{
	public interface IBlobServiceClientAuthenticatedConnectionGenerator
	{
		BlobServiceClient GetBlobServiceClientWithActiveDirectoryAuth(string ActiveDirectoryTenantId, string ActiveDirectoryApplicationId, string ActiveDirectoryApplicationSecret, string ActiveDirectoryAuthEndpoint, string ActiveDirectoryBlobUri);
		BlobServiceClient GetBlobServiceClientWithConnectionStringAuth(string ConnectionString);
		BlobServiceClient GetBlobServiceClientWithSharedAccessSignatureAuth(string StorageAccountName, string StorageAccountKey, string StorageAccountBlobUri);
		BlobServiceClient GetBlobServiceClientWithSharedKeyAuth(string StorageAccountName, string StorageAccountKey, string StorageAccountBlobUri);
	}
}