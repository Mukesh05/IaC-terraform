﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace SccmDataBlobArchiver
{
	public class FilterBlobForTimeSeries : IFilterBlobForTimeSeries
	{
		IConfiguration _config;
		ILogger<SccmDataBlobArchiver> _logger;
		public FilterBlobForTimeSeries(IConfiguration config, ILogger<SccmDataBlobArchiver> logger)
		{
			_config = config;
			_logger = logger;
		}

		public List<string> GetDeleteListOfOldMonthlyBlobsAsync(Dictionary<string, DateTimeOffset?> blobDetails)
		{
			try
			{
				int currentMonth = DateTime.UtcNow.Month;
				blobDetails = blobDetails.Where(bd => bd.Value.GetValueOrDefault().Month != currentMonth).ToDictionary(bd => bd.Key, bd => bd.Value);
				List<string> blobsTobeDeletedFinal = new List<string>();
				var lastblobProcessedMonth = currentMonth;
				foreach (var blob in blobDetails)
				{
					var blobMonth = blob.Value.GetValueOrDefault().Month;
					var blobYear = blob.Value.GetValueOrDefault().Year;
					var splitKeyArray = blob.Key.Split("-");
					var blobKeyTobeDeleted = splitKeyArray[0] + "-" + splitKeyArray[1] + "-" + splitKeyArray[2];
					var monthlyblobDetails = blobDetails.Where(bd => bd.Key.StartsWith(blobKeyTobeDeleted) && bd.Value.GetValueOrDefault().Month == blobMonth && bd.Value.GetValueOrDefault().Year == blobYear);
					var topblobOftheMonthNottobeDeleted = monthlyblobDetails.First();
					blobsTobeDeletedFinal.AddRange(monthlyblobDetails.Where(b => b.Key != topblobOftheMonthNottobeDeleted.Key).Select(b => b.Key).ToList());
				}

				return blobsTobeDeletedFinal.Distinct().ToList();
			}
			catch (Exception ex)
			{
				_logger.LogError($"Exception occured in GetDeleteListOfOldMonthlyBlobsAsync at {DateTime.Now} due to {ex.Message} and {ex.InnerException}");
				return null;
			}
		}

		public List<string> GetDeleteListOfOldWeeklyBlobsAsync(Dictionary<string, DateTimeOffset?> blobDetails)
		{
			try
			{
				int currentMonth = DateTime.UtcNow.Month;
				blobDetails = blobDetails.Where(bd => bd.Value.GetValueOrDefault().Month != currentMonth).ToDictionary(bd => bd.Key, bd => bd.Value);
				List<string> blobsTobeDeletedFinal = new List<string>();
				foreach (var blob in blobDetails)
				{
					var blobMonth = blob.Value.GetValueOrDefault().Month;
					var blobYear = blob.Value.GetValueOrDefault().Year;
					var blobWeekNumber = GetWeekNumberOfDate(blob.Value.GetValueOrDefault().DateTime);
					var splitKeyArray = blob.Key.Split("-");
					var blobKeyTobeDeleted = splitKeyArray[0] + "-" + splitKeyArray[1] + "-" + splitKeyArray[2];
					var weeklyblobDetails = blobDetails.Where(bd => bd.Value <= blob.Value && bd.Key.StartsWith(blobKeyTobeDeleted) && GetWeekNumberOfDate(bd.Value.GetValueOrDefault().DateTime) == blobWeekNumber && bd.Value.GetValueOrDefault().Month == blobMonth  && bd.Value.GetValueOrDefault().Year == blobYear);
					var topblobOftheWeekNottobeDeleted = weeklyblobDetails.First();
					blobsTobeDeletedFinal.AddRange(weeklyblobDetails.Where(b => b.Key != topblobOftheWeekNottobeDeleted.Key).Select(b => b.Key).ToList());
				}

				return blobsTobeDeletedFinal.Distinct().ToList();
				
			}
			catch (Exception ex)
			{
				_logger.LogError($"Exception occured in GetDeleteListOfOldWeeklyBlobsAsync at {DateTime.Now} due to {ex.Message} and {ex.InnerException}");
				return null;
			}
		}

		public List<string> GetDeleteListOfOldDailyBlobsAsync(Dictionary<string, DateTimeOffset?> blobDetails)
		{
			try
			{
				int currentMonth = DateTime.UtcNow.Month;
				blobDetails = blobDetails.Where(bd => bd.Value.GetValueOrDefault().Month != currentMonth).ToDictionary(bd => bd.Key, bd => bd.Value);
				List<string> blobsTobeDeletedFinal = new List<string>();
				foreach (var blob in blobDetails)
				{
					var blobMonth = blob.Value.GetValueOrDefault().Month;
					var blobDate = blob.Value.GetValueOrDefault().Date;
					var dailyblobDetails = blobDetails.Where(bd => bd.Value.GetValueOrDefault().Date == blobDate);
					var splitKeyArray = blob.Key.Split("-");
					var blobKeyTobeDeleted = splitKeyArray[0] + "-" + splitKeyArray[1] + "-" + splitKeyArray[2];
					var topblobOfthedAILYNottobeDeleted = dailyblobDetails.First().Value;
					blobsTobeDeletedFinal.AddRange(dailyblobDetails.Where(b => b.Key.StartsWith(blobKeyTobeDeleted) && b.Value < topblobOfthedAILYNottobeDeleted).Select(b => b.Key).ToList());
				}

				return blobsTobeDeletedFinal.Distinct().ToList();
			}
			catch (Exception ex)
			{
				_logger.LogError($"Exception occured in GetDeleteListOfOldDailyBlobsAsync at {DateTime.Now} due to {ex.Message} and {ex.InnerException}");
				return null;
			}
		}

		private int GetWeekNumberOfDate(DateTime date)
		{
			date = date.Date;
			DateTime firstMonthDay = new DateTime(date.Year, date.Month, 1);
			DateTime firstMonthMonday = firstMonthDay.AddDays((DayOfWeek.Monday + 7 - firstMonthDay.DayOfWeek) % 7);
			if (firstMonthMonday > date)
			{
				firstMonthDay = firstMonthDay.AddMonths(-1);
				firstMonthMonday = firstMonthDay.AddDays((DayOfWeek.Monday + 7 - firstMonthDay.DayOfWeek) % 7);
			}
			return (date - firstMonthMonday).Days / 7 + 1;
		}
	}
}
