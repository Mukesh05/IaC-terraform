﻿using System;
using System.Collections.Generic;

namespace SccmDataBlobArchiver
{
	public interface IFilterBlobForTimeSeries
	{
		List<string> GetDeleteListOfOldMonthlyBlobsAsync(Dictionary<string, DateTimeOffset?> blobDetails);
		List<string> GetDeleteListOfOldWeeklyBlobsAsync(Dictionary<string, DateTimeOffset?> blobDetails);
		List<string> GetDeleteListOfOldDailyBlobsAsync(Dictionary<string, DateTimeOffset?> blobDetails);
	}
}
