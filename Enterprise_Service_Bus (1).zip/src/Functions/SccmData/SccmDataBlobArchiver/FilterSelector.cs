﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace SccmDataBlobArchiver
{
	public class FilterSelector : IFilterSelector
	{
		IFilterBlobForTimeSeries _filterBlobForTimeSeries;
		IConfiguration _config;
		ILogger<FilterSelector> _logger;

		public FilterSelector(IFilterBlobForTimeSeries filterBlobForTimeSeries, IConfiguration config, ILogger<FilterSelector> logger)
		{
			_filterBlobForTimeSeries = filterBlobForTimeSeries;
			_config = config;
			_logger = logger;
		}

		public List<string> SelectFilter(Dictionary<string, DateTimeOffset?> blobDetails)
		{
			List<string> blobsTobeDeletedFinal = new List<string>();
			BlobTimeFrame timeFrame = (BlobTimeFrame)Enum.Parse(typeof(BlobTimeFrame), _config["BlobTimeFrame"], true);
			if (timeFrame == BlobTimeFrame.Daily)
			{
				blobsTobeDeletedFinal = _filterBlobForTimeSeries.GetDeleteListOfOldDailyBlobsAsync(blobDetails);
			}
			else if (timeFrame == BlobTimeFrame.Weekly)
			{
				blobsTobeDeletedFinal = _filterBlobForTimeSeries.GetDeleteListOfOldWeeklyBlobsAsync(blobDetails);
			}
			else
			{
				blobsTobeDeletedFinal = _filterBlobForTimeSeries.GetDeleteListOfOldMonthlyBlobsAsync(blobDetails);
			}

			return blobsTobeDeletedFinal;
		}
	}
}
