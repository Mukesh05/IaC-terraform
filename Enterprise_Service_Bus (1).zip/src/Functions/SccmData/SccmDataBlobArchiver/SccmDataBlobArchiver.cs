using System;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Configuration;

namespace SccmDataBlobArchiver
{
	public class SccmDataBlobArchiver
    {
		IConfigurationRefresher _configRefresher;
		IConfiguration _config;
		IManageBlobService _manageBlobService;
		ILogger<SccmDataBlobArchiver> _logger;

		public SccmDataBlobArchiver(IConfiguration config, IConfigurationRefresher configRefresher, IManageBlobService manageBlobService, ILogger<SccmDataBlobArchiver> logger)
		{
			_configRefresher = configRefresher;
			_config = config;
			_manageBlobService = manageBlobService;
			_logger = logger;
		}

		[FunctionName("OnDemandBlobArchive")]
		public async Task AcrhiveBloblsOnDemand([HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequest req)
		{
			_logger.LogInformation($"C# Http trigger function starting execution at: {DateTime.Now}");

			_manageBlobService.DeleteListOfOldBlobsAsync();

			_logger.LogInformation($"C# Http trigger function FetchCustomerInvoices finished executed at: {DateTime.Now}");
		}

		[FunctionName("SccmDataBlobArchiverFunc")]
        public async Task Run([TimerTrigger("%TimerSchedule%")] TimerInfo myTimer, ExecutionContext context)
        {

			await _configRefresher.TryRefreshAsync();

            //Runs every 7th of the month
			_logger.LogInformation($"C# Timer trigger function starting execution at: {DateTime.Now}");

			_manageBlobService.DeleteListOfOldBlobsAsync();

			_logger.LogInformation($"C# Timer trigger function FetchCustomerInvoices finished executed at: {DateTime.Now}");
        }
	}
}