﻿namespace SccmDataBlobArchiver
{
	public enum BlobTimeFrame
	{
		Daily,
		Weekly,
		Monthly
	}
}
