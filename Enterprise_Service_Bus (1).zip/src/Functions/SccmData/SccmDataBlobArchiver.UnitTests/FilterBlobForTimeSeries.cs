﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using SccmDataBlobArchiver;

namespace SccmDataBlobArchiverTests.UnitTests
{
	[TestClass]
	public class FilterBlobForTimeSeriesTests
	{
		IFilterBlobForTimeSeries _filterBlobForTimeSeries;
		Dictionary<string, DateTimeOffset?> _blobList;
		IConfiguration _config;
		Mock<ILogger<SccmDataBlobArchiver.SccmDataBlobArchiver>> _logger;
		public FilterBlobForTimeSeriesTests()
		{
			_config = TestHelper.GetIConfigurationRoot(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
			_logger = new Mock<ILogger<SccmDataBlobArchiver.SccmDataBlobArchiver>>();
			_filterBlobForTimeSeries = new FilterBlobForTimeSeries(_config, _logger.Object);
		}

		[TestMethod]
		public void GetDeleteListOfOldMonthlyBlobsAsync()
		{
			_blobList = new Dictionary<string, DateTimeOffset?>();
			_blobList.Add("bco-smalldata-mpiccolo-85e24eb0-f703-4505-b64f-184d97233d22.json", new DateTimeOffset(Convert.ToDateTime("05/02/2021 13:19:54")));
			_blobList.Add("bco-smalldata-mpiccolo-9c431ed3-0a48-4448-941d-0a1badecbe03.json", new DateTimeOffset(Convert.ToDateTime("09/02/2021 11:55:34")));

			_blobList.Add("bco-smalldata-mpiccolo-79409a1b-81de-45cb-a372-fedb95a0c8b1.json", new DateTimeOffset(Convert.ToDateTime("29/01/2021 13:53:42")));

			_blobList.Add("bco-smalldata-mpiccolo-c34e0381-ce22-4dbe-89ce-5a47ef193187.json", new DateTimeOffset(Convert.ToDateTime("29/01/2021 13:51:42")));
			_blobList.Add("bco-smalldata-mpiccolo-f2018266-4c7e-4113-be5f-ceb98e10c7e0.json", new DateTimeOffset(Convert.ToDateTime("29/01/2021 13:49:46")));
			_blobList.Add("bco-smalldata-mpiccolo-19da2443-e2ac-4dc4-8b40-4fe8e6df8814.json", new DateTimeOffset(Convert.ToDateTime("29/01/2021 03:42:02")));

			_blobList.Add("bco-scep-mpiccolo-55163a1d-b139-4b08-8f8d-584267f2d9c7.json", new DateTimeOffset(Convert.ToDateTime("28/01/2021 04:01:24")));

			_blobList.Add("bco-scep-mpiccolo-baf5c9f7-4440-4684-a0ed-e43d2f31497e.json", new DateTimeOffset(Convert.ToDateTime("28/01/2021 04:00:25")));
			_blobList.Add("bco-scep-mpiccolo-122c5056-b5d4-4c02-b291-0ae333dbe5a8.json", new DateTimeOffset(Convert.ToDateTime("28/01/2021 03:58:28")));
			_blobList.Add("bco-scep-mpiccolo-33253990-07eb-4f72-b87e-51648697423a.json", new DateTimeOffset(Convert.ToDateTime("28/01/2021 03:59:39")));

			_blobList = _blobList.OrderByDescending(blob => blob.Value).ToDictionary(b => b.Key, b => b.Value);

			var tobeDeleted = _filterBlobForTimeSeries.GetDeleteListOfOldMonthlyBlobsAsync(_blobList);

			Assert.IsTrue(tobeDeleted.Contains("bco-smalldata-mpiccolo-c34e0381-ce22-4dbe-89ce-5a47ef193187.json"));
			Assert.IsTrue(tobeDeleted.Contains("bco-smalldata-mpiccolo-f2018266-4c7e-4113-be5f-ceb98e10c7e0.json"));
			Assert.IsTrue(tobeDeleted.Contains("bco-smalldata-mpiccolo-19da2443-e2ac-4dc4-8b40-4fe8e6df8814.json"));
			Assert.IsTrue(tobeDeleted.Contains("bco-scep-mpiccolo-baf5c9f7-4440-4684-a0ed-e43d2f31497e.json"));
			Assert.IsTrue(tobeDeleted.Contains("bco-scep-mpiccolo-122c5056-b5d4-4c02-b291-0ae333dbe5a8.json"));
			Assert.IsTrue(tobeDeleted.Contains("bco-scep-mpiccolo-33253990-07eb-4f72-b87e-51648697423a.json"));

			Assert.IsFalse(tobeDeleted.Contains("bco-smalldata-mpiccolo-85e24eb0-f703-4505-b64f-184d97233d22.json"));
			Assert.IsFalse(tobeDeleted.Contains("bco-smalldata-mpiccolo-9c431ed3-0a48-4448-941d-0a1badecbe03.json"));
			Assert.IsFalse(tobeDeleted.Contains("bco-smalldata-mpiccolo-79409a1b-81de-45cb-a372-fedb95a0c8b1.json"));
			Assert.IsFalse(tobeDeleted.Contains("bco-scep-mpiccolo-55163a1d-b139-4b08-8f8d-584267f2d9c7.json"));
		}

		[TestMethod]
		public void GetDeleteListOfOldWeeklyBlobsAsync()
		{
			_blobList = new Dictionary<string, DateTimeOffset?>();
			_blobList.Add("bco-smalldata-mpiccolo-85e24eb0-f703-4505-b64f-184d97233d22.json", new DateTimeOffset(Convert.ToDateTime("05/02/2021 13:19:54")));
			_blobList.Add("bco-smalldata-mpiccolo-9c431ed3-0a48-4448-941d-0a1badecbe03.json", new DateTimeOffset(Convert.ToDateTime("09/02/2021 11:55:34")));

			_blobList.Add("bco-smalldata-mpiccolo-79409a1b-81de-45cb-a372-fedb95a0c8b1.json", new DateTimeOffset(Convert.ToDateTime("29/01/2021 13:53:42")));

			_blobList.Add("bco-smalldata-mpiccolo-c34e0381-ce22-4dbe-89ce-5a47ef193187.json", new DateTimeOffset(Convert.ToDateTime("29/01/2021 13:51:42")));
			_blobList.Add("bco-smalldata-mpiccolo-f2018266-4c7e-4113-be5f-ceb98e10c7e0.json", new DateTimeOffset(Convert.ToDateTime("29/01/2021 13:49:46")));
			_blobList.Add("bco-smalldata-mpiccolo-19da2443-e2ac-4dc4-8b40-4fe8e6df8814.json", new DateTimeOffset(Convert.ToDateTime("29/01/2021 03:42:02")));

			_blobList.Add("bco-scep-mpiccolo-55163a1d-b139-4b08-8f8d-584267f2d9c7.json", new DateTimeOffset(Convert.ToDateTime("24/01/2021 04:01:24")));

			_blobList.Add("bco-scep-mpiccolo-baf5c9f7-4440-4684-a0ed-e43d2f31497e.json", new DateTimeOffset(Convert.ToDateTime("24/01/2021 04:00:25")));
			_blobList.Add("bco-scep-mpiccolo-122c5056-b5d4-4c02-b291-0ae333dbe5a8.json", new DateTimeOffset(Convert.ToDateTime("24/01/2021 03:58:28")));
			_blobList.Add("bco-scep-mpiccolo-33253990-07eb-4f72-b87e-51648697423a.json", new DateTimeOffset(Convert.ToDateTime("18/01/2021 05:59:39")));


			_blobList.Add("bco-scep-mpiccolo-55163a1d-b139-4b08-8f8d-584267f2d9c7.json27/12/202004:01:24", new DateTimeOffset(Convert.ToDateTime("27/12/2020 04:01:24")));

			_blobList.Add("bco-scep-mpiccolo-baf5c9f7-4440-4684-a0ed-e43d2f31497e.json27/12/202004:00:25", new DateTimeOffset(Convert.ToDateTime("27/12/2020 04:00:25")));
			_blobList.Add("bco-scep-mpiccolo-122c5056-b5d4-4c02-b291-0ae333dbe5a8.json27/12/202003:58:28", new DateTimeOffset(Convert.ToDateTime("27/12/2020 03:58:28")));
			_blobList.Add("bco-scep-mpiccolo-33253990-07eb-4f72-b87e-51648697423a.json27/12/202003:59:39", new DateTimeOffset(Convert.ToDateTime("27/12/2020 03:59:39")));

			_blobList = _blobList.OrderByDescending(blob => blob.Value).ToDictionary(b => b.Key, b => b.Value);

			var tobeDeleted = _filterBlobForTimeSeries.GetDeleteListOfOldWeeklyBlobsAsync(_blobList);

			Assert.IsTrue(tobeDeleted.Contains("bco-smalldata-mpiccolo-c34e0381-ce22-4dbe-89ce-5a47ef193187.json"));
			Assert.IsTrue(tobeDeleted.Contains("bco-smalldata-mpiccolo-f2018266-4c7e-4113-be5f-ceb98e10c7e0.json"));
			Assert.IsTrue(tobeDeleted.Contains("bco-smalldata-mpiccolo-19da2443-e2ac-4dc4-8b40-4fe8e6df8814.json"));
			Assert.IsTrue(tobeDeleted.Contains("bco-scep-mpiccolo-baf5c9f7-4440-4684-a0ed-e43d2f31497e.json"));
			Assert.IsTrue(tobeDeleted.Contains("bco-scep-mpiccolo-122c5056-b5d4-4c02-b291-0ae333dbe5a8.json"));
			Assert.IsTrue(tobeDeleted.Contains("bco-scep-mpiccolo-33253990-07eb-4f72-b87e-51648697423a.json"));
			Assert.IsTrue(tobeDeleted.Contains("bco-scep-mpiccolo-baf5c9f7-4440-4684-a0ed-e43d2f31497e.json27/12/202004:00:25"));
			Assert.IsTrue(tobeDeleted.Contains("bco-scep-mpiccolo-122c5056-b5d4-4c02-b291-0ae333dbe5a8.json27/12/202003:58:28"));
			Assert.IsTrue(tobeDeleted.Contains("bco-scep-mpiccolo-33253990-07eb-4f72-b87e-51648697423a.json27/12/202003:59:39"));

			Assert.IsFalse(tobeDeleted.Contains("bco-scep-mpiccolo-55163a1d-b139-4b08-8f8d-584267f2d9c7.json27/12/202004:01:24"));
			Assert.IsFalse(tobeDeleted.Contains("bco-smalldata-mpiccolo-85e24eb0-f703-4505-b64f-184d97233d22.json"));
			Assert.IsFalse(tobeDeleted.Contains("bco-smalldata-mpiccolo-9c431ed3-0a48-4448-941d-0a1badecbe03.json"));
			Assert.IsFalse(tobeDeleted.Contains("bco-smalldata-mpiccolo-79409a1b-81de-45cb-a372-fedb95a0c8b1.json"));
			Assert.IsFalse(tobeDeleted.Contains("bco-scep-mpiccolo-55163a1d-b139-4b08-8f8d-584267f2d9c7.json"));
			

		}

		[TestMethod]
		public void GetDeleteListOfOldDailyBlobsAsync()
		{
			_blobList = new Dictionary<string, DateTimeOffset?>();
			_blobList.Add("bco-smalldata-mpiccolo-85e24eb0-f703-4505-b64f-184d97233d22.json", new DateTimeOffset(Convert.ToDateTime("05/02/2021 13:19:54")));
			_blobList.Add("bco-smalldata-mpiccolo-9c431ed3-0a48-4448-941d-0a1badecbe03.json", new DateTimeOffset(Convert.ToDateTime("09/02/2021 11:55:34")));

			_blobList.Add("bco-smalldata-mpiccolo-79409a1b-81de-45cb-a372-fedb95a0c8b1.json", new DateTimeOffset(Convert.ToDateTime("29/01/2021 13:53:42")));

			_blobList.Add("bco-smalldata-mpiccolo-c34e0381-ce22-4dbe-89ce-5a47ef193187.json", new DateTimeOffset(Convert.ToDateTime("29/01/2021 13:51:42")));
			_blobList.Add("bco-smalldata-mpiccolo-f2018266-4c7e-4113-be5f-ceb98e10c7e0.json", new DateTimeOffset(Convert.ToDateTime("29/01/2021 13:49:46")));
			_blobList.Add("bco-smalldata-mpiccolo-19da2443-e2ac-4dc4-8b40-4fe8e6df8814.json", new DateTimeOffset(Convert.ToDateTime("29/01/2021 03:42:02")));

			_blobList.Add("bco-scep-mpiccolo-55163a1d-b139-4b08-8f8d-584267f2d9c7.json", new DateTimeOffset(Convert.ToDateTime("24/01/2021 04:01:24")));

			_blobList.Add("bco-scep-mpiccolo-baf5c9f7-4440-4684-a0ed-e43d2f31497e.json", new DateTimeOffset(Convert.ToDateTime("24/01/2021 04:00:25")));
			_blobList.Add("bco-scep-mpiccolo-122c5056-b5d4-4c02-b291-0ae333dbe5a8.json", new DateTimeOffset(Convert.ToDateTime("24/01/2021 03:58:28")));
			_blobList.Add("bco-scep-mpiccolo-33253990-07eb-4f72-b87e-51648697423a.json", new DateTimeOffset(Convert.ToDateTime("18/01/2021 05:59:39")));


			_blobList.Add("bco-scep-mpiccolo-55163a1d-b139-4b08-8f8d-584267f2d9c7.json27/12/202004:01:24", new DateTimeOffset(Convert.ToDateTime("27/12/2020 04:01:24")));

			_blobList.Add("bco-scep-mpiccolo-baf5c9f7-4440-4684-a0ed-e43d2f31497e.json27/12/202004:00:25", new DateTimeOffset(Convert.ToDateTime("27/12/2020 04:00:25")));
			_blobList.Add("bco-scep-mpiccolo-122c5056-b5d4-4c02-b291-0ae333dbe5a8.json27/12/202003:58:28", new DateTimeOffset(Convert.ToDateTime("27/12/2020 03:58:28")));
			_blobList.Add("bco-scep-mpiccolo-33253990-07eb-4f72-b87e-51648697423a.json27/12/202003:59:39", new DateTimeOffset(Convert.ToDateTime("27/12/2020 03:59:39")));

			_blobList = _blobList.OrderByDescending(blob => blob.Value).ToDictionary(b => b.Key, b => b.Value);
			var tobeDeleted = _filterBlobForTimeSeries.GetDeleteListOfOldDailyBlobsAsync(_blobList);

			Assert.IsTrue(tobeDeleted.Contains("bco-smalldata-mpiccolo-c34e0381-ce22-4dbe-89ce-5a47ef193187.json"));
			Assert.IsTrue(tobeDeleted.Contains("bco-smalldata-mpiccolo-f2018266-4c7e-4113-be5f-ceb98e10c7e0.json"));
			Assert.IsTrue(tobeDeleted.Contains("bco-smalldata-mpiccolo-19da2443-e2ac-4dc4-8b40-4fe8e6df8814.json"));
			Assert.IsTrue(tobeDeleted.Contains("bco-scep-mpiccolo-baf5c9f7-4440-4684-a0ed-e43d2f31497e.json"));
			Assert.IsTrue(tobeDeleted.Contains("bco-scep-mpiccolo-122c5056-b5d4-4c02-b291-0ae333dbe5a8.json"));
			
			Assert.IsTrue(tobeDeleted.Contains("bco-scep-mpiccolo-baf5c9f7-4440-4684-a0ed-e43d2f31497e.json27/12/202004:00:25"));
			Assert.IsTrue(tobeDeleted.Contains("bco-scep-mpiccolo-122c5056-b5d4-4c02-b291-0ae333dbe5a8.json27/12/202003:58:28"));
			Assert.IsTrue(tobeDeleted.Contains("bco-scep-mpiccolo-33253990-07eb-4f72-b87e-51648697423a.json27/12/202003:59:39"));

			Assert.IsFalse(tobeDeleted.Contains("bco-scep-mpiccolo-33253990-07eb-4f72-b87e-51648697423a.json"));
			Assert.IsFalse(tobeDeleted.Contains("bco-scep-mpiccolo-55163a1d-b139-4b08-8f8d-584267f2d9c7.json27/12/202004:01:24"));
			Assert.IsFalse(tobeDeleted.Contains("bco-smalldata-mpiccolo-85e24eb0-f703-4505-b64f-184d97233d22.json"));
			Assert.IsFalse(tobeDeleted.Contains("bco-smalldata-mpiccolo-9c431ed3-0a48-4448-941d-0a1badecbe03.json"));
			Assert.IsFalse(tobeDeleted.Contains("bco-smalldata-mpiccolo-79409a1b-81de-45cb-a372-fedb95a0c8b1.json"));
			Assert.IsFalse(tobeDeleted.Contains("bco-scep-mpiccolo-55163a1d-b139-4b08-8f8d-584267f2d9c7.json"));


		}
	}
}
