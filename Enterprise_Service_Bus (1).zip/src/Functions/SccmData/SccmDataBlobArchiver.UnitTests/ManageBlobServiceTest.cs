﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using SccmDataBlobArchiver;
using SccmDataBlobArchiverTests.UnitTests;

namespace SccmDataBlobArchiverTests.UnitTests
{ 
	[TestClass]
	public class ManageBlobServiceTest
	{

		IBlobServiceClientAuthenticatedConnectionGenerator BlobServiceClientAuthenticatedConnectionGenerator;
		IManageBlobService manageBlobService;
		Mock<IFilterSelector> _mockFilterSelector;
		IConfiguration _config;
		Mock<ILogger<ManageBlobService>> _logger;
		Mock<ILogger<SccmDataBlobArchiver.SccmDataBlobArchiver>> _sdbaLogger;
		
		public ManageBlobServiceTest()
		{
			_config = TestHelper.GetIConfigurationRoot(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));

			_sdbaLogger = new Mock<ILogger<SccmDataBlobArchiver.SccmDataBlobArchiver>>();
			BlobServiceClientAuthenticatedConnectionGenerator = new BlobServiceClientAuthenticatedConnectionGenerator(_config, _sdbaLogger.Object);

			_mockFilterSelector = new Mock<IFilterSelector>();
			_logger = new Mock<ILogger<ManageBlobService>>();
			manageBlobService = new ManageBlobService(BlobServiceClientAuthenticatedConnectionGenerator, _mockFilterSelector.Object, _config, _logger.Object);
		}

		[TestMethod]
		public void ShouldGetBlobContainers()
		{
			var containers = manageBlobService.GetBlobContainersAsync();
			Assert.IsTrue(containers.Count > 0);
		}

		[TestMethod]
		public void ShouldGetBlobsForContainers()
		{
			var listofBlobs = manageBlobService.GetBlobsAsync();
			Assert.IsTrue(listofBlobs.Count > 0);
		}

		[TestMethod]
		public void ShouldDeleteBlobsForContainers()
		{
			var listofBlobs = manageBlobService.GetBlobsAsync();
			var listtoDelete = new List<string>();
			listtoDelete.Add(listofBlobs.Keys.ToList().Last());
			_mockFilterSelector.Setup(mock => mock.SelectFilter(listofBlobs)).Returns(listtoDelete);
			var deleteStatus = manageBlobService.DeleteListOfOldBlobsAsync();
			Assert.IsTrue(deleteStatus);
		}
	}
}
