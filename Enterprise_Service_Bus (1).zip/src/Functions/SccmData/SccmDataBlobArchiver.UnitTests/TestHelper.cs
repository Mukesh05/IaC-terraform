﻿using Microsoft.Extensions.Configuration;

namespace SccmDataBlobArchiverTests.UnitTests
{
	public static class TestHelper
	{
		public static IConfigurationRoot GetIConfigurationRoot(string outputPath)
		{

			return new ConfigurationBuilder()
				.SetBasePath(outputPath)
				.AddJsonFile("local.settings.json", optional: true)
				.AddEnvironmentVariables()
				.Build();
		}
	}
}
