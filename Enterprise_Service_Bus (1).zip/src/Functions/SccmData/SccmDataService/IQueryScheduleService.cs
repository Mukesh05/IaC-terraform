﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace SccmDataService
{
	public interface IQueryScheduleService
	{
		Task<List<QuerySchedule>> GetQueryScheduleAsync(string clientCode, string sccmServer);

		Task<string> RequestSasUriAsync(string clientCode, string sccmServer);

		Task UpdateQueryScheduleStatusAsync(string clientCode, string sccmServer, string queryName, string queryResult, int rowCount);
	}
}
