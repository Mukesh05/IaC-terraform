﻿using Microsoft.ApplicationInsights.Channel;
using Microsoft.ApplicationInsights.Extensibility;

namespace SccmDataService
{
	public class CustomTelemetryInitializer : ITelemetryInitializer
	{
		string _clientCode;
		string _sccmServer;

		public CustomTelemetryInitializer(string clientCode, string sccmServer)
		{
			_clientCode = clientCode;
			_sccmServer = sccmServer;
		}

		public void Initialize(ITelemetry telemetry)
		{
			telemetry.Context.Cloud.RoleName = $"SccmDataService_{_clientCode}";
			telemetry.Context.GlobalProperties.Add("ClientCode", _clientCode);
			telemetry.Context.GlobalProperties.Add("SccmServer", _sccmServer);
		}
	}
}
