﻿using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Text.Json;
using System.Collections.Generic;
using System.Text;

namespace SccmDataService
{
	public class QueryScheduleService : IQueryScheduleService
	{
		readonly IConfig _config;
		readonly HttpClient _httpClient;
				
		public QueryScheduleService(IConfig config, HttpClient httpClient)
		{
			_config = config;
			_httpClient = httpClient;
		}

		/// <summary>
		/// Return the query schedule from query schedule api endpoint.
		/// </summary>
		/// <returns></returns>
		public async Task<List<QuerySchedule>> GetQueryScheduleAsync(string clientCode, string sccmServer)
		{
			string uri = $"{_httpClient.BaseAddress}/schedule/query/runnable/{clientCode}/{sccmServer}?subscription-key={_config.Key}";
			
			_httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
			var json = await _httpClient.GetStringAsync(uri);

			var jsonDoc = JsonDocument.Parse(json);
			var querySchedules = jsonDoc.RootElement.GetProperty("result").EnumerateArray();

			List<QuerySchedule> scheduleList = new List<QuerySchedule>();

			foreach(var schedule in querySchedules)
			{
				var x = JsonSerializer.Deserialize<QuerySchedule>(schedule.GetRawText(), new JsonSerializerOptions()
				{
					PropertyNameCaseInsensitive = true
				});
				
				scheduleList.Add(x);
			}

			return scheduleList;
		}

		/// <summary>
		/// Get a SAS to write to blob
		/// </summary>
		/// <param name="clientCode"></param>
		/// <param name="sccmServer"></param>
		/// <returns></returns>
		public async Task<string> RequestSasUriAsync(string clientCode, string sccmServer)
		{
			//The sasuri is only valid for the clientcode and is write only.
			string uri = $"{_httpClient.BaseAddress}/schedule/{clientCode}/{sccmServer}/requestsas?subscription-key={_config.Key}";

			_httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
			var json = await _httpClient.GetStringAsync(uri);

			//The result property contains sas uri.
			var jsonDoc = JsonDocument.Parse(json);
			var result = jsonDoc.RootElement.GetProperty("result");
			var sas = result.GetString();
			
			return sas;
		}

		public async Task UpdateQueryScheduleStatusAsync(string clientCode, string sccmServer, string queryName, string queryResult, int rowCount)
		{
			string uri = $"{_httpClient.BaseAddress}/schedule/{clientCode}/{sccmServer}/{queryName}/updatestatus?subscription-key={_config.Key}";

			//Create payload to pass along.
			var payload = new
			{
				lastQueryRowCount = rowCount,
				lastQueryResult = queryResult
			};
			var json = JsonSerializer.Serialize<object>(payload);

			var content = new StringContent(json, Encoding.UTF8, "application/json");
			await _httpClient.PostAsync(uri, content);
		}
	}
}
