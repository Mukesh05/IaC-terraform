﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SccmDataService
{
	public interface ISccmDbQueryService
	{
		Task<IEnumerable<dynamic>> RunQueryAsync(string rawSql);
	}
}
