﻿
namespace SccmDataService
{
	partial class ProjectInstaller
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.SccmDataServiceProcessInstaller = new System.ServiceProcess.ServiceProcessInstaller();
            this.SccmDataServiceInstaller = new System.ServiceProcess.ServiceInstaller();
            // 
            // SccmDataServiceProcessInstaller
            // 
            this.SccmDataServiceProcessInstaller.Password = null;
            this.SccmDataServiceProcessInstaller.Username = null;
            // 
            // SccmDataServiceInstaller
            // 
            this.SccmDataServiceInstaller.DelayedAutoStart = true;
            this.SccmDataServiceInstaller.DisplayName = "SccmDataService";
            this.SccmDataServiceInstaller.ServiceName = "SccmDataService";
            this.SccmDataServiceInstaller.StartType = System.ServiceProcess.ServiceStartMode.Automatic;
            // 
            // ProjectInstaller
            // 
            this.Installers.AddRange(new System.Configuration.Install.Installer[] {
            this.SccmDataServiceProcessInstaller,
            this.SccmDataServiceInstaller});

		}

		#endregion

		private System.ServiceProcess.ServiceProcessInstaller SccmDataServiceProcessInstaller;
		private System.ServiceProcess.ServiceInstaller SccmDataServiceInstaller;
	}
}