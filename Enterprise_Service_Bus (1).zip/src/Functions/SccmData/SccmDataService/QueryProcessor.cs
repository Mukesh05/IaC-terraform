﻿using System;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace SccmDataService
{
	public class QueryProcessor : IQueryProcessor
	{
		IConfig _config;
		ILogger _logger;
		IQueryScheduleService _queryScheduleService;
		ISccmDbQueryService _sccmDbQueryService;
		IQueryResultService _queryResultService;

		public QueryProcessor(IConfig config,
							  ILogger<QueryProcessor> logger,
							  IQueryScheduleService queryScheduleService,
							  ISccmDbQueryService sccmDbQueryService,
							  IQueryResultService queryResultService)
		{
			_config = config;
			_logger = logger;
			_queryScheduleService = queryScheduleService;
			_sccmDbQueryService = sccmDbQueryService;
			_queryResultService = queryResultService;
		}

		/// <summary>
		/// The main entry point to start processing the scheduled queries.
		/// </summary>
		/// <returns></returns>
		public async Task RunAsync()
		{
			_logger.LogInformation("Query processor started.");

			var schedules = await _queryScheduleService.GetQueryScheduleAsync(_config.ClientCode, _config.HostName);
			_logger.LogInformation($"{schedules.Count} query schedules retreived.");
			
			var sasUri = await _queryScheduleService.RequestSasUriAsync(_config.ClientCode, _config.HostName);

			foreach (var schedule in schedules)
			{
				try
				{
					_logger.LogInformation($"Processing query schedule {schedule.Name} for {schedule.ClientCode}/{schedule.SccmServer}");

					//Execute the requested query
					var result = await _sccmDbQueryService.RunQueryAsync(schedule.Query);
					_logger.LogInformation($"Retrevied query results. {result.Count()} rows returned.");

					//Convert results to a JSON string for storage
					var json = JsonSerializer.Serialize<dynamic>(new { query = schedule.Query, data = result });

					//Create a unqiue name with details. Guid is to keep blob name unique.
					string blobName = $"{_config.ClientCode}-{schedule.Name}-{_config.HostName}-{Guid.NewGuid()}.json".ToLower();

					//Upload the results to the blob container specified in the 
					await _queryResultService.UploadQueryResultAsync(sasUri, blobName, json);

					//Send status of query result
					await _queryScheduleService.UpdateQueryScheduleStatusAsync(schedule.ClientCode,
																			   schedule.SccmServer,
																			   schedule.Name,
																			   $"Successfully processed query at {DateTime.UtcNow}.",
																			   result.Count());

					_logger.LogInformation($"Completed uploading query {schedule.Name} to blob {blobName} for {schedule.ClientCode}/{schedule.SccmServer}.");
				}
				catch(Exception ex)
				{
					//Send status of query result
					await _queryScheduleService.UpdateQueryScheduleStatusAsync(schedule.ClientCode,
																			   schedule.SccmServer,
																			   schedule.Name,
																			   $"Failed to process query at {DateTime.UtcNow}. --> {ex.ToString()}",
																			   -1);

					_logger.LogError($"Error processing query {schedule.Name} for {schedule.ClientCode}/{schedule.SccmServer}.\n{ex.ToString()}");
				}
			}

			_logger.LogInformation("Query processor completed.");
		}
	}
}
