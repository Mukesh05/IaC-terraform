﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace SccmDataService
{
	public interface IConfig
	{
		int PollRate { get; set; }
		string ClientCode { get; set; }
		string Key { get; set; }
		string BaseUrl { get; set; }
		string InstrumentationKey { get; set; }
		string HostName { get; set; }
		string SccmDbConnectionString { get; set; }
		int QueryTimeout { get; set; }
	}

	public class Config : IConfig
	{
		public int PollRate { get; set; }
		public string ClientCode { get; set; }
		public string Key { get; set; }
		public string BaseUrl { get; set; }
		public string InstrumentationKey { get; set; }
		public string HostName { get; set; }
		public string SccmDbConnectionString { get; set; }
		public int QueryTimeout { get; set; }

		static public IConfig Build()
		{
			Config config = new Config();

			var pollRate = ConfigurationManager.AppSettings["PollRateInSeconds"];
			config.PollRate = pollRate == null ? 300 : int.Parse(pollRate);

			config.ClientCode = ConfigurationManager.AppSettings["ClientCode"];

			config.Key = ConfigurationManager.AppSettings["Key"];

			config.BaseUrl = ConfigurationManager.AppSettings["BaseUrl"];

			config.InstrumentationKey = ConfigurationManager.AppSettings["InstrumentationKey"];

			config.QueryTimeout = int.Parse(ConfigurationManager.AppSettings["QueryTimeoutInSeconds"]);

			var hostName = Dns.GetHostName();
			if(string.IsNullOrWhiteSpace(hostName))
			{
				hostName = Environment.MachineName;
			}

			config.HostName = hostName;

			config.SccmDbConnectionString = ConfigurationManager.ConnectionStrings["SccmDb"].ConnectionString;

			return config;
		}

	}
}
