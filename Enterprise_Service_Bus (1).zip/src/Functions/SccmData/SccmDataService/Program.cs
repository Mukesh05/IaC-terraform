﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.ServiceProcess;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace SccmDataService
{
	static class Program
    {
		private static List<ServiceBase> _servicesToRun = new List<ServiceBase>();

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		static void Main()
		{
			//Run service.
			try
			{
				//Setup dependency injection service provider.
				var serviceProvider = BuildServiceProvider();

				_servicesToRun.Add(new SccmDataService(serviceProvider));

				if (Environment.UserInteractive)
				{
					RunInteractive(_servicesToRun.ToArray());
				}
				else
				{
					ServiceBase.Run(_servicesToRun.ToArray());
				}
			}
			catch (Exception ex)
			{
				EventLog.WriteEntry("SccmDataService", ex.ToString(), EventLogEntryType.Error);
				Console.WriteLine(ex.ToString());
			}
		}

		/// <summary>
		/// Setup service provider.
		/// </summary>
		/// <returns></returns>
		public static ServiceProvider BuildServiceProvider()
		{
			//Get config
			IConfig config = Config.Build();

			var serviceCollection = new ServiceCollection();
			serviceCollection.AddSingleton<IConfig>((service) =>
			{
				return config;
			});

			//Configure logging. Console, App insights
			serviceCollection.AddLogging((service) =>
			{
				service.AddConsole();
				service.AddApplicationInsights(config.InstrumentationKey);
				service.AddFilter(null, LogLevel.Information);
				service.AddFilter("System.Net.Http.HttpClient.IQueryScheduleService.ClientHandler", LogLevel.Warning);
				service.AddFilter("System.Net.Http.HttpClient.IQueryScheduleService.LogicalHandler", LogLevel.Warning);
				service.AddFilter("Microsoft.Extensions.Logging.ApplicationInsights.ApplicationInsightsLoggerProvider", LogLevel.Warning);
			});

			//Customize how data is presented in App Insights
			serviceCollection.Configure<TelemetryConfiguration>((conf) =>
			{
				conf.TelemetryInitializers.Add(new CustomTelemetryInitializer(config.ClientCode, config.HostName));
			});

			serviceCollection.AddSingleton<IQueryProcessor, QueryProcessor>();

			serviceCollection.AddHttpClient<IQueryScheduleService, QueryScheduleService>(client =>
			{
				client.BaseAddress = new Uri(config.BaseUrl);
			});

			serviceCollection.AddSingleton<ISccmDbQueryService, SccmDbQueryService>();

			serviceCollection.AddSingleton<IQueryResultService, QueryResultService>();

			var serviceProvider = serviceCollection.BuildServiceProvider();

			return serviceProvider;
		}

		/// <summary>
		/// Allow the service to run interactivly for local testing and debugging.
		/// </summary>
		/// <param name="servicesToRun"></param>
		public static void RunInteractive(ServiceBase[] servicesToRun)
		{
			//Start service or services up.
			var onStartMethod = typeof(ServiceBase).GetMethod("OnStart", BindingFlags.Instance | BindingFlags.NonPublic);

			foreach (ServiceBase service in servicesToRun)
			{
				Console.WriteLine("Starting {0} ...", service.ServiceName);

				onStartMethod.Invoke(service, new object[] { new string[] { } });

				Console.WriteLine("Service {0} started.", service.ServiceName);
			}

			//Wait for user to cancel (stop) service or services.
			Console.WriteLine("Press 'Enter' to stop service or services.");
			Console.WriteLine("Running ...");
			Console.ReadKey();
			Console.WriteLine();

			//Stop service or services.
			var onStopMethod = typeof(ServiceBase).GetMethod("OnStop", BindingFlags.Instance | BindingFlags.NonPublic);

			foreach (ServiceBase service in servicesToRun)
			{
				Console.WriteLine("Stoping {0} ...", service.ServiceName);
				onStopMethod.Invoke(service, null);
				Console.WriteLine("Service {0} Stopped.", service.ServiceName);
			}
		}
	}
}