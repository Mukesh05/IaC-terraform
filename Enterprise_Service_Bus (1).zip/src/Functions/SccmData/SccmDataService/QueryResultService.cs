﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure;
using Azure.Storage;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace SccmDataService
{
	public class QueryResultService : IQueryResultService
	{
		IConfig _config;

		public QueryResultService(IConfig config)
		{
			_config = config;
		}

		/// <summary>
		/// Upload data to blob. Access and where to upload depends on
		/// the SasUri.
		/// </summary>
		/// <param name="sasUri"></param>
		/// <param name="name"></param>
		/// <param name="data"></param>
		/// <returns></returns>
		public async Task UploadQueryResultAsync(string sasUri, string name, string data)
		{
			//Split sas uri parts. Sasuri contains uri and signature.
			var parsedSasUri = sasUri.Split('?');
			Uri uri = new Uri(parsedSasUri[0]);
			var sas = $"?{parsedSasUri[1]}";

			BlobContainerClient blobContainer = new BlobContainerClient(uri, new AzureSasCredential(sas));

			var content = Encoding.UTF8.GetBytes(data);
			BlobContentInfo blobInfo;
			using (var ms = new MemoryStream(content))
			{
				BlobClient blobClient = blobContainer.GetBlobClient(name);
				blobInfo = await blobClient.UploadAsync(ms);
			}
		}
	}
}
