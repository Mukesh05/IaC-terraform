﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text.Json;
using System.Threading.Tasks;
using Azure.Core;
using Azure.Identity;
using Dapper;

namespace SccmDataService
{
	public class SccmDbQueryService : ISccmDbQueryService
	{
		IConfig _config;

		public SccmDbQueryService(IConfig config)
		{
			_config = config;
		}

		/// <summary>
		/// Basic method to call raw Sql using dapper.
		/// </summary>
		/// <param name="rawSql"></param>
		/// <returns></returns>
		public async Task<IEnumerable<dynamic>> RunQueryAsync(string rawSql)
		{
			SqlConnection connection;
			if (Environment.UserInteractive)
			{
				// In this case we are locally debugging.
				// Also we dont have access to SCCM servers from local.
				// So we just connect to CMP db for development purposes.
				// Hence use the VisualStudio identity to connect to SQL.
				
				connection = new SqlConnection(_config.SccmDbConnectionString)
				{
					AccessToken = await GetAzureSqlAccessTokenAsync()
				};
			}
			else
			{
				// Connect to SCCM database.

				connection = new SqlConnection(_config.SccmDbConnectionString);
			}

			var results = await connection.QueryAsync<dynamic>(rawSql, commandTimeout: _config.QueryTimeout, commandType: CommandType.Text); //todo: set timeout in config or download as part of query schedule

			return results;
		}

		/// <summary>
		/// Get token to be able to call an Azure Sql database using your credentials.
		/// Make sure Visual Studio is logged in as you and you have access to dadtabase being connected to.
		/// </summary>
		/// <returns></returns>
		private async Task<string> GetAzureSqlAccessTokenAsync()
		{
			var tokenRequestContext = new TokenRequestContext(new[] { "https://database.windows.net//.default" });
			var tokenRequestResult = await new DefaultAzureCredential().GetTokenAsync(tokenRequestContext);

			return tokenRequestResult.Token;
		}
	}
}
