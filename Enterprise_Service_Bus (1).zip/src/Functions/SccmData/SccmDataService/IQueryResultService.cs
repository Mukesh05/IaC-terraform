﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SccmDataService
{
	public interface IQueryResultService
	{
		Task UploadQueryResultAsync(string sas, string name, string data);
	}
}
