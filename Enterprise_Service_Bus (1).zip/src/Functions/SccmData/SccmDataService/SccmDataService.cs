﻿using System;
using System.Diagnostics;
using System.ServiceProcess;
using System.Threading;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.ApplicationInsights;

namespace SccmDataService
{
	public partial class SccmDataService : ServiceBase
    {
		private static int StartDelay = Environment.UserInteractive ? 5000 : 1000; //Help with testing.
		Timer _timer;

		ServiceProvider _serviceProvider;
		ILogger _logger;
		IConfig _config;

		public SccmDataService(ServiceProvider serviceProvider)
        {
			_serviceProvider = serviceProvider;
			_logger = _serviceProvider.GetRequiredService<ILogger<ApplicationInsightsLoggerProvider>>();
			_config = _serviceProvider.GetRequiredService<IConfig>();
			
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
			_logger.LogInformation("SccmData service has started.");

			_timer = new Timer(async (object x) =>
			{
				try
				{
					//var processor = new QueryProcessor(config);
					IQueryProcessor processor = _serviceProvider.GetService<IQueryProcessor>();
					await processor.RunAsync();
				}
				catch (Exception ex)
				{
					var error = $"SccmDataService Error:{Environment.NewLine}{ex.ToString()}";
					EventLog.WriteEntry("SccmDataService", error, EventLogEntryType.Error);
					_logger.LogError(error);
				}
			});

			_timer.Change(StartDelay, _config.PollRate * 1000);

			EventLog.WriteEntry("SccmDataService", "SccmDataService OnStart completed.", EventLogEntryType.Information);
		}

        protected override void OnStop()
        {
			_logger.LogInformation("SccmData service has stopped.");

			if (_timer != null)
			{
				try
				{
					_timer.Change(Timeout.Infinite, Timeout.Infinite);
				}
				catch { }

				try
				{
					_timer.Dispose();
				}
				catch { }
			}

			if(_serviceProvider is IDisposable)
			{
				((IDisposable)_serviceProvider).Dispose();
			}

			EventLog.WriteEntry("SccmDataService", "SccmDataService OnStop completed.", EventLogEntryType.Information);
		}
    }
}
