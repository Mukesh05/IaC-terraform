﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SccmData.QueryResultRepository
{
	public class QueryResultDetails
	{
		public string Name { get; set; }
		public string ContainerName { get; set; }
		public DateTime? CreatedOn { get; set; }
		public DateTime? LastModified { get; set; }
	}
}
