﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Azure.Storage.Sas;
using Newtonsoft.Json;

namespace SccmData.QueryResultRepository
{
	public class AzureStorageQueryResultRepository : IQueryResultRepository
	{
		string _connectionString;

		public AzureStorageQueryResultRepository(string connectionString)
		{
			_connectionString = connectionString;
		}

		/// <summary>
		/// Delete a query result blob.
		/// </summary>
		/// <param name="clientCode"></param>
		/// <param name="name"></param>
		/// <returns></returns>
		public async Task<bool> DeleteQueryResult(string clientCode, string name)
		{
			BlobContainerClient blobContainer;
			blobContainer = new BlobContainerClient(_connectionString, clientCode);

			var result = await blobContainer.DeleteBlobIfExistsAsync(name);

			return result.Value;
		}

		/// <summary>
		/// Delete a query result blob.
		/// </summary>
		/// <param name="clientCode"></param>
		/// <param name="name"></param>
		/// <returns></returns>
		public async Task<QueryResult> GetQueryResultAsync(string clientCode, string name)
		{
			QueryResult queryResult = null;

			var blobContainer = new BlobContainerClient(_connectionString, clientCode);
			var blobClient = blobContainer.GetBlobClient(name);

			using (var stream = new StreamReader(await blobClient.OpenReadAsync()))
			{
				using(var jsonReader = new JsonTextReader(stream))
				{
					var jsonSerializer = new JsonSerializer();
					queryResult = jsonSerializer.Deserialize<QueryResult>(jsonReader);
				}
			}

			return queryResult;
		}

		/// <summary>
		/// Upload a query result blob.
		/// </summary>
		/// <param name="clientCode"></param>
		/// <param name="name"></param>
		/// <param name="data"></param>
		/// <returns></returns>
		public async Task UploadQueryResult(string clientCode, string name, string data)
		{
			var blobContainer = new BlobContainerClient(_connectionString, clientCode);
			var result = await blobContainer.CreateIfNotExistsAsync();
			
			var content = Encoding.UTF8.GetBytes(data);

			BlobContentInfo blobInfo;
			using (var ms = new MemoryStream(content))
			{
				BlobClient blobClient = blobContainer.GetBlobClient(name);
				blobInfo = await blobClient.UploadAsync(ms);
			}
		}

		/// <summary>
		/// List query result blob names.
		/// </summary>
		/// <param name="clientCode"></param>
		/// <returns></returns>
		public async Task<List<string>> ListQueryResultNamesAsync(string clientCode)
		{
			List<string> blobNames = new List<string>();

			var blobContainer = new BlobContainerClient(_connectionString, clientCode);
			await foreach(BlobItem blob in blobContainer.GetBlobsAsync())
			{
				blobNames.Add(blob.Name);
			}

			return blobNames;
		}

		/// <summary>
		/// Get SAS to allow upload of query results. This will allow
		/// client to get a token to only allow a limit window to write to
		/// the specified container (clientCode)
		/// </summary>
		/// <param name="clientCode"></param>
		/// <param name="sccmServer"></param>
		/// <returns></returns>
		public Uri GetSasForContainer(string clientCode, string sccmServer, int expireTime = 30 /*minutes default*/)
		{
			var blobContainer = new BlobContainerClient(_connectionString, clientCode.ToLower());

			if (blobContainer.CanGenerateSasUri)
			{
				BlobSasBuilder sasBuilder = new BlobSasBuilder()
				{
					BlobContainerName = clientCode.ToLower(),
					Resource = "c" //shared resource is a blob container
				};

				sasBuilder.ExpiresOn = DateTimeOffset.UtcNow.AddMinutes(expireTime); //ToDo: Set this to a configurable value
				sasBuilder.SetPermissions(BlobContainerSasPermissions.Write | BlobContainerSasPermissions.Add); //only allow access to write
				sasBuilder.Protocol = SasProtocol.Https;

				Uri sasUri = blobContainer.GenerateSasUri(sasBuilder);
				return sasUri;
			}
			else
			{
				throw new Exception("Blob container is not authorized to create a service SAS.");
			}
		}

		/// <summary>
		/// Get a list of container names in the storage account
		/// </summary>
		/// <returns></returns>
		public async Task<IEnumerable<string>> ListContainersAsync()
		{
			List<string> containerNames = new List<string>();

			BlobServiceClient client = new BlobServiceClient(_connectionString);
			await foreach (var item in client.GetBlobContainersAsync())
			{
				containerNames.Add(item.Name);
			}

			return containerNames;
		}

		/// <summary>
		/// Get detailed list of query results.
		/// </summary>
		/// <param name="clientCode"></param>
		/// <param name="queryName"></param>
		/// <returns></returns>
		public async Task<IEnumerable<QueryResultDetails>> GetQueryResultDetailsAsync(string clientCode, string queryName = null)
		{
			List<QueryResultDetails> details = new List<QueryResultDetails>();

			string prefix = string.Empty;
			if(queryName != null)
			{
				prefix = $"{clientCode}-{queryName}";
			}

			var blobContainer = new BlobContainerClient(_connectionString, clientCode);
			await foreach (BlobItem blob in blobContainer.GetBlobsAsync(prefix:prefix))
			{
				details.Add(new QueryResultDetails()
				{
					Name = blob.Name,
					ContainerName = clientCode,
					CreatedOn = blob.Properties.CreatedOn.HasValue ? (DateTime?)blob.Properties.CreatedOn.Value.UtcDateTime : null,
					LastModified = blob.Properties.CreatedOn.HasValue ? (DateTime?)blob.Properties.LastModified.Value.UtcDateTime : DateTime.MinValue
				});
			}

			return details;
		}
	}
}
