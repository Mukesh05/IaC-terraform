﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace SccmData.QueryScheduleRepository
{
	public interface IQueryScheduleRepository
	{
		QuerySchedule Get(string clientCode, string sccmServer, string queryName);
		Task<int> InsertAsync(QuerySchedule querySchedule);
		Task<int> DeleteAsync(QuerySchedule querySchedule);
		IEnumerable<QuerySchedule> List(string clientCode);
		Task<IEnumerable<string>> ListClientCodesAsync();
	}
}
