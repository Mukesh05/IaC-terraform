﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace SccmData.QueryResultRepository
{
	public interface IQueryResultRepository
	{
		/// <summary>
		/// This method is to upload to data to a blob in storage.
		/// </summary>
		/// <param name="clientCode">Name of the container</param>
		/// <param name="name"></param>
		/// <param name="data"></param>
		/// <returns></returns>
		Task UploadQueryResult(string clientCode, string name, string data);

		/// <summary>
		/// This method will return a QueryResult that contains the query and the data for the query.
		/// </summary>
		/// <param name="clientCode">Name of the container</param>
		/// <param name="name"></param>
		/// <returns></returns>
		Task<QueryResult> GetQueryResultAsync(string clientCode, string name);

		/// <summary>
		/// This methed will return a list of query result blob names that contain all the available query results.
		/// </summary>
		/// <param name="clientCode">Name of the container</param>
		/// <returns></returns>
		Task<List<string>> ListQueryResultNamesAsync(string clientCode);

		/// <summary>
		/// This method will delete the named blob for the specific client.
		/// </summary>
		/// <param name="clientCode">Name of the container</param>
		/// <param name="name"></param>
		/// <returns></returns>
		Task<bool> DeleteQueryResult(string clientCode, string name);

		/// <summary>
		/// This method returns a write only URI that is used to upload data to a blob in the storage account.
		/// </summary>
		/// <param name="clientCode">Name of the container</param>
		/// <param name="sccmServer"></param>
		/// <param name="expireTime"></param>
		/// <returns></returns>
		Uri GetSasForContainer(string clientCode, string sccmServer, int expireTime = 30);

		/// <summary>
		/// This method will return a list of all the available containers in the storage account.
		/// </summary>
		/// <returns></returns>
		Task<IEnumerable<string>> ListContainersAsync();

		/// <summary>
		/// This method will return detailed info of query result blobs.
		/// </summary>
		/// <param name="clientCode"></param>
		/// <returns></returns>
		Task<IEnumerable<QueryResultDetails>> GetQueryResultDetailsAsync(string clientCode, string queryName = null);
	}
}
