﻿using Microsoft.Azure.Cosmos.Table;

namespace SccmData.QueryScheduleRepository
{
	public class QuerySchedule : TableEntity
	{
		string _clientCode, _sccmServer, _name;

		public string ClientCode { get { return _clientCode; } set { _clientCode = value.ToLower(); } }
		public string SccmServer { get { return _sccmServer; } set { _sccmServer = value.ToLower(); } }
		public string Name { get { return _name; } set { _name = value.ToLower(); } }
		public string Schedule { get; set; }
		public string Query { get; set; }
		public int LastQueryRowCount { get; set; }
		public string LastQueryResult { get; set; }
	}
}