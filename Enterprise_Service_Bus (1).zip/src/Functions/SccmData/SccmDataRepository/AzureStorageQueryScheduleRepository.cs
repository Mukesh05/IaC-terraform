﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Azure.Cosmos.Table;

namespace SccmData.QueryScheduleRepository
{
	public class AzureStorageQueryScheduleRepository : IQueryScheduleRepository
	{
		readonly string _tableName = "QuerySchedule";
		string _storageConnString;
		CloudTable _cloudTable;
		
		public AzureStorageQueryScheduleRepository(string storageConnString)
		{
			_storageConnString = storageConnString;
			CloudStorageAccount storageAccount = CloudStorageAccount.Parse(_storageConnString);
			CloudTableClient tableClient = storageAccount.CreateCloudTableClient(new TableClientConfiguration());
			_cloudTable = tableClient.GetTableReference(_tableName);
		}

		/// <summary>
		/// Return a query schedule.
		/// </summary>
		/// <param name="clientCode"></param>
		/// <param name="sccmServer"></param>
		/// <param name="queryName"></param>
		/// <returns></returns>
		public QuerySchedule Get(string clientCode, string sccmServer, string queryName)
		{
			//Make sure row key is always lower case.
			var rowKey = $"{clientCode}{sccmServer}{queryName}".ToLower();

			var filter = TableQuery.CombineFilters(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, _tableName),
												   TableOperators.And,
												   TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, rowKey));

			try
			{ 
				TableQuery<QuerySchedule> query = new TableQuery<QuerySchedule>();
				var tableQuery = query.Where(filter);

				var result = _cloudTable.ExecuteQuery(tableQuery);
				return result.FirstOrDefault();
			}
			catch (StorageException ex)
			{
				throw new Exception($"Storage exception. {ex.Message}, { ex.RequestInformation.ExtendedErrorInformation.ErrorMessage}");
			}
		}

		/// <summary>
		/// Insert a new query schedule.
		/// </summary>
		/// <param name="querySchedule"></param>
		/// <returns></returns>
		public async Task<int> InsertAsync(QuerySchedule querySchedule)
		{
			if(string.IsNullOrEmpty(querySchedule.ClientCode) || string.IsNullOrEmpty(querySchedule.SccmServer) || string.IsNullOrEmpty(querySchedule.Name))
			{
				throw new ArgumentException("ClientCode or SccmServer or Name not set. Verify query object is valid.");
			}

			//Save row key as lower case so get() method will return expected result no matter the case.
			var rowKey = $"{querySchedule.ClientCode}{querySchedule.SccmServer}{querySchedule.Name}".ToLower();

			querySchedule.PartitionKey = _tableName;
			querySchedule.RowKey = rowKey;

			try
			{
				var operation = TableOperation.InsertOrMerge(querySchedule);
				await _cloudTable.CreateIfNotExistsAsync();
				var result = await _cloudTable.ExecuteAsync(operation);

				return result.HttpStatusCode;
			}
			catch (StorageException ex)
			{
				throw new Exception($"Storage exception. {ex.Message}, { ex.RequestInformation.ExtendedErrorInformation.ErrorMessage}");
			}
		}

		/// <summary>
		/// Delete a query schedule.
		/// </summary>
		/// <param name="querySchedule"></param>
		/// <returns></returns>
		public async Task<int> DeleteAsync(QuerySchedule querySchedule)
		{
			try
			{
				//Get the result that contains the eTag so we can delete.
				var queryScheduleWithEtag = Get(querySchedule.ClientCode, querySchedule.SccmServer, querySchedule.Name);

				//Delete query schedule. The should only be one combination with clientcode/sccmserver/name
				var operation = TableOperation.Delete(queryScheduleWithEtag);
				var result = await _cloudTable.ExecuteAsync(operation);

				return result.HttpStatusCode;
			}
			catch(StorageException ex)
			{
				throw new Exception($"Storage exception. {ex.Message}, { ex.RequestInformation.ExtendedErrorInformation.ErrorMessage}");
			}
		}

		/// <summary>
		/// Return a list of query schedules by the client code.
		/// </summary>
		/// <param name="clientCode"></param>
		/// <returns></returns>
		public IEnumerable<QuerySchedule> List(string clientCode)
		{
			if (string.IsNullOrEmpty(clientCode))
			{
				throw new ArgumentException("clientCode is null or empty");
			}

			var filter = TableQuery.CombineFilters(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, _tableName),
												   TableOperators.And,
												   TableQuery.GenerateFilterCondition("ClientCode", QueryComparisons.Equal, $"{clientCode.ToLower()}"));

			try
			{
				TableQuery<QuerySchedule> query = new TableQuery<QuerySchedule>();
				var tableQuery = query.Where(filter);
				var result = _cloudTable.ExecuteQuery(tableQuery);

				return result;
			}
			catch(StorageException ex)
			{
				throw new Exception($"Storage exception. {ex.Message}, { ex.RequestInformation.ExtendedErrorInformation.ErrorMessage}");
			}
		}

		/// <summary>
		/// Return a list of distinct client codes from the table.
		/// </summary>
		/// <returns></returns>
		public async Task<IEnumerable<string>> ListClientCodesAsync()
		{
			TableContinuationToken tableContinuationToken = null;

			var list = new List<QuerySchedule>();

			do
			{
				var query = new TableQuery<QuerySchedule>();
				var result = await _cloudTable.ExecuteQuerySegmentedAsync<QuerySchedule>(query, tableContinuationToken);
				list.AddRange(result);

			} while (tableContinuationToken != null);

			var clientCodes = list.GroupBy(x => x.ClientCode)
								  .Select(x => x.First())
								  .Select(x => x.ClientCode)
								  .ToList();
			return clientCodes;
		}
	}
}
