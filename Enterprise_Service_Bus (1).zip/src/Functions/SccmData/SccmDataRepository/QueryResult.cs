﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace SccmData.QueryResultRepository
{
	public class QueryResult
	{
		[JsonProperty("query")]
		public string Query { get; set; }
		[JsonProperty("data")]
		public JArray Data { get; set; }
	}
}
