﻿using System;
using System.Collections.Generic;
using System.Text;
using Cronos;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SccmData.QueryScheduleRepository;

namespace SccmData.Scheduler
{
	public class ScheduleCronExpressionCalculator : IScheduleCronExpressionCalculatorService
	{
		ILogger<ScheduleCronExpressionCalculator> _logger;

		public ScheduleCronExpressionCalculator(ILogger<ScheduleCronExpressionCalculator> logger)
		{
			_logger = logger;
		}

		/// <summary>
		/// Return queries that are within 5 minutes of the cron based schedule.
		/// </summary>
		/// <param name="querySchedules"></param>
		/// <returns></returns>
		public List<QuerySchedule> GetRunnableQuerySchedules(IEnumerable<QuerySchedule> querySchedules)
		{
			var runnableList = new List<QuerySchedule>();

			foreach(var schedule in querySchedules)
			{
				try
				{
					CronExpression expression = CronExpression.Parse(schedule.Schedule);
					DateTime? nextUtc = expression.GetNextOccurrence(DateTime.UtcNow);

					if (nextUtc != null)
					{
						TimeSpan diff = (DateTime)nextUtc - DateTime.UtcNow;
						if (diff.TotalSeconds <= 5 * 60)
						{
							runnableList.Add(schedule);
						}
					}
				}
				catch(CronFormatException ex)
				{
					_logger.LogError($"Cron Expression format error for schedule {schedule.ClientCode} - {schedule.SccmServer} - {schedule.Name}. {ex.Message}");
				}
			}

			return runnableList;
		}
	}
}
