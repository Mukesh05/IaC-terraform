﻿using System.Collections.Generic;
using SccmData.QueryScheduleRepository;

namespace SccmData.Scheduler
{
	public interface IScheduleCronExpressionCalculatorService
	{
		List<QuerySchedule> GetRunnableQuerySchedules(IEnumerable<QuerySchedule> querySchedules);
	}
}
