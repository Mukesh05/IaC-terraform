using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using SccmData.QueryScheduleRepository;
using SccmData.QueryResultRepository;
using System.Linq;
using Microsoft.Extensions.Configuration;
using System;

namespace SccmData.Scheduler
{
	public class SccmDataScheduler
	{
		ILogger<SccmDataScheduler> _logger;
		IQueryScheduleRepository _queryScheduleRepository;
		IQueryResultRepository _queryResultRepository;
		IScheduleCronExpressionCalculatorService _expressionCalculatorService;
		IConfiguration _config;

		public SccmDataScheduler(ILogger<SccmDataScheduler> logger,
								 IQueryScheduleRepository queryScheduleRepository,
								 IQueryResultRepository queryResultRepository,
								 IScheduleCronExpressionCalculatorService expressionCalculatorService,
								 IConfiguration config)
		{
			_queryScheduleRepository = queryScheduleRepository;
			_queryResultRepository = queryResultRepository;
			_logger = logger;
			_expressionCalculatorService = expressionCalculatorService;
			_config = config;
		}

		/// <summary>
		/// Return a query schedule.
		/// </summary>
		/// <param name="req"></param>
		/// <param name="clientCode"></param>
		/// <param name="sccmServer"></param>
		/// <param name="queryName"></param>
		/// <returns></returns>
		[FunctionName("SccmDataSchedulerGet")]
		public IActionResult Get([HttpTrigger(AuthorizationLevel.Function, "get", Route = "schedule/{clientCode}/{sccmserver}/{queryName}")]
								 HttpRequest req, string clientCode, string sccmServer, string queryName)
		{
			_logger.LogInformation($"Request to get a query schedule for {clientCode}/{sccmServer}/{queryName}.");

			var result = _queryScheduleRepository.Get(clientCode, sccmServer, queryName);

			if(result == null)
			{
				return new NotFoundObjectResult(new
				{
					result = $"Query schedule not found."
				});
			}

			return new OkObjectResult(new
			{
				result = new
				{
					result.ClientCode,
					result.Name,
					result.Query,
					result.SccmServer,
					result.Schedule,
					result.LastQueryResult,
					result.LastQueryRowCount
				}
			});
		}

		/// <summary>
		/// Return a list of query schedules for specified client code.
		/// </summary>
		/// <param name="req"></param>
		/// <param name="clientCode"></param>
		/// <returns></returns>
		[FunctionName("SccmDataSchedulerList")]
		public IActionResult List([HttpTrigger(AuthorizationLevel.Function, "get", Route = "schedule/{clientCode}")] HttpRequest req, string clientCode)
		{
			_logger.LogInformation($"Request list of query schedules for {clientCode}.");

			var result = _queryScheduleRepository.List(clientCode.ToLower());

			return new OkObjectResult(new
			{
				result = result.Select(x => new
				{
					x.ClientCode,
					x.Name,
					x.Query,
					x.SccmServer,
					x.Schedule,
					x.LastQueryResult,
					x.LastQueryRowCount
				})
			});
		}

		/// <summary>
		/// Return a list of query schedules for the specified client code where schedule
		/// indicates now is the time to run.
		/// </summary>
		/// <param name="req"></param>
		/// <param name="clientCode"></param>
		/// <returns></returns>
		[FunctionName("SccmDataSchedulerListRunnable")]
		public IActionResult ListRunnable([HttpTrigger(AuthorizationLevel.Function, "get", Route = "schedule/query/runnable/{clientCode}/{sccmServer}")]
										   HttpRequest req,
										   string clientCode,
										   string sccmServer)
		{
			_logger.LogInformation($"Requets list of query schedules to run for {clientCode} from {sccmServer}");

			var result = _queryScheduleRepository.List(clientCode).Where(x => string.Compare(sccmServer, x.SccmServer, true) == 0);
			var runnableResults = _expressionCalculatorService.GetRunnableQuerySchedules(result);

			return new OkObjectResult(new
			{
				result = runnableResults.Select(x => new
										{
											x.ClientCode,
											x.Name,
											x.Query,
											x.SccmServer,
											x.Schedule,
											x.LastQueryResult,
											x.LastQueryRowCount
										})
			});
		}

		/// <summary>
		/// Insert a query schedule.
		/// </summary>
		/// <param name="req"></param>
		/// <returns></returns>
		[FunctionName("SccmDataSchedulerInsert")]
		public async Task<IActionResult> Insert([HttpTrigger(AuthorizationLevel.Function, "post", Route = "schedule")] HttpRequest req)
		{
			var payload = await req.ReadAsStringAsync();
			_logger.LogInformation($"Request to insert a query scheduled. {payload}");

			var queryShedule = JsonConvert.DeserializeObject<QuerySchedule>(payload);

			await _queryScheduleRepository.InsertAsync(queryShedule);

			var result = _queryScheduleRepository.Get(queryShedule.ClientCode, queryShedule.SccmServer, queryShedule.Name);

			return new OkObjectResult(new
			{
				result = new
				{
					result.ClientCode,
					result.Name,
					result.Query,
					result.SccmServer,
					result.Schedule,
					result.LastQueryResult,
					result.LastQueryRowCount
				}
			});
		}

		/// <summary>
		/// Delete a query schedule.
		/// </summary>
		/// <param name="req"></param>
		/// <returns></returns>
		[FunctionName("SccmDataSchedulerDelete")]
		public async Task<IActionResult> Delete([HttpTrigger(AuthorizationLevel.Function, "delete", Route = "schedule")] HttpRequest req)
		{
			var payload = await req.ReadAsStringAsync();
			_logger.LogInformation($"Request to delete a query schedule. {payload}");
						
			var queryShedule = JsonConvert.DeserializeObject<QuerySchedule>(payload);

			var result = await _queryScheduleRepository.DeleteAsync(queryShedule);
			
			return new OkObjectResult(new
			{
				result = result
			});
		}

		/// <summary>
		/// Get a sas token for the blob container the client can store the query result too.
		/// </summary>
		/// <param name="req"></param>
		/// <param name="clientCode"></param>
		/// <param name="sccmServer"></param>
		/// <param name="queryName"></param>
		/// <returns></returns>
		[FunctionName("SccmDataRequestSas")]
		[DisableRequestSizeLimit]
		public IActionResult GetSasUri([HttpTrigger(AuthorizationLevel.Function, "get", Route = "schedule/{clientCode}/{sccmserver}/requestsas")]
										 HttpRequest req, string clientCode, string sccmServer)
		{
			_logger.LogInformation($"Request blob SAS Uri for {clientCode}/{sccmServer}.");

			Uri sasUri;
			string sasExpireTimeConfig = _config["SccmData:SasExpireTime"];
			if (!string.IsNullOrWhiteSpace(sasExpireTimeConfig))
			{
				sasUri = _queryResultRepository.GetSasForContainer(clientCode, sccmServer, int.Parse(sasExpireTimeConfig));
			}
			else
			{
				sasUri = _queryResultRepository.GetSasForContainer(clientCode, sccmServer);
			}
			
			return new OkObjectResult(new
			{
				result = sasUri
			});
		}

		[FunctionName("SccmDataSchedulerUpdateQueryStatus")]
		public async Task<IActionResult> UploadDataAsync([HttpTrigger(AuthorizationLevel.Function, "post", Route = "schedule/{clientCode}/{sccmserver}/{queryName}/updatestatus")]
										 HttpRequest req, string clientCode, string sccmServer, string queryName)
		{
			var payload = await req.ReadAsStringAsync();
			_logger.LogInformation($"Request to update query schedule result for {clientCode}/{sccmServer}/{queryName}. \n{payload}");
						
			//First get query result from repository
			var status = _queryScheduleRepository.Get(clientCode, sccmServer, queryName);

			//Update status
			var statusPayload = JsonConvert.DeserializeObject<QuerySchedule>(payload);
			status.LastQueryResult = statusPayload.LastQueryResult;
			status.LastQueryRowCount = statusPayload.LastQueryRowCount;
			var result = await _queryScheduleRepository.InsertAsync(status);

			return new OkObjectResult(new
			{
				result = result
			});
		}

		[FunctionName("SccmDataScheduelerListClientCodes")]
		public async Task<IActionResult> ListClientCodes([HttpTrigger(AuthorizationLevel.Function, "get", Route = "schedule/data/clientcodes")] HttpRequest req)
		{
			var list = await _queryScheduleRepository.ListClientCodesAsync();
			return new OkObjectResult(new
			{
				result = list
			});
		}
	}
}
