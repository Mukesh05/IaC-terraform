using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using PartnerCenter;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Common.ESB;

namespace CSPBillingPublisher
{
    public class CSPBillingPublisher
    {
		IConfigurationRefresher _configRefresher;
		IConfiguration _config;
		IPartnerCenterApi _partnerAPI;
		IESBSender _eSBSender;

		public CSPBillingPublisher(IConfiguration config, IConfigurationRefresher configRefresher, IPartnerCenterApi partnerAPI, IESBSender eSBSender)
		{
			_configRefresher = configRefresher;
			_config = config;
			_partnerAPI = partnerAPI;
			_eSBSender = eSBSender;
		}

		[FunctionName("OnDemandFetchCustomerInvoices")]
		public async Task FetchCustomerInvoicesOnDemand([HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequest req, ILogger log)
		{
			log.LogInformation($"C# Http trigger function starting execution at: {DateTime.Now}");

			var Year = int.Parse(req.Query["Year"]);
			var Month = int.Parse(req.Query["Month"]);

			var queryDate = new DateTime(Year, Month, 07);

			await InvokeInvoiceGetForAllCountries(queryDate, log);

			log.LogInformation($"C# Http trigger function FetchCustomerInvoices finished executed at: {DateTime.Now}");
		}

		[FunctionName("CSPBillingPublisher")]
        public async Task Run([TimerTrigger("%TimerSchedule%")] TimerInfo myTimer, ILogger log, ExecutionContext context)
        {
			await _configRefresher.TryRefreshAsync();

            //Runs every 7th of the month
			log.LogInformation($"C# Timer trigger function starting execution at: {DateTime.Now}");

			var queryDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 07);

			await InvokeInvoiceGetForAllCountries(queryDate, log);

			log.LogInformation($"C# Timer trigger function FetchCustomerInvoices finished executed at: {DateTime.Now}");
        }

		private async Task InvokeInvoiceGetForAllCountries(DateTime queryDate,
														   ILogger log)
		{
			log.LogInformation($"Started pulling invoice data for Canada: {DateTime.Now}");

			try
			{
				var clientBillingList = await InvokePartnerCenterApiForFetchingInvoice(
										_config["CSPBillingPublisher:CATenantId"],
										_config["CSPBillingPublisher:CAClientId"],
										_config["CSPBillingPublisher:CASecret"],
										"cad",
										queryDate);

				var serializedClientBilling = JsonConvert.SerializeObject(clientBillingList);
				await _eSBSender.SendMessageAsync("cspbilling", serializedClientBilling);
			}
			catch (Exception ex)
			{
				log.LogError(ex, $"Exception {ex.Message} whilst pulling invoice data for Canada: {DateTime.Now}");
			}

			log.LogInformation($"Started pulling invoice data for US: {DateTime.Now}");

			try
			{
				var clientBillingList = await InvokePartnerCenterApiForFetchingInvoice(
										_config["CSPBillingPublisher:USTenantId"],
										_config["CSPBillingPublisher:USClientId"],
										_config["CSPBillingPublisher:USSecret"],
										"usd",
										queryDate);

				var serializedClientBilling = JsonConvert.SerializeObject(clientBillingList);
				await _eSBSender.SendMessageAsync("cspbilling", serializedClientBilling);
			}
			catch (Exception ex)
			{
				log.LogError(ex, $"Exception {ex.Message} whilst pulling invoice data for US: {DateTime.Now}");
			}

			log.LogInformation($"Started pulling invoice data for UK: {DateTime.Now}");

			try
			{
				var clientBillingList = await InvokePartnerCenterApiForFetchingInvoice(
										_config["CSPBillingPublisher:UKTenantId"],
										_config["CSPBillingPublisher:UKClientId"],
										_config["CSPBillingPublisher:UKSecret"],
										"gbp",
										queryDate);

				var serializedClientBilling = JsonConvert.SerializeObject(clientBillingList);
				await _eSBSender.SendMessageAsync("cspbilling", serializedClientBilling);
			}
			catch (Exception ex)
			{
				log.LogError(ex, $"Exception {ex.Message} whilst pulling invoice data for UK: {DateTime.Now}");
			}
		}

		private async Task<List<InvoiceDetails>> InvokePartnerCenterApiForFetchingInvoice(string tenant,
																	string clientId,
																	string secret,
																	string currency,
																	DateTime queryDate)
		{
			var results = await _partnerAPI.GetChargesAsync(queryDate, currency, clientId, secret, tenant);

			return results;
		}
	}
}