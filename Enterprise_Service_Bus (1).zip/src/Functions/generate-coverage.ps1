<#
 #
 # Generates coverage file that vscode extension can use to show lines covered after unit test.
 #
 #>

# set this to the base path for the ESB repo on your machine
$ESBPATH="~\code\engineering\ESB2"

Push-Location "$($ESBPATH)\src\Functions\"

dotnet test -v=normal --logger trx -r ./TestResults /p:CollectCoverage=true /p:CoverletOutputFormat=cobertura /p:CoverletOutput=./Coverage/ ./SecHealthAlerts/SecHealthToSnowComparison.Tests/

Copy-Item "$($ESBPATH)\src\Functions\SecHealthAlerts\SecHealthToSnowComparison.Tests\Coverage\coverage.cobertura.xml" `
          "$($ESBPATH)\src\Functions\SecHealthAlerts\SecHealthToSNowComparison\cov.xml"

Pop-Location
