using System.Collections.Generic;
using PartnerCenter;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using Common.ESB;

namespace CSPBillingSubscriber
{
	public class CSPBillingSubscriber
    {
		IConfiguration _configuration;
		IESBReceiver _esbReceiver;
		IInvoiceLineItemsDB _invoiceLineItemsDB;

		public CSPBillingSubscriber(IConfiguration configuration, IESBReceiver esbReceiver, IInvoiceLineItemsDB invoiceLineItemsDB)
		{
			_configuration = configuration;
			_esbReceiver = esbReceiver;
			_invoiceLineItemsDB = invoiceLineItemsDB;
		}

        [FunctionName("CSPBillingSubscriber")]
        public void Run([ServiceBusTrigger("%TopicName%", "%SubscriptionName%")]string mySbMsg, ILogger log)
        {
            log.LogInformation($"C# ServiceBus topic trigger function processed message: {mySbMsg}");

			var invoiceDetails = JsonConvert.DeserializeObject<List<InvoiceDetails>>(mySbMsg);
			_invoiceLineItemsDB.Add(invoiceDetails);

			log.LogInformation($"C# Timer trigger function CSPBillingSubscriber finished executed at: {DateTime.Now}");
		}
	}
}
