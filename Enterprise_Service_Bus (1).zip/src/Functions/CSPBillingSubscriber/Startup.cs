﻿using System;
using System.IO;
using PartnerCenter;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Azure.Identity;
using Common.ESB;

[assembly: FunctionsStartup(typeof(CSPBillingSubscriber.Startup))]
namespace CSPBillingSubscriber
{
	public class Startup : FunctionsStartup
	{
		public override void Configure(IFunctionsHostBuilder builder)
		{
			IConfigurationRefresher configRefresher = null;
			var appconfigConnectionString = Environment.GetEnvironmentVariable("appconfigconnectionstring");

			//Basic config setup
			var configBuilder = new ConfigurationBuilder()
				.SetBasePath(Directory.GetCurrentDirectory())
				.AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
				.AddEnvironmentVariables();

			//Azure App config setup
			configBuilder.AddAzureAppConfiguration(options =>
			{
				options.Connect(appconfigConnectionString)
				.Select("CSPBillingSubscriber:*")
				.ConfigureKeyVault(kv =>
				{
					kv.SetCredential(new DefaultAzureCredential()); //NuGet Azure.Identity
				});
				configRefresher = options.GetRefresher();
			});

			IConfiguration config = configBuilder.Build();

			// Register Config services

			builder.Services.AddSingleton<IConfiguration>((services) =>
			{
				return config;
			});

			builder.Services.AddSingleton<IConfigurationRefresher>((services) =>
			{
				return configRefresher;
			});

			IESBReceiver esbReceiver = new ESBReceiver(config["CSPBillingSubscriber:cspbillingtopic-readersas"]);
			var exists = esbReceiver.CreateSubscriptionIfNotExist(config["TopicName"], config["SubscriptionName"]).Result;
			if (!exists)
			{
				throw new Exception($"Subscription {config["SubscriptionName"]} does not exist. Check if topic {config["TopicName"]} exists.");
			}

			builder
				.Services
				.AddSingleton(esbReceiver);

			builder
				.Services
				.AddSingleton<IInvoiceLineItemsDB, InvoiceLineItemsDB>();
		}
	}
}
