﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Configuration;

namespace PartnerCenter
{
	public class BillingsMarginDB : IBillingsMarginDB
	{
		IEnumerable<BillingMargin> _billingMargin;
				
		public BillingsMarginDB(IConfiguration config)
		{
			_billingMargin = new List<BillingMargin>();
			using (var context = new BillingsMarginDBContext(config["CSPBillingPublisher:SqlConnectionString"]))
			{
				_billingMargin = context.BillingMargin.ToList();
			}
		}

		public IEnumerable<BillingMargin> GetBillingsMarginEntities()
		{
			return _billingMargin;
		}
	}
}
