﻿using System.Collections.Generic;

namespace PartnerCenter
{
	public interface IInvoiceLineItemsDB
	{
		void Add(IEnumerable<InvoiceDetails> unBilledLineItems);
	}
}