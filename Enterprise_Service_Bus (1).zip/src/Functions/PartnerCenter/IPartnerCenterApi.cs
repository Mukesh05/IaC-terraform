﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PartnerCenter
{
	public interface IPartnerCenterApi
	{
		Task<List<InvoiceDetails>> GetChargesAsync(DateTime invoiceDate, string currency, string clientId, string secret, string tenant);
	}
}