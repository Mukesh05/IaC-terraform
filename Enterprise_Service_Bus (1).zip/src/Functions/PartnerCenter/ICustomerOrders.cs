﻿using Microsoft.Store.PartnerCenter.Models;
using Microsoft.Store.PartnerCenter.Models.Invoices;
using Microsoft.Store.PartnerCenter.Models.Orders;

namespace PartnerCenter
{
	public interface ICustomerOrders
	{
		void Add(string customerId, ResourceCollection<Order> orders);
		bool CheckIfPurchaseCharge(string customerId, string productId, string skuId, string availId, int lineitemMonth);
		bool CheckIfPurchaseCharge(InvoiceLineItem lineItem);
		bool Exist(string customerId);
		ResourceCollection<Order> Get(string customerId);
	}
}