﻿using System;
using System.Collections.Generic;
using Microsoft.Store.PartnerCenter;
using Microsoft.Store.PartnerCenter.Extensions;
using Microsoft.Store.PartnerCenter.Models.Query;
using Microsoft.Store.PartnerCenter.Models.Invoices;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.Store.PartnerCenter.RequestContext;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace PartnerCenter
{
	public class PartnerCenterApi : IPartnerCenterApi
	{
		const string ApiRoot = "https://api.partnercenter.microsoft.com/v1";

		IAggregatePartner _partnerOperations;
		ICustomerOrders _customerOrders;
		IBillingsMarginDB _billingsMarginDBInstance;
		IConfiguration _config;
		ILogger<PartnerCenterApi> _logger;

		public PartnerCenterApi(ILogger<PartnerCenterApi> logger,
								IConfiguration config,
								ICustomerOrders customerOrders,
								IBillingsMarginDB billingsMarginDBInstance)
		{
			_logger = logger;
			_config = config;
			_customerOrders = customerOrders;
			_billingsMarginDBInstance = billingsMarginDBInstance;
		}

		/// <summary>
		/// Summarize the charges.
		/// </summary>
		public async Task<List<InvoiceDetails>> GetChargesAsync(DateTime invoiceDate, string currency, string clientId, string secret, string tenant)
		{
			PartnerService.Instance.ApiRootUrl = ApiRoot;
			var credentials = PartnerCredentials.Instance.GenerateByApplicationCredentials(clientId, secret, tenant);
			_partnerOperations = PartnerService.Instance.CreatePartnerOperations(credentials);
			var invoices = await GetInvoicesAsync(invoiceDate);
			var unbilledItems = new List<InvoiceDetails>();

			foreach (var invoice in invoices)
			{
				switch (invoice.InvoiceType.ToLower())
				{
					//not using this invoice type
					case "recurring":
						_logger.LogInformation($"Skipping 'recurring' invoice {invoice.Id} ({invoice.InvoiceDate})");
						break;

					//this is the invoice type we want
					case "onetime":
						_logger.LogInformation($"Processing 'onetime' invoice {invoice.Id} ({invoice.InvoiceDate})");

						//using this format of the call gives us both usage and purchase line items
						var invoiceLineItemWithUsage = await GetInvoiceLineItemsAsync(Period.previous, LineItemType.billingLineItems, Provider.onetime, invoice.Id, currency);
						var billingMargins = _billingsMarginDBInstance.GetBillingsMarginEntities();

						//quick summary of cost for each customer
						var customerTotals = invoiceLineItemWithUsage.GroupBy(x => x.CustomerName)
																				 .Select(x => new
																				 {
																					 x.Key,
																					 SubTotal = x.Sum(y => ((OneTimeInvoiceLineItem)y.InvoiceLineItem).Subtotal),
																					 TaxTotal = x.Sum(y => ((OneTimeInvoiceLineItem)y.InvoiceLineItem).TaxTotal),
																					 TotalForCustomer = x.Sum(y => ((OneTimeInvoiceLineItem)y.InvoiceLineItem).TotalForCustomer),
																				 }).ToList();

						var customerTotalsWithPurchaseCost = invoiceLineItemWithUsage.Where(x => x.IsPurchaseCharge == true)
																				.GroupBy(x => new { x.CustomerName, x.IsPurchaseCharge })
																				 .Select(x => new
																				 {
																					 x.Key,
																					 PurchaseSubTotal = x.Sum(y => ((OneTimeInvoiceLineItem)y.InvoiceLineItem).Subtotal)
																				 }).ToList();

						var customerTotalsWithUsageCost = invoiceLineItemWithUsage.Where(x => x.IsPurchaseCharge == false)
																				.GroupBy(x => new { x.CustomerName, x.IsPurchaseCharge })
																				 .Select(x => new
																				 {
																					 x.Key,
																					 UsageSubTotal = x.Sum(y => ((OneTimeInvoiceLineItem)y.InvoiceLineItem).Subtotal)
																				 }).ToList();

						foreach (var customer in customerTotals)
						{
							_logger.LogInformation($"Processed customer {customer.Key}.");

							var customerInvoice = (OneTimeInvoiceLineItem)invoiceLineItemWithUsage.First(b => b.CustomerName == customer.Key).InvoiceLineItem;
							var billingMargin = billingMargins.SingleOrDefault(bm => bm.Customer_Id.Equals(customerInvoice.CustomerId));
							var margin = billingMargin?.Margin;
							var webDirectdiscount = billingMargin?.Discount_From_Web_Direct;
							var chargeMonth = invoiceDate.ToString("MMMM");
							var chargeYear = invoiceDate.ToString("yyyy");
							var usageCost = customerTotalsWithUsageCost.FirstOrDefault(c => c.Key.CustomerName == customerInvoice.CustomerName)?.UsageSubTotal;
							var purchaseCost = customerTotalsWithPurchaseCost.FirstOrDefault(c => c.Key.CustomerName == customerInvoice.CustomerName)?.PurchaseSubTotal;

							var unbilledItem = new InvoiceDetails()
							{
								CustomerId = customerInvoice.CustomerId,
								CustomerName = customerInvoice.CustomerName,
								CustomerCountry = customerInvoice.CustomerCountry,
								PartnerName = "New Signature",
								Currency = customerInvoice.Currency,
								PricingCurrency = customerInvoice.PricingCurrency,
								MonthYear = chargeMonth + ' ' + chargeYear,
								Subtotal = customer.SubTotal,
								TaxTotal = customer.TaxTotal,
								TotalForCustomer = customer.TotalForCustomer,
								DiscountFromWebDirect = GetWebDirectDiscount(webDirectdiscount),
								Margin = GetMargin(margin),
								SubtotalWithMargin = AddMarginAndDiscount(customer.SubTotal, margin, webDirectdiscount),
								TaxTotalWithMargin = AddMarginAndDiscount(customer.TaxTotal, margin, webDirectdiscount),
								TotalForCustomerWithMargin = AddMarginAndDiscount(customer.TotalForCustomer, margin, webDirectdiscount),
								Markup = customer.SubTotal > 0 ? ((AddMarginAndDiscount(customer.SubTotal, margin, webDirectdiscount) / customer.SubTotal) * 100) - 100 : customer.SubTotal,

								PCToBCExchangeRate = customerInvoice.PCToBCExchangeRate,
								PCToBCExchangeRateDate = customerInvoice.PCToBCExchangeRateDate,
								UsageCost = usageCost.HasValue ? usageCost.Value : 0,
								UsageCostWithMargin = usageCost.HasValue ? AddMarginAndDiscount(usageCost.Value, margin, webDirectdiscount) : 0,
								PurchaseCost = purchaseCost.HasValue ? purchaseCost.Value : 0,
								PurchaseCostWithMargin = purchaseCost.HasValue ? AddMarginAndDiscount(purchaseCost.Value, margin, webDirectdiscount) : 0
							};

							unbilledItems.Add(unbilledItem);
						}

						break;
				}
			}

			return unbilledItems;
		}

		/// <summary>
		/// Return a list of available invoice for the supplied period. The day is not
		/// important. The year/month is what is important.
		/// </summary>
		private async Task<List<Invoice>> GetInvoicesAsync(DateTime invoiceDate)
		{
			List<Invoice> invoices = new List<Invoice>();
			var invoiceDateStr = invoiceDate.ToString("yyyy-MM-dd");
			var simpleFilter = new SimpleFieldFilter(InvoiceSearchField.InvoiceDate.ToString(), FieldFilterOperation.Equals, invoiceDateStr);
			var invoiceQuery = QueryFactory.Instance.BuildSimpleQuery(simpleFilter);
			var results = await _partnerOperations.Invoices.QueryAsync(invoiceQuery);
			var invoiceEnumerator = _partnerOperations.Enumerators.Invoices.Create(results);

			while (invoiceEnumerator.HasValue)
			{
				foreach (var invoice in invoiceEnumerator.Current.Items)
				{
					if (invoice.InvoiceDate.Year == invoiceDate.Year && invoice.InvoiceDate.Month == invoiceDate.Month)
					{
						invoices.Add(invoice);
					}
				}

				invoiceEnumerator.Next();
			}

			return invoices;
		}

		/// <summary>
		/// Get invoice line items.
		/// </summary>
		private async Task<IEnumerable<InvoiceLineItemWithPurchase>> GetInvoiceLineItemsAsync(Period period,
																										LineItemType lineItemType = LineItemType.usageLineItems,
																										Provider provider = Provider.onetime,
																										string invoiceId = "unbilled",
																										string currency = "usd")
		{
			//https://docs.microsoft.com/en-us/partner-center/develop/get-invoice-unbilled-consumption-lineitems
			IPartner scopedPartnerOperations = _partnerOperations.With(RequestContextFactory.Instance.Create(Guid.NewGuid()));
			var seekBasedResourceCollection = await scopedPartnerOperations.Invoices.ById(invoiceId).By(provider.ToString(), lineItemType.ToString(), currency, period.ToString(), 2000).GetAsync();
			var fetchNext = true;
			var lineItems = new List<InvoiceLineItemWithPurchase>();
			while (fetchNext)
			{
				seekBasedResourceCollection.Items.ToList().ForEach(item =>
				{
					var lineItem = (OneTimeInvoiceLineItem)item;
					try
					{
						
						if (item is OneTimeInvoiceLineItem)
						{
							
							if (!_customerOrders.Exist(lineItem.CustomerId))
							{
								var orders = _partnerOperations.Customers.ById(lineItem.CustomerId).Orders.Get();
								_customerOrders.Add(lineItem.CustomerId, orders);
							}

							var isPurchaseCharge = _customerOrders.CheckIfPurchaseCharge(lineItem);
							lineItems.Add(
								new InvoiceLineItemWithPurchase
								{
									InvoiceLineItem = lineItem,
									IsPurchaseCharge = isPurchaseCharge,
									CustomerId = lineItem.CustomerId,
									CustomerName = lineItem.CustomerName
								});

						}
					}
					catch (Exception ex)
					{
						_logger.LogError(ex, @$"Exception : Could not find purchase charge for customer  {lineItem.CustomerName} >>  ({ ex.Message})");
					}
					
				});

				fetchNext = !string.IsNullOrWhiteSpace(seekBasedResourceCollection.ContinuationToken);

				if (fetchNext)
				{
					if (seekBasedResourceCollection.Links.Next.Headers != null && seekBasedResourceCollection.Links.Next.Headers.Any())
					{
						seekBasedResourceCollection = scopedPartnerOperations.Invoices.ById(invoiceId).By(provider.ToString(), lineItemType.ToString(), currency, period.ToString(), 2000).Seek(seekBasedResourceCollection.ContinuationToken, SeekOperation.Next);
					}
				}
			}

			return lineItems;
		}
				

		private decimal AddMarginAndDiscount(decimal amaount, decimal? margin, decimal? webDirectdiscount)
		{
			margin = GetMargin(margin);
			webDirectdiscount = GetWebDirectDiscount(webDirectdiscount);
			var cspDiscountProviderGetsFromMicrosoft = (decimal)margin / 100; // should be based on date, but for now it is a DB field called margin on the company row
			var customerDiscountFromWebDirect = (decimal)webDirectdiscount / 100; // DB Field discount on the company row, 0 by default
			var finalPrice = Math.Round(amaount / ((1 - cspDiscountProviderGetsFromMicrosoft) * (1 - customerDiscountFromWebDirect)), 10);

			return finalPrice;
		}

		private decimal GetWebDirectDiscount(decimal? webDirectdiscount)
		{
			if (!webDirectdiscount.HasValue)
			{
				webDirectdiscount = Convert.ToInt32(_config["CSPBillingPublisher:DefaultWebDirectDiscount"]);
			}

			return (decimal)webDirectdiscount;
		}

		private decimal GetMargin(decimal? margin)
		{
			if (!margin.HasValue)
			{
				margin = Convert.ToInt32(_config["CSPBillingPublisher:DefaultMargin"]);
			}

			return (decimal)margin;
		}
	}

	public enum Period
	{
		current,
		previous
	}

	public enum LineItemType
	{
		billingLineItems,
		usageLineItems
	}

	public enum Provider
	{
		office,
		azure,
		onetime
	}
}
