﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace PartnerCenter
{
	public class InvoiceLineItemsDB : IInvoiceLineItemsDB
	{
		string _sqlConnectionString;

		public InvoiceLineItemsDB(IConfiguration config)
		{
			_sqlConnectionString = config["CSPBillingSubscriber:SqlConnectionString"];
		}

		public void Add(IEnumerable<InvoiceDetails> unBilledLineItems)
		{
			DataTable unbilledLineItemsDataTable = new DataTable("UnbilledLineItemsBatch");
			unbilledLineItemsDataTable.Columns.Add("CustomerId", typeof(string));
			unbilledLineItemsDataTable.Columns.Add("CustomerName", typeof(string));
			unbilledLineItemsDataTable.Columns.Add("CustomerCountry", typeof(string));
			unbilledLineItemsDataTable.Columns.Add("PartnerName", typeof(string));
			unbilledLineItemsDataTable.Columns.Add("Currency", typeof(string));
			unbilledLineItemsDataTable.Columns.Add("PricingCurrency", typeof(string));
			unbilledLineItemsDataTable.Columns.Add("MonthYear", typeof(string));
			unbilledLineItemsDataTable.Columns.Add("Subtotal", typeof(decimal));
			unbilledLineItemsDataTable.Columns.Add("TaxTotal", typeof(decimal));
			unbilledLineItemsDataTable.Columns.Add("TotalForCustomer", typeof(decimal));
			unbilledLineItemsDataTable.Columns.Add("TotalForCustomerWithMargin", typeof(decimal));
			unbilledLineItemsDataTable.Columns.Add("TaxTotalWithMargin", typeof(decimal));
			unbilledLineItemsDataTable.Columns.Add("SubtotalWithMargin", typeof(decimal));
			unbilledLineItemsDataTable.Columns.Add("Markup", typeof(decimal));
			unbilledLineItemsDataTable.Columns.Add("Margin", typeof(decimal));
			unbilledLineItemsDataTable.Columns.Add("DiscountFromWebDirect", typeof(decimal));
			unbilledLineItemsDataTable.Columns.Add("PCToBCExchangeRate", typeof(decimal));
			unbilledLineItemsDataTable.Columns.Add("PCToBCExchangeRateDate", typeof(string));
			unbilledLineItemsDataTable.Columns.Add("UsageCost", typeof(decimal));
			unbilledLineItemsDataTable.Columns.Add("UsageCostWithMargin", typeof(decimal));
			unbilledLineItemsDataTable.Columns.Add("PurchaseCost", typeof(decimal));
			unbilledLineItemsDataTable.Columns.Add("PurchaseCostWithMargin", typeof(decimal));

			foreach (var item in unBilledLineItems)
			{
				DataRow dr = unbilledLineItemsDataTable.NewRow();

				dr["CustomerId"] = item.CustomerId;
				dr["CustomerName"] = item.CustomerName;
				dr["CustomerCountry"] = item.CustomerCountry;
				dr["PartnerName"] = item.PartnerName;
				dr["Currency"] = item.Currency;
				dr["PricingCurrency"] = item.PricingCurrency;
				dr["MonthYear"] = item.MonthYear;
				dr["Subtotal"] = item.Subtotal;
				dr["TaxTotal"] = item.TaxTotal;
				dr["TotalForCustomer"] = item.TotalForCustomer;
				dr["TotalForCustomerWithMargin"] = item.TotalForCustomerWithMargin;
				dr["TaxTotalWithMargin"] = item.TaxTotalWithMargin;
				dr["SubtotalWithMargin"] = item.SubtotalWithMargin;
				dr["Markup"] = item.Markup;
				dr["Margin"] = item.Margin;
				dr["DiscountFromWebDirect"] = item.DiscountFromWebDirect;
				dr["PCToBCExchangeRate"] = item.PCToBCExchangeRate;
				dr["PCToBCExchangeRateDate"] = item.PCToBCExchangeRateDate.Value.ToString("yyyy-MM-dd");
				dr["UsageCost"] = item.UsageCost;
				dr["UsageCostWithMargin"] = item.UsageCostWithMargin;
				dr["PurchaseCost"] = item.PurchaseCost;
				dr["PurchaseCostWithMargin"] = item.PurchaseCostWithMargin;

				unbilledLineItemsDataTable.Rows.Add(dr);
			}

			using (SqlConnection connection = new SqlConnection(_sqlConnectionString))
			{
				connection.Open();

				SqlCommand cmd = new SqlCommand("usp_AddInvoiceUnbilledInfoRow", connection);
				cmd.CommandType = CommandType.StoredProcedure;

				cmd.Parameters.Add(
						new SqlParameter()
						{
							ParameterName = "@InvoiceUnbilledInfoTable",
							SqlDbType = SqlDbType.Structured,
							TypeName = "InvoiceUnbilledInfoTableType",
							Value = unbilledLineItemsDataTable,
						});

				cmd.ExecuteNonQuery();
			}
		}
	}
}
