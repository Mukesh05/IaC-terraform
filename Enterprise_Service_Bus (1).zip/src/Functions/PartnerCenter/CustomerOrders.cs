﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Logging;
using Microsoft.Store.PartnerCenter.Models;
using Microsoft.Store.PartnerCenter.Models.Invoices;
using Microsoft.Store.PartnerCenter.Models.Offers;
using Microsoft.Store.PartnerCenter.Models.Orders;

namespace PartnerCenter
{

	public class CustomerOrders : ICustomerOrders
	{
		IDictionary<string, ResourceCollection<Order>> Orders;
		ILogger<CustomerOrders> _logger;

		public CustomerOrders(ILogger<CustomerOrders> logger)
		{
			_logger = logger;
			Orders = new Dictionary<string, ResourceCollection<Order>>();
		}

		public bool Exist(string customerId)
		{
			return Orders.ContainsKey(customerId);
		}

		public void Add(string customerId, ResourceCollection<Order> orders)
		{
			if (!Orders.ContainsKey(customerId))
			{
				Orders.Add(customerId, orders);
			}
		}

		public ResourceCollection<Order> Get(string customerId)
		{
			ResourceCollection<Order> orders;
			Orders.TryGetValue(customerId, out orders);

			return orders;
		}

		public bool CheckIfPurchaseCharge(string customerId, string productId, string skuId, string availId, int lineitemMonth)
		{
			var isPurchaseCharge = this.Orders[customerId].Items.Any(item => item.CreationDate.Value.Month == lineitemMonth &&  item.LineItems
																.Any(li => li.OfferId == $"{productId}:{skuId}:{availId}"));

			return isPurchaseCharge;
		}

		public bool CheckIfPurchaseCharge(InvoiceLineItem lineItem)
		{
			if (!(lineItem is OneTimeInvoiceLineItem))
			{
				return false;
			}

			var invoiceLineItem = (OneTimeInvoiceLineItem)lineItem;
			var customerId = invoiceLineItem.CustomerId;
			var productId = invoiceLineItem.ProductId;
			var skuId = invoiceLineItem.SkuId;
			var availId = invoiceLineItem.AvailabilityId;
			var lineItemMonth = invoiceLineItem.ChargeStartDate.Month;

			var isPurchaseCharge = this.Orders[customerId].Items.Any(item => item.CreationDate.Value.Month == lineItemMonth && item.LineItems
																.Any(li => li.OfferId == $"{productId}:{skuId}:{availId}"));
			if (isPurchaseCharge)
			{
				_logger.LogInformation($"Found 'New' purchase charge for customer {invoiceLineItem.CustomerName}. (Total Cost : {invoiceLineItem.TotalForCustomer} {invoiceLineItem.Currency })({productId}:{skuId}:{availId})");
			}


			//If this is not a 'New' chargeType, check if it is 'recurring' purchase charge.
			//We have noticed the invoice line item chargeType is 'CycleCharge'. The order item can
			//have the billingCycle set to 'monthly' or 'one_time'.
			//Continue to look for the order item based on productId:skuId:availId but use billingCycle from order
			//if the invoice lineitem has a chargeType set to 'CycleCharge.
			if (!isPurchaseCharge)
			{
				isPurchaseCharge = this.Orders[invoiceLineItem.CustomerId].Items.Any(item => (item.BillingCycle == BillingCycleType.Monthly || item.BillingCycle == BillingCycleType.Annual) &&
																					 item.LineItems.Any(li => li.OfferId == $"{productId}:{skuId}:{availId}"));	

				if (isPurchaseCharge)
				{
					_logger.LogInformation(@$"Found 'CycleCharge' purchase charge for customer {invoiceLineItem.CustomerName}. (Total Cost : {invoiceLineItem.TotalForCustomer} {invoiceLineItem.Currency }) ( {productId}:{skuId}:{availId})");
				}
			}
				
			return isPurchaseCharge;
		}
	}
}	
