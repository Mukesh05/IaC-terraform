﻿using System.Collections.Generic;

namespace PartnerCenter
{
	public interface IBillingsMarginDB
	{
		IEnumerable<BillingMargin> GetBillingsMarginEntities();
	}
}