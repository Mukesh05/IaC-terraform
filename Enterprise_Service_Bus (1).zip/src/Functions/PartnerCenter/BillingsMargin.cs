﻿using System.ComponentModel.DataAnnotations;

namespace PartnerCenter
{
	public class BillingMargin
	{

		[Key]
		public int Id { get; set; }

		public string Client_Name { get; set; }
		public string Customer_Id { get; set; }
		public decimal? Margin { get; set; }
		public decimal? Discount_From_Web_Direct { get; set; }
	}
	
}
