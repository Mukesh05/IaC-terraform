﻿using Microsoft.Store.PartnerCenter.Models.Invoices;

namespace PartnerCenter
{
	public class InvoiceLineItemWithPurchase
	{
		public InvoiceLineItem InvoiceLineItem { get; set; }
		public bool IsPurchaseCharge { get; set; }
		public string CustomerId { get; set; }
		public string CustomerName { get; set; }
	}
}
