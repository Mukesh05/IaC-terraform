﻿
using System;

namespace PartnerCenter
{
	public class InvoiceDetails
	{
		public string CustomerId { get; set; }
		public string CustomerName { get; set; }
		public string CustomerCountry { get; set; }
		public string PartnerName { get; set; }
		public string Currency { get; set; }
		public string PricingCurrency { get; set; }
		public string MonthYear { get; set; }
		public decimal Subtotal { get; set; }
		public decimal TaxTotal { get; set; }
		public decimal TotalForCustomer { get; set; }
		public decimal TotalForCustomerWithMargin { get; set; }
		public decimal TaxTotalWithMargin { get; set; }
		public decimal SubtotalWithMargin { get; set; }
		public decimal Markup { get; set; }
		public decimal Margin { get; set; }
		public decimal DiscountFromWebDirect { get; set; }
		public decimal PCToBCExchangeRate { get; set; }
		public DateTime? PCToBCExchangeRateDate { get; set; }
		public decimal UsageCost { get; set; }
		public decimal PurchaseCost { get; set; }
		public decimal UsageCostWithMargin { get;  set; }
		public decimal PurchaseCostWithMargin { get;  set; }
	}
}
