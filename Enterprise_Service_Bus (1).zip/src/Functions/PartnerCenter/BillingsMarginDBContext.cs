﻿using Microsoft.EntityFrameworkCore;

namespace PartnerCenter
{
	public class BillingsMarginDBContext : DbContext
	{
		string _connectionString;
		public BillingsMarginDBContext(string connectionString)
		{
			_connectionString = connectionString;
		}
		public DbSet<BillingMargin> BillingMargin { get; set; }
		
		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			optionsBuilder.UseSqlServer(_connectionString);
		}
	}
}
