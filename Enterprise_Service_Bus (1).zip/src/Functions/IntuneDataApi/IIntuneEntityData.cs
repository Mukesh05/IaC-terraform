﻿using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace IntuneDataApi
{
	public interface IIntuneEntityData
	{
		Task<string> GetIntuneEntityData(HttpRequest req, string type, HttpClient httpClient);
	}
}