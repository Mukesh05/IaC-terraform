﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Common.ESB;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace IntuneDataApi
{
	public class IntuneEntityData : IIntuneEntityData
	{
		ISecurity _security;
		IServiceNowAccounts _serviceNow;
		IConfiguration _configuration;
		ILogger<IntuneEntityData> _logger;

		public IntuneEntityData(ISecurity security, IServiceNowAccounts serviceNow, IConfiguration configuration, ILogger<IntuneEntityData> logger)
		{
			_security = security;
			_serviceNow = serviceNow;
			_configuration = configuration;
			_logger = logger;
		}

		private UriBuilder BuildUrl(HttpRequest req, string type, string intuneDataWarehouseUrl)
		{
			var uriBuilder = new UriBuilder(intuneDataWarehouseUrl);
			if (!string.IsNullOrEmpty(req.Query["api-version"]))
			{
				uriBuilder.Query = "api-version=" + req.Query["api-version"].ToString();
			}

			if (!string.IsNullOrEmpty(req.Query["$filter"]))
			{
				uriBuilder.Query += "&$filter=" + req.Query["$filter"].ToString();
			}

			if (!string.IsNullOrEmpty(req.Query["$select"]))
			{
				uriBuilder.Query += "&$select=" + req.Query["$select"].ToString();
			}

			if (!string.IsNullOrEmpty(req.Query["$top"]))
			{
				uriBuilder.Query += "&$top=" + req.Query["$top"].ToString();
			}

			if (!string.IsNullOrEmpty(req.Query["$orderby"]))
			{
				uriBuilder.Query += "&$orderby=" + req.Query["$orderby"].ToString();
			}

			if (!string.IsNullOrEmpty(req.Query["$skip"]))
			{
				uriBuilder.Query += "&$skip=" + req.Query["$skip"].ToString();
			}
			uriBuilder.Path += "/" + type;

			return uriBuilder;
		}
		
		public async Task<string> GetIntuneEntityData(HttpRequest req, string type, HttpClient httpClient)
		{
			JArray accumulatedEntities = new JArray();
	
			if (!string.IsNullOrEmpty(type) && !type.Contains("$metadata"))
			{
				var serviceNowAccounts = await _serviceNow.GetServiceNowAccounts();
				foreach(var account in serviceNowAccounts)
				{
					try
					{
						//Retrieve intune data for current account
						string tenantId = account.Tenant_ids;
						var uriBuilder = BuildUrl(req, type, account.Intune_warehouse_endpoint);

						var accessToken = await _security.GetAuthToken(tokenAudience : "https://api.manage.microsoft.com/", tenantId, _configuration["IntuneDataApi:Secret"], _configuration["IntuneDataApi:ClientId"]);
						httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
						HttpResponseMessage response = await httpClient.GetAsync(uriBuilder.Uri);
						var responseContentFromApi = await response.Content.ReadAsStringAsync();

						//If not successful, log api error response and move on to next client.
						if (!response.IsSuccessStatusCode)
						{
							_logger.LogError($"Failed to call Intune API for {account.Account_name}({account.Tenant_ids}). ({response.RequestMessage})");
							continue;
						}

						//We need to accumulate the response for each account into one final response
						var result = JObject.Parse(responseContentFromApi);
						var odataContext = (string)result["@odata.context"];
						var odataCount = (string)result["@odata.count"];
						var odataNextLink = (string)result["@odata.nextLink"];
						var value = (JArray)result["value"];

						accumulatedEntities.Merge(value);

						//Keep grabbing and saving data as long as there is a NextLink available
						while (!string.IsNullOrEmpty(odataNextLink))
						{
							response = await httpClient.GetAsync(odataNextLink);
							var nextLinkResponse = await response.Content.ReadAsStringAsync();

							result = JObject.Parse(nextLinkResponse);
							odataNextLink = (string)result["@odata.nextLink"];
							value = (JArray)result["value"]; //JArray

							accumulatedEntities.Merge(value);
						}

						//We need to insert the tenant id to each record so we can determine what client this record belongs to.
						foreach (var entity in accumulatedEntities)
						{
							((JObject)entity).Add("tenant", tenantId);
						}
					}
					catch(Exception ex)
					{
						//Log error and move on to processing the next client.
						_logger.LogError(ex, $"Failed to process data for {account.Account_name}({account.Tenant_ids}).");
					}
				}
			}

			JObject odataReturn = new JObject();
			odataReturn.Add("@odata.context",  $"https://{req.Host.Value}/ReportingService/DataWarehouseFEService/$metadata#{type}");
			odataReturn.Add("@odata.count", 0);
			odataReturn.Add("value", accumulatedEntities);
			
			return odataReturn.ToString(Formatting.None);
		}
	}
}
