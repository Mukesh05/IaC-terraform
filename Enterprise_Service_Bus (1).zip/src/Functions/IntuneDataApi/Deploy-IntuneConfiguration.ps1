function Deploy-IntuneConfiguration {
  Param (
    [string]$SubscriptionId,
    [string]$ConfigurationSvcName,
    [string]$KeyVaultName,
    [string]$Environment
  )

  # connect
  az account set --subscription $SubscriptionId

  Write-Output "SubscriptionId: $($SubscriptionId)"
  Write-Output "Configuration:  $ConfigurationSvcName"
  Write-Output "Key Vault:      $KeyVaultName"
  Write-Output "Environment:    $Environment"

  Write-Output "Updating Intune Settings ..."

  # service now secret
  if('prod' -eq $Environment)
  {
    az appconfig kv set -n $ConfigurationSvcName --key ServiceNow:Instance            --value newsignature.service-now.com --yes --query 'key' -o tsv --only-show-errors
  }
  else
  {
    az appconfig kv set -n $ConfigurationSvcName --key ServiceNow:Instance            --value newsignaturedev.service-now.com --yes --query 'key' -o tsv --only-show-errors
  }

  # app secrets for service now
  az appconfig kv set-keyvault -n $ConfigurationSvcName          --key ServiceNow:ClientId            --secret-identifier "https://$($KeyVaultName).vault.azure.net/secrets/servicenow-client-id" --yes --query 'key' -o tsv --only-show-errors
  az appconfig kv set-keyvault -n $ConfigurationSvcName          --key ServiceNow:Secret              --secret-identifier "https://$($KeyVaultName).vault.azure.net/secrets/servicenow-secret" --yes --query 'key' -o tsv --only-show-errors
  az appconfig kv set-keyvault -n $ConfigurationSvcName          --key ServiceNow:UserId              --secret-identifier "https://$($KeyVaultName).vault.azure.net/secrets/servicenow-user-id" --yes --query 'key' -o tsv --only-show-errors
  az appconfig kv set-keyvault -n $ConfigurationSvcName          --key ServiceNow:UserPassword        --secret-identifier "https://$($KeyVaultName).vault.azure.net/secrets/servicenow-user-password" --yes --query 'key' -o tsv --only-show-errors

  # app secrets for intune api service
  az appconfig kv set-keyvault -n $ConfigurationSvcName          --key IntuneDataApi:ClientId         --secret-identifier "https://$($KeyVaultName).vault.azure.net/secrets/intunedata-api-sp-client-id" --yes --query 'key' -o tsv --only-show-errors
  az appconfig kv set-keyvault -n $ConfigurationSvcName          --key IntuneDataApi:Secret           --secret-identifier "https://$($KeyVaultName).vault.azure.net/secrets/intunedata-api-sp-secret" --yes --query 'key' -o tsv --only-show-errors
  az appconfig kv set-keyvault -n $ConfigurationSvcName          --key IntuneDataApi:TenantId         --secret-identifier "https://$($KeyVaultName).vault.azure.net/secrets/intunedata-api-sp-tenantid-id" --yes --query 'key' -o tsv --only-show-errors

  Write-Output "Done Updating Settings"
  }

  # QA
  Deploy-IntuneConfiguration -SubscriptionId 'a796a3fe-dffd-4ae7-9aee-f76574986de6' -ConfigurationSvcName 'ac-dti-qa-core' -KeyVaultName 'kv-dti-qa-core' -Environment 'dev'

  # Production
  #Deploy-IntuneConfiguration -SubscriptionId '3a74db16-883d-4ac1-b7f7-ee0335c94bad' -ConfigurationSvcName 'ac-dti-prod-core' -KeyVaultName 'kv-dti-prod-core' -Environment 'prod'
