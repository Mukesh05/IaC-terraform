﻿using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using System;
using Azure.Identity;
using System.IO;
using Common.ESB;

[assembly: FunctionsStartup(typeof(IntuneDataApi.Startup))]
namespace IntuneDataApi
{
	public class Startup : FunctionsStartup
	{
		public override void Configure(IFunctionsHostBuilder builder)
		{
			IConfigurationRefresher configRefresher = null;

			var appconfigConnectionString = Environment.GetEnvironmentVariable("appconfigconnectionstring");

			//Basic config setup
			var configBuilder = new ConfigurationBuilder()
				.SetBasePath(Directory.GetCurrentDirectory())
				.AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
				.AddEnvironmentVariables();

			//Azure App config setup
			configBuilder.AddAzureAppConfiguration(options =>
			{
				options.Connect(appconfigConnectionString)
				.Select("IntuneDataApi:*")
				.Select("ServiceNow:*")
				.ConfigureKeyVault(kv =>
				{
					kv.SetCredential(new DefaultAzureCredential()); //NuGet Azure.Identity
				});
				configRefresher = options.GetRefresher();
			});

			IConfiguration config = configBuilder.Build();

			// Register Config services
			builder.Services.AddSingleton<IConfiguration>((services) =>
			{
				return config;
			});

			builder.Services.AddSingleton<IConfigurationRefresher>((services) =>
			{
				return configRefresher;
			});

			// Registering services
			builder
				.Services
				.AddSingleton<ISecurity, Security>();

			builder
				.Services
				.AddSingleton<IIntuneMetadata, IntuneMetadata>();

			builder
				.Services
				.AddSingleton<IIntuneEntityData, IntuneEntityData>();

			builder
				.Services
				.AddSingleton<IServiceNowAccounts, ServiceNowAccounts>();
		}
	}
}
