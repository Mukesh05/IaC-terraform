﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace IntuneDataApi
{
	public interface IIntuneMetadata
	{
		Task<string> GetIntuneEntityMetaData(HttpRequest req, string type, HttpClient httpClient);
		Task<string> GetListOfIntuneEntities(HttpRequest req, string type, HttpClient httpClient);
	}
}