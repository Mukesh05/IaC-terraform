﻿using System;
using System.Dynamic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Xml;
using Common.ESB;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace IntuneDataApi
{
	public class IntuneMetadata : IIntuneMetadata
	{
		ISecurity _security;
		IConfiguration _config;
		//Later this needs to be moved to storage table
		string _warehouseUrl = "https://fef.msua04.manage.microsoft.com/ReportingService/DataWarehouseFEService";

		public IntuneMetadata(ISecurity security, IConfiguration config)
		{
			_security = security;
			_config = config;
		}

		private async Task<UriBuilder> BuildUrl(HttpClient httpClient)
		{
			var accessToken = await _security.GetAuthToken(tokenAudience: "https://api.manage.microsoft.com/", _config["IntuneDataApi:TenantId"], _config["IntuneDataApi:Secret"], _config["IntuneDataApi:ClientId"]);
			httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
			var uriBuilder = new UriBuilder(_warehouseUrl);

			return uriBuilder;
		}

		public async Task<string> GetListOfIntuneEntities(HttpRequest req, string type, HttpClient httpClient)
		{
			string finalResponse = null;

			if (string.IsNullOrEmpty(type))
			{
				var uriBuilder = await BuildUrl(httpClient);
				HttpResponseMessage response = await httpClient.GetAsync(uriBuilder.Uri);
				var responseContentFromApi = await response.Content.ReadAsStringAsync();
				dynamic obj = JsonConvert.DeserializeObject<ExpandoObject>(responseContentFromApi);
				finalResponse = JsonConvert.SerializeObject(obj);
				finalResponse = finalResponse?.Replace(_warehouseUrl, $"http://{req.Host.Value}/api/IntuneData");
			}

			return finalResponse;
		}

		public async Task<string> GetIntuneEntityMetaData(HttpRequest req, string type, HttpClient httpClient)
		{
			string finalResponse = null;

			if (!string.IsNullOrEmpty(type) && type.Contains("$metadata"))
			{
				var warehouseUrl = _warehouseUrl + "/" + type;
				HttpResponseMessage response = await httpClient.GetAsync(warehouseUrl);
				var responseContentFromApi = await response.Content.ReadAsStringAsync();
				XmlDocument doc = new XmlDocument();
				doc.LoadXml(responseContentFromApi);
				XmlNodeList nodeList;
				nodeList = doc.GetElementsByTagName("EntityType");
				foreach (XmlNode entityTypeNode in nodeList)
				{
					XmlDocument newDocument = new XmlDocument();
					newDocument.LoadXml(@"<Property Name=""tenant"" Type=""Edm.String"" Nullable=""false"" />");
					XmlNode n = doc.ImportNode(newDocument.FirstChild, true);
					entityTypeNode.AppendChild(n);
				}

				using (var stringWriter = new StringWriter())
				using (var xmlTextWriter = XmlWriter.Create(stringWriter))
				{
					doc.WriteTo(xmlTextWriter);
					xmlTextWriter.Flush();
					finalResponse = stringWriter.GetStringBuilder().ToString();
				}
			}

			finalResponse = finalResponse?.Replace(@"xmlns=""""", string.Empty);
			finalResponse = finalResponse?.Replace(_warehouseUrl, $"http://{req.Host.Value}/api/IntuneData");

			return finalResponse;
		}
	}
}
