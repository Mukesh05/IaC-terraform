using System;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Net.Http;
using System.Net;
using System.Text;

namespace IntuneDataApi
{
	public class IntuneDataApi
	{
		IIntuneMetadata _intuneMetadata;
		IIntuneEntityData _intuneEntityData;
		HttpClient _httpClient = new HttpClient();

		public IntuneDataApi(IIntuneMetadata intuneMetadata, IIntuneEntityData intuneEntityData)
		{
			_intuneMetadata = intuneMetadata;
			_intuneEntityData = intuneEntityData;
		}

		[FunctionName("IntuneData")]
		public async Task<HttpResponseMessage> IntuneData(
			[HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = "IntuneData/{type?}")] HttpRequest req,
			string type,
			ILogger log)
		{
			try
			{
				log.LogInformation("C# HTTP trigger function processed a request.");

				var finalResponse = await _intuneMetadata.GetListOfIntuneEntities(req, type, _httpClient);

				if (finalResponse == null)
				{
					finalResponse = await _intuneMetadata.GetIntuneEntityMetaData(req, type, _httpClient);
				}

				if (finalResponse == null)
				{
					finalResponse = await _intuneEntityData.GetIntuneEntityData(req, type, _httpClient);
				}

				string responseMessage = finalResponse != null
											? finalResponse
											: $"Null Response. This HTTP triggered function failed!";

				var response = new HttpResponseMessage(HttpStatusCode.OK);

				ConvertResponseToOdataResponse(req, responseMessage, response);

				return response;
			}
			catch (Exception ex)
			{
				return new HttpResponseMessage(HttpStatusCode.InternalServerError)
				{
					Content = new StringContent(ex.Message, Encoding.UTF8, "application/json")
				};
			}
		}

		private static void ConvertResponseToOdataResponse(HttpRequest req, string responseMessage, HttpResponseMessage response)
		{
			if (req.HttpContext.Request.Path.Value.EndsWith("$metadata"))
			{
				response.Content = new StringContent(responseMessage, Encoding.UTF8, "application/xml");
				response.Content.Headers.Clear();
				response.Content.Headers.Add("Content-Type", "application/xml");
				response.Content.Headers.Add("service-name", "DataWarehouseFEService");
				response.Content.Headers.Add("OData-Version", "4.0");
			}
			else
			{
				response.Content = new StringContent(responseMessage, Encoding.UTF8, "application/json");
				response.Content.Headers.Clear();
				response.Content.Headers.Add("Content-Type", "application/json; odata.metadata=minimal");
				response.Content.Headers.Add("OData-Version", "4.0");
			}
		}
	}
}
