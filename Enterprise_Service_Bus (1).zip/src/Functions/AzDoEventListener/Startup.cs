﻿[assembly: Microsoft.Azure.Functions.Extensions.DependencyInjection.FunctionsStartup(typeof(AzDoListener.Startup))]
namespace AzDoListener
{
	using System;
	using System.Diagnostics.CodeAnalysis;
	using System.IO;
	using Azure.Identity;
	using Microsoft.ApplicationInsights.Channel;
	using Microsoft.ApplicationInsights.Extensibility;
	using Microsoft.Azure.Functions.Extensions.DependencyInjection;
	using Microsoft.Extensions.Azure;
	using Microsoft.Extensions.Configuration;
	using Microsoft.Extensions.Configuration.AzureAppConfiguration;
	using Microsoft.Extensions.DependencyInjection;
	using Microsoft.Extensions.Logging;

	[ExcludeFromCodeCoverage]
	class Startup: FunctionsStartup
	{
		public override void Configure(IFunctionsHostBuilder builder)
		{
			var serviceProvider = builder.Services.BuildServiceProvider();
			var configurationRoot = serviceProvider.GetService<IConfiguration>();

			IConfigurationRefresher configRefresher = null;
			var appconfigConnectionString = Environment.GetEnvironmentVariable("appconfigconnectionstring");

			//Basic config setup
			var configBuilder = new ConfigurationBuilder()
				.SetBasePath(Directory.GetCurrentDirectory())
				.AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
				.AddEnvironmentVariables()
				.AddConfiguration(configurationRoot);

			//Azure App config setup
			configBuilder.AddAzureAppConfiguration(options =>
			{
				options.Connect(appconfigConnectionString)
				.Select("AzDevOpsListener:*")
				.ConfigureKeyVault(kv =>
				{
					kv.SetCredential(new DefaultAzureCredential()); // NuGet Azure.Identity
				});
				configRefresher = options.GetRefresher();
			});

			IConfiguration config = configBuilder.Build();

			// Register Config services
			builder.Services.AddSingleton<IConfiguration>((services) =>
			{
				return config;
			});

			builder.Services.AddSingleton<IConfigurationRefresher>((services) =>
			{
				return configRefresher;
			});

			builder.Services.AddLogging();

			// Registering services

			// None right now ... maybe later ?
		}

	}
}