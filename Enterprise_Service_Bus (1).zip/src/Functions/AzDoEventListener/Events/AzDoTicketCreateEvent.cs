﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;

namespace AzDoListener.Events
{
	public class AzDoTicketCreateEvent : IAzDoTicketEvent
	{
		/// <summary>
		/// Unique ID representing a Work Item
		/// </summary>
		public virtual int WorkItemId
		{
			get { return this._workItemId; }
			set { this._workItemId = value; }
		}

		/// <summary>
		/// HTML Link to the in-context Work Item in Azure DevOps
		/// </summary>
		public virtual string Href
		{
			get { return this._href; }
			set { this._href = value; }
		}
		/// <summary>
		/// Specific Type for the in-context Work Item
		/// </summary>
		public virtual string WorkItemType
		{
			get { return this._workItemType; }
			set { this._workItemType = value; }
		}

		public virtual string Source
		{
			get { return this._source; }
			set { this._source = value; }
		}

		public static AzDoTicketCreateEvent TryParse(JObject message, ILogger log)
		{
			var ticket = new AzDoTicketCreateEvent();

			try
			{
				ticket.WorkItemId = (int)message.SelectToken("$['resource']['id']", errorWhenNoMatch: true);
				ticket.WorkItemType = (string)message.SelectToken("$['resource']['fields']['System.WorkItemType']", errorWhenNoMatch: true);

				ticket.Href = (string)message.SelectToken("$['resource']['_links']['self']['href']");

				ticket.Source = (string)message.SelectToken("$['resource']['fields']['Custom.Source']");
			}
			catch (Exception e)
			{
				log.LogError($"{ticket.WorkItemType} {ticket.WorkItemId} - {e}");
			}

			return ticket;
		}

		private int _workItemId;

		private string _href;

		private string _workItemType;

		private string _source;
	}
}
