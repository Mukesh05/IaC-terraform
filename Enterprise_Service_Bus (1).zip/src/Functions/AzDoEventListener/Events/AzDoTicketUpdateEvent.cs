﻿namespace AzDoListener.Events
{
	using System;
	using Microsoft.Extensions.Logging;
	using Newtonsoft.Json;
	using Newtonsoft.Json.Linq;

	/// <summary>
	/// Class to represent an instance of an Azure DevOps Work Item Update/Delta,
	/// which represents the specific changes made during a Work Item save action.
	/// </summary>
	public class AzDoTicketUpdateEvent : IAzDoTicketEvent
	{
		/// <summary>
		/// Unique ID representing a Work Item
		/// </summary>
		public virtual int WorkItemId
		{
			get { return this._workItemId; }
			set { this._workItemId = value; }
		}

		/// <summary>
		/// HTML Link to the in-context Work Item in Azure DevOps
		/// </summary>
		public virtual string Href
		{
			get { return this._href; }
			set { this._href = value; }
		}
		/// <summary>
		/// Specific Type for the in-context Work Item
		/// </summary>
		public virtual string WorkItemType
		{
			get { return this._workItemType; }
			set { this._workItemType = value; }
		}
		/// <summary>
		/// Value of System.State from before the Update event
		/// </summary>
		public virtual string OldState
		{
			get { return this._oldState; }
			set { this._oldState = value; }
		}
		/// <summary>
		/// Value of System.State after the Update event
		/// </summary>
		public virtual string NewState
		{
			get { return this._newState; }
			set { this._newState = value; }
		}

		/// <summary>
		/// Attempt to Parse the Data from the Message and Log any Exceptions and Processing Notes.
		///
		/// Only return an object if it is a Task that is moved from
		///
		///       "System.State": {
		///       "oldValue": "Proposed",
		///       "newValue": "Active"
		///       },
		///
		/// </summary>
		/// <param name="message">Dynamic JObject received from message bus</param>
		/// <param name="log">The Azure Function Logger Object</param>
		/// <returns>null if the parse fails or a valid AzDoTicketStateUpdateEvent on success</returns>
		public static AzDoTicketUpdateEvent TryParse(JObject message, ILogger log)
		{
			var ticket = new AzDoTicketUpdateEvent();

			try
			{
				// test if the message is the correct type ...
				// No longer required, event type is now determined in ProcessAzDoWorkItemEvent
				bool isUpdateEvent = ((string)message["eventType"] == "workitem.updated");

				// grab essential information about the Work Item in context
				ticket.WorkItemId = (int)message.SelectToken("$['resource']['workItemId']", errorWhenNoMatch: true);
				ticket.WorkItemType = (string)message.SelectToken("$['resource']['revision']['fields']['System.WorkItemType']", errorWhenNoMatch: true);

				if (!isUpdateEvent)
				{
					// log event is not interesting ...
					log.LogInformation($"{ticket.WorkItemType} {ticket.WorkItemId} - Event received is not a Work Item Update.");
					ticket = null;
				}
				else
				{
					try
					{
						var stateUpdate2 = message.SelectToken($"['resource']['fields']['System.State']");

						if (stateUpdate2 != null)
						{
							ticket.Href = (string)message.SelectToken("$['resource']['_links']['parent']['href']");
							ticket.OldState = (string)message.SelectToken("$['resource']['fields']['System.State']['oldValue']");
							ticket.NewState = (string)message.SelectToken("$['resource']['fields']['System.State']['newValue']");
						}
						else
						{
							log.LogInformation($"{ticket.WorkItemType} {ticket.WorkItemId} - Update/Delta event does not contain state change.");
							ticket = null;
						}
					}
					catch (JsonException je)
					{
						log.LogError($"{ticket.WorkItemType} {ticket.WorkItemId} - {je}");
					}
				}
			}
			catch (Exception e)
			{
				log.LogError($"Failed to parse message into AzDoTicketStateUpdateEvent object : {e}");
				ticket = null;
			}

			return ticket;
		}

		protected AzDoTicketUpdateEvent()
		{
		}

		private int _workItemId;

		private string _href;

		private string _workItemType;

		private string _oldState;

		private string _newState;
	}
}