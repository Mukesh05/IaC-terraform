﻿namespace AzDoListener.Events
{
	public interface IAzDoTicketEvent
	{
		string Href { get; set; }
		int WorkItemId { get; set; }
		string WorkItemType { get; set; }
	}
}