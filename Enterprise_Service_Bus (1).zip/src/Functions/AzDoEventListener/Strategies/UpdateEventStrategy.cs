﻿using System.Threading.Tasks;
using AzDoListener.Events;
using AzDoListener.WorkItem;
using Microsoft.Extensions.Logging;

namespace AzDoListener.Strategies
{
	public class UpdateEventStrategy : ITicketEventStrategy
	{
		string _pat;
		ILogger _logger;
		AzDoTicketUpdateEvent _ticketEvent;
		IAzDoWorkItemFactory _wiFactory;

		public UpdateEventStrategy(string pat,
								   ILogger<ProcessAzDoWorkItemEvent> log,
								   IAzDoWorkItemFactory wiFactory,
								   AzDoTicketUpdateEvent ticketEvent)
		{
			this._logger = log;
			this._pat = pat;
			this._wiFactory = wiFactory;
			this._ticketEvent = ticketEvent;
		}
		
		/// <summary>
		/// Strategy that defines the processing of an updated ticket
		/// </summary>
		/// <returns>task of void</returns>
		public async Task Execute()
		{
			_logger.LogInformation($"{_ticketEvent.WorkItemId} of type {_ticketEvent.WorkItemType} updated from " +
			                       $"{_ticketEvent.OldState} to {_ticketEvent.NewState} with href {_ticketEvent.Href}");

			// if parent status is in a "Proposed" state, update it to "In Progress" state
			this._logger.LogInformation($"Using PAT Token : {this._pat.Substring(0, 5)}");

			var changeWorkItem = this._wiFactory.GetAzDoWorkItem(this._ticketEvent.Href, this._pat);
			await changeWorkItem.Get();

			var parentHref = changeWorkItem.ParentHref;

			if (!string.IsNullOrEmpty(parentHref))
			{
				var parentWorkItem = _wiFactory.GetAzDoWorkItem(parentHref, _pat);
				await parentWorkItem.Get();

				if (changeWorkItem.State == "Active" &&
					parentWorkItem.State == "Proposed")
				{
					parentWorkItem.UpdateState = true;
					await parentWorkItem.Update();
					_logger.LogInformation("Parent Work Item has been moved to In Progress");
				}
				else
				{
					_logger.LogInformation("Child and parent states don't require action");
				}
			}
			else
			{
				_logger.LogInformation("Ticket does not have a parent");
			}
		}
	}
}
