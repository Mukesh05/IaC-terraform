﻿using System.Threading.Tasks;

namespace AzDoListener.Strategies
{
	public interface ITicketEventStrategy
	{
		Task Execute();
	}
}