﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using AzDoListener.Events;
using AzDoListener.WorkItem;
using Microsoft.Extensions.Logging;

namespace AzDoListener.Strategies
{
	public class CreateEventStrategy : ITicketEventStrategy
	{
		string _pat;
		ILogger _logger;
		AzDoTicketCreateEvent _ticketEvent;
		IAzDoWorkItemFactory _wiFactory;

		public CreateEventStrategy(string pat,
								   ILogger<ProcessAzDoWorkItemEvent> log,
								   IAzDoWorkItemFactory wiFactory,
								   AzDoTicketCreateEvent ticketEvent)
		{
			this._logger = log;
			this._pat = pat;
			this._wiFactory = wiFactory;
			this._ticketEvent = ticketEvent;
		}

		/// <summary>
		/// Strategy that defines the processing of a created ticket
		/// </summary>
		/// <returns>task of void</returns>
		public async Task Execute()
		{
			_logger.LogInformation($"{_ticketEvent.WorkItemId} of type {_ticketEvent.WorkItemType} has been created with href {_ticketEvent.Href}");
			this._logger.LogInformation($"Using PAT Token : {this._pat.Substring(0, 5)}");

			var createdWorkItem = this._wiFactory.GetAzDoWorkItem(this._ticketEvent.Href, this._pat);
			await createdWorkItem.Get();

			// if Created work item does not have a source, set the source from its parent.
			if (string.IsNullOrEmpty(createdWorkItem.Source))
			{
				var parentHref = createdWorkItem.ParentHref;

				if (!string.IsNullOrEmpty(parentHref))
				{
					var parentWorkItem = _wiFactory.GetAzDoWorkItem(parentHref, _pat);
					await parentWorkItem.Get();

					if (!string.IsNullOrEmpty(parentWorkItem.Source))
					{
						createdWorkItem.NewSource = parentWorkItem.Source;
						await createdWorkItem.Update();
						_logger.LogInformation($"Created Work Item {createdWorkItem.Id} has had its Source set from Parent {parentWorkItem.Id}.");
					}
					else
					{
						_logger.LogInformation($"Parent work item {parentWorkItem.Id} does not have a Source.");
					}
				}
				else
				{
					_logger.LogInformation("Ticket does not have a parent.");
				}
			}
			else
			{
				_logger.LogInformation($"Work Item {_ticketEvent.WorkItemId} already has a source.");
			} 
		}
	}
}
