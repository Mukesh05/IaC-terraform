﻿namespace AzDoListener.WorkItem
{
	using System;
	using System.Collections.Generic;
	using System.Net.Http;
	using System.Net.Http.Headers;
	using System.Text;
	using System.Threading.Tasks;
	using Newtonsoft.Json;
	using Newtonsoft.Json.Linq;

	/// <summary>
	/// Class to represent an instance of an Azure DevOps Work Item
	/// </summary>
	public class AzDoWorkItem : IAzDoWorkItem
	{
		private HttpClient _httpClient;
		private string _ticketUri = null;
		private JObject _ticketContent = null;
		private string _PAT = ""; // string.Empty;
		private string _source = null;
		private string _retrievedSource = null;
		private string _state = null;
		private string _retrievedState = null;
		private JObject _updatePayload;
		private int _workItemId;

		/// <summary>
		///
		/// </summary>
		/// <param name="uri"></param>
		/// <param name="pat"></param>
		public AzDoWorkItem(string uri, string pat)
		{
			this._httpClient = new HttpClient();
			this._ticketUri = uri;
			this._PAT = pat;
		}

		public AzDoWorkItem(HttpMessageHandler handler, string uri, string pat)
		{
			this._httpClient = new HttpClient(handler);
			this._ticketUri = uri;
			this._PAT = pat;
		}

		private string _workItemType = string.Empty;

		/// <summary>
		/// Get the Work Item Id
		/// </summary>
		public int Id
		{
			get
			{
				if (null == this._ticketContent)
				{
					throw new InvalidOperationException("Ticket has not been populated via Get() method first.");
				}

				int value = (int)this._ticketContent?["id"];

				return value;
			}
		}

		/// <summary>
		/// Get the Work Item Type
		/// </summary>
		public string Type
		{
			get
			{
				if (null == this._ticketContent)
				{
					throw new InvalidOperationException("Ticket has not been populated via Get() method first.");
				}

				string value = (string)this._ticketContent?["fields"]?["System.WorkItemType"];

				return value;
			}
		}

		/// <summary>
		/// Get the Work Item Status
		/// </summary>
		public string State
		{
			get
			{
				if (null == this._ticketContent)
				{
					throw new InvalidOperationException("Ticket has not been populated via Get() method first.");
				}

				// status
				return this._state;
			}
			set
			{
				if (null == this._ticketContent)
				{
					throw new InvalidOperationException("Ticket has not been populated via Get() method first.");
				}
				
				this._state = value;
			}
		}
		/// <summary>
		/// Get the link to the full WorkItem in Azure DevOps
		/// </summary>
		public string ParentHref
		{
			get
			{
				string value = null;

				if (null == this._ticketContent)
				{
					throw new InvalidOperationException("Ticket has not been populated via Get() method first.");
				}

				foreach (var record in (JArray)this._ticketContent?["relations"])
				{
					string linkType = (string)record?["attributes"]?["name"];
					if ("Parent" == linkType)
					{
						value = (string)record?["url"];
					}
				}

				return value;
			}
		}

		public string Source
		{
			get
			{
				if (null == this._ticketContent)
				{
					throw new InvalidOperationException("Ticket has not been populated via Get() method first.");
				}

				return this._source;
			}
			set
			{
				if (null == this._ticketContent)
				{
					throw new InvalidOperationException("Ticket has not been populated via Get() method first.");
				}

				this._source = value;
			}
		}

		public bool UpdateState { get; set; }
		public string NewSource { get; set; }

		private AzDoWorkItem() { }

		/// <summary>
		/// Read a copy of an Azure DevOps Work Item
		/// </summary>
		/// <returns>success flag or throws exception on failure</returns>
		public async Task<bool> Get()
		{
			var encodedCredential = Encoding.ASCII.GetBytes($":{this._PAT}");
			string basic = Convert.ToBase64String(encodedCredential);

			// https://docs.microsoft.com/en-us/rest/api/azure/devops/wit/work%20items/get%20work%20item?view=azure-devops-rest-6.0
			// adding some extra query parameters to enrich the ticket data from  the call
			var uri = new Uri($"{this._ticketUri}?$expand=All&api-version=6.0");

			var request = new HttpRequestMessage(HttpMethod.Get, uri);
			request.Headers.Clear();
			request.Headers.Add("Authorization", $"Basic {basic}");
			request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

			var result = await this._httpClient.SendAsync(request);

			if (!result.IsSuccessStatusCode)
			{
				throw new Exception($"Failed to query the work item. (StatusCode : {result.StatusCode}, ReasonPhrase: {result.ReasonPhrase}, ReasonContent: {result.Content})");
			}

			await ProcessWorkItemResponse(result);

			return true;
		}

		private async Task ProcessWorkItemResponse(HttpResponseMessage result)
		{
			var responsePayload = "";
			try
			{
				responsePayload = await result.Content.ReadAsStringAsync();
				this._ticketContent = JObject.Parse(responsePayload);
				this._source = (string)this._ticketContent.SelectToken("$['fields']['Custom.Source']");
				this._retrievedSource = this._source;
				this._state = (string)this._ticketContent.SelectToken("$['fields']['System.State']");
				this._retrievedState = this._state;
			}
			catch
			{
				throw new Exception($"Failed parsing response payload. Payload: {responsePayload}");
			}
		}

		public async Task Update()
		{
			List<Dictionary<string, string>> payload = new List<Dictionary<string, string>> { };

			if (this.UpdateState)
			{
				if (this.Type.ToLowerInvariant() == "task")
				{
					var updateParams = new Dictionary<string, string>
					{
						{"op", "replace" },
						{"path", "/fields/System.State" },
						{"value", "Active" }
					};
					payload.Add(updateParams);
				}
				else if (this.Type.ToLowerInvariant() == "story" || this.Type.ToLowerInvariant() == "bug")
				{
					var updateParams = new Dictionary<string, string>
					{
						{"op", "replace" },
						{"path", "/fields/System.State" },
						{"value", "In Progress" }
					};
					payload.Add(updateParams);
				}
			}

			if (!string.IsNullOrEmpty(this.NewSource))
			{
				var updateParams = new Dictionary<string, string>
					{
						{"op", "replace" },
						{"path", "/fields/Custom.Source" },
						{"value", this.NewSource }
					};
				payload.Add(updateParams);
			}

			StringContent body = new StringContent(JsonConvert.SerializeObject(payload, Formatting.Indented), Encoding.UTF8, "application/json-patch+json");

			var encodedCredential = Encoding.ASCII.GetBytes($":{this._PAT}");
			string basic = Convert.ToBase64String(encodedCredential);
			var uri = new Uri($"{this._ticketUri}?$expand=All&api-version=6.0");

			var request = new HttpRequestMessage(HttpMethod.Patch, uri);
			request.Headers.Clear();
			request.Headers.Add("Authorization", $"Basic {basic}");
			request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json-patch+json"));
			request.Content = body;

			var result = await this._httpClient.SendAsync(request);

			if (!result.IsSuccessStatusCode)
			{
				throw new Exception($"Failed to update the work item. (StatusCode : {result.StatusCode}, ReasonPhrase: {result.ReasonPhrase}), ReasonContent: {result.Content}");
			}

			await ProcessWorkItemResponse(result);

			if (this.UpdateState)
			{
				if (this.State != "In Progress")
				{
					throw new Exception("Failed to update the parent work item to \"In Progress\" state.");
				}
			}

			if (!string.IsNullOrEmpty(this.NewSource))
			{
				if (this.Source != this.NewSource)
				{
					throw new Exception($"Failed to update source on child task to \" {this.NewSource} \".");
				}
			}
		}
	}
}
