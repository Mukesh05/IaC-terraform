﻿namespace AzDoListener.WorkItem
{
	using System.Threading.Tasks;

	public interface IAzDoWorkItem
	{
		int Id { get; }
		string ParentHref { get; }
		string State { get; }
		string Type { get; }
		string Source { get; }
		string NewSource { get; set; }
		bool UpdateState { get; set; }

		Task<bool> Get();
		Task Update();
	}
}