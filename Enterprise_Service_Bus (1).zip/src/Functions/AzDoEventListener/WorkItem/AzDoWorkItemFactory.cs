﻿namespace AzDoListener.WorkItem
{
	public class AzDoWorkItemFactory : IAzDoWorkItemFactory
	{
		/// <summary>
		/// Create an instance of the work item object
		/// </summary>
		/// <param name="uri">reference for the work item ticket in the Azure DevOps instance</param>
		/// <param name="pat">PAT token for authentication</param>
		public IAzDoWorkItem GetAzDoWorkItem(string uri, string pat)
		{
			return new AzDoWorkItem(uri, pat);
		}
	}
}
