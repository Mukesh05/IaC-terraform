﻿namespace AzDoListener.WorkItem
{
	public interface IAzDoWorkItemFactory
	{
		/// <summary>
		/// Create a Work Item Proxy Object from Given Inputs
		/// </summary>
		/// <param name="uri">Uri for DevOps object</param>
		/// <param name="pat">PAT for authentication</param>
		/// <returns>Work Item object if the action succeeds, null otherwise</returns>
		public IAzDoWorkItem GetAzDoWorkItem(string uri, string pat);
	}
}


