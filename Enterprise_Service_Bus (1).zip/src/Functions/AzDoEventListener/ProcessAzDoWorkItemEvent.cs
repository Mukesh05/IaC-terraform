using AzDoListener.Events;
using AzDoListener.Strategies;
using AzDoListener.WorkItem;
using System;
namespace AzDoListener
{
	using Microsoft.AspNetCore.Mvc.Infrastructure;
	using Microsoft.Azure.WebJobs;
	using Microsoft.Extensions.Configuration;
	using Microsoft.Extensions.Logging;
	using Newtonsoft.Json.Linq;
	using System;
	using System.Threading.Tasks;

	public class ProcessAzDoWorkItemEvent
	{
		IConfiguration _config;
		ILogger<ProcessAzDoWorkItemEvent> _logger;

		public ProcessAzDoWorkItemEvent(IConfiguration config, ILogger<ProcessAzDoWorkItemEvent> log)
		{
			_config = config;
			_logger = log;
		}

		/// <summary>
		/// Extract the correct event from the message with a known type
		/// </summary>
		/// <param name="log">logger</param>
		/// <param name="message">message object</param>
		/// <returns>Event object if parse was successful or null object if not</returns>
		private static IAzDoTicketEvent BuildEventFromMessage(JObject message, ILogger log)
		{
			switch ((string)message["eventType"])
			{
				case "workitem.updated":
					return AzDoTicketUpdateEvent.TryParse(message, log);
				case "workitem.created":
					return AzDoTicketCreateEvent.TryParse(message, log);
				default:
					throw new Exception($"Event type not supported. Event ID: {(string)message["id"]}, Event Type: {(string)message["eventType"]}");
			}

			//
		}

		/// <summary>
		/// If possible, create a strategy object
		/// </summary>
		/// <param name="log">logger</param>
		/// <param name="pat">Azure DevOps PAT Token</param>
		/// <param name="ticket">parsed event from message bus</param>
		/// <returns>strategy if applicable, null if not</returns>
		private ITicketEventStrategy BuildStrategyFromEvent(ILogger<ProcessAzDoWorkItemEvent> log,
															string pat,
															IAzDoTicketEvent ticket)
		{
			ITicketEventStrategy strategy = null;

			switch (ticket)
			{
				case AzDoTicketUpdateEvent update:
					strategy = new UpdateEventStrategy(pat,
												   log,
												   new AzDoWorkItemFactory(),
												   (AzDoTicketUpdateEvent)update);
					break;

				case AzDoTicketCreateEvent create:
					strategy = new CreateEventStrategy(pat,
													   log,
													   new AzDoWorkItemFactory(),
													   (AzDoTicketCreateEvent)create);
					break;
			}


			return strategy;
		}

		[FunctionName("ProcessAzDoUpdateEvent")]
		public async Task RunAsync(
			[ServiceBusTrigger("%topicname%", "%subscription%")]
			string mySbMsg)
		{
			string pat = _config.GetValue<string>("AzDevOpsListener:PAT");

			var message = JObject.Parse(mySbMsg);

			IAzDoTicketEvent parsedEvent = BuildEventFromMessage(message, _logger);

			// skip if no event could be derived from the message
			if (parsedEvent != null)
			{
				ITicketEventStrategy workflow = null;

				workflow = BuildStrategyFromEvent(_logger, pat, parsedEvent);

				await workflow.Execute();
			}
			else
			{
				_logger.LogTrace($"Skipping message: {mySbMsg}");
				_logger.LogInformation($"Skipping message: {message["id"]}");
			}

			_logger.LogInformation("-- Done --");
		}
	}
}