﻿using System.Threading.Tasks;

namespace SecHealthToServiceNow
{
	public interface IServiceNowSecurirtyEventsCreation
	{
		Task<SNowSecurityResponseModel> CreateSecurityEvent(string data);
	}
}