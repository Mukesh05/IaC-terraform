﻿using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace SecHealthToServiceNow
{
	public class SnowHelper : ISnowHelper
	{
		ILogger<SecHealthToServiceNow> _logger;
		IConfigurationRefresher _configRefresher;
		IConfiguration _config;
		IServiceNowSecurirtyEventsCreation _serviceNowSecurirtyEventsCreation;

		public SnowHelper(IConfiguration config,
								IConfigurationRefresher configRefresher,
								ILogger<SecHealthToServiceNow> logger,
								IServiceNowSecurirtyEventsCreation serviceNowSecurirtyEventsCreation)
		{
			_configRefresher = configRefresher;
			_config = config;
			_logger = logger;
			_serviceNowSecurirtyEventsCreation = serviceNowSecurirtyEventsCreation;
		}

		public async Task SendToSNow(string content)
		{
			SNowSecurityResponseModel response = new SNowSecurityResponseModel();
			try
			{
				response = await _serviceNowSecurirtyEventsCreation.CreateSecurityEvent(content);
			}
			catch (Exception ex)
			{
				throw new Exception($"Failed to send security event to Service Now. ({ex.Message})");
			};
		}

		public SNowEvent MapForSNowGeneral(string sbMessage)
		{
			var SecHealthTopicMessage = JsonConvert.DeserializeObject<SecHealthTopicMessage>(sbMessage);
			var sNowEvent = new SNowEvent
			{
				MessageKey = SecHealthTopicMessage.MessageKey,
				AzureTenantId = SecHealthTopicMessage.AzureTenantId,
				Type = SecHealthTopicMessage.Type,
				Description = SecHealthTopicMessage.Description,
				InitialEventTime = SecHealthTopicMessage.InitialEventTime,
				CreatedDateTime = SecHealthTopicMessage.CreatedDateTime,
				LastModifiedDateTime = SecHealthTopicMessage.LastModifiedDateTime,
				ShortDescription = SecHealthTopicMessage.ShortDescription,
				EventSource = SecHealthTopicMessage.EventSource,
				AlertSeverity = SecHealthTopicMessage.AlertSeverity,
				AdditionalInformation = SecHealthTopicMessage.AdditionalInformation,
				SecurityAPI = SecHealthTopicMessage.SecurityAPI,
				ResolutionState = SecHealthTopicMessage.ResolutionState,
				LastEventDateString = SecHealthTopicMessage.LastEventDateString
			};

			return sNowEvent;
		}
	}
}
