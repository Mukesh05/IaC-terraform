﻿using System;
using System.Threading.Tasks;

namespace SecHealthToServiceNow
{
	public interface ISnowHelper
	{
		SNowEvent MapForSNowGeneral(string SecHealthTopicMessage);
		Task SendToSNow(string content);
	}
}