﻿using System.Net.Http;
using System.Threading.Tasks;

namespace SecHealthToServiceNow.HttpHandler
{
	public interface IHttpClientHandler
	{
		HttpResponseMessage Get(string url, string accessToken);
		Task<HttpResponseMessage> GetAsync(string url, string accessToken);
		HttpResponseMessage Post(string url, HttpContent content, string accessToken);
		Task<HttpResponseMessage> PostAsync(string url, HttpContent content, string accessToken);
	}
}