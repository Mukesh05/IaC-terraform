﻿namespace SecHealthToServiceNow
{
	public class SecHealthTopicMessage
	{

		public string MessageKey { get; set; }
		public string AzureTenantId { get; set; }
		public string Type { get; set; }
		public string Description { get; set; }
		public string InitialEventTime { get; set; }
		public string CreatedDateTime { get; set; }
		public string LastModifiedDateTime { get; set; }
		public string ShortDescription { get; set; }
		public string EventSource { get; set; }
		public string AlertSeverity { get; set; }
		public string AdditionalInformation { get; set; }
		public string SecurityAPI { get; set; }
		public string ResolutionState { get; set; }
		public string LastEventDateString { get; set; }

	}
}