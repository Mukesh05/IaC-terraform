﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Common.ESB;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;


namespace SecHealthToServiceNow
{
	public class ServiceNowSecurirtyEventsCreation : IServiceNowSecurirtyEventsCreation
	{
		ILogger<SecHealthToServiceNow> _logger;
		IConfigurationRefresher _configRefresher;
		IConfiguration _config;

		public ServiceNowSecurirtyEventsCreation(IConfiguration config,
								IConfigurationRefresher configRefresher,
								ILogger<SecHealthToServiceNow> logger)
		{
			_logger = logger;
			_configRefresher = configRefresher;
			_config = config;
		}

		public async Task<SNowSecurityResponseModel> CreateSecurityEvent(string data)
		{
			//Get access token
			var instance = _config["ServiceNow:Instance"];
			var clientId = _config["ServiceNow:ClientId"];
			var clientSecret = _config["ServiceNow:Secret"];
			var userId = _config["ServiceNow:UserId"];
			var userPw = _config["ServiceNow:UserPassword"];

			IServiceNowOauthTokenProvider _serviceNowOauthTokenProvider = new ServiceNowOauthTokenProvider(instance,
																										   clientId,
																										   clientSecret,
																										   userId,
																										   userPw);

			string token = await _serviceNowOauthTokenProvider.GetBearerAccessToken();
			string url = $"https://{instance}/api/nesi/securityhealth/createEvent";

			//Post the request
			HttpWebRequest request = HttpWebRequest.CreateHttp(url);
			request.Method = WebRequestMethods.Http.Post;
			request.Headers.Add(HttpRequestHeader.Authorization, "Bearer " + token);
			request.ContentType = "application/json";
			var payload = Encoding.ASCII.GetBytes(data);
			request.ContentLength = payload.Length;

			using (var stream = await request.GetRequestStreamAsync())
			{
				await stream.WriteAsync(payload, 0, payload.Length);
			}

			try
			{
				var response = await request.GetResponseAsync();
				StreamReader sr = new StreamReader(response.GetResponseStream());
				string body = await sr.ReadToEndAsync();
				JObject json = JsonConvert.DeserializeObject<JObject>(body);
				if (json == null)
				{
					throw new Exception("ServiceNow returned nothing back!");
				}
				return json["result"].ToObject<SNowSecurityResponseModel>();
			}
			catch (WebException ex)
			{
				StreamReader sr = new StreamReader(ex.Response.GetResponseStream());
				string error = await sr.ReadToEndAsync();
				JObject json = JsonConvert.DeserializeObject<JObject>(error);
				throw new Exception(((string)json["result"]["message"]) + " /// " + ex.ToString());
			}
		}
	}
}
