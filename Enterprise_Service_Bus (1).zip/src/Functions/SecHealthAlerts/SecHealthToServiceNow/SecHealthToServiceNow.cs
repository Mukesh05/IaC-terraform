using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace SecHealthToServiceNow
{
	public class SecHealthToServiceNow
	{

		IConfigurationRefresher _configRefresher;
		IConfiguration _config;
		ILogger<SecHealthToServiceNow> _logger;
		ISnowHelper _snowHelper;

		public SecHealthToServiceNow(IConfiguration config,
									 IConfigurationRefresher configRefresher,
									 ILogger<SecHealthToServiceNow> logger,
									 ISnowHelper snowHelper)
		{
			_configRefresher = configRefresher;
			_config = config;
			_logger = logger;
			_snowHelper = snowHelper;
		}

		[FunctionName("SecHealthToServiceNow")]
        public async Task SecHealthToServiceNowSb([ServiceBusTrigger("%TopicName%", "%SubscriptionName%")] string mySbMsg,
			ExecutionContext context)
        {
			await ProcessSecHealthToServiceNowAsync(mySbMsg);
		}

		[FunctionName("SecHealthToServiceNowOnDemand")]
		public async Task<bool> SecHealthToServiceNowOnDemandAsync([HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequest req)
		{
			var testsbMessage = (req.Query["mySbMsg"]).ToString();
			return await ProcessSecHealthToServiceNowAsync(testsbMessage);
		}

		private async Task<bool> ProcessSecHealthToServiceNowAsync(String secHealthMessage)
		{
			_logger.LogInformation($"SecHealthToServiceNow function started execution at: {DateTime.Now}");

			try
			{
				var sNowEvent = _snowHelper.MapForSNowGeneral(secHealthMessage);
				_logger.LogInformation($"Mapped security message to Service Now event message with message key {sNowEvent.MessageKey}.");
				var sNoweventList = new List<SNowEvent> { sNowEvent };
				var sNowEventContent = JsonConvert.SerializeObject(sNoweventList);
				await _snowHelper.SendToSNow(sNowEventContent);
				_logger.LogInformation($"Sent message to Service Now with message key {sNowEvent.MessageKey}");
			}
			catch(Exception ex)
			{
				_logger.LogError($"Failed to send alert message to Service Now. ({ex.Message})");
				_logger.LogInformation($"SecHealthToServiceNow function finished execution at: {DateTime.Now}");
				return false;
			}

			_logger.LogInformation($"SecHealthToServiceNow function finished execution at: {DateTime.Now}");
			return true;
		}
	}
}
