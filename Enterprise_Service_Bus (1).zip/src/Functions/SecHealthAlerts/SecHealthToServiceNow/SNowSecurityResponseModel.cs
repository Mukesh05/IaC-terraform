﻿using Newtonsoft.Json;

namespace SecHealthToServiceNow
{
	public class SNowSecurityResponseModel
	{
		[JsonProperty("status")]
		public string Status { get; set; }

		[JsonProperty("message")]
		public string Message { get; set; }
	}
}