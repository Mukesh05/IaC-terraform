﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Common.ESB;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Moq.Protected;
using SecHealthSecEvents.Model;
using SecHealthSecEvents.Services;

namespace SecHealthSecEventsTests.Services
{
	[TestClass]
	public class AlertProcessorTests
	{
		Mock<IAzureGraphAuth> _mockAzureGraphAuth;
		Mock<IConfiguration> _mockConfiguration;
		Mock<ILogger<AlertProcessor>> _mockLogger;
		Mock<IPhishEmailStorage> _mockPhishEmailStorage;
		Mock<IESBSender> _mockEsbSender;

		[TestInitialize]
		public void Initialize()
		{
			_mockAzureGraphAuth = new Mock<IAzureGraphAuth>();
			_mockAzureGraphAuth.Setup(x => x.GetBearerTokenAsync(It.IsAny<string>())).ReturnsAsync(It.IsAny<string>);
			_mockConfiguration = new Mock<IConfiguration>();
			_mockLogger = new Mock<ILogger<AlertProcessor>>();
			_mockPhishEmailStorage = new Mock<IPhishEmailStorage>();
			_mockPhishEmailStorage.Setup(x => x.GetPhishEmailDetailsAsync(It.IsAny<string>(), It.IsAny<DateTime>())).ReturnsAsync((IEnumerable<EmailDetails>)null);
			_mockEsbSender = new Mock<IESBSender>();
		}

		[TestMethod]
		public async Task Process_ShouldReturnEventMessage_WhenAlertVenderProviderIsValid()
		{
			var mockHandler = new Mock<HttpMessageHandler>();
			mockHandler
				.Protected()
				.SetupSequence<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>())
				.ReturnsAsync(new HttpResponseMessage()
				{
					StatusCode = HttpStatusCode.OK,
					Content = new StringContent(alertResponseBody)
				});

			var httpClient = new HttpClient(mockHandler.Object);
			var mockHttpClientFactory = new Mock<IHttpClientFactory>();
			mockHttpClientFactory.Setup(_ => _.CreateClient("default")).Returns(httpClient);

			IAlertProcessor alertProcessor =
				new AlertProcessor(_mockConfiguration.Object,
								   _mockLogger.Object,
								   mockHttpClientFactory.Object,
								   _mockAzureGraphAuth.Object,
								   _mockPhishEmailStorage.Object,
								   _mockEsbSender.Object);

			List<Notification> notifications = new List<Notification>() {
				new Notification()
				{
					ChangeType = "update",
					Resource = "https://isg-prod.trafficmanager.net/security/alerts?$filter=status+eq+microsoft.graph.alertStatus%27newAlert%27",
					TentantId = "56c90202-7b8c-492e-bcae-01c71d54d60a",
					ResourceData = new ResourceData()
					{
						 Id = "67806444ea890d0a94680138d66476868f10a5c55fd0e03b6b67c1d3160bb8c7"
					}
				}
			};

			var messages = (List<EventMessage>)await alertProcessor.ProcessAndSendAlerts(notifications);
			Assert.IsTrue(messages.Count >= 1, "Failed to process an alert with a valid vender provider.");
		}

		[TestMethod]
		public async Task Process_ShouldReturnNoEventMessage_WhenAlertVenderProviderIsNotValid()
		{
			var mockHandler = new Mock<HttpMessageHandler>();
			mockHandler
				.Protected()
				.SetupSequence<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>())
				.ReturnsAsync(new HttpResponseMessage()
				{
					StatusCode = HttpStatusCode.OK,
					Content = new StringContent(alertWithNoVenderProviderResponseBody)
				});

			var httpClient = new HttpClient(mockHandler.Object);
			var mockHttpClientFactory = new Mock<IHttpClientFactory>();
			mockHttpClientFactory.Setup(_ => _.CreateClient("default")).Returns(httpClient);
			
			IAlertProcessor alertProcessor =
				new AlertProcessor(_mockConfiguration.Object,
								   _mockLogger.Object,
								   mockHttpClientFactory.Object,
								   _mockAzureGraphAuth.Object,
								   _mockPhishEmailStorage.Object,
								   _mockEsbSender.Object);

			List<Notification> notifications = new List<Notification>() {
				new Notification()
				{
					ChangeType = "update",
					Resource = "https://isg-prod.trafficmanager.net/security/alerts?$filter=status+eq+microsoft.graph.alertStatus%27newAlert%27",
					TentantId = "56c90202-7b8c-492e-bcae-01c71d54d60a",
					ResourceData = new ResourceData()
					{
						 Id = "67806444ea890d0a94680138d66476868f10a5c55fd0e03b6b67c1d3160bb8c7"
					}
				}
			};

			var messages = (List<EventMessage>)await alertProcessor.ProcessAndSendAlerts(notifications);


			Assert.IsTrue(messages.Count == 0, "Should not process an alert without a valid vend provider.");
		}

		#region Mock Notification Response Body
		string mockNotificationBody =
			@"{
				""value"": [
					{
						""resourceData"": {
							""id"": ""67806444ea890d0a94680138d66476868f10a5c55fd0e03b6b67c1d3160bb8c7"",
							""@odata.id"": ""https://isg-prod.trafficmanager.net/security/alerts?$filter=status+eq+microsoft.graph.alertStatus%27newAlert%27"",
							""@odata.type"": ""#Microsoft.Graph.alertStatus%27newAlert%27""
						},
						""subscriptionId"": ""88745977-fb30-4057-a831-94a8370350ef"",
						""resource"": ""https://isg-prod.trafficmanager.net/security/alerts?$filter=status+eq+microsoft.graph.alertStatus%27newAlert%27"",
						""changeType"": ""updated"",
						""clientState"": ""xxx"",
						""subscriptionExpirationDateTime"": ""2021-04-28T04:00:00-07:00"",
						""tenantId"": ""56c90202-7b8c-492e-bcae-01c71d54d60a""
					}
				]
			}";
		#endregion

		#region Mock Alert Response Body
		string alertResponseBody =
			@"{
				""@odata.context"": ""https://graph.microsoft.com/v1.0/$metadata#security/alerts/$entity"",
				""id"": ""67806444ea890d0a94680138d66476868f10a5c55fd0e03b6b67c1d3160bb8c7"",
				""azureTenantId"": ""56c90202-7b8c-492e-bcae-01c71d54d60a"",
				""azureSubscriptionId"": null,
				""riskScore"": null,
				""tags"": [],
				""activityGroupName"": null,
				""assignedTo"": null,
				""category"": ""UnfamiliarLocation"",
				""closedDateTime"": null,
				""comments"": [],
				""confidence"": null,
				""createdDateTime"": ""2021-04-16T16:02:47.4683194Z"",
				""description"": ""Sign-in with properties we‘ve not seen recently for the given user"",
				""detectionIds"": [],
				""eventDateTime"": ""2021-04-16T16:02:47.4683194Z"",
				""feedback"": null,
				""incidentIds"": [],
				""lastEventDateTime"": null,
				""lastModifiedDateTime"": ""2021-04-16T16:05:18.1400124Z"",
				""recommendedActions"": [],
				""severity"": ""low"",
				""sourceMaterials"": [],
				""status"": ""newAlert"",
				""title"": ""Unfamiliar sign-in properties"",
				""vendorInformation"": {
					""provider"": ""IPC"",
					""providerVersion"": null,
					""subProvider"": null,
					""vendor"": ""Microsoft""
				},
				""alertDetections"": [],
				""cloudAppStates"": [],
				""fileStates"": [],
				""hostStates"": [],
				""historyStates"": [],
				""investigationSecurityStates"": [],
				""malwareStates"": [],
				""messageSecurityStates"": [],
				""networkConnections"": [],
				""processes"": [],
				""registryKeyStates"": [],
				""securityResources"": [],
				""triggers"": [],
				""userStates"": [
					{
						""aadUserId"": ""edd21235-f280-44f8-a42e-efe3d3942462"",
						""accountName"": ""adm-collab"",
						""domainName"": ""nsdevelopment.onmicrosoft.com"",
						""emailRole"": ""unknown"",
						""isVpn"": null,
						""logonDateTime"": ""2021-04-16T16:02:47.4683194Z"",
						""logonId"": null,
						""logonIp"": ""192.69.224.0"",
						""logonLocation"": ""Oradell, New Jersey, US"",
						""logonType"": null,
						""onPremisesSecurityIdentifier"": null,
						""riskScore"": null,
						""userAccountType"": null,
						""userPrincipalName"": ""adm-collab@nsdevelopment.onmicrosoft.com""

					}
				],
				""uriClickSecurityStates"": [],
				""vulnerabilityStates"": []
			}";
		#endregion

		#region Mock Alert Response Body
		string alertWithNoVenderProviderResponseBody =
			@"{
				""@odata.context"": ""https://graph.microsoft.com/v1.0/$metadata#security/alerts/$entity"",
				""id"": ""67806444ea890d0a94680138d66476868f10a5c55fd0e03b6b67c1d3160bb8c7"",
				""azureTenantId"": ""56c90202-7b8c-492e-bcae-01c71d54d60a"",
				""azureSubscriptionId"": null,
				""riskScore"": null,
				""tags"": [],
				""activityGroupName"": null,
				""assignedTo"": null,
				""category"": ""UnfamiliarLocation"",
				""closedDateTime"": null,
				""comments"": [],
				""confidence"": null,
				""createdDateTime"": ""2021-04-16T16:02:47.4683194Z"",
				""description"": ""Sign-in with properties we‘ve not seen recently for the given user"",
				""detectionIds"": [],
				""eventDateTime"": ""2021-04-16T16:02:47.4683194Z"",
				""feedback"": null,
				""incidentIds"": [],
				""lastEventDateTime"": null,
				""lastModifiedDateTime"": ""2021-04-16T16:05:18.1400124Z"",
				""recommendedActions"": [],
				""severity"": ""low"",
				""sourceMaterials"": [],
				""status"": ""newAlert"",
				""title"": ""Unfamiliar sign-in properties"",
				""vendorInformation"": {
					""provider"": """",
					""providerVersion"": null,
					""subProvider"": null,
					""vendor"": ""Microsoft""
				},
				""alertDetections"": [],
				""cloudAppStates"": [],
				""fileStates"": [],
				""hostStates"": [],
				""historyStates"": [],
				""investigationSecurityStates"": [],
				""malwareStates"": [],
				""messageSecurityStates"": [],
				""networkConnections"": [],
				""processes"": [],
				""registryKeyStates"": [],
				""securityResources"": [],
				""triggers"": [],
				""userStates"": [
					{
						""aadUserId"": ""edd21235-f280-44f8-a42e-efe3d3942462"",
						""accountName"": ""adm-collab"",
						""domainName"": ""nsdevelopment.onmicrosoft.com"",
						""emailRole"": ""unknown"",
						""isVpn"": null,
						""logonDateTime"": ""2021-04-16T16:02:47.4683194Z"",
						""logonId"": null,
						""logonIp"": ""192.69.224.0"",
						""logonLocation"": ""Oradell, New Jersey, US"",
						""logonType"": null,
						""onPremisesSecurityIdentifier"": null,
						""riskScore"": null,
						""userAccountType"": null,
						""userPrincipalName"": ""adm-collab@nsdevelopment.onmicrosoft.com""

					}
				],
				""uriClickSecurityStates"": [],
				""vulnerabilityStates"": []
			}";
		#endregion
	}
}
