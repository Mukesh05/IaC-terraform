using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Moq.Protected;
using SecHealthAlertUpdater;
using SecHealthAlertUpdater.Services;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System.IO;
using System.Text;
using Microsoft.AspNetCore.Mvc;

namespace SecHealthAlertUpdate.Tests
{
    [TestClass]
    public class AlertUpdateTests
    {
		Mock<IConfiguration> _mockConfiguration;
		Mock<ILogger<AlertUpdate>> _mockLogger;
		Mock<IAzureGraphSecurityAPI> _mockAPI;

		[TestInitialize]
		public void Initialize()
		{
			_mockConfiguration = new Mock<IConfiguration>();
			_mockLogger = new Mock<ILogger<AlertUpdate>>();
			_mockAPI = new Mock<IAzureGraphSecurityAPI>();
		}

		[TestMethod]
        public async Task Run_ShouldReturnNotWhitelisted_WhenConfigContainsWhitelistSettingAsync()
        {
			// Note b at end of tenant id vs tenant id from request
			_mockConfiguration.Setup(x => x["SecHealthSecEvents:TenantIdWhiteList"]).Returns("56c90202-7b8c-492e-bcae-01c71d54d60b");

			AlertUpdate alertUpdate = new AlertUpdate(_mockConfiguration.Object, _mockLogger.Object, _mockAPI.Object);
			var httpRequest = CreateMockHttpRequest();
			var result = (OkObjectResult) await alertUpdate.Run(httpRequest);

			var actualMessage = result.Value.ToString();
			var expectedMessage = "{ message = Succesfully received requests but tenant id 56c90202-7b8c-492e-bcae-01c71d54d60a is not white listed. Not calling Azure Graph Security API. }";

			Assert.AreEqual(expectedMessage, actualMessage, "Expected tenant id not to be whitelisted.");
		}

		[TestMethod]
		public async Task Run_ShouldReturnWhitelisted_WhenConfigContainsWhitelistSettingAsync()
		{
			// Note a at end of tenant id vs tenant id from request
			_mockConfiguration.Setup(x => x["SecHealthSecEvents:TenantIdWhiteList"]).Returns("56c90202-7b8c-492e-bcae-01c71d54d60a");

			AlertUpdate alertUpdate = new AlertUpdate(_mockConfiguration.Object, _mockLogger.Object, _mockAPI.Object);
			var httpRequest = CreateMockHttpRequest();
			var result = (OkObjectResult)await alertUpdate.Run(httpRequest);

			var actualMessage = result.Value.ToString();
			var expectedMessage = "{ message = Succesfully processed alert 0e03d35eb32ddc299fd0dc0428b08ae0893dadd5308c52f33878f1339c3ff025. }";

			Assert.AreEqual(expectedMessage, actualMessage, "Expected tenant id to be whitelisted.");
		}

		private HttpRequest CreateMockHttpRequest()
		{
			var requestPayload = new
			{
				tenantId = "56c90202-7b8c-492e-bcae-01c71d54d60a",
				id = "0e03d35eb32ddc299fd0dc0428b08ae0893dadd5308c52f33878f1339c3ff025",
				alertFeedback = "unknown",
				alertStatus = "resolved",
				closeDate = "2021-06-28T03:25:24Z"
			};

			var json = JsonConvert.SerializeObject(requestPayload);

			var ms = new MemoryStream(Encoding.UTF8.GetBytes(json));
			var context = new DefaultHttpContext();
			var request = context.Request;
			request.Body = ms;
			request.ContentType = "application/json";

			return request;
		}
	}
}
