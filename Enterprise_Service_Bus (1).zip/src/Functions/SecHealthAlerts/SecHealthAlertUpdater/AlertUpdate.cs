using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using SecHealthAlertUpdater.Services;
using SecHealthAlertUpdater.Models;
using Microsoft.Extensions.Configuration;
using System.Linq;

namespace SecHealthAlertUpdater
{
    public class AlertUpdate
    {
		IConfiguration _config;
		ILogger<AlertUpdate> _logger;
		IAzureGraphSecurityAPI _api;

		public AlertUpdate(IConfiguration config, ILogger<AlertUpdate> logger, IAzureGraphSecurityAPI api)
		{
			_config = config;
			_logger = logger;
			_api = api;
		}

        [FunctionName("AlertUpdate")]
        public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");
			
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
			AlertUpdateDetails alertUpdateDetails = JsonConvert.DeserializeObject<AlertUpdateDetails>(requestBody);

			// To only allow certain alerts to be process from certain tenant, set comma delimited white list.
			// If the white list config doesn't exist, all alerts will be processed.
			// This is useful since Service Now Test can be receiving actual security alerts.
			var tenantIdWhiteList = _config["SecHealthSecEvents:TenantIdWhiteList"];
			if (!string.IsNullOrEmpty(tenantIdWhiteList))
			{
				_logger.LogInformation($"White listing of tenant ids is enabled. {tenantIdWhiteList}");
				var tenantIds = tenantIdWhiteList.ToLower().Split(',');
				if(!tenantIds.Contains(alertUpdateDetails.TenantId.ToLower()))
				{
					var message = $"Succesfully received requests but tenant id {alertUpdateDetails.TenantId} is not white listed. Not calling Azure Graph Security API.";
					_logger.LogInformation(message);

					return new OkObjectResult(new
					{
						message = message
					});
				}

				_logger.LogInformation($"Tenant id {alertUpdateDetails.TenantId} is in the white list.");
			}

			string result = string.Empty;
			try
			{
				result = await _api.UpdateAlertStateAsync(alertUpdateDetails);

				return new OkObjectResult(new
				{
					message = $"Succesfully processed alert {alertUpdateDetails.Id}."
				});
			}
			catch
			{
				return new BadRequestObjectResult(new
				{
					error = $"Failed to process alert {alertUpdateDetails.Id}."
				});
			}
        }
    }
}