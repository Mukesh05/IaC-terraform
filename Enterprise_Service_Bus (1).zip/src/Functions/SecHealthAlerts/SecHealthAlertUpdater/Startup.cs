﻿using System;
using System.IO;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Azure.Identity;
using System.Net.Http;
using SecHealthAlertUpdater.Services;

[assembly: FunctionsStartup(typeof(SecHealthAlertUpdater.Startup))]
namespace SecHealthAlertUpdater
{
	public class Startup : FunctionsStartup
	{
		public override void Configure(IFunctionsHostBuilder builder)
		{
			IConfigurationRefresher configRefresher = null;

			//Basic config setup
			var configBuilder = new ConfigurationBuilder()
				.SetBasePath(Directory.GetCurrentDirectory())
				.AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
				.AddEnvironmentVariables();

			var appconfigConnectionString = Environment.GetEnvironmentVariable("appconfigconnectionstring", EnvironmentVariableTarget.Process);

			// code snippet for VS credentials 

			Azure.Core.TokenCredential creds = new DefaultAzureCredential();
			var environment = Environment.GetEnvironmentVariable("AZURE_FUNCTIONS_ENVIRONMENT");
			if (string.Compare(environment, "development", true) == 0)
			{
				creds = new SharedTokenCacheCredential(new SharedTokenCacheCredentialOptions()
				{ TenantId = "a1a2578a-8fd3-4595-bb18-7d17df8944b0" });
			}

			//Azure App config setup
			configBuilder.AddAzureAppConfiguration(options =>
			{
				options.Connect(appconfigConnectionString)
				.Select("Common:*")
				.Select("ServiceNow:*")
				.Select("SecHealthSecEvents:*")
				.ConfigureKeyVault(kv =>
				{
					kv.SetCredential(creds); //NuGet Azure.Identity
				});
				configRefresher = options.GetRefresher();
			});

			IConfiguration config = configBuilder.Build();

			// Register Config services

			builder.Services.AddSingleton<IConfiguration>((services) =>
			{
				return config;
			});

			builder.Services.AddSingleton<IConfigurationRefresher>((services) =>
			{
				return configRefresher;
			});

			// Registering services

			builder.Services.AddSingleton<IAzureGraphAuth, AzureGraphAuth>();

			builder.Services.AddSingleton<IAzureGraphSecurityAPI, AzureGraphSecurityAPI>();

			builder.Services.AddHttpClient("default").ConfigurePrimaryHttpMessageHandler(() =>
			{
				return new HttpClientHandler()
				{
					UseCookies = false
				};
			});
		}
	}
}
