﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SecHealthAlertUpdater.Models;

namespace SecHealthAlertUpdater.Services
{
	public enum AlertFeedback
	{
		unknown,
		truePositive,
		falsePositive,
		benignPositive
	}

	public enum AlertStatus
	{
		unknown,
		newAlert,
		inProgress,
		resolved
	}

	public class AzureGraphSecurityAPI : IAzureGraphSecurityAPI
	{
		const string GET_ALERT_URL = "https://graph.microsoft.com/v1.0/security/alerts/{0}"; //{0} is alert id
		const string PATCH_ALERT_URL = "https://graph.microsoft.com/v1.0/security/alerts/{0}"; //{0} is alert id
		const string ACCEPT = "application/json";
		
		IConfiguration _config;
		ILogger<AzureGraphSecurityAPI> _logger;
		IAzureGraphAuth _auth;
		HttpClient _httpClient;

		public AzureGraphSecurityAPI(IConfiguration config,
									 ILogger<AzureGraphSecurityAPI> logger,
									 IHttpClientFactory httpClientFactory,
									 IAzureGraphAuth auth)
		{
			_config = config;
			_logger = logger;
			_auth = auth;
			_httpClient = httpClientFactory.CreateClient("default");
		}

		public async Task<string> UpdateAlertStateAsync(AlertUpdateDetails alertUpdateDetails)
		{
			var token = await _auth.GetBearerTokenAsync(alertUpdateDetails.TenantId);

			var getUrl = string.Format(GET_ALERT_URL, alertUpdateDetails.Id);
			var patchUrl = string.Format(PATCH_ALERT_URL, alertUpdateDetails.Id);

			// Retrieve the alert details first so we can get vendor info
			var result = await CallApiAsync<dynamic>(HttpMethod.Get, getUrl, token);

			// Build the payload to send to Graph Security API
			// https://docs.microsoft.com/en-us/graph/api/alert-update?view=graph-rest-1.0&tabs=http
			var vendorInformation = new
			{
				provider = result.vendorInformation.provider,
				vendor = result.vendorInformation.vendor
			};

			var alertDetails = new
			{
				closeDateTime = alertUpdateDetails.CloseDateTime.ToString("o"),
				feedback = alertUpdateDetails.AlertFeedback.ToString(),
				status = alertUpdateDetails.AlertStatus.ToString(),
				vendorInformation = vendorInformation
			};

			var payload = JsonConvert.SerializeObject(alertDetails);
			result = await CallApiAsync<dynamic>(HttpMethod.Patch, patchUrl, token, payload);

			return string.Empty;
		}

		/// <summary>
		/// Helper generic function to call 'GET' API endpoints
		/// </summary>
		private async Task<T> CallApiAsync<T>(HttpMethod httpMethod, string url, string token, string jsonPayload = null)
		{
			_logger.LogTrace($"Url endpoint to be called is {httpMethod.ToString()} : {url}");

			// Setup request to send
			HttpRequestMessage requestMessage;
			if (httpMethod == HttpMethod.Get)
			{
				requestMessage = new HttpRequestMessage(HttpMethod.Get, url);
			}
			else
			{
				requestMessage = new HttpRequestMessage(httpMethod, url);
				requestMessage.Content = new StringContent(jsonPayload);
			}

			requestMessage.Headers.Clear();
			requestMessage.Headers.Authorization = new AuthenticationHeaderValue("bearer", token);
			requestMessage.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue(ACCEPT));
			
			// Send request and validate for success
			var result = await _httpClient.SendAsync(requestMessage);
			if (!result.IsSuccessStatusCode)
			{
				var errorPayload = await result.Content.ReadAsStringAsync();

				string message = $@"Failed to call {url}. (StatusCode : {result.StatusCode}, Response : {errorPayload})";
				_logger.LogError(message);
				throw new Exception(message);
			}
			_logger.LogTrace($"Call to {url} was successful.");

			// Read the payload
			var payload = await result.Content.ReadAsStringAsync();
			_logger.LogTrace("Response payload was read ok.");

			T resultObj;
			try
			{
				resultObj = JsonConvert.DeserializeObject<T>(payload);
				_logger.LogTrace($"Payload converted to type {typeof(T).Name}.");
			}
			catch (Exception ex)
			{
				// Json payload didn't match type
				var message = $"Failed to deserialize payload to type {typeof(T).Name}. ({ex.Message})";
				_logger.LogError(message);
				throw new Exception(message);
			}

			return resultObj;
		}
	}
}
