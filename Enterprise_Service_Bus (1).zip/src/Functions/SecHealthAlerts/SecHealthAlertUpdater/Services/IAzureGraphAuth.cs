﻿using System.Threading.Tasks;

namespace SecHealthAlertUpdater.Services
{
	public interface IAzureGraphAuth
	{
		Task<string> GetBearerTokenAsync(string tenantId);
	}
}
