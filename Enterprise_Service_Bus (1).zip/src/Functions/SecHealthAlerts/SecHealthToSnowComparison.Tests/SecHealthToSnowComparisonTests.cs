using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;
using SecHealthToServiceNowComparison.Services;
using SecHealthToServiceNowComparison.Model;
using System.Collections.Generic;
using Newtonsoft.Json;
using Common.ESB;
using System;

namespace SecHealthToServiceNowComparisonTests
{
	[TestClass]
	public class SecHealthToServiceNowComparisonTests
	{
		Mock<IConfigurationRefresher> _configRefresher;
		Mock<IConfiguration> _config;
		Mock<ILogger<SecHealthToServiceNowComparison.SecHealthToServiceNowComparison>> _logger;
		Mock<IAzureIncidentFetcher> _azureIncidentFetcher;
		Mock<ISnowEventsFetcher> _snowAlertsFetcher;
		Mock<IServiceNowTableQuery> _serviceNowTableQuery;
		Mock<IAlertsMapping> _alertsMapping;

		[TestInitialize]
		public void Startup()
		{
			_configRefresher = new Mock<IConfigurationRefresher>();
			_configRefresher.Setup(cr => cr.TryRefreshAsync());
			_config = new Mock<IConfiguration>();
			_logger = TestHelper.GetMockedLoggerWithAutoSetup<SecHealthToServiceNowComparison.SecHealthToServiceNowComparison>();
			_azureIncidentFetcher = new Mock<IAzureIncidentFetcher>();
			_snowAlertsFetcher = new Mock<ISnowEventsFetcher>();
			_serviceNowTableQuery = new Mock<IServiceNowTableQuery>();
			_alertsMapping = new Mock<IAlertsMapping>();
		}

		[TestMethod]
		public void CompareSecHealthToServiceNow_CallsInsertIntoServiceNowTabletoAddIncident_ForNonMatchingSnowAlert()
		{
			SecHealthToServiceNowComparison.SecHealthToServiceNowComparison SecHealthToServiceNowComparison = new
									SecHealthToServiceNowComparison.SecHealthToServiceNowComparison(
									_config.Object, _configRefresher.Object,
									_logger.Object, _azureIncidentFetcher.Object,
									_snowAlertsFetcher.Object, _serviceNowTableQuery.Object, _alertsMapping.Object);

			var request = new Mock<HttpRequest>();
			
			var SNowAlertsObject = new SNowEvents
			{
				Result = new List<Result>() {
								new Result{
									TimeOfEvent = DateTime.UtcNow.AddDays(-1).ToString(),
									UAccountName  = "Seal for Life Global Dutch Holding B.V",
									Source = "Azure Security",
									State = "Open",
									MessageKey = "2517839168229999999_0c084ea2-027c-49c3-8c28-c5e138ec3291"
								},
								new Result{
									TimeOfEvent = DateTime.UtcNow.AddDays(-1).ToString(),
									UAccountName  = "Seal for Life Global Dutch Holding B.V",
									Source = "Azure Security",
									State = "Open",
									MessageKey = "2517839168229999999_0c084ea2-027c-49c3-8c28-c5e138ec3300"
								},
				}
			};

			var azureIncidentObject = new AzureIncidents
			{
				OdataContext = "https://api-us.security.microsoft.com/api/$metadata#Incidents",
				value = new List<Value>
				{
					new Value{
						alerts = new List<Alert>
						{
							 new Alert
							 {
								 creationTime = DateTime.UtcNow.AddDays(-1),
								 alertId = "2517839168229999999_0c084ea2-027c-49c3-8c28-c5e138ec3290",
								 providerAlertId = "2517839168229999999_0c084ea2-027c-49c3-8c28-c5e138ec3290"
							 }
						}
					},
					new Value{
						alerts = new List<Alert>
						{
							 new Alert
							 {
								 creationTime = DateTime.UtcNow.AddDays(-1),
								 alertId = "2517839168229999999_0c084ea2-027c-49c3-8c28-c5e138ec3291",
								 providerAlertId = "2517839168229999999_0c084ea2-027c-49c3-8c28-c5e138ec3291"
							 }
						}
					},
					new Value{
						alerts = new List<Alert>
						{
							 new Alert
							 {
								 creationTime = DateTime.UtcNow.AddDays(-1),
								 alertId = "2517839168229999999_0c084ea2-027c-49c3-8c28-c5e138ec3293",
								 providerAlertId = "2517839168229999999_0c084ea2-027c-49c3-8c28-c5e138ec3293"
							 }
						}
					}
				}
			};

			var snowAccount = new ServiceNowAccount
			{
				Account_name = "accountname1",
				Tenant_ids = "tenant1"
			};

			ServiceNowAccountResult ServiceNowAccountResult = new ServiceNowAccountResult
			{
				ServiceNowAccounts = new List<ServiceNowAccount> { snowAccount }
			};
			_serviceNowTableQuery.Setup(query => query.GetServiceNowTableData<ServiceNowAccountResult>("u_account_azure_event_mapping", It.IsAny<string>())).ReturnsAsync(ServiceNowAccountResult);
			_serviceNowTableQuery.Setup(query => query.InsertIntoServiceNowTable<dynamic>("incident", It.IsAny<string>())).ReturnsAsync("true");
			_alertsMapping.Setup(alerts => alerts.IsAlertAllowed(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(true);
			_snowAlertsFetcher.Setup(sf => sf.FetchSnowEvents(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(SNowAlertsObject);
			_azureIncidentFetcher.Setup(ai => ai.FetchIncidents(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(azureIncidentObject);
			_config.SetupGet(config => config["SecHealthToServiceNowComparison:CheckAlertsTotalHours"]).Returns("24");
			_config.SetupGet(config => config["SecHealthToServiceNowComparison:CheckAlertsFromCurrentDaysBack"]).Returns("1");

			var response = SecHealthToServiceNowComparison.CompareAzureSNowAlertsOnDemand(request.Object);
			dynamic dyn = JsonConvert.DeserializeObject(response.Result.Content.ReadAsStringAsync().Result);
			Assert.IsNull(((Newtonsoft.Json.Linq.JContainer)((Newtonsoft.Json.Linq.JContainer)((Newtonsoft.Json.Linq.JContainer)dyn).First).First).First);
			Assert.AreEqual("2517839168229999999_0c084ea2-027c-49c3-8c28-c5e138ec3290", ((Newtonsoft.Json.Linq.JContainer)((Newtonsoft.Json.Linq.JContainer)((Newtonsoft.Json.Linq.JContainer)dyn).Last).Last).First);
			Assert.AreEqual("2517839168229999999_0c084ea2-027c-49c3-8c28-c5e138ec3293", ((Newtonsoft.Json.Linq.JContainer)((Newtonsoft.Json.Linq.JContainer)((Newtonsoft.Json.Linq.JContainer)dyn).Last).Last).Last);

			_snowAlertsFetcher.Verify(sf => sf.FetchSnowEvents(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));
			_azureIncidentFetcher.Verify(ai => ai.FetchIncidents(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));
			_serviceNowTableQuery.Verify(query => query.InsertIntoServiceNowTable<dynamic>("incident", It.IsAny<string>()), Times.Exactly(2));
			_alertsMapping.Verify(alerts => alerts.IsAlertAllowed(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(2));

		}

		[TestMethod]
		public void CompareSecHealthToServiceNow_NoServiceNowCalls_IfAzureAlertsAreWithin30mins()
		{
			SecHealthToServiceNowComparison.SecHealthToServiceNowComparison SecHealthToServiceNowComparison = new
									SecHealthToServiceNowComparison.SecHealthToServiceNowComparison(
									_config.Object, _configRefresher.Object,
									_logger.Object, _azureIncidentFetcher.Object,
									_snowAlertsFetcher.Object, _serviceNowTableQuery.Object,_alertsMapping.Object);

			var request = new Mock<HttpRequest>();

			var SNowAlertsObject = new SNowEvents
			{
				Result = new List<Result>() {
								new Result{
									TimeOfEvent = DateTime.UtcNow.AddMinutes(-20).ToString(),
									UAccountName  = "Seal for Life Global Dutch Holding B.V",
									Source = "Azure Security",
									State = "Open",
									MessageKey = "2517839168229999999_0c084ea2-027c-49c3-8c28-c5e138ec3291"
								},
				}
			};

			var azureIncidentObject = new AzureIncidents
			{
				OdataContext = "https://api-us.security.microsoft.com/api/$metadata#Incidents",
				value = new List<Value>
				{
					new Value{
						alerts = new List<Alert>
						{
							 new Alert
							 {
								 creationTime = DateTime.UtcNow.AddMinutes(-20),
								 alertId = "2517839168229999999_0c084ea2-027c-49c3-8c28-c5e138ec3291",
								 providerAlertId = "2517839168229999999_0c084ea2-027c-49c3-8c28-c5e138ec3291"
							 }
						}
					}
				}
			};

			var snowAccount = new ServiceNowAccount
			{
				Account_name = "accountname1",
				Tenant_ids = "tenant1",
				Account_SysId = "tenant1"
			};

			ServiceNowAccountResult ServiceNowAccountResult = new ServiceNowAccountResult
			{
				ServiceNowAccounts = new List<ServiceNowAccount> { snowAccount }
			};
			_serviceNowTableQuery.Setup(query => query.GetServiceNowTableData<ServiceNowAccountResult>("u_account_azure_event_mapping", It.IsAny<string>())).ReturnsAsync(ServiceNowAccountResult);
			_serviceNowTableQuery.Setup(query => query.InsertIntoServiceNowTable<dynamic>("incident", It.IsAny<string>())).ReturnsAsync("true");

			_snowAlertsFetcher.Setup(sf => sf.FetchSnowEvents(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(SNowAlertsObject);
			_azureIncidentFetcher.Setup(ai => ai.FetchIncidents(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(azureIncidentObject);
			_config.SetupGet(config => config["SecHealthToServiceNowComparison:CheckAlertsTotalHours"]).Returns("24");
			_config.SetupGet(config => config["SecHealthToServiceNowComparison:CheckAlertsFromCurrentDaysBack"]).Returns("31");

			var response = SecHealthToServiceNowComparison.CompareAzureSNowAlertsOnDemand(request.Object);
			dynamic dyn = JsonConvert.DeserializeObject(response.Result.Content.ReadAsStringAsync().Result);
			Assert.IsNull(((Newtonsoft.Json.Linq.JContainer)((Newtonsoft.Json.Linq.JContainer)((Newtonsoft.Json.Linq.JContainer)dyn).First).First).First);
			Assert.IsNull(((Newtonsoft.Json.Linq.JContainer)((Newtonsoft.Json.Linq.JContainer)((Newtonsoft.Json.Linq.JContainer)dyn).Last).Last).Last);

			_azureIncidentFetcher.Verify(ai => ai.FetchIncidents(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));
			_snowAlertsFetcher.Verify(sf => sf.FetchSnowEvents(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));
			_serviceNowTableQuery.Verify(query => query.InsertIntoServiceNowTable<dynamic>("incident", It.IsAny<string>()), Times.Never);
		}
	}
}
