using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;
using SecHealthToServiceNowComparison.Services;
using SecHealthToServiceNowComparison.Model;
using System.Collections.Generic;
using Newtonsoft.Json;
using Common.ESB;
using System;

namespace SecHealthToServiceNowComparisonTests
{
	[TestClass]
	public class AlertsMappingTests
	{
		Mock<IConfiguration> _config;
		Mock<ILogger<SecHealthToServiceNowComparison.SecHealthToServiceNowComparison>> _logger;
		const string BROOKFIELDTENANTID = "daf884b0-be16-4f2a-8bbb-dc6099a56844";

		[TestInitialize]
		public void Startup()
		{
			_config = new Mock<IConfiguration>();
			_logger = TestHelper.GetMockedLoggerWithAutoSetup<SecHealthToServiceNowComparison.SecHealthToServiceNowComparison>();
		}

		[TestMethod]
		public void AlertsMapping_IsAlertAllowed_True_AllAlerts()
		{
			SecHealthToServiceNowComparison.Services.AlertsMapping AlertsMapping = new
									SecHealthToServiceNowComparison.Services.AlertsMapping(
									_config.Object,
									_logger.Object
									);

			var response = AlertsMapping.IsAlertAllowed(BROOKFIELDTENANTID, "Azure AD IP", "");
			Assert.IsTrue(response);
		}

		[TestMethod]
		public void AlertsMapping_IsAlertAllowed_True_IfNotAllowedAlertList()
		{
			SecHealthToServiceNowComparison.Services.AlertsMapping AlertsMapping = new
									SecHealthToServiceNowComparison.Services.AlertsMapping(
									_config.Object,
									_logger.Object
									);

			var response = AlertsMapping.IsAlertAllowed(BROOKFIELDTENANTID, "Office 365 Security and Compliance", "Admin Submission result completed Allowed");
			Assert.IsTrue(response);
		}

		[TestMethod]
		public void AlertsMapping_IsAlertAllowed_False_DefaultNotBrookFieldClient()
		{
			SecHealthToServiceNowComparison.Services.AlertsMapping AlertsMapping = new
									SecHealthToServiceNowComparison.Services.AlertsMapping(
									_config.Object,
									_logger.Object
									);

			var response = AlertsMapping.IsAlertAllowed("Not BROOKFIELDTENANTID", "Office 365 Security and Compliance", "Admin Submission result completed Allowed");
			Assert.IsFalse(response);
		}
	}
}
