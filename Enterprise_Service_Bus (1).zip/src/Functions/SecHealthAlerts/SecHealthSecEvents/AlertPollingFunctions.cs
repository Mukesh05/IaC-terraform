﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Logging;
using SecHealthSecEvents.Services;

namespace SecHealthSecEvents
{
	public class AlertPollingFunctions
	{
		IConfiguration _config;
		IConfigurationRefresher _configurationRefresher;
		ILogger<AlertPollingFunctions> _logger;
		IAlertPolling _alertPolling;
		ISecurityAlertProcessor _securityAlertProcessor;

		public AlertPollingFunctions(IConfiguration config,
									 IConfigurationRefresher configRefresher,
									 ILogger<AlertPollingFunctions> logger,
									 IAlertPolling alertPolling,
									 ISecurityAlertProcessor securityAlertProcessor)
		{
			_configurationRefresher = configRefresher;
			_config = config;
			_logger = logger;
			_alertPolling = alertPolling;
			_securityAlertProcessor = securityAlertProcessor;
		}


		[FunctionName("GetGraphSecurityAlerts")]
		public async Task GetGraphSecurityAlertsAsync([TimerTrigger("%TimerSchedule%")] TimerInfo myTimer, ExecutionContext context)
		{
			await RunAsync();
		}


		[FunctionName("ProcessAlertsOnDemand")]
		public async Task ProcessAlertsOnDemandAsync([HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req)
		{
			await RunAsync();
		}

		private async Task RunAsync()
		{
			_logger.LogInformation($"ProcessAlerts function started execution at: {DateTime.Now}");

			await _configurationRefresher.RefreshAsync();
			var alerts = await _alertPolling.GetAlertsToBeProcessedAsync();

			foreach (var alert in alerts)
			{
				try
				{
					await _securityAlertProcessor.ProcessAlertAsync(alert);
				}
				catch (Exception ex)
				{
					_logger.LogError($"Alert {alert.id} : {ex}");
				}
			}

			_logger.LogInformation($"ProcessAlerts function completed execution at: {DateTime.Now}");
		}
	}
}