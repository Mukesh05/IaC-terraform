using System.Collections.Generic;
using System.Threading.Tasks;
using SecHealthSecEvents.Model;

namespace SecHealthSecEvents.Services
{
	public interface IAlertProcessor
	{
		Task<IEnumerable<EventMessage>> ProcessAndSendAlerts(IEnumerable<Notification> notifications);
	}
}