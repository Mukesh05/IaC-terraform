﻿using System.Collections.Generic;
using System.Threading.Tasks;
using SecHealthSecEvents.Model;

namespace SecHealthSecEvents.Services
{
	public interface IAlertPolling
	{
		Task<IEnumerable<AlertResult>> GetAlertsToBeProcessedAsync();
	}
}
