﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace SecHealthSecEvents.Services
{
	public interface IGraphSecurityApi
	{
		Task<string> CreateSecurityAlertSubscriptionAsync(string tenantId,
														  string receiverUrl,
														  string subscriptionResource,
														  int expireDaysFromNow);

		Task<string> GetSecurityAlertSubscriptionsAsync(string tenantId);

		Task<string> GetAlertsAsync(string tenantId, DateTime fromUTC);

		Task<string> GetRiskDetectionAsync(string tenantId, string aadUserId);

		Task<string> GetRiskyUserAsync(string tenantId, string aadUserId);


	}
}
