using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Common.ESB;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SecHealthSecEvents.Model;

namespace SecHealthSecEvents.Services
{
	public class AlertProcessor : IAlertProcessor
	{
		const string GET_ALERT_URL = "https://graph.microsoft.com/v1.0/security/alerts/{0}"; //{0} is alert id
		const string GET_RISKYUSER_URL = "https://graph.microsoft.com/v1.0/identityProtection/riskyUsers/{0}"; //{0} is user id
		const string GET_RISK_DETECTION_URL = "https://graph.microsoft.com/v1.0/identityProtection/riskDetections?$filter=id eq '{0}'"; //{0} is alert id
		const string ACCEPT = "application/json";

		IConfiguration _config;
		ILogger<AlertProcessor> _logger;
		HttpClient _httpClient;
		IAzureGraphAuth _azureGraphAuth;
		IPhishEmailStorage _phishEmailStorage;
		IESBSender _eSBSender;

		string _currentToken = null;

		public AlertProcessor(IConfiguration configuration,
							  ILogger<AlertProcessor> logger,
							  IHttpClientFactory httpClientFactory,
							  IAzureGraphAuth azureGraphAuth,
							  IPhishEmailStorage phishEmailStorage,
							  IESBSender eSBSender)
		{
			_config = configuration;
			_logger = logger;
			_httpClient = httpClientFactory.CreateClient("default");
			_azureGraphAuth = azureGraphAuth;
			_phishEmailStorage = phishEmailStorage;
			_eSBSender = eSBSender;

		}

		/// <summary>
		/// Transform and enrich alert notification to a message and sent to message bus.
		/// </summary>
		public async Task<IEnumerable<EventMessage>> ProcessAndSendAlerts(IEnumerable<Notification> notifications)
		{
			// It is expected that each set of notifications will only come from
			// one tenant at any one time. We should never see a list with multiple
			// tenants. We will use the tenant id from the first notfication in the
			// list.

			if (((List<Notification>)notifications).Count < 1)
			{
				_logger.LogTrace("Empty notifications. Nothing to do.");
				return new List<EventMessage>();
			}

			var tenantId = ((List<Notification>)notifications)[0].TentantId;
			_currentToken = await _azureGraphAuth.GetBearerTokenAsync(tenantId);
			_logger.LogTrace("Retreived a bearer token.");

			List<EventMessage> eventMessages = new List<EventMessage>();
			foreach (var notification in notifications)
			{
				// Retrieve the alert
				var url = string.Format(GET_ALERT_URL, notification.ResourceData.Id);
				var alert = await CallApiAsync<AlertResult>(url, _currentToken);

				// Ignore alerts that don't have a vendor provider set
				if (string.IsNullOrEmpty(alert.vendorInformation.provider))
				{
					continue;
				}

				// Create a message based on the alert and put on the message bus.
				var message = await ConvertAlertToMessageAsync(alert);
				eventMessages.Add(message);
			}

			// Send the messages to the message bus
			_logger.LogInformation($"Sending {eventMessages.Count} to the message bus.");
			foreach (var message in eventMessages)
			{
				string json = JsonConvert.SerializeObject(message);
				await _eSBSender.SendMessageAsync(_config["SecHealthSecEvents:TopicName"], json);

				_logger.LogInformation($"Message sent -> {json}");
			}

			return eventMessages;
		}

		/// <summary>
		/// Transform and enrich the alert from the API to a message for service bus.
		/// </summary>
		private async Task<EventMessage> ConvertAlertToMessageAsync(AlertResult alert)
		{
			EventMessage eventMessage = new EventMessage();
			eventMessage.MessageKey = alert.id;
			eventMessage.AzureTenantId = alert.azureTenantId;
			eventMessage.Type = alert.category;
			eventMessage.ResolutionState = alert.status;
			eventMessage.Description = alert.description;
			eventMessage.InitialEventTime = alert.eventDateTime.ToString();
			eventMessage.CreatedDateTime = alert.createdDateTime.ToString();
			eventMessage.LastModifiedDateTime = alert.lastModifiedDateTime.ToString();
			eventMessage.ShortDescription = alert.title;
			eventMessage.EventSource = alert.vendorInformation.provider;
			eventMessage.AlertSeverity = alert.severity;
			eventMessage.AdditionalInformation = JsonConvert.SerializeObject(alert);

			// Add extra info based on provider type.
			switch (alert.vendorInformation.provider.ToLower())
			{
				// Identity Protection Alerts
				case "ipc":
					if (alert.userStates != null && alert.userStates.Count > 0)
					{
						var json = JObject.Parse(eventMessage.AdditionalInformation);

						// Enrich with risk user data
						var riskyUser = await GetRiskyUserDetailsAsync(alert.userStates);
						if (riskyUser != null)
						{
							eventMessage.AlertSeverity = riskyUser.riskLevel;
							json.Add("riskLevel", riskyUser.riskLevel);
						}

						//  with risk detection data
						var riskDetectionResults = await GetRiskDetectionDetails(alert.userStates);
						if (riskDetectionResults != null)
						{
							var riskDetail = riskDetectionResults.value[0].riskDetail;
							var riskState = riskDetectionResults.value[0].riskState;
							if (!string.IsNullOrEmpty(riskState) && riskState != "atRisk" && riskState != "confirmedCompromised")
							{
								eventMessage.ResolutionState = "Closing";
							}

							json.Add("riskDetail", riskDetail);
							json.Add("riskState", riskState);
						}

						eventMessage.AdditionalInformation = json.ToString();
					}
					else
					{
						_logger.LogWarning($"'userStates' is empty for ipc alert. alert id : {alert.id}");
					}
					break;

				// Microsoft Cloud App Security alerts
				case "mcas":
					if (alert.userStates != null && alert.userStates.Count > 0)
					{
						eventMessage.ShortDescription = $"{alert.title} : {alert.userStates[0].userPrincipalName}";
					}
					else
					{
						_logger.LogWarning($"'userStates' is empty for mcas alert. alert id : {alert.id}");
					}
					break;

				// Microsoft Defender ATP alerts
				case "wdatp":
				case "microsoft defender atp":
					eventMessage.ShortDescription = $"{alert.title} : {alert.sourceMaterials}";
					break;

				// O365 Sec and Compliance alerts
				case "office 365 security and compliance":
					if (alert.title.ToLower().Equals("user reported phish"))
					{
						var emailResult = await GetPhishEmailDetailsAsync(alert.azureTenantId, alert.userStates, alert.eventDateTime.ToString());
						if (emailResult != null)
						{
							var json = JObject.Parse(eventMessage.AdditionalInformation);
							json.Add(JObject.FromObject(emailResult));
						}
					}
					else
					{
						_logger.LogWarning("Only 'user reported phish' is supported for 'office 365 security and compliance'.");
					}
					break;
			}

			return eventMessage;
		}

		/// <summary>
		/// Call API to try and get risky user details for specified user.
		/// </summary>
		private async Task<RiskyUserResult> GetRiskyUserDetailsAsync(List<UserState> userStates)
		{
			// User the first entry.
			var userId = userStates[0].aadUserId;
			var url = string.Format(GET_RISKYUSER_URL, userId);

			try
			{
				var riskyUserResult = await CallApiAsync<RiskyUserResult>(url, _currentToken);
				return riskyUserResult;
			}
			catch (Exception ex)
			{
				// We don't want processing to stop for a Risky User error so just log it.
				_logger.LogError($"Failed to get Risky User details for {userStates[0].aadUserId} ({userStates[0].userPrincipalName}). ({ex.Message})");
			}

			return null;
		}

		/// <summary>
		/// Call API to try and get risk detection details for specified user.
		/// </summary>
		private async Task<RiskDetectionResult> GetRiskDetectionDetails(List<UserState> userStates)
		{
			var userId = userStates[0].aadUserId;
			var url = string.Format(GET_RISK_DETECTION_URL, userId);

			try
			{
				var riskDetectionResults = await CallApiAsync<RiskDetectionResult>(url, _currentToken);
				if (riskDetectionResults.value.Count == 0)
				{
					return null;
				}
				else
				{
					return riskDetectionResults;
				}
			}
			catch (Exception ex)
			{
				// We don't want processing to stop for a Risk Detection error so just log it.
				_logger.LogError($"Failed to get Risk Detection details for {userStates[0].aadUserId} ({userStates[0].userPrincipalName}). ({ex.Message})");
			}

			return null;
		}

		/// <summary>
		/// Attempt to retrieve phish emails details that are in storage.
		/// </summary>
		private async Task<PhishEmailResult> GetPhishEmailDetailsAsync(string tenantid, List<UserState> userStates, string eventDateTime)
		{
			string[] formats = {"M/d/yyyy h:mm:ss tt", "M/d/yyyy h:mm tt",
								"MM/dd/yyyy hh:mm:ss", "M/d/yyyy h:mm:ss",
								"M/d/yyyy hh:mm tt", "M/d/yyyy hh tt",
								"M/d/yyyy h:mm", "M/d/yyyy h:mm",
								"MM/dd/yyyy hh:mm", "M/dd/yyyy hh:mm",
								"yyyy'-'MM'-'dd'T'HH':'mm':'ss.fffffff'Z'", "d/M/yyyy H:mm:ss"};

			DateTime formatedEventDateTime;
			if (!DateTime.TryParseExact(eventDateTime, formats, CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal, out formatedEventDateTime))
			{
				return null;
			}

			// Get the email details from storage
			var emailSender = userStates.Where(x => x.emailRole.ToLower() == "sender").Select(x => x.userPrincipalName).FirstOrDefault();
			var emailReceiver = userStates.Where(x => x.emailRole.ToLower() == "recipient").Select(x => x.userPrincipalName).FirstOrDefault();
			var emailDetails = await _phishEmailStorage.GetPhishEmailDetailsAsync(tenantid, formatedEventDateTime);
			var emailFromSender = emailDetails.Where(x => CompareEmails(x.EmailSender, emailSender));

			EmailDetails email;
			if (emailFromSender.Count() > 1)
			{
				// If there are multiple emails from this sender for this time period, use the
				// one with the same receiver.
				var emailFromSenderAndReceiver = emailFromSender.Where(x => CompareEmails(x.EmailReceiver, emailReceiver));

				//Please Note if there are multiple matching entities, then the closest one is picked. But there is no certainty that the chosen entity is perfect match.
				var nearestDiff = emailFromSenderAndReceiver.Min(ed => Math.Abs(Convert.ToInt64(ed.RowKey) - formatedEventDateTime.Ticks));
				email = emailFromSenderAndReceiver.Where(ed => Math.Abs(Convert.ToInt64(ed.RowKey) - formatedEventDateTime.Ticks) == nearestDiff).First();
			}
			else
			{
				// This is the only email from this sender for this time period so we assume this
				// is the match.
				email = emailFromSender.FirstOrDefault();
			}

			if (email == null)
			{
				return null;
			}

			return new PhishEmailResult()
			{
				ClientName = email.ClientName,
				From = email.EmailSender,
				To = email.EmailReceiver,
				EmailReceivedTime = email.OriginalPhishMessageDate,
				EmailSubject = email.EmailSubject,
				IsSimulation = email.IsSimulation,
				XForefrontAntispamReport = email.XForefrontAntispamReport,
				AuthenticationResults = email.AuthenticationResults
			};
		}

		/// <summary>
		/// Helper method to compare two emails to check if they are the same.
		/// </summary>
		private bool CompareEmails(string sourceEmail, string targetEmail)
		{
			string RegexPattern = @"\b[A-Z0-9._-]+@[A-Z0-9][A-Z0-9.-]{0,61}[A-Z0-9]\.[A-Z.]{2,6}\b";

			Match match = Regex.Match(sourceEmail, RegexPattern, RegexOptions.IgnoreCase);
			var email1 = match.ToString();

			match = Regex.Match(targetEmail, RegexPattern, RegexOptions.IgnoreCase);
			var email2 = match.ToString();

			return string.Equals(email1, email2, StringComparison.InvariantCultureIgnoreCase);
		}

		/// <summary>
		/// Helper generic function to call 'GET' API endpoints
		/// </summary>
		private async Task<T> CallApiAsync<T>(string url, string token)
		{
			_logger.LogTrace($"Url endpoint to be called is {url}");

			// Setup request to send
			var requestMessage = new HttpRequestMessage(HttpMethod.Get, url);
			requestMessage.Headers.Clear();
			requestMessage.Headers.Authorization = new AuthenticationHeaderValue("bearer", token);
			requestMessage.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue(ACCEPT));

			// Send request and validate for success
			var result = await _httpClient.SendAsync(requestMessage);
			if (!result.IsSuccessStatusCode)
			{
				var errorPayload = await result.Content.ReadAsStringAsync();

				string message = $@"Failed to call {url}. (StatusCode : {result.StatusCode}, Response : {errorPayload})";
				_logger.LogError(message);
				throw new Exception(message);
			}
			_logger.LogTrace($"Call to {url} was successful.");

			// Read the payload and parse out the access token.
			var payload = await result.Content.ReadAsStringAsync();
			_logger.LogTrace("Response payload was read ok.");

			T resultObj;
			try
			{
				resultObj = JsonConvert.DeserializeObject<T>(payload);
				_logger.LogTrace($"Payload converted to type {typeof(T).Name}.");
			}
			catch (Exception ex)
			{
				// Json payload didn't match type
				var message = $"Failed to deserialize payload to type {typeof(T).Name}. ({ex.Message})";
				_logger.LogError(message);
				throw new Exception(message);
			}

			return resultObj;
		}
	}
}