﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.Cosmos.Table;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;


namespace SecHealthSecEvents.Services
{
	public class PhishEmailStorage : IPhishEmailStorage
	{
		IConfiguration _config;
		ILogger<PhishEmailStorage> _logger;
		
		public PhishEmailStorage(IConfiguration config, ILogger<PhishEmailStorage> logger)
		{
			_config = config;
			_logger = logger;
		}

		/// <summary>
		/// Return email details in storage based on the parameters provided.
		/// </summary>
		/// <param name="tenentId"></param>
		/// <param name="alertDateTime"></param>
		/// <param name="emailSender"></param>
		/// <param name="emailReceiver"></param>
		/// <returns></returns>
		public async Task<IEnumerable<EmailDetails>> GetPhishEmailDetailsAsync(string tenentId, DateTime alertDateTime)
		{
			var connectionString = _config["SecHealthSecEvents:PhishEmailStorageConnString"];
			var tableName = $"EmailDetails{tenentId.Replace("-", string.Empty)}";

			CloudStorageAccount storageAccount = CloudStorageAccount.Parse(connectionString);
			CloudTableClient tableClient = storageAccount.CreateCloudTableClient(new TableClientConfiguration());
			CloudTable cloudTable = tableClient.GetTableReference(tableName);

			if(!await cloudTable.CreateIfNotExistsAsync())
			{
				_logger.LogInformation($"Table {tableName} already exists.");
			}
			else
			{
				_logger.LogInformation($"Created new table {tableName}");
			}

			int numberOfMinutes = 5;
			if(!int.TryParse(_config["SecHealthSecEvents:NumOfMinutesForPhishEmailTimeSpan"], out numberOfMinutes))
			{
				numberOfMinutes = 5;
			}
			var startEmailTime = DateTime.SpecifyKind(alertDateTime.AddMinutes(numberOfMinutes * -1), DateTimeKind.Utc);
			var endEmailTime = DateTime.SpecifyKind(alertDateTime.AddMinutes(numberOfMinutes), DateTimeKind.Utc);

			var x1 = TableQuery.GenerateFilterConditionForDate("PhishReportedDateForAlerts", QueryComparisons.GreaterThanOrEqual, startEmailTime);
			var x2 = TableQuery.GenerateFilterConditionForDate("PhishReportedDateForAlerts", QueryComparisons.LessThanOrEqual, endEmailTime);			
			var filter = TableQuery.CombineFilters(x1, TableOperators.And, x2);

			TableQuery<EmailDetails> query = new TableQuery<EmailDetails>()
			{
				FilterString = filter
			};

			var results = cloudTable.ExecuteQuery<EmailDetails>(query);
			return results;
		}
	}

	public class EmailDetails : TableEntity
	{
		public string AuthenticationResults { get; set; }
		public string ClientName { get; set; }
		public string EmailBody { get; set; }
		public string EmailReceiver { get; set; }
		public string EmailSender { get; set; }
		public string EmailSubject { get; set; }
		public bool IsSimulation { get; set; }
		public DateTime OriginalPhishMessageDate { get; set; }
		public DateTime PhishReportedDateForAlerts { get; set; }
		public string XForefrontAntispamReport { get; set; }
	}
}
