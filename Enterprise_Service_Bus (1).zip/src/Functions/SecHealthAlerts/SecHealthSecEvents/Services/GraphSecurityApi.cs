﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using SecHealthSecEvents.Model;

namespace SecHealthSecEvents.Services
{
	public class GraphSecurityApi : IGraphSecurityApi
	{
		const string SUBSCRIPTION_URL = "https://graph.microsoft.com/v1.0/subscriptions";
		const string ACCEPT = "application/json";
		const string ALERTS_URL = "https://graph.microsoft.com/v1.0/security/alerts";
		const string RISK_DETECTION_URL = "https://graph.microsoft.com/v1.0/identityProtection/riskDetections";
		const string RISKY_USER_URL = "https://graph.microsoft.com/v1.0/identityProtection/riskyUsers";

		ILogger<GraphSecurityApi> _logger;
		HttpClient _httpClient;
		IAzureGraphAuth _azureGraphAuth;

		public GraphSecurityApi(ILogger<GraphSecurityApi> logger, IHttpClientFactory httpClientFactory, IAzureGraphAuth azureGraphAuth)
		{
			_logger = logger;
			_httpClient = httpClientFactory.CreateClient("default");
			_azureGraphAuth = azureGraphAuth;
		}

		/// <summary>
		/// Subscribe to Azure Security Graph events.
		/// </summary>
		public async Task<string> CreateSecurityAlertSubscriptionAsync(string tenantId,
																	   string notificationUrl,
																	   string subscriptionResource,
																	   int expireDaysFromNow)
		{
			if(expireDaysFromNow > 29)
			{
				throw new ArgumentException("expireDaysFromNow max is 29 days");
			}

			var token = await _azureGraphAuth.GetBearerTokenAsync(tenantId);

			//Create subscription payload.
			var expirationDate = string.Format("{0:O}", DateTime.UtcNow.AddDays(expireDaysFromNow)); //29 days max
			var payload = new
			{
				changeType = "updated",
				notificationUrl = notificationUrl,
				resource = subscriptionResource,
				expirationDateTime = expirationDate,
				clientState = "somesecretvalue"
			};

			var jsonPaylaod = JsonConvert.SerializeObject(payload);
			var content = new StringContent(jsonPaylaod, Encoding.UTF8, "application/json");

			// Setup request to send
			var requestMessage = new HttpRequestMessage(HttpMethod.Post, SUBSCRIPTION_URL);
			requestMessage.Headers.Clear();
			requestMessage.Headers.Authorization = new AuthenticationHeaderValue("bearer", token);
			requestMessage.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue(ACCEPT));
			requestMessage.Content = content;

			// Send request and validate for success
			var result = await _httpClient.SendAsync(requestMessage);
			if (!result.IsSuccessStatusCode)
			{
				var errorPayload = await result.Content.ReadAsStringAsync();

				string message = $@"Failed to call {SUBSCRIPTION_URL}. (StatusCode : {result.StatusCode}, Response : {errorPayload})";
				_logger.LogError(message);
				throw new Exception(message);
			}
			_logger.LogTrace($"Call to {SUBSCRIPTION_URL} was successful.");

			var response = await result.Content.ReadAsStringAsync();

			return response;
		}

		/// <summary>
		/// Return the subscriptions or Security Alerts if it exists.
		/// </summary>
		public async Task<string> GetSecurityAlertSubscriptionsAsync(string tenantId)
		{
			var token = await _azureGraphAuth.GetBearerTokenAsync(tenantId);
			var result = await CallApiAsync<string>(SUBSCRIPTION_URL, token);

			return result;
		}

		/// <summary>
		/// Helper generic function to call 'GET' API endpoints
		/// </summary>
		private async Task<string> CallApiAsync<T>(string url, string token)
		{
			_logger.LogTrace($"Url endpoint to be called is {url}");

			// Setup request to send
			var requestMessage = new HttpRequestMessage(HttpMethod.Get, url);
			requestMessage.Headers.Clear();
			requestMessage.Headers.Authorization = new AuthenticationHeaderValue("bearer", token);
			requestMessage.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue(ACCEPT));

			// Send request and validate for success
			var result = await _httpClient.SendAsync(requestMessage);
			if (!result.IsSuccessStatusCode)
			{
				var errorPayload = await result.Content.ReadAsStringAsync();

				string message = $@"Failed to call {url}. (StatusCode : {result.StatusCode}, Response : {errorPayload})";
				_logger.LogError(message);
				throw new Exception(message);
			}
			_logger.LogTrace($"Call to {url} was successful.");

			// Read the payload and parse out the access token.
			var payload = await result.Content.ReadAsStringAsync();
			_logger.LogTrace("Response payload was read ok.");

			return payload;
		}

		/// <summary>
		/// Get the Azure Graph Security alerts back from 'fromUTC'
		/// </summary>
		public async Task<string> GetAlertsAsync(string tenantId, DateTime fromUTC)
		{
			//Build the url with query parameters.
			var dateTimeString = fromUTC.ToString("yyyy-MM-ddTHH:mm:ssZ");
			var queryParams = $"?$orderby=createdDateTime desc&$filter=createdDateTime ge {dateTimeString}";
			var url = $"{ALERTS_URL}{queryParams}";

			var token = await _azureGraphAuth.GetBearerTokenAsync(tenantId);
			var response = await CallApiAsync<string>(url, token);

			return response;
		}

		/// <summary>
		/// Get Risk Detection details of the specified AAD user.
		/// </summary>		
		public async Task<string> GetRiskDetectionAsync(string tenantId, string alertId)
		{
			var url = $"{RISK_DETECTION_URL}?$filter=id eq '{alertId}'";
			var token = await _azureGraphAuth.GetBearerTokenAsync(tenantId);
			var response = await CallApiAsync<string>(url, token);

			return response;
		}

		/// <summary>
		/// Get Risky User details of the specified AAD user.
		/// </summary>
		public async Task<string> GetRiskyUserAsync(string tenantId, string aadUserId)
		{
			var url = $"{RISKY_USER_URL}/{aadUserId}";
			var token = await _azureGraphAuth.GetBearerTokenAsync(tenantId);
			var response = await CallApiAsync<string>(url, token);

			return response;
		}
	}
}
