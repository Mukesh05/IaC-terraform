﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.ESB;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SecHealthSecEvents.Model;

namespace SecHealthSecEvents.Services
{
	/// <summary>
	/// This class determines what alerts from security graph api are
	/// not alread in Service Now. These alerts still need to be processed
	/// and sent to Service Now.
	/// </summary>
	public class AlertPolling : IAlertPolling
	{
		IConfiguration _config;
		ILogger<AlertPolling> _logger;
		IServiceNowTableQuery _serviceNowTableQuery;
		IGraphSecurityApi _graphSecurityApi;

		/// <summary>
		/// Constructor
		/// </summary>
		public AlertPolling(IConfiguration config,
							ILogger<AlertPolling> logger,
							IServiceNowTableQuery serviceNowTableQuery,
							IGraphSecurityApi graphSecurityApi)
		{
			_config = config;
			_logger = logger;
			_serviceNowTableQuery = serviceNowTableQuery;
			_graphSecurityApi = graphSecurityApi;
		}

		/// <summary>
		/// Add new alerts from graph in to Service Now.
		/// </summary>
		public async Task<IEnumerable<AlertResult>> GetAlertsToBeProcessedAsync()
		{
			var checkAlertsFromConfig = 30;
			if(!int.TryParse(_config["SecHealthSecEvents:CheckAlertsFromLastXMins"], out checkAlertsFromConfig))
			{
				checkAlertsFromConfig = 30;
			}
			var checkAlertsFrom = DateTime.UtcNow.AddMinutes(-checkAlertsFromConfig);

			List<AlertResult> alertsToBeProcessed = new List<AlertResult>();

			//Process each client that is enabled for security health
			var accounts = await GetClientsEnabledForAzureSecurityAsync();
			foreach (var account in accounts["result"])
			{
				var accountName = (string)account["u_account.name"];
				var accountSysId = (string)account["u_account.sys_id"];
				var accountTenantIds = (string)account["u_tenant_ids"];

				//Process for one or more tenants for each client
				foreach(var id in accountTenantIds.Split(','))
				{
					//Figure out what alerts from Graph are not yet in Service Now for current Tenant
					var alertsFromGraphResult = await _graphSecurityApi.GetAlertsAsync(id, checkAlertsFrom);
					var alertsFromGraph = JsonConvert.DeserializeObject<AlertResults>(alertsFromGraphResult).Alerts;
					var alertsFromSnow = await GetAzureSecurityEventsFromSnow(accountSysId, checkAlertsFrom);
					var alertsToAddToSnow = GetAlertsFromGraphNotInSnow(alertsFromGraph, alertsFromSnow);

					alertsToBeProcessed.AddRange(alertsToAddToSnow);
					_logger.LogInformation($"Found {alertsToAddToSnow.Count()} security alerts to be processed for {accountName} from tenant {id}.");
				}
			}

			return alertsToBeProcessed;
		}

		/// <summary>
		/// Return the alerts from graph are not yet in Service Now.
		/// </summary>		
		private IEnumerable<AlertResult> GetAlertsFromGraphNotInSnow(List<AlertResult> alertsFromGraph, List<string> alertsFromSnow)
		{
			var alertsFromGraphIds = alertsFromGraph.Select(x => x.id).ToList();
			var missingAlertsFromSnow = alertsFromGraphIds.Except(alertsFromSnow);

			var results = alertsFromGraph.Where(x => missingAlertsFromSnow.Any(y => string.Compare(x.id, y, true) == 0)).ToList();

			return results;
		}

		/// <summary>
		/// Retrieve Azure Security events in Service Now. Only the message key of the event is required.
		/// </summary>
		private async Task<List<string>> GetAzureSecurityEventsFromSnow(string accountSysId, DateTime atOrAfter)
		{
			string snTable = "em_event";
			string snQuery = $"sysparm_query=sys_created_on>={atOrAfter.ToString("yyyy-MM-dd HH:mm:ss")}^" +
											 $"u_account.sys_id={accountSysId}^source=Azure Security&" +
							 "sysparm_fields=message_key";

			var result = await _serviceNowTableQuery.GetServiceNowTableData<JObject>(snTable, snQuery);
			var messageKeyList = result["result"].Select(x => (string)x["message_key"]).ToList();

			return messageKeyList;
		}

		/// <summary>
		/// Retrieve Service Now data for accounts that are enabled for Azure Security.
		/// </summary>
		private async Task<JObject> GetClientsEnabledForAzureSecurityAsync()
		{
			string snTable = "u_account_azure_event_mapping";
			string snQuery = "sysparm_query=u_enable_azure_security_alert_and_snow_incident_comparisn=true&" +
							 "sysparm_fields=u_account.name,u_account.sys_id,u_tenant_ids";

			var result = await _serviceNowTableQuery.GetServiceNowTableData<JObject>(snTable, snQuery);

			return result;
		}
	}
}
