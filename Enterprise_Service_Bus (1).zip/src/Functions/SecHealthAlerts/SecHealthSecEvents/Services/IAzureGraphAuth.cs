﻿using System.Threading.Tasks;

namespace SecHealthSecEvents.Services
{
	public interface IAzureGraphAuth
	{
		Task<string> GetBearerTokenAsync(string tenantId);
	}
}
