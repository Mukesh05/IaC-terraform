﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Common.ESB;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SecHealthSecEvents.Model;

namespace SecHealthSecEvents.Services
{
	/// <summary>
	/// This class will process and enrich a single alert and send a
	/// message to the service bus.
	/// </summary>
	public class SecurityAlertProcessor : ISecurityAlertProcessor
	{
		IConfiguration _config;
		ILogger<SecurityAlertProcessor> _logger;
		IGraphSecurityApi _graphSecurityApi;
		IPhishEmailStorage _phishEmailStorage;
		IESBSender _esbSender;

		public SecurityAlertProcessor(IConfiguration config,
									  ILogger<SecurityAlertProcessor> logger,
									  IGraphSecurityApi graphSecurityApi,
									  IPhishEmailStorage phishEmailStorage,
									  IESBSender eSBSender)
		{
			_config = config;
			_logger = logger;
			_graphSecurityApi = graphSecurityApi;
			_phishEmailStorage = phishEmailStorage;
			_esbSender = eSBSender;
		}

		/// <summary>
		/// Start processing the Security alert.
		/// </summary>
		public async Task ProcessAlertAsync(AlertResult alert)
		{
			_logger.LogInformation($"Alert {alert.id} : Processing alert from tenant {alert.azureTenantId}. Alert title \"{alert.title}\"");

			//Log a warning where the time we start processing (when we get from graph) and the
			//time of the actual event is more than 20 minutes.
			var minutes = (DateTime.UtcNow - alert.createdDateTime).Minutes;
			if(minutes > 20)
			{
				_logger.LogWarning($"Alert {alert.id} : Alert was received from Graph Api at least {minutes} minutes or more after the alert createdDateTime.");
			}

			var eventMessage = ConvertAlertToEventMessage(alert);

			//Enrich the event message based on the provider of the alert
			var alertProvider = alert.vendorInformation.provider.ToLower();
			_logger.LogInformation($"Alert {eventMessage.MessageKey} : Provider {alertProvider}");
			switch (alertProvider)
			{
				case "ipc":
					eventMessage = await EnrichIPCAlertEventAsync(eventMessage, alert.userStates);
					break;
				case "mcas":
					if(alert.userStates == null || alert.userStates.Count <= 0)
					{
						_logger.LogWarning($"Alert {alert.id} : Alert contains no user state details.");
						eventMessage.ShortDescription = $"{alert.title}";
					}
					else
					{
						eventMessage.ShortDescription = $"{alert.title} : {alert.userStates[0].userPrincipalName}";
					}
					break;
				case "wdatp":
				case "microsoft defender atp":
					var sourceMaterials = JsonConvert.SerializeObject(alert.sourceMaterials, Formatting.Indented);
					eventMessage.ShortDescription = $"{alert.title} : {sourceMaterials}";
					break;
				case "office 365 security and compliance":
					eventMessage = await EnrichO365AlertEventAsync(eventMessage, alert.userStates, alert.eventDateTime);
					break;
				default:
					//nothing to change with unknown provider
					break;
			}

			//send the event message to the bus
			_logger.LogInformation($"Alert {eventMessage.MessageKey} : Sending event message.");
			string json = JsonConvert.SerializeObject(eventMessage);
			_logger.LogTrace($"Alert {eventMessage.MessageKey} : Sending event message. {json}");
			await _esbSender.SendMessageAsync(_config["SecHealthSecEvents:TopicName"], json);
		}

		/// <summary>
		/// Transform the Security alert to an event message expected
		/// on the service bus.
		/// </summary>
		private EventMessage ConvertAlertToEventMessage(AlertResult alert)
		{
			EventMessage eventMessage = new EventMessage();
			eventMessage.MessageKey = alert.id;
			eventMessage.AzureTenantId = alert.azureTenantId;
			eventMessage.Type = alert.category;
			eventMessage.ResolutionState = alert.status;
			eventMessage.Description = alert.description;
			eventMessage.InitialEventTime = alert.eventDateTime.ToString();
			eventMessage.CreatedDateTime = alert.createdDateTime.ToString();
			eventMessage.LastModifiedDateTime = alert.lastModifiedDateTime.ToString();
			eventMessage.ShortDescription = alert.title;
			eventMessage.EventSource = MapProviderName(alert.vendorInformation.provider);
			eventMessage.AlertSeverity = alert.severity;
			eventMessage.AdditionalInformation = JsonConvert.SerializeObject(alert);

			return eventMessage;
		}

		/// <summary>
		/// Enrich the alert event message with email details if it's a user report phish alert.
		/// </summary>
		private async Task<EventMessage> EnrichO365AlertEventAsync(EventMessage eventMessage, List<UserState> userStates, DateTime eventDateTime)
		{
			//At this time, we only care about enriching user reported phish alerts
			if(!eventMessage.ShortDescription.ToLower().Equals("user reported phish"))
			{
				_logger.LogInformation($"Alert {eventMessage.MessageKey} : Short description is not 'User Reported Phish', skipping email enrichment.");
				return eventMessage;
			}

			try
			{
				//Attempt to get phish email details. If none found, just return unenriched event message
				var emailResult = await GetPhishEmailDetailsAsync(eventMessage.AzureTenantId, userStates, eventDateTime.ToString());
				if (emailResult == null)
				{
					_logger.LogWarning($"Alert {eventMessage.MessageKey} : Unabled to retrieve email details for 'User Reported Phish' alert.");
					return eventMessage;
				}

				//Add phish email details to additional info json
				dynamic obj = JsonConvert.DeserializeObject<ExpandoObject>(eventMessage.AdditionalInformation);
				obj.phishEmailDetails = new
				{
					clientName = emailResult.ClientName,
					from = emailResult.From,
					to = emailResult.To,
					emailTime = emailResult.EmailReceivedTime,
					emailSubject = emailResult.EmailSubject,
					isSimulation = emailResult.IsSimulation,
					xForefrontAntispamReport = emailResult.XForefrontAntispamReport,
					authenticationResults = emailResult.AuthenticationResults
				};

				//Update event message with enriched details.
				eventMessage.AdditionalInformation = JsonConvert.SerializeObject(obj);
				_logger.LogInformation($"Alert {eventMessage.MessageKey} : Enriched 'User Reported Phish' alert.");
			}
			catch (Exception ex)
			{
				_logger.LogError($"Alert {eventMessage.MessageKey} : Failed to enrich 'User Reported Phish' alert. {ex.ToString()}");
			}


			return eventMessage;
		}

		/// <summary>
		/// Enrich the alert event message with IPC info.
		/// Risky User and Risk Detection details.
		/// </summary>
		private async Task<EventMessage> EnrichIPCAlertEventAsync(EventMessage eventMessage, List<UserState> userStates)
		{
			_logger.LogInformation($"Alert {eventMessage.MessageKey} : Enriching 'IPC' alert.");

			//There is no user state data so just return the default
			//additional info which is just the alert itself.
			if (userStates == null || userStates.Count <= 0)
			{
				_logger.LogWarning($"Alert {eventMessage.MessageKey} : Unable to enrich 'IPC' alert. UserStates empty.");
				return eventMessage;
			}

			try
			{
				//Enrich description with the user namne
				var user = userStates[0].userPrincipalName;
				eventMessage.ShortDescription += $" {user}";

				var jsonAdditionalInfo = JObject.Parse(eventMessage.AdditionalInformation);
				var userId = userStates[0].aadUserId;

				//Enrich with risk user data
				var riskyUserResult = await _graphSecurityApi.GetRiskyUserAsync(eventMessage.AzureTenantId, userId);
				var riskyUser = JsonConvert.DeserializeObject<RiskyUserResult>(riskyUserResult);
				if (riskyUser != null)
				{
					eventMessage.AlertSeverity = riskyUser.riskLevel;
					jsonAdditionalInfo.Add("riskLevel", riskyUser.riskLevel);
				}
				else
				{
					_logger.LogWarning($"Alert {eventMessage.MessageKey} : Unable to retrieve 'RiskyUser' data.");
				}

				//Enrich with risk detection data
				var riskDetectionResult = await _graphSecurityApi.GetRiskDetectionAsync(eventMessage.AzureTenantId, eventMessage.MessageKey);
				var riskDetection = JsonConvert.DeserializeObject<RiskDetectionResult>(riskDetectionResult);
				if (riskDetection != null && riskDetection.value.Count > 0)
				{
					var riskDetail = riskDetection.value[0].riskDetail;
					var riskState = riskDetection.value[0].riskState;
					if (!string.IsNullOrEmpty(riskState) && riskState != "atRisk" && riskState != "confirmedCompromised")
					{
						eventMessage.ResolutionState = "Closing";
					}

					jsonAdditionalInfo.Add("riskDetail", riskDetail);
					jsonAdditionalInfo.Add("riskState", riskState);
				}
				else
				{
					_logger.LogWarning($"Alert {eventMessage.MessageKey} : Unable to retrieve 'RiskDetection' data.");
				}

				eventMessage.AdditionalInformation = jsonAdditionalInfo.ToString();
				_logger.LogInformation($"Alert {eventMessage.MessageKey} : Enriched 'IPC' alert.");
			}
			catch(Exception ex)
			{
				_logger.LogError($"Alert {eventMessage.MessageKey} : Failed to enrich 'IPC' alert. {ex.ToString()}");
			}
			
			return eventMessage;
		}

		/// <summary>
		/// Attempt to retrieve phish emails details that are in storage.
		/// </summary>
		private async Task<PhishEmailResult> GetPhishEmailDetailsAsync(string tenantid, List<UserState> userStates, string eventDateTime)
		{
			string[] formats = {"M/d/yyyy h:mm:ss tt", "M/d/yyyy h:mm tt",
								"MM/dd/yyyy hh:mm:ss", "M/d/yyyy h:mm:ss",
								"M/d/yyyy hh:mm tt", "M/d/yyyy hh tt",
								"M/d/yyyy h:mm", "M/d/yyyy h:mm",
								"MM/dd/yyyy hh:mm", "M/dd/yyyy hh:mm",
								"yyyy'-'MM'-'dd'T'HH':'mm':'ss.fffffff'Z'", "d/M/yyyy H:mm:ss"};

			DateTime formatedEventDateTime;
			if (!DateTime.TryParseExact(eventDateTime, formats, CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal, out formatedEventDateTime))
			{
				return null;
			}

			// Get the email details from storage
			var emailSender = userStates.Where(x => x.emailRole.ToLower() == "sender").Select(x => x.userPrincipalName).FirstOrDefault();
			var emailReceiver = userStates.Where(x => x.emailRole.ToLower() == "recipient").Select(x => x.userPrincipalName).FirstOrDefault();
			var emailDetails = (await _phishEmailStorage.GetPhishEmailDetailsAsync(tenantid, formatedEventDateTime)).ToList();
			var emailFromSender = emailDetails.Where(x => CompareEmails(x.EmailSender, emailSender)).ToList();

			EmailDetails email = null;
			if (emailFromSender.Count() > 1)
			{				
				// If there are multiple emails from this sender for this time period, use the
				// one with the same receiver.
				var emailFromSenderAndReceiver = emailFromSender.Where(x => CompareEmails(x.EmailReceiver, emailReceiver)).ToList();
				if(emailFromSenderAndReceiver.Count() > 0)
				{ 
					//Please Note if there are multiple matching entities, then the closest one is picked. But there is no certainty that the chosen entity is perfect match.
					var nearestDiff = emailFromSenderAndReceiver.Min(ed => Math.Abs(Convert.ToInt64(ed.RowKey) - formatedEventDateTime.Ticks));
					email = emailFromSenderAndReceiver.Where(ed => Math.Abs(Convert.ToInt64(ed.RowKey) - formatedEventDateTime.Ticks) == nearestDiff).First();
				}
			}
			else
			{
				// This is the only email from this sender for this time period so we assume this
				// is the match.
				email = emailFromSender.FirstOrDefault();
			}

			if (email == null)
			{
				return null;
			}

			return new PhishEmailResult()
			{
				ClientName = email.ClientName,
				From = email.EmailSender,
				To = email.EmailReceiver,
				EmailReceivedTime = email.OriginalPhishMessageDate,
				EmailSubject = email.EmailSubject,
				IsSimulation = email.IsSimulation,
				XForefrontAntispamReport = email.XForefrontAntispamReport,
				AuthenticationResults = email.AuthenticationResults
			};
		}

		/// <summary>
		/// Helper method to compare two emails to check if they are the same.
		/// </summary>
		private bool CompareEmails(string sourceEmail, string targetEmail)
		{
			string RegexPattern = @"\b[A-Z0-9._-]+@[A-Z0-9][A-Z0-9.-]{0,61}[A-Z0-9]\.[A-Z.]{2,6}\b";

			Match match = Regex.Match(sourceEmail, RegexPattern, RegexOptions.IgnoreCase);
			var email1 = match.ToString();

			match = Regex.Match(targetEmail, RegexPattern, RegexOptions.IgnoreCase);
			var email2 = match.ToString();

			var result = string.Equals(email1, email2, StringComparison.InvariantCultureIgnoreCase);

			return result;
		}

		/// <summary>
		/// Map some provider names to a more friendly name. At this
		/// time Service Now requires the friendly name.
		/// </summary>
		private string MapProviderName(string providerold)
		{
			switch (providerold.ToLower())
			{
				case "asc":
					return "Azure Security Center";
				case "mcas":
					return "Microsoft Cloud App Sec";
				case "wdatp":
					return "Windows Defender ATP";
				case "ipc":
					return "Azure AD IP";
			}

			return providerold;
		}
	}
}
