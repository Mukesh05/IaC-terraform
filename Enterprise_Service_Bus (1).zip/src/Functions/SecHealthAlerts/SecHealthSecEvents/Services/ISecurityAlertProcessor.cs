﻿using System.Threading.Tasks;
using SecHealthSecEvents.Model;

namespace SecHealthSecEvents.Services
{
	public interface ISecurityAlertProcessor
	{
		Task ProcessAlertAsync(AlertResult alert);
	}
}
