﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace SecHealthSecEvents.Model
{
	public class PhishEmailResult
	{
		[JsonProperty("clientName")]
		public string ClientName { get; set; }
		[JsonProperty("from")]
		public string From { get; set; }
		[JsonProperty("to")]
		public string To { get; set; }
		[JsonProperty("emailReceivedTime")]
		public DateTime? EmailReceivedTime { get; set; }
		[JsonProperty("emailSubject")]
		public string EmailSubject { get; set; }
		[JsonProperty("isSimulation")]
		public bool IsSimulation { get; set; }
		[JsonProperty("xForefrontAntispamReport")]
		public string XForefrontAntispamReport { get; set; }
		[JsonProperty("authenticationResults")]
		public string AuthenticationResults { get; set; }

	}
}
