using System.Collections.Generic;
using Newtonsoft.Json;

namespace SecHealthSecEvents.Model
{
    public class GraphNotificationDetails
    {
        [JsonProperty("value")]
        public IEnumerable<Notification> Notifications { get; set; }
    }

    public class Notification
    {
        [JsonProperty("changeType")]
        public string ChangeType { get; set; }
        [JsonProperty("resource")]
        public string Resource { get; set; }
        [JsonProperty("tenantId")]
        public string TentantId  { get; set; }
        [JsonProperty("resourceData")]
        public ResourceData ResourceData { get; set; }
    }

    public class ResourceData
    {
        [JsonProperty("id")]
        public string Id { get; set; }
    }
}