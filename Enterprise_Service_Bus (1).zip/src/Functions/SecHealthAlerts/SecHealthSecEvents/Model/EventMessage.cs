﻿using Newtonsoft.Json;

namespace SecHealthSecEvents.Model
{
	public class EventMessage
	{
		[JsonProperty("messageKey")]
		public string MessageKey { get; set; }
		[JsonProperty("azureTenantId")]
		public string AzureTenantId { get; set; }
		[JsonProperty("type")]
		public string Type { get; set; }
		[JsonProperty("description")]
		public string Description { get; set; }
		[JsonProperty("initialEventTime")]
		public string InitialEventTime { get; set; }
		[JsonProperty("createDateTime")]
		public string CreatedDateTime { get; set; }
		[JsonProperty("lastModifiedDateTime")]
		public string LastModifiedDateTime { get; set; }
		[JsonProperty("ShortDescription")]
		public string ShortDescription { get; set; }
		[JsonProperty("eventSource")]
		public string EventSource { get; set; }
		[JsonProperty("alertSeverity")]
		public string AlertSeverity { get; set; }
		[JsonProperty("additionalInformation")]
		public string AdditionalInformation { get; set; }
		[JsonProperty("securityAPI")]
		public string SecurityAPI { get; set; }
		[JsonProperty("resolutionState")]
		public string ResolutionState { get; set; }
		[JsonProperty("lastEventDateString")]
		public string LastEventDateString { get; set; }
	}
}
