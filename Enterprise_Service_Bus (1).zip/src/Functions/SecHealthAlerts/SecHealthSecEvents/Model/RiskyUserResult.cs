﻿using System;
using Newtonsoft.Json;

namespace SecHealthSecEvents.Model
{
	public class RiskyUserResult
	{
		[JsonProperty("@odata.context")]
		public string OdataContext { get; set; }
		public string id { get; set; }
		public bool isDeleted { get; set; }
		public bool isProcessing { get; set; }
		public string riskLevel { get; set; }
		public string riskState { get; set; }
		public string riskDetail { get; set; }
		public DateTime riskLastUpdatedDateTime { get; set; }
		public string userDisplayName { get; set; }
		public string userPrincipalName { get; set; }
	}

}
