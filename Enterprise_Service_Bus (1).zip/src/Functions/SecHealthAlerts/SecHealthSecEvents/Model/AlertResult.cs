﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace SecHealthSecEvents.Model
{
	// This reflects the json result for https://graph.microsoft.com/v1.0/security/alerts/{alert id}


	// Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
	public class VendorInformation
	{
		public string provider { get; set; }
		public object providerVersion { get; set; }
		public object subProvider { get; set; }
		public string vendor { get; set; }
	}

	public class UserState
	{
		public string aadUserId { get; set; }
		public string accountName { get; set; }
		public string domainName { get; set; }
		public string emailRole { get; set; }
		public object isVpn { get; set; }
		public DateTime? logonDateTime { get; set; }
		public object logonId { get; set; }
		public string logonIp { get; set; }
		public string logonLocation { get; set; }
		public object logonType { get; set; }
		public object onPremisesSecurityIdentifier { get; set; }
		public object riskScore { get; set; }
		public object userAccountType { get; set; }
		public string userPrincipalName { get; set; }
	}

	public class AlertResult
	{
		[JsonProperty("@odata.context")]
		public string OdataContext { get; set; }
		public string id { get; set; }
		public string azureTenantId { get; set; } 
		public object azureSubscriptionId { get; set; } 
		public object riskScore { get; set; }
		public List<object> tags { get; set; }
		public object activityGroupName { get; set; }
		public object assignedTo { get; set; }
		public string category { get; set; } 
		public object closedDateTime { get; set; }
		public List<object> comments { get; set; }
		public object confidence { get; set; }
		public DateTime createdDateTime { get; set; } 
		public string description { get; set; } 
		public List<object> detectionIds { get; set; }
		public DateTime eventDateTime { get; set; } 
		public object feedback { get; set; }
		public List<object> incidentIds { get; set; }
		public object lastEventDateTime { get; set; }
		public DateTime lastModifiedDateTime { get; set; } 
		public List<object> recommendedActions { get; set; }
		public string severity { get; set; } 
		public List<object> sourceMaterials { get; set; }
		public string status { get; set; } 
		public string title { get; set; } 
		public VendorInformation vendorInformation { get; set; } 
		public List<object> alertDetections { get; set; }
		public List<object> cloudAppStates { get; set; }
		public List<object> fileStates { get; set; }
		public List<object> hostStates { get; set; }
		public List<object> historyStates { get; set; }
		public List<object> investigationSecurityStates { get; set; }
		public List<object> malwareStates { get; set; }
		public List<object> messageSecurityStates { get; set; }
		public List<object> networkConnections { get; set; }
		public List<object> processes { get; set; }
		public List<object> registryKeyStates { get; set; }
		public List<object> securityResources { get; set; }
		public List<object> triggers { get; set; }
		public List<UserState> userStates { get; set; }
		public List<object> uriClickSecurityStates { get; set; }
		public List<object> vulnerabilityStates { get; set; }
	}

	public class AlertResults
	{
		[JsonProperty("value")]
		public List<AlertResult> Alerts { get; set; }
	}
}
