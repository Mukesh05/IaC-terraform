﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace SecHealthSecEvents.Model
{
	public class Location
	{
		public string city { get; set; }
		public string state { get; set; }
		public string countryOrRegion { get; set; }
		public object geoCoordinates { get; set; }
	}

	public class Value
	{
		[JsonProperty("@odata.type")]
		public string OdataType { get; set; }
		public string id { get; set; }
		public string requestId { get; set; }
		public string correlationId { get; set; }
		public string riskEventType { get; set; }
		public string riskState { get; set; }
		public string riskLevel { get; set; }
		public string riskDetail { get; set; }
		public string source { get; set; }
		public string detectionTimingType { get; set; }
		public string activity { get; set; }
		public string tokenIssuerType { get; set; }
		public string ipAddress { get; set; }
		public Location location { get; set; }
		public DateTime activityDateTime { get; set; }
		public DateTime detectedDateTime { get; set; }
		public DateTime lastUpdatedDateTime { get; set; }
		public string userId { get; set; }
		public string userDisplayName { get; set; }
		public string userPrincipalName { get; set; }
		public string additionalInfo { get; set; }
	}

	public class RiskDetectionResult
	{
		public List<Value> value { get; set; }
	}


}
