using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using System.Net;
using System.Net.Http;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http.Internal;
using Microsoft.Extensions.Primitives;
using SecHealthToServiceNow;
using System.Collections.Specialized;
using Newtonsoft.Json;

namespace SecHealthSecEventsTests
{
	[TestClass]
	public class SecHealthSecEventsTests
	{
		Mock<IConfigurationRefresher> _configRefresher;
		Mock<IConfiguration> _config;
		Mock<ILogger<SecHealthToServiceNow.SecHealthToServiceNow>> _logger;
		Mock<ISnowHelper> _snowHelper;
		string _sbMessage;

		[TestInitialize]
		public void Startup()
		{
			_configRefresher = new Mock<IConfigurationRefresher>();
			_configRefresher.Setup(cr => cr.TryRefreshAsync());
			_config = new Mock<IConfiguration>();
			_logger = TestHelper.GetMockedLoggerWithAutoSetup<SecHealthToServiceNow.SecHealthToServiceNow>();
			_snowHelper = new Mock<ISnowHelper>();
			_sbMessage = @"{ 'MessageKey': 'bf_3823765d-7dc3-5ce1-ea00-08d807255558v1','AzureTenantId': 'daf884b0-be16-4f2a-8bbb-dc6099a56844','Type': 'ThreatManagement','Description': 'This alert is triggered when any email message is reported as malware or phish by users -V1.0.0.2','InitialEventTime': '02/06/2020 18:47:00','CreatedDateTime':'02/06/2020 19:35:51','LastModifiedDateTime': '03/06/2020 01:52:01','ShortDescription': 'User Reported Phish','EventSource': 'Office 365 Security and Compliance','AlertSeverity': 'medium','AdditionalInformation': 'AdditionalInformation string','SecurityAPI': null,'ResolutionState': 'inProgress','LastEventDateString': null}";
		}

		[TestMethod]
		public async Task AssertSecHealthToServiceNowWillRunsuccessfullyAsync()
		{
			SNowEvent snowEvent = new SNowEvent
			{
				MessageKey = "bf_3823765d-7dc3-5ce1-ea00-08d807255558v1",
				AzureTenantId = "daf884b0-be16-4f2a-8bbb-dc6099a56844",
				Type = "ThreatManagement",
				Description = "This alert is triggered when any email message is reported as malware or phish by users -V1.0.0.2",
				InitialEventTime = "02/06/2020 18:47:00",
				CreatedDateTime = "02/06/2020 19:35:51",
				LastModifiedDateTime = "03/06/2020 01:52:01",
				ShortDescription = "User Reported Phish",
				EventSource = "Office 365 Security and Compliance",
				AlertSeverity = "medium",
				AdditionalInformation = "AdditionalInformation string",
				SecurityAPI = null,
				ResolutionState = "inProgress",
				LastEventDateString = null
			};

			var sNowEventContent = JsonConvert.SerializeObject(snowEvent);
			var queryStringCol = new NameValueCollection { { "mySbMsg", _sbMessage } };
			var dictionary = new Dictionary<string, StringValues>();
			dictionary.Add("mySbMsg", _sbMessage);
			var qc = new QueryCollection(dictionary);
			var request = new Mock<HttpRequest>();
			request.Setup(r => r.Query).Returns(qc);
			
			_snowHelper = new Mock<ISnowHelper>();
			_snowHelper.Setup(sh => sh.SendToSNow(It.Is<string>(s => s.Contains("bf_3823765d-7dc3-5ce1-ea00-08d807255558v1")))).Verifiable();
			_snowHelper.Setup(sh => sh.MapForSNowGeneral(_sbMessage)).Returns(snowEvent).Verifiable();

			SecHealthToServiceNow.SecHealthToServiceNow secHealthSecEvents = new SecHealthToServiceNow.SecHealthToServiceNow(
																			_config.Object,
																			_configRefresher.Object,
																			_logger.Object,
																			_snowHelper.Object);

			var status = await secHealthSecEvents.SecHealthToServiceNowOnDemandAsync(request.Object);

			Assert.IsTrue(status, "this failed for this reason...");

			_snowHelper.VerifyAll();
		}
	}
}
