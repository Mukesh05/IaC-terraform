﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace SecHealthToServiceNowComparison.Model
{
	public class Result
	{
		[JsonProperty("time_of_event")]
		public string TimeOfEvent;

		[JsonProperty("u_account.name")]
		public string UAccountName;

		[JsonProperty("source")]
		public string Source;

		[JsonProperty("state")]
		public string State;

		[JsonProperty("message_key")]
		public string MessageKey;
	}

	public class SNowEvents
	{
		[JsonProperty("result")]
		public List<Result> Result;
	}
}
