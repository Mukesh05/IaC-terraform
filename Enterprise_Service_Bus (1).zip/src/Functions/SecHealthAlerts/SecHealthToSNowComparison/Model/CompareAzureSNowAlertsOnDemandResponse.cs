﻿using System;
using System.Collections.Generic;

namespace SecHealthToServiceNowComparison.Model
{
	public class CompareAzureSNowAlertsOnDemandResponse
	{
		public List<string> matchingSnowAlerts = new List<string>();
		public List<string> nonMatchingAlerts = new List<string>();

	}
}
