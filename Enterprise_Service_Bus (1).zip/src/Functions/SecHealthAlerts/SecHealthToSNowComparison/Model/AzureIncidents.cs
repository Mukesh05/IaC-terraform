﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace SecHealthToServiceNowComparison.Model
{
	// This reflects the json result for https://api.security.microsoft.com/api/incidents


	// Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
	public class Entity
	{
		public string entityType { get; set; }
		public DateTime evidenceCreationTime { get; set; }
		public string verdict { get; set; }
		public string remediationStatus { get; set; }
		public string accountName { get; set; }
		public string domainName { get; set; }
		public string userSid { get; set; }
		public string aadUserId { get; set; }
		public string userPrincipalName { get; set; }
		public string mailboxDisplayName { get; set; }
		public string mailboxAddress { get; set; }
		public string ipAddress { get; set; }
		public string sender { get; set; }
		public string recipient { get; set; }
		public string subject { get; set; }
		public string internetMessageId { get; set; }
		public string clusterBy { get; set; }
		public string clusterByValue { get; set; }
		public int? emailCount { get; set; }
	}

	public class Alert
	{
		public Alert()
		{
			mitreTechniques = new List<object>();
			devices = new List<object>();
			entities = new List<Entity>();
		}

		public string alertId { get; set; }
		public object providerAlertId { get; set; }
		public int incidentId { get; set; }
		public string serviceSource { get; set; }
		public DateTime creationTime { get; set; }
		public DateTime lastUpdatedTime { get; set; }
		public object resolvedTime { get; set; }
		public DateTime firstActivity { get; set; }
		public DateTime lastActivity { get; set; }
		public string title { get; set; }
		public string description { get; set; }
		public string category { get; set; }
		public string status { get; set; }
		public string severity { get; set; }
		public object investigationId { get; set; }
		public string investigationState { get; set; }
		public object classification { get; set; }
		public object determination { get; set; }
		public string detectionSource { get; set; }
		public string detectorId { get; set; }
		public string assignedTo { get; set; }
		public object actorName { get; set; }
		public object threatFamilyName { get; set; }
		public List<object> mitreTechniques { get; set; }
		public List<object> devices { get; set; }
		public List<Entity> entities { get; set; }
	}

	public class Value
	{
		public Value()
		{
			tags = new List<object>();
			comments = new List<object>();
			alerts = new List<Alert>();
		}

		public int incidentId { get; set; }
		public string incidentUri { get; set; }
		public object redirectIncidentId { get; set; }
		public string incidentName { get; set; }
		public DateTime createdTime { get; set; }
		public DateTime lastUpdateTime { get; set; }
		public object assignedTo { get; set; }
		public string classification { get; set; }
		public string determination { get; set; }
		public string status { get; set; }
		public string severity { get; set; }
		public List<object> tags { get; set; }
		public List<object> comments { get; set; }
		public List<Alert> alerts { get; set; }
	}

	public class Error
	{
		public string code { get; set; }
		public string message { get; set; }
		public string target { get; set; }
	}

	public class AzureIncidents
	{
		public AzureIncidents()
		{
			value = new List<Value>();
		}

		[JsonProperty("@odata.context")]
		public string OdataContext { get; set; }
		public List<Value> value { get; set; }

		public Error error { get; set; }
	}
}
