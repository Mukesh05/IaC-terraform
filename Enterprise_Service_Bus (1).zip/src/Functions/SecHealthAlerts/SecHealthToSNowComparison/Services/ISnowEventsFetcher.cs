using System.Threading.Tasks;
using SecHealthToServiceNowComparison.Model;

namespace SecHealthToServiceNowComparison.Services
{
	public interface ISnowEventsFetcher
	{
		Task<SNowEvents> FetchSnowEvents(string fromDate, string toDate, string tenantId);
	}
}