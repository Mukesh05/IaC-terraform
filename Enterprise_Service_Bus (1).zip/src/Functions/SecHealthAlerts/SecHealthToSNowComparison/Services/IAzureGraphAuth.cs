﻿using System.Threading.Tasks;

namespace SecHealthToServiceNowComparison.Services
{
	public interface IAzureGraphAuth
	{
		Task<string> GetBearerTokenAsync(string tenantId);
	}
}
