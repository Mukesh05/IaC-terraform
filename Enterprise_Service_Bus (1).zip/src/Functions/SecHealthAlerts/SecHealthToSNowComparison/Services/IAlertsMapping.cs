namespace SecHealthToServiceNowComparison.Services
{
	public interface IAlertsMapping
	{
		bool IsAlertAllowed(string tenantId, string alertCategory, string alertDescription);
	}
}