using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using SecHealthToServiceNowComparison.HttpHandler;
using SecHealthToServiceNowComparison.Model;
using System.Collections.Generic;

namespace SecHealthToServiceNowComparison.Services
{
	public class AlertsMapping : IAlertsMapping
	{
		IConfiguration _config;
        ILogger<SecHealthToServiceNowComparison> _logger;
		Dictionary<Tuple<string, string>, List<string>> _mappingData = new Dictionary<Tuple<string, string>, List<string>>();
																
		private static readonly string GET_Incident_URL_filter = $"?$filter=lastUpdateTime+ge+{DateTime.UtcNow.AddDays(-1):yyyy-MM-ddT00:00:00Z}";
		const string ACCEPT = "application/json";
		const string BROOKFIELDTENANTID = "daf884b0-be16-4f2a-8bbb-dc6099a56844";
		const string INCLUDEALLALERTS = "All alerts";

		private void PopulateBrookfieldMappingData()
		{
			_mappingData.Add(new Tuple<string, string> (BROOKFIELDTENANTID, "Azure AD IP" ), new List<string> { INCLUDEALLALERTS } );
			_mappingData.Add(new Tuple<string, string>(BROOKFIELDTENANTID, "Microsoft Defender ATP"), new List<string> { INCLUDEALLALERTS });
			_mappingData.Add(new Tuple<string, string>(BROOKFIELDTENANTID, "Azure Advanced Threat Protection"), new List<string> { INCLUDEALLALERTS });
			_mappingData.Add(new Tuple<string, string>(BROOKFIELDTENANTID, "Microsoft Cloud App Sec"), new List<string> { INCLUDEALLALERTS });
			_mappingData.Add(new Tuple<string, string>(BROOKFIELDTENANTID, "Office 365 Security and Compliance"),
														new List<string> { "Admin Submission result completed",
																		   "Creation of forwarding/redirect rule",
																		   "eDiscovery search started or exported",
																		   "Email messages containing malware removed after delivery",
																		   "Email messages containing phish URLs removed after delivery",
																		   "Email reported by user as malware or phish",
																		   "Malware campaign detected and blocked",
																		   "Phish delivered due to tenant or user override",
															               "Unusual increase in email reported as phish",
																		   "User impersonation phish delivered to inbox/folder",
			});
		}
		public AlertsMapping(IConfiguration configuration,
							  ILogger<SecHealthToServiceNowComparison> logger)
		{
            _config = configuration;
            _logger = logger;
			PopulateBrookfieldMappingData();
		}

		public bool IsAlertAllowed(string tenantId, string alertCategory, string alertTitle)
		{
			try
			{
				_logger.LogInformation("Started executing IsAlertAllowed method");
								
				if (tenantId == BROOKFIELDTENANTID)
				{
					return true;
				}

				return false;
			}
			catch (Exception ex)
			{
				var errorMessage = $"Exception Message:{ex.Message} StackTrace:{ex.StackTrace} InnerException:{ex.InnerException} Source:{ex.Source}triggered in function CompareAzureSNowIncidentsOnDemand at: {DateTime.UtcNow}";
				_logger.LogError(errorMessage);
				throw (ex);
			}
		}

	}
}