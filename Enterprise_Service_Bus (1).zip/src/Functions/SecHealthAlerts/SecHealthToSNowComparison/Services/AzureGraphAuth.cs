﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;

namespace SecHealthToServiceNowComparison.Services
{
	public class AzureGraphAuth : IAzureGraphAuth
	{
		const string AUTH_URL = "https://login.microsoftonline.com/{0}/oauth2/token";
		const string SCOPE = "https://api.security.microsoft.com";
		const string GRANT_TYPE = "client_credentials";
		const string CONTENT_TYPE = "application/x-www-form-urlencoded";
		const string ACCEPT = "application/json";

		IConfiguration _config;
		ILogger<SecHealthToServiceNowComparison> _logger;
		
		public AzureGraphAuth(IConfiguration config,
							  ILogger<SecHealthToServiceNowComparison> logger
							  )
		{
			_config = config;
			_logger = logger;
		}

		public async Task<string> GetBearerTokenAsync(string tenantId)
		{
			try
			{
				var fullAuthUrl = string.Format(AUTH_URL, tenantId);
				_logger.LogTrace($"Authorization url is {fullAuthUrl}");

				IDictionary<string, string> data = new Dictionary<string, string>()
				{
					{ "resource", SCOPE },
					{ "grant_type", GRANT_TYPE },
					{ "client_id", _config["SecHealthSecEvents:ClientId"] },
					{ "client_secret", _config["SecHealthSecEvents:Secret"] }
				};

				// Setup request to retrieve a bearer token
				var requestMessage = new HttpRequestMessage(HttpMethod.Post, fullAuthUrl);
				requestMessage.Content = new FormUrlEncodedContent(data);
				requestMessage.Content.Headers.Clear();
				requestMessage.Content.Headers.ContentType = new MediaTypeHeaderValue(CONTENT_TYPE);

				HttpClient _httpClient = new HttpClient();
				_httpClient.DefaultRequestHeaders.Clear();
				_httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(ACCEPT));

				// Send request and validate for success
				var result = await _httpClient.SendAsync(requestMessage);
				if (result.StatusCode != HttpStatusCode.OK)
				{
					var errorPayload = await result.Content.ReadAsStringAsync();

					string message = $@"Failed to retrieve bearer token for {tenantId}. (StatusCode : {result.StatusCode}, Response : {errorPayload})";
					_logger.LogError(message);
					throw new Exception(message);
				}
				_logger.LogTrace($"Call to {fullAuthUrl} was successful.");

				// Read the payload and parse out the access token.
				var payload = await result.Content.ReadAsStringAsync();
				_logger.LogTrace("Response payload was read ok.");

				JObject jsonObject;
				try
				{
					jsonObject = JObject.Parse(payload);
					_logger.LogTrace("Json payload was parsed ok.");
				}
				catch
				{
					// Json payload was expected but not received
					string message = $"Failed to retrieve bearer token for {tenantId}. Call was successful but response was not json.";
					_logger.LogError(message);
					throw new Exception(message);
				}

				var accessToken = (string)jsonObject["access_token"];
				_logger.LogInformation($"Successfully retrieved bearer token for {tenantId}");

				return accessToken;
			}
			catch (Exception ex)
			{
				var errorMessage = $"Exception Message:{ex.Message} StackTrace:{ex.StackTrace} InnerException:{ex.InnerException} Source:{ex.Source}triggered in function CompareAzureSNowIncidentsOnDemand at: {DateTime.UtcNow}";
				_logger.LogError(errorMessage);
				throw (ex);
			}
		}
	}
}
