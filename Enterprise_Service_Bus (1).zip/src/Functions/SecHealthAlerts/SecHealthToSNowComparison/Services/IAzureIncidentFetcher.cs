using System.Threading.Tasks;
using SecHealthToServiceNowComparison.Model;

namespace SecHealthToServiceNowComparison.Services
{
	public interface IAzureIncidentFetcher
	{
		Task<AzureIncidents> FetchIncidents(string tenantId, string dateFrom, string dateTo);
	}
}