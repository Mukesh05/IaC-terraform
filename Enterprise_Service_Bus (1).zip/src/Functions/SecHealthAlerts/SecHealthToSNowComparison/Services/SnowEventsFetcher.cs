using System;
using System.Threading.Tasks;
using Common.ESB;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SecHealthToServiceNowComparison.Model;

namespace SecHealthToServiceNowComparison.Services
{
	public class SnowEventsFetcher : ISnowEventsFetcher
	{
		const string SNOW_QUERY = "sysparm_query=source=Azure Security^u_account={0}^time_of_eventBETWEENjavascript:gs.dateGenerate('{1}','00:00:00')@javascript:gs.dateGenerate('{2}','11:59:59')&sysparm_fields=time_of_event,source,u_account.name,message_key,state";
		const string SNOW_TABLENAME = "em_event";

		IConfiguration _config;
        ILogger<SecHealthToServiceNowComparison> _logger;
        IServiceNowTableQuery _serviceNowTableQuery;

		public SnowEventsFetcher(IConfiguration configuration,
							  ILogger<SecHealthToServiceNowComparison> logger,
							  IServiceNowTableQuery serviceNowTableQuery)
		{
            _config = configuration;
            _logger = logger;
        	_serviceNowTableQuery = serviceNowTableQuery;
		}

		/// <summary>
		/// Fetch Snow Alerts.
		/// </summary>
		public async Task<SNowEvents> FetchSnowEvents(string fromDate,
													  string toDate,
													  string accountId)
		{
			try
			{
				_logger.LogInformation("Started executing FetchSnowAlerts method");
				var query = string.Format(SNOW_QUERY,
										accountId,
										DateTime.Parse(fromDate).ToString("yyyy-MM-dd"),
										DateTime.Parse(toDate).ToString("yyyy-MM-dd"));

				var snowalerts = await _serviceNowTableQuery.GetServiceNowTableData<SNowEvents>(SNOW_TABLENAME,
																								query);
				_logger.LogInformation("FetchSnowAlerts execution sucess");
				return snowalerts;
			}
			catch(Exception ex)
			{
				var errorMessage = $"Exception Message:{ex.Message} StackTrace:{ex.StackTrace} InnerException:{ex.InnerException} Source:{ex.Source}triggered in function CompareAzureSNowIncidentsOnDemand at: {DateTime.UtcNow}";
				_logger.LogError(errorMessage);
				throw (ex);
			}
		}

	}
}