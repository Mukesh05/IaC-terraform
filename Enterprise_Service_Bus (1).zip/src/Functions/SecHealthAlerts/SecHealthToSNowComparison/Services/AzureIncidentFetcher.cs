using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using SecHealthToServiceNowComparison.HttpHandler;
using SecHealthToServiceNowComparison.Model;

namespace SecHealthToServiceNowComparison.Services
{
	public class AzureIncidentFetcher : IAzureIncidentFetcher
	{
		
		IConfiguration _config;
        ILogger<SecHealthToServiceNowComparison> _logger;
		IHttpClientHandler _httpClient;
		IAzureGraphAuth _azureGraphAuth;

		const string ACCEPT = "application/json";

		public AzureIncidentFetcher(IConfiguration configuration,
							  ILogger<SecHealthToServiceNowComparison> logger,
							  IHttpClientHandler httpClient,
							  IAzureGraphAuth azureGraphAuth)
		{
            _config = configuration;
            _logger = logger;
            _httpClient = httpClient;
			_azureGraphAuth = azureGraphAuth;
		}

		/// <summary>
		/// Fetch Azure Alerts for a date range
		/// </summary>
		public async Task<AzureIncidents> FetchIncidents(string tenantId, string dateFrom, string dateTo)
		{
			try
			{
				_logger.LogInformation("Started executing FetchIncidents method");
				var token = await _azureGraphAuth.GetBearerTokenAsync(tenantId);
				_logger.LogTrace("Retreived a bearer token.");
				string GET_Incident_URL_filter = $"?$filter=lastUpdateTime+ge+{dateFrom}+and+lastUpdateTime+le+{dateTo}";
				var incidentURL = _config["SecHealthToServiceNowComparison:AzureIncidentUrl"] + GET_Incident_URL_filter;
				var response = _httpClient.GetAsync(incidentURL, token).Result.Content.ReadAsStringAsync().Result;
				var incidents = JsonConvert.DeserializeObject<AzureIncidents>(response);
				if (incidents.error != null)
				{
					_logger.LogError($"Error Code: {incidents.error.code} & Error Message: {incidents.error.message}");
				}
				_logger.LogInformation("Started executing FetchIncidents method");

				return incidents;
			}
			catch (Exception ex)
			{
				var errorMessage = $"Exception Message:{ex.Message} StackTrace:{ex.StackTrace} InnerException:{ex.InnerException} Source:{ex.Source}triggered in function CompareAzureSNowIncidentsOnDemand at: {DateTime.UtcNow}";
				_logger.LogError(errorMessage);
				throw (ex);
			}
		}

	}
}