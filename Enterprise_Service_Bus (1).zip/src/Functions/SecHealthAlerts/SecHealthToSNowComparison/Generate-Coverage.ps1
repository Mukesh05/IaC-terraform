<#
 #
 # Generates coverage file that vscode extension can use to show lines covered after unit test.
 #
 # Documentation here: https://docs.microsoft.com/en-us/dotnet/core/tools/dotnet-test
 #
 #>

# set this to the base path for the ESB repo on your machine
[CmdletBinding()]
  param (
    $ESBPATH      = "~/code/engineering/_ESB",
    $SOLUTIONFILE = "./SecHealth.sln"
  )

# constant or derived values
$FUNCTIONSPATH = "/src/Functions/"
$TESTPATH = Join-Path -Path $ESBPATH -ChildPath "src/Functions/SecHealthAlerts/SecHealthToSNowComparisn.Tests"
$CUTPATH  = Join-Path -Path $ESBPATH -ChildPath "src/Functions/SecHealthAlerts/SecHealthToSNowComparisn"
$COVERAGE_FILE_SRC_PATH = Join-Path -Path $TESTPATH -ChildPath "Coverage/coverage.cobertura.xml"
$COVERAGE_FILE_DST_PATH = Join-Path -Path $CUTPATH  -ChildPath "cov.xml"

Push-Location (Join-Path -Path $ESBPATH -ChildPath $FUNCTIONSPATH)

dotnet clean $SOLUTIONFILE `
             --verbosity=quiet

dotnet test --verbosity=quiet `
            --blame `
            --nologo `
            --logger trx `
            --results-directory ./TestResults `
            /p:CollectCoverage=true `
            /p:CoverletOutputFormat=cobertura `
            /p:CoverletOutput=./Coverage/ `
            $SOLUTIONFILE

Copy-Item "$($COVERAGE_FILE_SRC_PATH)" "$($COVERAGE_FILE_DST_PATH)" -Force

Pop-Location
