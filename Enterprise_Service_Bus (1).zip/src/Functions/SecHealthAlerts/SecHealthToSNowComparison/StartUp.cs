﻿using System;
using System.IO;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Common.ESB;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Azure.Identity;
using SecHealthToServiceNowComparison.HttpHandler;
using SecHealthToServiceNowComparison.Services;

[assembly: FunctionsStartup(typeof(SecHealthToServiceNowComparison.Startup))]
namespace SecHealthToServiceNowComparison
{
	public class Startup : FunctionsStartup
	{
		public override void Configure(IFunctionsHostBuilder builder)
		{
			IConfigurationRefresher configRefresher = null;

			//Required to get access to Azure App config
			Azure.Core.TokenCredential creds = new DefaultAzureCredential();
			var environment = Environment.GetEnvironmentVariable("AZURE_FUNCTIONS_ENVIRONMENT");
			if (string.Compare(environment, "development", true) == 0)
			{
				creds = new SharedTokenCacheCredential(new SharedTokenCacheCredentialOptions()
				{ TenantId = "a1a2578a-8fd3-4595-bb18-7d17df8944b0" });
			}

			var appconfigConnectionString = Environment.GetEnvironmentVariable("appconfigconnectionstring", EnvironmentVariableTarget.Process);

			//Config setup. Azure App Config first to allow local.settings.json to
			//override settings during local testing.
			var configBuilder = new ConfigurationBuilder()
				.SetBasePath(Directory.GetCurrentDirectory())
				.AddAzureAppConfiguration(options =>
				{
					options.Connect(appconfigConnectionString)
					.Select("Common:*")
					.Select("ServiceNow:*")
					.Select("SecHealthSecEvents:*")
					.Select("SecHealthToServiceNowComparison:*")
					.ConfigureKeyVault(kv =>
					{
						kv.SetCredential(creds); //NuGet Azure.Identity
					});
					configRefresher = options.GetRefresher();
				})
				.SetBasePath(Directory.GetCurrentDirectory())
				.AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
				.AddEnvironmentVariables();

			IConfiguration config = configBuilder.Build();

			// Register Config services

			builder.Services.AddSingleton<IConfiguration>((services) =>
			{
				return config;
			});

			builder.Services.AddSingleton<IConfigurationRefresher>((services) =>
			{
				return configRefresher;
			});

			// Registering services

			builder
				.Services
				.AddSingleton<IServiceNowTableQuery, ServiceNowTableQuery>();
			
			builder
				.Services
				.AddSingleton<IHttpClientHandler, HttpClientHandler>();

			builder
				.Services
				.AddSingleton<IAzureGraphAuth, AzureGraphAuth>();

			builder
				.Services
				.AddSingleton<IAzureIncidentFetcher, AzureIncidentFetcher>();

			builder
				.Services
				.AddSingleton<ISnowEventsFetcher, SnowEventsFetcher>();

			builder
				.Services
				.AddSingleton<IAlertsMapping, AlertsMapping>();

		}
	}
}
