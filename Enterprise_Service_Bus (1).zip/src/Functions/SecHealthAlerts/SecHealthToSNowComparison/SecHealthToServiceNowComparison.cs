using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Common.ESB;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SecHealthToServiceNowComparison.Model;
using SecHealthToServiceNowComparison.Services;

namespace SecHealthToServiceNowComparison
{
	public class SecHealthToServiceNowComparison
	{
		private const string NewSignaturecompanySys_id = "72b8655cdbd6e7401b1518df4b961977";
		private const string EventManagementSysId = "9d5de9e5930022005bc5f179077ffb07";
		private const string SecurityOperationsGroupsSysId = "8912ce9bdbc5f340400a28240596196a";
		IAzureIncidentFetcher _azureIncidentFetcher;
		ISnowEventsFetcher _snowAlertsFetcher;
		IConfigurationRefresher _configRefresher;
		IConfiguration _config;
		IServiceNowTableQuery _serviceNowTableQuery;
		IAlertsMapping _alertsMapping;

		ILogger<SecHealthToServiceNowComparison> _logger;
		public SecHealthToServiceNowComparison(IConfiguration config,
									 IConfigurationRefresher configRefresher,
									 ILogger<SecHealthToServiceNowComparison> logger,
									 IAzureIncidentFetcher azureIncidentFetcher,
									 ISnowEventsFetcher snowAlertsFetcher,
									 IServiceNowTableQuery serviceNowTableQuery,
									 IAlertsMapping alertsMapping)
		{
			_configRefresher = configRefresher;
			_config = config;
			_logger = logger;
			_azureIncidentFetcher = azureIncidentFetcher;
			_snowAlertsFetcher = snowAlertsFetcher;
			_serviceNowTableQuery = serviceNowTableQuery;
			_alertsMapping = alertsMapping;
		}

		[FunctionName("CompareAzureSNowAlertsOnSchedule")]
		public async Task Run([TimerTrigger("%TimerSchedule%")] TimerInfo myTimer, ILogger log, ExecutionContext context)
		{
			await _configRefresher.TryRefreshAsync();

			//Runs every 7th of the month
			_logger.LogInformation($"C# Timer trigger function CompareAzureSNowAlertsOnSchedule starting execution at: {DateTime.Now}");

			var queryDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 07);

			await CompareAlerts();

			_logger.LogInformation($"C# Timer trigger function CompareAzureSNowAlertsOnSchedule finished executed at: {DateTime.Now}");
		}

		[FunctionName("CompareAzureSNowAlertsOnDemand")]
		public async Task<HttpResponseMessage> CompareAzureSNowAlertsOnDemand([HttpTrigger(AuthorizationLevel.Function, "get", Route = null)] HttpRequest req)
		{
			return await CompareAlerts();
		}

		private string ConstructSnowIncidentPayload(string tenantId, string accountName, string shortDescription, string description, string alertId)
		{
			JObject payloadObj = JObject.FromObject(new
			{
				company = NewSignaturecompanySys_id,
				short_description = $"Missing Alert: {alertId} for Tenant: {accountName} " + shortDescription,
				description= description,
				caller_id= EventManagementSysId,
				u_source = tenantId,
				category="Alert",
				subcategory="Azure",
				contact_type="Alert",
				u_alert_priority="2",
				impact ="2",
				assignment_group = SecurityOperationsGroupsSysId,
				opened_by =""
			});

			string payload = payloadObj.ToString();

			return payload;
		}

		private async Task<HttpResponseMessage> CompareAlerts()
		{
			try
			{
				_logger.LogInformation($"C# Http trigger function to compare Azure and Snow Incidents starting execution at: {DateTime.UtcNow}");

				string tableQuery = "sysparm_query=u_enable_azure_security_alert_and_snow_incident_comparisn=true&sysparm_fields=u_account.name, u_account.sys_id,u_tenant_ids,u_intune_warehouse_endpoint,u_workspace_ids";
				var snowAccounts = await _serviceNowTableQuery.GetServiceNowTableData<ServiceNowAccountResult>("u_account_azure_event_mapping", tableQuery);
				var compareAzureSNowAlertsOnDemandResponse = new CompareAzureSNowAlertsOnDemandResponse();

				foreach (var account in snowAccounts.ServiceNowAccounts)
				{
					var tenantIds = account.Tenant_ids.Split(",");

					foreach (var tenantId in tenantIds)
					{
						string dateFrom = GetStartDateForFetchingAlerts();
						string currentDate = GetEndDateForFetchingAlerts(dateFrom);

						var azureIncidents = await _azureIncidentFetcher.FetchIncidents(tenantId, dateFrom, currentDate);
						if (azureIncidents.error != null)
						{
							_logger.LogError($"Error Code: {azureIncidents.error.code} & Error Message: {azureIncidents.error.message}");
							continue;
						}

						_logger.LogInformation($"Comparing alerts between : {dateFrom} to {currentDate}");
						var allAzurealerts = azureIncidents.value.SelectMany(av => av.alerts);
						var azurealertsTimeBound = allAzurealerts.Where(
							ai => ai.creationTime >= DateTime.Parse(dateFrom) && ai.creationTime <= DateTime.Parse(currentDate));

						var snowEvents = await _snowAlertsFetcher.FetchSnowEvents(dateFrom, currentDate, account.Account_SysId);
						var missingAzureAlerts = (from azureAlert in azurealertsTimeBound
												  where !snowEvents.Result.Any(snowAlert => azureAlert.providerAlertId.ToString() == snowAlert.MessageKey)
												  select azureAlert).ToList();

						_logger.LogInformation($"There are : {missingAzureAlerts.Count()} missing alerts at {DateTime.UtcNow} for tenant :{account.Account_name}");

						foreach (var alert in missingAzureAlerts)
						{
							_logger.LogInformation($"Azure alert with providerAlertId: {alert.providerAlertId.ToString()} found {DateTime.UtcNow} for tenant :{account.Account_name} is not present in Snow");
							var isAlertAllowed = _alertsMapping.IsAlertAllowed(tenantId, alert.category, alert.title);
							if (isAlertAllowed)
							{
								compareAzureSNowAlertsOnDemandResponse.nonMatchingAlerts.Add(alert.providerAlertId.ToString());
								var payload = ConstructSnowIncidentPayload(tenantId, account.Account_name, alert.title, alert.description, alert.providerAlertId.ToString());
								var insertResponse = await _serviceNowTableQuery.InsertIntoServiceNowTable<dynamic>("incident", payload);
								if (insertResponse != null)
								{
									_logger.LogInformation($"Created incident for Azure alert with providerAlertId: {alert.providerAlertId.ToString()} inserted in Snow at {DateTime.UtcNow} for tenant :{account.Account_name}");
								}
								else
								{
									_logger.LogError($"Failed to create incident for Azure alert with providerAlertId: {alert.providerAlertId.ToString()} at {DateTime.UtcNow} for tenant :{account.Account_name}");
								}
							}
						}
					}
				}
			
				var responseContent = JsonConvert.SerializeObject(compareAzureSNowAlertsOnDemandResponse);
				var response = new HttpResponseMessage(System.Net.HttpStatusCode.OK)
				{
					Content = new StringContent(responseContent)
				};

				_logger.LogInformation($"C# Http trigger function to compare Azure incidents and Snow incidents for all tenants finished execution at: {DateTime.UtcNow}");
				return response;
			}
			catch (Exception ex)
			{
				var errorMessage = $"Exception Message:{ex.Message} StackTrace:{ex.StackTrace} InnerException:{ex.InnerException} Source:{ex.Source}triggered in function CompareAzureSNowIncidentsOnDemand at: {DateTime.UtcNow}";
				_logger.LogError(errorMessage);
				var response = new HttpResponseMessage(System.Net.HttpStatusCode.OK)
				{
					Content = new StringContent(errorMessage)
				};

				return response;
			}
		}

		private string GetEndDateForFetchingAlerts(string dateFrom)
		{
			return Convert.ToDateTime(dateFrom).AddHours(Convert.ToInt32(_config["SecHealthToServiceNowComparison:CheckAlertsTotalHours"])).ToString("yyyy-MM-ddT00:00:00Z");
		}

		private string GetStartDateForFetchingAlerts()
		{
			return DateTime.UtcNow.AddDays(-1 * Convert.ToInt32(_config["SecHealthToServiceNowComparison:CheckAlertsFromCurrentDaysBack"])).ToString("yyyy-MM-ddT00:00:00Z");
		}
	}
}
