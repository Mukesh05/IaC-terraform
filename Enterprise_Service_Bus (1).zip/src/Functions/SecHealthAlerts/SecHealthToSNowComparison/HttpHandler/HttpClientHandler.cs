﻿using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace SecHealthToServiceNowComparison.HttpHandler
{
	public class HttpClientHandler : IHttpClientHandler
	{
		private HttpClient _client = new HttpClient();

		public HttpResponseMessage Get(string url, string accessToken)
		{
			SetAuthHeader(accessToken);
			return GetAsync(url, accessToken).Result;
		}

		private void SetAuthHeader(string accessToken)
		{
			_client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
		}

		public HttpResponseMessage Post(string url, HttpContent content, string accessToken)
		{
			return PostAsync(url, content, accessToken).Result;
		}

		public async Task<HttpResponseMessage> GetAsync(string url, string accessToken)
		{
			SetAuthHeader(accessToken);
			var response = await _client.GetAsync(url);
			return response;
		}

		public async Task<HttpResponseMessage> PostAsync(string url, HttpContent content, string accessToken)
		{
			SetAuthHeader(accessToken);
			return await _client.PostAsync(url, content);
		}
	}
}
