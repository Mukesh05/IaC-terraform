using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using ServiceNowAccountSync.Services;

namespace ServiceNowAccountSync
{
	public class ServiceNowAccountSync
    {
		IConfiguration _configuration;
		ILogger<ServiceNowAccountSync> _logger;
		ISyncAccountsService _syncAccountsService;

		public ServiceNowAccountSync(IConfiguration configuration,
									 ILogger<ServiceNowAccountSync> logger,
									 ISyncAccountsService syncAccountsService)
		{
			_configuration = configuration;
			_logger = logger;
			_syncAccountsService = syncAccountsService;
		}

		[FunctionName("ServiceNowAccountSyncOnDemand")]
		public async Task<IActionResult> OnDemandAsync([HttpTrigger(AuthorizationLevel.Function, "post", Route = "ondemand")] HttpRequest req)
		{
			_logger.LogInformation("Start on demand account sync.");
			await _syncAccountsService.SyncAccounts();
			_logger.LogInformation("Completed on demand account sync.");

			return new OkObjectResult(new
			{
				message = "Account syncing complete."
			});
		}

        [FunctionName("ServiceNowAccountSync")]
        public async Task RunAsync([TimerTrigger("%TimerSchedule%")]TimerInfo myTimer, ILogger log)
        {
            log.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");

			_logger.LogInformation("Started timer triggered account sync.");
			await _syncAccountsService.SyncAccounts();
			_logger.LogInformation("Completed timer triggered account sync.");
		}
    }
}
