﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using ServiceNowAccountSync.Models;

namespace ServiceNowAccountSync.Services
{
	//https://developer.servicenow.com/dev.do#!/reference/api/quebec/rest/c_TableAPI

	public class SyncAccountsService : ISyncAccountsService
	{
		IConfiguration _configuration;
		ILogger<SyncAccountsService> _logger;
		
		IServiceNowService _sourceServiceNowSerivce;
		IServiceNowService _targetServiceNowService;

		readonly string customerAccountTable = "customer_account";
		readonly string customerAccountQuery
			= "sysparm_query=customer=true&sysparm_fields=city,country,customer,name,number,phone,state,sys_id,u_customer_number,u_ns_region,zip";

		readonly string accountAzureEventMappingTable = "u_account_azure_event_mapping";
		readonly string accountAzureEventMappingQuery
			= @"sysparm_query=u_account.customer=true&sysparm_fields=sys_id,u_account.sys_id,u_azure_auth_key,u_data_source_prefix,u_disable_esb_reporting,u_disable_vm_sync,u_enable_cmdb_sync,u_enable_intune_reports,
				u_enable_user_sync,u_intune_warehouse_endpoint,u_subscription_ids,u_tenant_ids,u_workspace_ids";

		public SyncAccountsService(IConfiguration configuration,
								   ILogger<SyncAccountsService> logger,
								   IEnumerable<IServiceNowService> serviceNowServices)
		{
			_configuration = configuration;
			_logger = logger;

			_sourceServiceNowSerivce = serviceNowServices.Where(x => x.Instance == _configuration["SourceInstance"]).FirstOrDefault();
			_targetServiceNowService = serviceNowServices.Where(x => x.Instance == _configuration["TargetInstance"]).FirstOrDefault();
		}

		public async Task SyncAccounts()
		{
			/*
			 * Sync missing accounts from source to target instance.
			 */
			var sourceAcccountResults = await _sourceServiceNowSerivce.ExecuteTableQueryAsync(customerAccountTable, customerAccountQuery);
			var sourceAccounts = sourceAcccountResults.ToObject<List<CustomerAccount>>();

			var targetAccountResults = await _targetServiceNowService.ExecuteTableQueryAsync(customerAccountTable, customerAccountQuery);
			var targetAccounts = targetAccountResults.ToObject<List<CustomerAccount>>();

			var missingAccountsInTargets = sourceAccounts.Where(x => !targetAccounts.Any(y => y.SysId == x.SysId)).ToList();
			_logger.LogInformation($"There are {missingAccountsInTargets.Count} accounts to add in {_targetServiceNowService.Instance}");
			foreach(var missingAccount in missingAccountsInTargets)
			{
				try
				{
					await _targetServiceNowService.ExecuteInsertAsync(customerAccountTable, missingAccount);
					_logger.LogInformation($"Added account {missingAccount.Name} ({missingAccount.SysId}) accounts in {_targetServiceNowService.Instance}.");
				}
				catch(Exception ex)
				{
					_logger.LogError($"Failed to insert account {missingAccount.Name} ({missingAccount.SysId}) in {_targetServiceNowService.Instance}. \n{ex.Message}");
				}
			}

			/*
			 * Sync missing account azure event mappings from source to target. 
			 */

			var sourceMappingResult = await _sourceServiceNowSerivce.ExecuteTableQueryAsync(accountAzureEventMappingTable, accountAzureEventMappingQuery);
			var sourceMappings = sourceMappingResult.ToObject<List<AccountAzureEventMapping>>();

			var targetMappingResult = await _targetServiceNowService.ExecuteTableQueryAsync(accountAzureEventMappingTable, accountAzureEventMappingQuery);
			var targetMappings = targetMappingResult.ToObject<List<AccountAzureEventMapping>>();

			var missingMappings = sourceMappings.Where(x => !targetMappings.Any(y => y.SysId == x.SysId)).ToList();
			_logger.LogInformation($"There are {missingMappings.Count} account azure event mappings to add in {_targetServiceNowService.Instance}");
			foreach (var missingMapping in missingMappings)
			{
				try
				{
					await _targetServiceNowService.ExecuteInsertAsync(accountAzureEventMappingTable, missingMapping);
					_logger.LogInformation($"Added auth key {missingMapping.AzureAuthKey} to account azure event mappings in {_targetServiceNowService.Instance}.");
				}
				catch (Exception ex)
				{
					_logger.LogError($"Failed to insert account azure event mappings for {missingMapping.AzureAuthKey} in {_targetServiceNowService.Instance}. \n{ex.Message}");
				}
			}
		}
	}
}
