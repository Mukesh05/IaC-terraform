﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace ServiceNowAccountSync.Services
{
	public interface IServiceNowService
	{
		string Instance { get; }

		Task ExecuteInsertAsync<T>(string tableName, T dataObject);

		Task<JArray> ExecuteTableQueryAsync(string tableName, string query);
	}
}
