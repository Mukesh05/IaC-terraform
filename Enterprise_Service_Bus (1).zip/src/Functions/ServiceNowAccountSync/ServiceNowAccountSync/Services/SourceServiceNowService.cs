﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using Microsoft.Extensions.Configuration;

namespace ServiceNowAccountSync.Services
{
	public class SourceServiceNowService : ServiceNowServiceBase, IServiceNowService
	{
		string _instance;

		public SourceServiceNowService(IConfiguration config, IHttpClientFactory httpClientFactory) :
			base(httpClientFactory, config["SourceInstance"],
							 config["ServiceNow:ClientId"],
							 config["ServiceNow:Secret"],
							 config["ServiceNow:UserId"],
							 config["ServiceNow:UserPassword"])
		{
			_instance = config["SourceInstance"];
		}

		public string Instance
		{
			get
			{
				return _instance;
			}
		}
	}
}
