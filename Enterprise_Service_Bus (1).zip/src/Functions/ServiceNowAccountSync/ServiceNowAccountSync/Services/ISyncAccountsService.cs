﻿using System.Threading.Tasks;

namespace ServiceNowAccountSync.Services
{
	public interface ISyncAccountsService
	{
		Task SyncAccounts();
	}
}
