﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace ServiceNowAccountSync.Services
{
	[ExcludeFromCodeCoverage]
	public abstract class ServiceNowServiceBase
	{
		HttpClient _httpClient;
		string _instance;
		string _clientId;
		string _clientSecret;
		string _userId;
		string _password;

		public ServiceNowServiceBase(IHttpClientFactory httpClientFactory,
									 string instance,
									 string clientId,
									 string clientSecret,
									 string userId,
									 string password)
		{
			_httpClient = httpClientFactory.CreateClient("Default");
			_instance = instance;
			_clientId = clientId;
			_clientSecret = clientSecret;
			_userId = userId;
			_password = password;
		}

		public async Task ExecuteInsertAsync<T>(string tableName, T dataObject)
		{
			//Convert the object to a json string containing property:value.
			//Objects properties need to have JsonProperty with matching name as field name
			//in Service Now for specified table.
			var json = JsonConvert.SerializeObject(dataObject);

			var token = await GetBearerTokenAsync();

			var request = new HttpRequestMessage(HttpMethod.Post, $"https://{_instance}/api/now/table/{tableName}");
			request.Headers.Clear();
			request.Headers.Add("Authorization", $"Bearer {token}");
			request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
			request.Content = new StringContent(json);
			request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

			var result = await _httpClient.SendAsync(request, HttpCompletionOption.ResponseContentRead);
			if (result.StatusCode != System.Net.HttpStatusCode.OK &&
				result.StatusCode != System.Net.HttpStatusCode.Created)
			{
				var error = await result.Content.ReadAsStringAsync();
				throw new Exception($"Failed to call Service Now table api (POST). (StatusCode : {result.StatusCode}, Error: {error})");
			}
			var responsePayload = await result.Content.ReadAsStringAsync();

			var queryResult = JObject.Parse(responsePayload);
		}

		public async Task<JArray> ExecuteTableQueryAsync(string tableName, string query)
		{
			string token = await GetBearerTokenAsync();

			var request = new HttpRequestMessage(HttpMethod.Get, $"https://{_instance}/api/now/table/{tableName}?{query}");
			request.Headers.Clear();
			request.Headers.Add("Authorization", $"Bearer {token}");
			request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
			
			var result = await _httpClient.SendAsync(request);
			if (result.StatusCode != System.Net.HttpStatusCode.OK)
			{
				var error = await result.Content.ReadAsStringAsync();
				throw new Exception($"Failed to call Service Now table api. (StatusCode : {result.StatusCode}, Error: {error})");
			}
			result.Headers.Clear();

			var responsePayload = await result.Content.ReadAsStringAsync();

			var queryResult = JObject.Parse(responsePayload);

			return (JArray)queryResult["result"];
		}

		private async Task<string> GetBearerTokenAsync()
		{
			IDictionary<string, string> keyValuePairs = new Dictionary<string, string>();
			keyValuePairs.Add("grant_type", "password");
			keyValuePairs.Add("client_id", _clientId);
			keyValuePairs.Add("client_secret", _clientSecret);
			keyValuePairs.Add("username", _userId);
			keyValuePairs.Add("password", _password);

			var request = new HttpRequestMessage(HttpMethod.Post, $"https://{_instance}/oauth_token.do")
			{
				Content = new FormUrlEncodedContent(keyValuePairs),
			};
			request.Content.Headers.Clear();
			request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/x-www-form-urlencoded");
			
			_httpClient.DefaultRequestHeaders.Clear();
			_httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
			
			var result = await _httpClient.SendAsync(request, HttpCompletionOption.ResponseContentRead);
			if (result.StatusCode != System.Net.HttpStatusCode.OK)
			{
				throw new Exception($"Failed to retrieve bearer token. (StatusCode : {result.StatusCode}, ReasonPhrase: {result.ReasonPhrase})");
			}

			result.Headers.Clear();

			var responsePayload = await result.Content.ReadAsStringAsync();

			JObject json;
			try
			{
				json = JObject.Parse(responsePayload);
			}
			catch
			{
				throw new Exception($"Failed to retrieve bearer token. Call was successful but response was not json.");
			}

			var accessToken = (string)json["access_token"];
			if (string.IsNullOrEmpty(accessToken))
			{
				throw new Exception("Access token was null or empty. Unknown error.");
			}

			return accessToken;
		}
	}
}
