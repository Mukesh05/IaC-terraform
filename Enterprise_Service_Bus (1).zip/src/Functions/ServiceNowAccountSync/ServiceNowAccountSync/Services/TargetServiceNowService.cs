﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using Microsoft.Extensions.Configuration;

namespace ServiceNowAccountSync.Services
{
	public class TargetServiceNowService : ServiceNowServiceBase, IServiceNowService
	{
		string _instance;

		public TargetServiceNowService(IConfiguration config, IHttpClientFactory httpClientFactory) :
			base(httpClientFactory, config["TargetInstance"],
							 config["ServiceNow:ClientId"],
							 config["ServiceNow:Secret"],
							 config["ServiceNow:UserId"],
							 config["ServiceNow:UserPassword"])
		{
			_instance = config["TargetInstance"];
		}

		public string Instance
		{
			get
			{
				return _instance;
			}
		}
	}
}
