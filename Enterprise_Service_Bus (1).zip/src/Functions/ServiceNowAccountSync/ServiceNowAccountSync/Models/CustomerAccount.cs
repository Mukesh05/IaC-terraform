﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace ServiceNowAccountSync.Models
{
	//account_code,account_path,city,country,customer,name,number,phone,state,sys_id,u_customer_number,u_ns_region,zip

	public class CustomerAccount
	{
		//[JsonProperty("account_code")]
		//public string AccountCode { get; set; }
		//[JsonProperty("account_path")]
		//public string AccountPath { get; set; }
		[JsonProperty("city")]
		public string City { get; set; }
		[JsonProperty("country")]
		public string Country { get; set; }
		[JsonProperty("customer")]
		public bool IsCustomer { get; set; }
		[JsonProperty("name")]
		public string Name { get; set; }
		[JsonProperty("number")]
		public string Number { get; set; }
		[JsonProperty("phone")]
		public string Phone { get; set; }
		[JsonProperty("state")]
		public string State { get; set; }
		[JsonProperty("sys_id")]
		public string SysId { get; set; }
		[JsonProperty("u_customer_number")]
		public string CustomerNumber { get; set; }
		[JsonProperty("u_ns_region")]
		public string NSRegion { get; set; }
		[JsonProperty("zip")]
		public string Zip { get; set; }
	}
}
