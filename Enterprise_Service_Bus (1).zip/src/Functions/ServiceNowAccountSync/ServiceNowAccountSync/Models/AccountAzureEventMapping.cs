﻿using Newtonsoft.Json;

namespace ServiceNowAccountSync.Models
{
	public class AccountAzureEventMapping
	{

		[JsonProperty("sys_id")]
		public string SysId { get; set; }
		[JsonProperty("u_account.sys_id")]
		public string AccountSysId { get; set; }
		[JsonProperty("u_account")]
		public string Account { get { return AccountSysId; } set { value = AccountSysId; } }
		[JsonProperty("u_azure_auth_key")]
		public string AzureAuthKey { get; set; }
		[JsonProperty("u_data_source_prefix")]
		public string DataSourcePrefix { get; set; }
		[JsonProperty("u_disable_esb_reporting")]
		public bool DisableESBReport { get; set; }
		[JsonProperty("u_disable_vm_sync")]
		public bool DisableVmSync { get; set; }
		[JsonProperty("u_enable_cmdb_sync")]
		public bool EnableCMDBSync { get; set; }
		[JsonProperty("u_enable_intune_reports")]
		public bool EnableIntuneReports { get; set; }
		[JsonProperty("u_enable_user_sync")]
		public bool EnableUserSync { get; set; }
		[JsonProperty("u_intune_report_consent")]
		public string IntuneReportConsent { get; set; }
		[JsonProperty("u_intune_warehouse_endpoint")]
		public string IntuneWarehouseEndpoint { get; set; }
		[JsonProperty("u_subscription_ids")]
		public string SubscriptionIds { get; set; }
		[JsonProperty("u_security_health_consent")]
		public string SecurityHealthConsent { get; set; }
		[JsonProperty("u_system_health_consent")]
		public string SystemHealthConsent { get; set; }
		[JsonProperty("u_tenant_ids")]
		public string TenantIds { get; set; }
		[JsonProperty("u_workspace_ids")]
		public string WorkspaceIds { get; set; }
		
	}
}
