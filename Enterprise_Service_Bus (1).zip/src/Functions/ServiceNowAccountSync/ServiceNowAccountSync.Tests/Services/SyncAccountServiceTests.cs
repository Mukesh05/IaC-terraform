﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Moq.Protected;
using ServiceNowAccountSync.Services;

namespace ServiceNowAccountSync.Tests.Services
{
	[TestClass]
	public class SyncAccountServiceTests
	{
		Mock<IConfiguration> _mockConfiguration;
		Mock<ILogger<SyncAccountsService>> _mockLogger;


		[TestInitialize]
		public void Initialize()
		{
			_mockConfiguration = new Mock<IConfiguration>();
			_mockConfiguration.Setup(x => x["SourceInstance"]).Returns("newsignaturetest.service-now.com");
			_mockConfiguration.Setup(x => x["TargetInstance"]).Returns("newsignaturedev.service-now.com");
			_mockConfiguration.Setup(x => x["ServiceNow:ClientId"]).Returns("xxxxx");
			_mockConfiguration.Setup(x => x["ServiceNow:Secret"]).Returns("xxxxx");
			_mockConfiguration.Setup(x => x["ServiceNow:UserId"]).Returns("xxxxx");
			_mockConfiguration.Setup(x => x["ServiceNow:UserPassword"]).Returns("xxxxx");

			_mockLogger = new Mock<ILogger<SyncAccountsService>>();
		}

		[TestMethod]
		public async Task TestSyncProdToDev()
		{
			List<IServiceNowService> serviceList = new List<IServiceNowService>();
			serviceList.Add(SetupSourceServiceNowService());
			serviceList.Add(SetupTargetServiceNowService());
			
			SyncAccountsService syncAccountsService =
				new SyncAccountsService(_mockConfiguration.Object,
										_mockLogger.Object,
										serviceList);

			await syncAccountsService.SyncAccounts();

			_mockLogger.VerifyLogging("There are 0 accounts to add in newsignaturedev.service-now.com", LogLevel.Information);
			_mockLogger.VerifyLogging("There are 0 account azure event mappings to add in newsignaturedev.service-now.com", LogLevel.Information);
		}

		private IServiceNowService SetupSourceServiceNowService()
		{
			var prodToken = File.ReadAllText("TestFiles\\FakeToken.json");
			var prodAccounts = File.ReadAllText("TestFiles\\ProdAccounts.json");
			var prodMappings = File.ReadAllText("TestFiles\\ProdMappings.json");
			
			var handlerMock = new Mock<HttpMessageHandler>();
			handlerMock
				.Protected()
				.SetupSequence<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>())
				.ReturnsAsync(new HttpResponseMessage
				{
					StatusCode = HttpStatusCode.OK,
					Content = new StringContent(prodToken),
				})
				.ReturnsAsync(new HttpResponseMessage
				{
					StatusCode = HttpStatusCode.OK,
					Content = new StringContent(prodAccounts),
				})
				.ReturnsAsync(new HttpResponseMessage
				{
					StatusCode = HttpStatusCode.OK,
					Content = new StringContent(prodToken),
				})
				.ReturnsAsync(new HttpResponseMessage
				{
					StatusCode = HttpStatusCode.OK,
					Content = new StringContent(prodMappings),
				});

			var httpClient = new HttpClient(handlerMock.Object);
			var mockFactoryForProd = new Mock<IHttpClientFactory>();
			mockFactoryForProd.Setup(_ => _.CreateClient(It.IsAny<string>())).Returns(httpClient);

			IServiceNowService prodService =new SourceServiceNowService(_mockConfiguration.Object, mockFactoryForProd.Object);

			return prodService;
		}

		private IServiceNowService SetupTargetServiceNowService()
		{
			var devToken = File.ReadAllText("TestFiles\\FakeToken.json");
			var devAccounts = File.ReadAllText("TestFiles\\DevAccounts.json");
			var devMappings = File.ReadAllText("TestFiles\\ProdMappings.json");

			var handlerMock = new Mock<HttpMessageHandler>();
			handlerMock
				.Protected()
				.SetupSequence<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>())
				.ReturnsAsync(new HttpResponseMessage
				{
					StatusCode = HttpStatusCode.OK,
					Content = new StringContent(devToken),
				})
				.ReturnsAsync(new HttpResponseMessage
				{
					StatusCode = HttpStatusCode.OK,
					Content = new StringContent(devAccounts),
				}).ReturnsAsync(new HttpResponseMessage
				{
					StatusCode = HttpStatusCode.OK,
					Content = new StringContent(devToken),
				}).ReturnsAsync(new HttpResponseMessage
				{
					StatusCode = HttpStatusCode.OK,
					Content = new StringContent(devMappings),
				});

			var httpClient = new HttpClient(handlerMock.Object);

			var mockFactoryForDev = new Mock<IHttpClientFactory>();
			mockFactoryForDev.Setup(_ => _.CreateClient(It.IsAny<string>())).Returns(httpClient);

			IServiceNowService devService = new TargetServiceNowService(_mockConfiguration.Object, mockFactoryForDev.Object);

			return devService;
		}
	}
}