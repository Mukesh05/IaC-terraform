﻿using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace Common.ESB
{
	public class ServiceNowTableQuery : IServiceNowTableQuery
	{
		IConfiguration _configuration;

		public ServiceNowTableQuery(IConfiguration configuration)
		{
			_configuration = configuration;
		}

		/// <summary>
		/// Generic method to retreive parametrised table data from ServiceNow. 
		/// </summary>
		/// <returns></returns>
		public async Task<T> GetServiceNowTableData<T>(string table, string tableQuery)
		{
			var instance = _configuration["ServiceNow:Instance"];
			var clientId = _configuration["ServiceNow:ClientId"];
			var clientSecret = _configuration["ServiceNow:Secret"];
			var userId = _configuration["ServiceNow:UserId"];
			var userPw = _configuration["ServiceNow:UserPassword"];

			IServiceNowOauthTokenProvider tokenProvider = new ServiceNowOauthTokenProvider(instance,
																						   clientId,
																						   clientSecret,
																						   userId,
																						   userPw);

			IServiceNowClient client = new ServiceNowClient(tokenProvider);

			var serviceNowTableJsonData = await client.QueryTable(table, tableQuery);
			var serviceNowRows = JsonConvert.DeserializeObject<T>(serviceNowTableJsonData);

			return serviceNowRows;
		}

		public async Task<T> InsertIntoServiceNowTable<T>(string table, string jsonPayload)
		{
			var instance = _configuration["ServiceNow:Instance"];
			var clientId = _configuration["ServiceNow:ClientId"];
			var clientSecret = _configuration["ServiceNow:Secret"];
			var userId = _configuration["ServiceNow:UserId"];
			var userPw = _configuration["ServiceNow:UserPassword"];

			IServiceNowOauthTokenProvider tokenProvider = new ServiceNowOauthTokenProvider(instance,
																						   clientId,
																						   clientSecret,
																						   userId,
																						   userPw);

			IServiceNowClient client = new ServiceNowClient(tokenProvider);
			var response = await client.InsertIntoTable(table, jsonPayload);
			var result = JsonConvert.DeserializeObject<T>(response);

			return result;
		}
	}
}
