﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace Common.ESB
{
	public class ServiceNowAccountResult
	{
		public ServiceNowAccountResult()
		{
			ServiceNowAccounts = new List<ServiceNowAccount>();
		}
		[JsonProperty("result")]
		public IList<ServiceNowAccount> ServiceNowAccounts { get; set; }
	}

	public class ServiceNowAccount
	{
		[JsonProperty("u_account.name")]
		public string Account_name { get; set; }

		[JsonProperty("u_account.sys_id")]
		public string Account_SysId { get; set; }

		[JsonProperty("u_tenant_ids")]
		public string Tenant_ids { get; set; }
		[JsonProperty("u_intune_warehouse_endpoint")]
		public string Intune_warehouse_endpoint { get; set; }
		[JsonProperty("u_workspace_ids")]
		public string LA_WorkspaceIds { get; set; }
	}
}
