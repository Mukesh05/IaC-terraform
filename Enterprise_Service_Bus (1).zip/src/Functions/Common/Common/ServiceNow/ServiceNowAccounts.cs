﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace Common.ESB
{
	public class ServiceNowAccounts : IServiceNowAccounts
	{
		IConfiguration _configuration;

		public ServiceNowAccounts(IConfiguration configuration)
		{
			_configuration = configuration;
		}

		/// <summary>
		/// Retreive Intune endpoint url from ServiceNow. If there is no endpoint set
		/// in service now it is consider not enabled for account.
		/// </summary>
		/// <returns></returns>
		public async Task<IList<ServiceNowAccount>> GetServiceNowAccounts()
		{
			var instance = _configuration["ServiceNow:Instance"];
			var clientId = _configuration["ServiceNow:ClientId"];
			var clientSecret = _configuration["ServiceNow:Secret"];
			var userId = _configuration["ServiceNow:UserId"];
			var userPw = _configuration["ServiceNow:UserPassword"];

			IServiceNowOauthTokenProvider tokenProvider = new ServiceNowOauthTokenProvider(instance,
																						   clientId,
																						   clientSecret,
																						   userId,
																						   userPw);

			IServiceNowClient client = new ServiceNowClient(tokenProvider);

			var serviceNowTenantJsonData = await client.QueryTable("u_account_azure_event_mapping",
					"sysparm_query=u_intune_warehouse_endpointISNOTEMPTY^u_disable_esb_reporting=false&sysparm_fields=u_account.name,u_tenant_ids,u_intune_warehouse_endpoint,u_workspace_ids");

			var serviceNowTenantObject = JsonConvert.DeserializeObject<ServiceNowAccountResult>(serviceNowTenantJsonData);

			return serviceNowTenantObject.ServiceNowAccounts;
		}
	}
}
