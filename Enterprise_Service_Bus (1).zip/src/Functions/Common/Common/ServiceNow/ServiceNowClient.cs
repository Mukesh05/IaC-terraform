﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace Common.ESB
{
	public class ServiceNowClient : IServiceNowClient
	{
		string _serviceNowInstance;
		IServiceNowOauthTokenProvider _serviceNowOauthTokenProvider;
		
		private static readonly HttpClient _httpClient = new HttpClient();

		private ServiceNowClient() { }

		public ServiceNowClient(IServiceNowOauthTokenProvider serviceNowOauthTokenProvider)
		{
			_serviceNowOauthTokenProvider = serviceNowOauthTokenProvider;
			_serviceNowInstance = serviceNowOauthTokenProvider.ServiceNowInstance;
		}

		/// <summary>
		/// Makes a call out to Service Now table query API.
		/// See https://docs.servicenow.com/bundle/london-platform-user-interface/page/use/common-ui-elements/reference/r_OpAvailableFiltersQueries.html for sysparm_query options.
		/// </summary>
		/// <param name="tableName">The name of the table in Service Now</param>
		/// <param name="queryString">The query string to use against the table. </param>
		/// <returns>JSON string</returns>
		public async Task<string> QueryTable(string tableName, string queryString)
		{
			string url = $"https://{_serviceNowInstance}/api/now/table/{tableName}?{queryString}";
			string token = await _serviceNowOauthTokenProvider.GetBearerAccessToken();

			var request = new HttpRequestMessage(HttpMethod.Get, url);
			request.Headers.Clear();
			request.Headers.Add("Authorization", $"Bearer {token}");
			request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

			var result = await _httpClient.SendAsync(request);

			if (result.StatusCode != System.Net.HttpStatusCode.OK)
			{
				throw new Exception($"Failed to call Service Now table query. (StatusCode : {result.StatusCode}, ReasonPhrase: {result.ReasonPhrase})");
			}

			var responsePayload = await result.Content.ReadAsStringAsync();

			return responsePayload;
		}

		public async Task<string> InsertIntoTable(string tableName, string jsonPayload)
		{
			string url = $"https://{_serviceNowInstance}/api/now/table/{tableName}";
			string token = await _serviceNowOauthTokenProvider.GetBearerAccessToken();

			var request = new HttpRequestMessage(HttpMethod.Post, url);
			request.Headers.Clear();
			request.Headers.Add("Authorization", $"Bearer {token}");
			request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
			request.Content = new StringContent(jsonPayload, System.Text.Encoding.UTF8, "application/json");
			
			var result = await _httpClient.SendAsync(request);
			var responsePayload = await result.Content.ReadAsStringAsync();

			return responsePayload;
		}

	}
}
