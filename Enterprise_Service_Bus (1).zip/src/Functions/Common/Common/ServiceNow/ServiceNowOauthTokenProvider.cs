﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace Common.ESB
{
	public class ServiceNowOauthTokenProvider : IServiceNowOauthTokenProvider
	{
		string _authEndpoint;
		string _clientId;
		string _clientSecret;
		string _userId;
		string _userPassword;

		private static readonly HttpClient _httpClient = new HttpClient();

		private ServiceNowOauthTokenProvider() { }

		public ServiceNowOauthTokenProvider(string serviceNowInstance,
											string clientId,
											string clientSecret,
											string userId,
											string userPassword)
		{
			ServiceNowInstance = serviceNowInstance;
			_authEndpoint = $"https://{ServiceNowInstance}/oauth_token.do";
			_clientId = clientId;
			_clientSecret = clientSecret;
			_userId = userId;
			_userPassword = userPassword;
		}

		public string ServiceNowInstance { get; }

		public async Task<string> GetBearerAccessToken()
		{
			IDictionary<string, string> keyValuePairs = new Dictionary<string, string>();
			keyValuePairs.Add("grant_type", "password");
			keyValuePairs.Add("client_id", _clientId);
			keyValuePairs.Add("client_secret", _clientSecret);
			keyValuePairs.Add("username", _userId);
			keyValuePairs.Add("password", _userPassword);

			var result = await _httpClient.PostAsync(_authEndpoint, new FormUrlEncodedContent(keyValuePairs));

			if (result.StatusCode != System.Net.HttpStatusCode.OK)
			{
				throw new Exception($"Failed to retrieve bearer token. (StatusCode : {result.StatusCode}, ReasonPhrase: {result.ReasonPhrase})");
			}

			var responsePayload = await result.Content.ReadAsStringAsync();
			var json = JObject.Parse(responsePayload);

			var accessToken = (string)json["access_token"];
			if (string.IsNullOrEmpty(accessToken))
			{
				throw new Exception("Access token was null or empty. Unknown error.");
			}

			return accessToken;
		}
	}
}