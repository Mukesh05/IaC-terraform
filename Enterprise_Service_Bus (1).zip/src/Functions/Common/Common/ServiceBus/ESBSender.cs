﻿using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Management;
using System.Text;
using System.Threading.Tasks;


namespace Common.ESB
{
	public class ESBSender : IESBSender
    {
        string _connectionString;
		string _name;   

		public string Name { get
			{
				return _name;
			}
		}
		private ESBSender() { }

        public ESBSender(string connectionString)
        {
            _connectionString = connectionString;
        }

		
		public ESBSender(string connectionString, string name)
		{
			_connectionString = connectionString;
			_name = name;
		}

        public async Task SendMessageAsync(string topicName, string message)
        {
            ServiceBusConnectionStringBuilder builder = new ServiceBusConnectionStringBuilder(_connectionString);
            builder.EntityPath = topicName;

            //Create topic if not exist.
            ManagementClient managementClient = new ManagementClient(builder);
            bool topicExists = await managementClient.TopicExistsAsync(topicName);
            if (!topicExists)
            {
                var topicDescription = await managementClient.CreateTopicAsync(topicName);
            }

			Message esbMessage = new Message(Encoding.UTF8.GetBytes(message));
            TopicClient topicClient = new TopicClient(builder);
            await topicClient.SendAsync(esbMessage);
        }
    }
}
