﻿using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Management;
using System.Threading.Tasks;

namespace Common.ESB
{
	public class ESBReceiver : IESBReceiver
    {
        string _connectionString;

        private ESBReceiver() { }

        public ESBReceiver(string connectionString)
        {
            _connectionString = connectionString;
        }

		public async Task<bool> CreateSubscriptionIfNotExist(string topicName, string subscriptionName)
		{
			ServiceBusConnectionStringBuilder builder = new ServiceBusConnectionStringBuilder(_connectionString);
			builder.EntityPath = topicName;

			//Create subscription if not exist.
			ManagementClient managementClient = new ManagementClient(builder);
			var topicExists = await managementClient.TopicExistsAsync(topicName);
			if(!topicExists)
			{
				return false;
			}

			var subscriptionExists = await managementClient.SubscriptionExistsAsync(topicName, subscriptionName);
			if (!subscriptionExists)
			{
				await managementClient.CreateSubscriptionAsync(topicName, subscriptionName);
				return true;
			}

			return true;

		}
	}
}