﻿using System.Threading.Tasks;

namespace Common.ESB
{
	public interface IServiceNowOauthTokenProvider
	{
		string ServiceNowInstance { get; }

		Task<string> GetBearerAccessToken();
	}
}
