﻿using System.Threading.Tasks;

namespace Common.ESB
{
	public interface IESBReceiver
    {
		Task<bool> CreateSubscriptionIfNotExist(string topicName, string subscriptionName);
    }
}
