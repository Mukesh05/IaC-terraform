﻿using System.Threading.Tasks;

namespace Common.ESB
{
	public interface IServiceNowClient
	{
		Task<string> QueryTable(string tableName, string queryString);
		Task<string> InsertIntoTable(string tableName, string jsonPayload);

	}
}
