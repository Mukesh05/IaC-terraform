﻿using System.Threading.Tasks;

namespace Common.ESB
{
	public interface ISecurity
	{
		Task<string> GetAuthToken(string tokenAudience, string tenantId, string servicePrincipalSecret, string servicePrincipalId);
	}
}