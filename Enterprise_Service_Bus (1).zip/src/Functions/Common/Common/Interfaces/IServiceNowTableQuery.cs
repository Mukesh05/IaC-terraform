﻿using System.Threading.Tasks;

namespace Common.ESB
{
	public interface IServiceNowTableQuery
	{
		Task<T> GetServiceNowTableData<T>(string table, string tableQuery);
		Task<T> InsertIntoServiceNowTable<T>(string table, string jsonPayload);
	}
}
