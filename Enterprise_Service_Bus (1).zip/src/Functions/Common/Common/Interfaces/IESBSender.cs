﻿using System.Threading.Tasks;

namespace Common.ESB
{
	public interface IESBSender
    {
        Task SendMessageAsync(string topicName, string message);
		string Name { get; }
	}
}
