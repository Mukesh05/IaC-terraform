﻿using System.Threading.Tasks;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.Extensions.Configuration;

namespace Common.ESB
{
	public class Security : ISecurity
	{
		IConfiguration _config;

		public Security(IConfiguration config)
		{
			_config = config;
		}

		public async Task<string> GetAuthToken(string tokenAudience, string tenantId, string servicePrincipalSecret, string servicePrincipalId)
		{
			var authenticationContext = new AuthenticationContext($"https://login.windows.net/{tenantId}");
			var credentials = new ClientCredential(servicePrincipalId, servicePrincipalSecret);
			var x = await authenticationContext.AcquireTokenAsync(tokenAudience, credentials);
			return x.AccessToken;
		}
	}
}
