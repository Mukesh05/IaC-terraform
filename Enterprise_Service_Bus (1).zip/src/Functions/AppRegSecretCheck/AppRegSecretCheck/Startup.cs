﻿using System;
using System.IO;
using AppRegSecretCheck.Services;
using Azure.Core;
using Azure.Identity;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

[assembly: FunctionsStartup(typeof(AppRegSecretCheck.Startup))]

namespace AppRegSecretCheck;

[System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage()]
public class Startup : FunctionsStartup
{
	public override void Configure(IFunctionsHostBuilder builder)
	{

		IConfigurationRefresher configRefresher = null;

		// Needed for local development if trying to access app config in Azure
		TokenCredential tokenCredential = new DefaultAzureCredential();
		var environment = Environment.GetEnvironmentVariable("AZURE_FUNCTIONS_ENVIRONMENT");
		if (string.Compare(environment, "development", true) == 0)
		{
			tokenCredential = new VisualStudioCredential(new VisualStudioCredentialOptions()
			{
				TenantId = "a1a2578a-8fd3-4595-bb18-7d17df8944b0"
			});
		}

		// Config setup. Azure App Config first to allow local.settings.json to
		// override settings during local testing.
		var appconfigConnectionString = Environment.GetEnvironmentVariable("appconfigconnectionstring", EnvironmentVariableTarget.Process);
		var configBuilder = new ConfigurationBuilder()
			.SetBasePath(Directory.GetCurrentDirectory())
			.AddAzureAppConfiguration(options =>
			{
				options.Connect(appconfigConnectionString)
				.Select("ServiceNow:*")
				.Select("AppRegSecretCheck:*")
				.ConfigureKeyVault(kv =>
				{
					kv.SetCredential(tokenCredential); //NuGet Azure.Identity
				});
				configRefresher = options.GetRefresher();
			})
			.SetBasePath(Directory.GetCurrentDirectory())
			.AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
			.AddEnvironmentVariables();

		IConfiguration config = configBuilder.Build();

		// Register services here
		builder.Services.AddSingleton<IConfiguration>((services) =>
		{
			return config;
		});

		builder.Services.AddHttpClient("default").ConfigurePrimaryHttpMessageHandler(() =>
		{
			return new System.Net.Http.HttpClientHandler()
			{
				UseCookies = false
			};
		});

		builder.Services.AddSingleton<IAppRegistrationStorage, AppRegistrationStorage>();
		builder.Services.AddSingleton<IGraphApplication, GraphApplication>();
		builder.Services.AddSingleton<IAppRegistrationCore, AppRegistrationCore>();

		builder.Services.AddHttpClient("default").ConfigurePrimaryHttpMessageHandler(() =>
		{
			return new System.Net.Http.HttpClientHandler()
			{
				UseCookies = false
			};
		});

		builder.Services.AddSingleton<IServiceNow, ServiceNow>();
	}
}

