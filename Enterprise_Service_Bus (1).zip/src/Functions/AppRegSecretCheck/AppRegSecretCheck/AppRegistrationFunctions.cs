using System.Text.Json;
using System.Threading.Tasks;
using AppRegSecretCheck.Models;
using AppRegSecretCheck.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace AppRegSecretCheck;

[System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage()]
public class AppRegSecretCheckFunction
{
	IConfiguration _config;
	ILogger _logger;
	IAppRegistrationStorage _storage;
	IAppRegistrationCore _appRegistrationCore;
	IServiceNow _serviceNow;


	public AppRegSecretCheckFunction(IConfiguration config,
		ILogger<AppRegSecretCheckFunction> logger,
		IAppRegistrationStorage storage,
		IAppRegistrationCore appRegistrationCore,
		IServiceNow serviceNow)
	{
		_logger = logger;
		_storage = storage;
		_appRegistrationCore = appRegistrationCore;
		_serviceNow = serviceNow;
		_config = config;
	}

    [FunctionName("CheckTimerTrigger")]
    public async Task RunAsync([TimerTrigger("%TimerSchedule%")]TimerInfo myTimer)
    {
		await _appRegistrationCore.CheckForExpiringAppRegSecretsAsync();
    }

	[FunctionName("CheckOnDemand")]
	public async Task RunOnDemandAsync([HttpTrigger(AuthorizationLevel.Function, "get", Route = null)] HttpRequest req)
	{
		await _appRegistrationCore.CheckForExpiringAppRegSecretsAsync();
	}

	[FunctionName("AddAppRegToCheck")]
	public async Task Add([HttpTrigger(AuthorizationLevel.Function, "post", Route = "appregistration")] HttpRequest req)
	{
		var request = await req.ReadAsStringAsync();
		var app = JsonSerializer.Deserialize<AppRegistration>(request);
		await _storage.AddAsync(app);
	}

	[FunctionName("DeleteAppRegToCheck")]
	public async Task Delete(
		[HttpTrigger(AuthorizationLevel.Function, "delete", Route = "appregistration/tenantId/{tenantId}/clientId/{clientId}")] HttpRequest req,
		string tenantId,
		string clientId)
	{
		await _storage.DeleteAsync(tenantId, clientId);
	}

	[FunctionName("ListAppRegsToCheck")]
	public async Task<IActionResult> List([HttpTrigger(AuthorizationLevel.Function, "get", Route = "appregistration")] HttpRequest req)
	{
		var appRegList = await _storage.ListAsync();
		return new OkObjectResult(appRegList);
	}

	[FunctionName("GetAppRegToCheck")]
	public async Task<IActionResult> Get(
		[HttpTrigger(AuthorizationLevel.Function, "get", Route = "appregistration/tenantId/{tenantId}/clientId/{clientId}")] HttpRequest req,
		string tenantId,
		string clientId)
	{
		var app = await _storage.GetAsync(tenantId, clientId);
		return new OkObjectResult(app);
	}
}
