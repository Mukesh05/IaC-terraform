﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AppRegSecretCheck.Models;

namespace AppRegSecretCheck.Services;

public interface IAppRegistrationStorage
{
	public Task<IEnumerable<AppRegistration>> ListAsync();
	public Task AddAsync(AppRegistration entry);
	public Task DeleteAsync(string tenantId, string clientId);
	public Task<AppRegistration> GetAsync(string tenantId, string clientId);

}

