﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AppRegSecretCheck.Models;
using Azure.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Graph;

namespace AppRegSecretCheck.Services;

public class GraphApplication : IGraphApplication
{
	IConfiguration _config;

	public GraphApplication(IConfiguration config)
	{
		_config = config;
	}

	public async Task<AppRegistrationResult> GetApplicationAsync(AppRegistration appRegistration)
	{
		var client = GetClient();

		var app = await client.Applications[appRegistration.ClientId]
			.Request()
			.Select(x => new
			{
				x.Id,
				x.DisplayName,
				x.PasswordCredentials
			})
			.GetAsync();

		var secretExpireTimes = new Dictionary<string, DateTime?>();
		var passwordCredentials = app.PasswordCredentials.Select(x => new { x.DisplayName, x.EndDateTime }).ToList();
		foreach(var secret in passwordCredentials)
		{
			secretExpireTimes.Add(secret.DisplayName, secret.EndDateTime?.DateTime);
		}

		return new AppRegistrationResult()
		{
			ClientId = app.Id,
			Name = app.DisplayName,
			SecretExpireDateTimes = secretExpireTimes
		};
	}

	private GraphServiceClient GetClient()
	{
		// See https://docs.microsoft.com/en-us/graph/sdks/choose-authentication-providers?tabs=CS#tabpanel_2_CS

		var scopes = new[] { "https://graph.microsoft.com/.default" };

		// Multi-tenant apps can use "common",
		// single-tenant apps must use the tenant ID from the Azure portal

		var tenantId = _config["AppRegSecretCheck:TenantId"];
		var clientId = _config["AppRegSecretCheck:ClientId"];
		var clientSecret = _config["AppRegSecretCheck:Secret"];

		// using Azure.Identity;
		var options = new TokenCredentialOptions
		{
			AuthorityHost = AzureAuthorityHosts.AzurePublicCloud
		};

		var clientSecretCredential = new ClientSecretCredential(tenantId, clientId, clientSecret, options);

		var graphClient = new GraphServiceClient(clientSecretCredential, scopes);

		return graphClient;
	}
}