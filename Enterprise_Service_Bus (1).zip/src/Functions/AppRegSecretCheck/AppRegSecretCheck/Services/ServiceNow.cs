﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace AppRegSecretCheck.Services;

public class ServiceNow : IServiceNow
{
	IConfiguration _config;
	HttpClient _httpClient;
	string _serviceNowInstance;

	public ServiceNow(IConfiguration config, IHttpClientFactory httpClientFactory)
	{
		_config = config;
		_httpClient = httpClientFactory.CreateClient("default");
		_serviceNowInstance = _config["ServiceNow:Instance"];
	}

	public async Task<T> QueryAsync<T>(string table, string sysparmQuery, string sysparmFields)
	{
		string url = $"https://{_serviceNowInstance}/api/now/table/{table}?sysparm_query={sysparmQuery}&sysparm_fields={sysparmFields}";
		string token = await GetAccessTokenAsync();

		var request = new HttpRequestMessage(HttpMethod.Get, url);
		request.Headers.Clear();
		request.Headers.Add("Authorization", $"Bearer {token}");
		request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

		var result = await _httpClient.SendAsync(request);

		if (result.StatusCode != System.Net.HttpStatusCode.OK)
		{
			throw new Exception($"Failed to call Service Now table query. (StatusCode : {result.StatusCode}, ReasonPhrase: {result.ReasonPhrase})");
		}

		var responsePayload = await result.Content.ReadAsStringAsync();
		using var jDoc = JsonDocument.Parse(responsePayload);
		var obj = jDoc.RootElement.GetProperty("result").Deserialize<T>();
		
		return obj;
	}

	public async Task<T> InsertAsync<T>(string table, T serviceNowObj, string responseSysparmFields = null)
	{
		var json = JsonSerializer.Serialize<T>(serviceNowObj, new JsonSerializerOptions()
		{
			DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
		});

		string sysParm = string.Empty;
		if(!string.IsNullOrEmpty(responseSysparmFields))
		{
			sysParm = $"?sysparm_fields={responseSysparmFields}";
		}

		string url = $"https://{_serviceNowInstance}/api/now/table/{table}{sysParm}";
		string token = await GetAccessTokenAsync();

		var request = new HttpRequestMessage(HttpMethod.Post, url);
		request.Headers.Clear();
		request.Headers.Add("Authorization", $"Bearer {token}");
		request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
		request.Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
		request.Headers.Add("X-no-response-body", "false");

		var result = await _httpClient.SendAsync(request);
		var responsePayload = await result.Content.ReadAsStringAsync();
				
		using var jDoc = JsonDocument.Parse(responsePayload);
		var resultList = jDoc.RootElement.GetProperty("result");

		return resultList.Deserialize<T>();
	}

	public async Task<string> GetAccessTokenAsync()
	{
		var endpoint = $"https://{_serviceNowInstance}/oauth_token.do";

		IDictionary<string, string> keyValuePairs = new Dictionary<string, string>();
		keyValuePairs.Add("grant_type", "password");
		keyValuePairs.Add("client_id", _config["ServiceNow:ClientId"]);
		keyValuePairs.Add("client_secret", _config["ServiceNow:Secret"]);
		keyValuePairs.Add("username", _config["ServiceNow:UserId"]);
		keyValuePairs.Add("password", _config["ServiceNow:UserPassword"]);

		var result = await _httpClient.PostAsync(endpoint, new FormUrlEncodedContent(keyValuePairs));

		if (result.StatusCode != System.Net.HttpStatusCode.OK)
		{
			throw new Exception($"Failed to retrieve bearer token. (StatusCode : {result.StatusCode}, ReasonPhrase: {result.ReasonPhrase})");
		}

		var responsePayload = await result.Content.ReadAsStringAsync();
	
		string accessToken = String.Empty;
		using (JsonDocument doc = JsonDocument.Parse(responsePayload))
		{
			JsonElement root = doc.RootElement;
			JsonElement jsonAccessToken;
			if (!root.TryGetProperty("access_token", out jsonAccessToken))
			{
				string message = $"Failed to retrieve bearer token for {_serviceNowInstance}. Call was successful but response was not expected.";
				throw new Exception(message);
			}

			accessToken = jsonAccessToken.GetString();
		}

		return accessToken;
	}
}