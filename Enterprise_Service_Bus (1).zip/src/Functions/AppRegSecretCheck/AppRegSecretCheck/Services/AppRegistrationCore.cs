﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AppRegSecretCheck.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Linq;

namespace AppRegSecretCheck.Services;

public class AppRegistrationCore : IAppRegistrationCore
{
	IConfiguration _config;
	ILogger _logger;
	IGraphApplication _graphApplication;
	IAppRegistrationStorage _storage;
	IServiceNow _serviceNow;

	public AppRegistrationCore(IConfiguration config,
		ILogger<AppRegistrationCore> logger,
		IGraphApplication graphApplication,
		IAppRegistrationStorage storage,
		IServiceNow serviceNow)
	{
		_config = config;
		_logger = logger;
		_graphApplication = graphApplication;
		_storage = storage;
		_serviceNow = serviceNow;
	}

	public async Task<bool> IsSecretExpiringAsync(AppRegistration appRegistration, int daysFrom = 0)
	{
		bool isSecretExpired = true;

		var appRegistationsToCheck = await _storage.ListAsync();
		foreach(var app in appRegistationsToCheck)
		{
			var result = await _graphApplication.GetApplicationAsync(appRegistration);
			foreach (var secret in result.SecretExpireDateTimes.Where(secret => secret.Value.HasValue)
			// There can be multiple secrets. Make sure at least one is not expired.
			)
			{
				var expireDate = ((DateTime)secret.Value);
				var current = DateTime.UtcNow;
				if ((current - expireDate).TotalDays < daysFrom)
				{
					isSecretExpired = false;
					break;
				}
			}
		}

		return isSecretExpired;
	}

	public async Task<ServiceNowIncident> CreateServiceNowIncident(AppRegistration app)
	{
		// Check for existing incident
		// If not exists, create it

		var shortDesciption = $"App Registration secret about to expire for App Registration {app.Name} ({app.ClientId})";

		var incidents = await _serviceNow.QueryAsync<List<ServiceNowIncident>>("incident",
			$"active=true^incident_stateIN1,2,3^short_description={shortDesciption}",
			ServiceNowIncident.SysParmFields);

		if(incidents.Count >= 1)
		{
			_logger.LogInformation($"Incident {incidents[0].Number} already created for {app.Name} ({app.ClientId}) in tenant {app.TenantId}.");
			return null;
		}

		var incident = new ServiceNowIncident()
		{
			_assignment_group = "67fd1353dbff0c90c3f96def4b961978",
			_caller_id = "9d5de9e5930022005bc5f179077ffb07",
			_company = "72b8655cdbd6e7401b1518df4b961977",
			ShortDescription = shortDesciption,
			Description = $"App Registration secret about to expire.\nName : {app.Name}\nClientId : {app.ClientId}\nTenantId : {app.TenantId}",
			Impact = "1",
			Urgency = "2",
			Category = "Alert",
			SubCategory = "Other",
			ContactType = "Alert"
		};

		var result = await _serviceNow.InsertAsync("incident", incident, ServiceNowIncident.SysParmFields);

		return result;
	}

	public async Task CheckForExpiringAppRegSecretsAsync()
	{
		var checkDaysFrom = _config["AppRegSecretCheck:DaysToExpireCheck"];
		if(!int.TryParse(checkDaysFrom, out var checkDays))
		{
			checkDays = 7;
		}

		var appRegistrationsToCheck = await _storage.ListAsync();
		foreach(var app in appRegistrationsToCheck)
		{
			_logger.LogInformation($"Checking app registration {app.Name} ({app.ClientId}) for expired secret within {checkDays} days.");
			var isExpired = await IsSecretExpiringAsync(app, checkDays);
			if (isExpired)
			{
				var createdIncident = await CreateServiceNowIncident(app);
				if(createdIncident != null)
				{
					_logger.LogInformation($"App registration {app.Name} ({app.ClientId}) will expire within {checkDays}. " +
						$" Incident {createdIncident.Number} has been created in Service Now.");
				}
			}
		}
	}
}