﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AppRegSecretCheck.Models;
using Azure;
using Azure.Data.Tables;
using Microsoft.Extensions.Configuration;

namespace AppRegSecretCheck.Services;

public class AppRegistrationStorage : IAppRegistrationStorage
{
	public const string TABLE_NAME = "AppRegistrations";

	IConfiguration _config;

	public AppRegistrationStorage(IConfiguration config)
	{
		_config = config;
	}

	public async Task AddAsync(AppRegistration entry)
	{
		TableClient tableClient = new TableClient(_config["AppRegSecretCheck:ConfigStorageConnection"], TABLE_NAME);
		tableClient.CreateIfNotExists();

		TableEntity tableEntity = new TableEntity();
		tableEntity.PartitionKey = entry.TenantId;
		tableEntity.RowKey = entry.ClientId;
		tableEntity.Add("Name", entry.Name);
		
		var response = await tableClient.AddEntityAsync<TableEntity>(tableEntity);
	}

	public async Task<IEnumerable<AppRegistration>> ListAsync()
	{
		TableClient tableClient = new TableClient(_config["AppRegSecretCheck:ConfigStorageConnection"], TABLE_NAME);
		var list = tableClient.QueryAsync<TableEntity>();

		var results = new List<AppRegistration>();

		await foreach (var item in list)
		{
			results.Add(new AppRegistration()
			{
				TenantId = item.PartitionKey,
				ClientId = item.RowKey,
				Name = item.GetString("Name"),
			});
		}

		return results;
	}

	public async Task DeleteAsync(string tenantId, string clientId)
	{
		TableClient tableClient = new TableClient(_config["AppRegSecretCheck:ConfigStorageConnection"], TABLE_NAME);
		await tableClient.DeleteEntityAsync(tenantId, clientId);
	}

	public async Task<AppRegistration> GetAsync(string tenantId, string clientId)
	{
		TableClient tableClient = new TableClient(_config["AppRegSecretCheck:ConfigStorageConnection"], TABLE_NAME);
		Response<TableEntity> entity = null;
		try
		{
			entity = await tableClient.GetEntityAsync<TableEntity>(tenantId, clientId);
		}
		catch (RequestFailedException ex)
		{
			if(ex.ErrorCode == "ResourceNotFound")
			{
				return null;
			}
		}

		var app = new AppRegistration()
		{
			TenantId = entity.Value.PartitionKey,
			ClientId = entity.Value.RowKey,
			Name = entity.Value.GetString("Name")
		};

		return app;
	}
}