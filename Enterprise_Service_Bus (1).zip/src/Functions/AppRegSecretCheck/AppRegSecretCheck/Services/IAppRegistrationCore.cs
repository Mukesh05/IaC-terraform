﻿using System.Threading.Tasks;
using AppRegSecretCheck.Models;

namespace AppRegSecretCheck.Services;

public interface IAppRegistrationCore
{
	Task<bool> IsSecretExpiringAsync(AppRegistration appRegistration, int daysFrom = 0);
	Task<ServiceNowIncident> CreateServiceNowIncident(AppRegistration app);
	Task CheckForExpiringAppRegSecretsAsync();
}

