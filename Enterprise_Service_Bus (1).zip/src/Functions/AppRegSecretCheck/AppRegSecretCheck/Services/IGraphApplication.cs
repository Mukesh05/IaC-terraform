﻿using System.Threading.Tasks;
using AppRegSecretCheck.Models;

namespace AppRegSecretCheck.Services;

public interface IGraphApplication
{
	Task<AppRegistrationResult> GetApplicationAsync(AppRegistration appRegistration);
}

