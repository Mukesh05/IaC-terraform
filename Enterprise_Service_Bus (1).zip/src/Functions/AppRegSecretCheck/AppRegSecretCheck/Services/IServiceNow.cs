﻿using System.Threading.Tasks;

namespace AppRegSecretCheck.Services
{
	public interface IServiceNow
	{
		Task<T> QueryAsync<T>(string table, string sysparmQuery, string sysparmFields);
		Task<T> InsertAsync<T>(string table, T obj, string responseSysparmFields = null);
	}
}
