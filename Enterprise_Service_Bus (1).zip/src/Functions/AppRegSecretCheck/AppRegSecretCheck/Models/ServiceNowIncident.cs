﻿using System.Text.Json.Serialization;

namespace AppRegSecretCheck.Models;

[System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage()]
public class ServiceNowIncident
{
	public const string SysParmFields = "sys_id,number,short_description,description,state,impact,urgency," +
											"company.sys_id,company.name,caller_id.sys_id,caller_id.first_name," +
											"assignment_group.sys_id,assignment_group.name,category,subcategory,contact_type";

	[JsonPropertyName("sys_id")]
	public string SysId { get; set; }
	[JsonPropertyName("number")]
	public string Number { get; set; }
	[JsonPropertyName("short_description")]
	public string ShortDescription { get; set; }
	[JsonPropertyName("description")]
	public string Description { get; set; }
	[JsonPropertyName("state")]
	public string State { get; set; }
	[JsonPropertyName("impact")]
	public string Impact { get; set; }
	[JsonPropertyName("urgency")]
	public string Urgency { get; set; }

	[JsonPropertyName("company")]
	public string _company { get; set; }
	[JsonPropertyName("company.sys_id")]
	public string CompanySysId { get; set; }
	[JsonPropertyName("company.name")]
	public string CompanyName { get; set; }

	[JsonPropertyName("caller_id")]
	public string _caller_id { get; set; }
	[JsonPropertyName("caller_id.sys_id")]
	public string CallerIdSysId { get; set; }
	[JsonPropertyName("caller_id.first_name")]
	public string CallerName { get; set; }

	[JsonPropertyName("assignment_group")]
	public string _assignment_group { get; set; }
	[JsonPropertyName("assignment_group.sys_id")]
	public string AssignmentGroupSysId { get; set; }
	[JsonPropertyName("assignment_group.name")]
	public string AssignmentGroupName { get; set; }

	[JsonPropertyName("category")]
	public string Category { get; set; }
	[JsonPropertyName("subcategory")]
	public string SubCategory { get; set; }
	[JsonPropertyName("contact_type")]
	public string ContactType { get; set; }
}
