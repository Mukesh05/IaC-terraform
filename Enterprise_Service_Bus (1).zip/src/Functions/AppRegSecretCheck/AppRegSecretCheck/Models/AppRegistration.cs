﻿using System;
using System.Text.Json.Serialization;

namespace AppRegSecretCheck.Models;

[System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage()]
public class AppRegistration
{
	[JsonPropertyName("name")]
	public string Name { get; set; }
	[JsonPropertyName("clientId")]
	public string ClientId { get; set; }
	[JsonPropertyName("tenantId")]
	public string TenantId { get; set; }
}