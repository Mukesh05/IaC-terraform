﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppRegSecretCheck.Models;

[System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage()]
public class AppRegistrationResult
{
	public string ClientId { get; set; }
	public string Name { get; set; }
	public IDictionary<string, DateTime?> SecretExpireDateTimes { get; set; }
}