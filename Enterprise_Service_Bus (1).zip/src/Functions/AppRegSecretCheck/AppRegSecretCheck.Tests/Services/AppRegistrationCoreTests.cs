﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AppRegSecretCheck.Models;
using AppRegSecretCheck.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace AppRegSecretCheck.Tests.Services;

[System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage()]
[TestClass]
public class AppRegistrationCoreTests
{
	Mock<IConfiguration> _mockConfig=  new Mock<IConfiguration>();
	Mock<ILogger<AppRegistrationCore>> _mockLogger =  new Mock<ILogger<AppRegistrationCore>>();
	Mock<IGraphApplication> _mockGraphApplication = new Mock<IGraphApplication>();
	Mock<IAppRegistrationStorage> _mockAppRegStorage = new Mock<IAppRegistrationStorage>();
	Mock<IServiceNow> _mockServicNow  = new Mock<IServiceNow>();

    [TestInitialize]
    public void Initialize()
    {
		_mockConfig.Setup(x => x["AppRegSecretCheck:DaysToExpireCheck"]).Returns("7");

        _mockAppRegStorage.Setup(x => x.ListAsync()).ReturnsAsync(new List<AppRegistration>()
        {
            new AppRegistration()
            {
                TenantId = "681f3fd6-2edc-40a4-8e7b-99ca665dbff0",
                ClientId = "5a82cbdb-552c-42a4-a9aa-be1948f789f2",
                Name = "MBG Test App Reg"
            }
        });
	}

	[TestMethod]
	public async Task CreateServiceNowIncident_WhenNoExistingIncidentExists()
    {
		var appRegToCheck = new AppRegistration()
		{
			TenantId = "681f3fd6-2edc-40a4-8e7b-99ca665dbff0",
			ClientId = "5a82cbdb-552c-42a4-a9aa-be1948f789f2",
			Name = "MBG Test App Reg"
		};

		// Mock no service now incident is returned
		_mockServicNow.Setup(x => x.QueryAsync<List<ServiceNowIncident>>(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
			.ReturnsAsync(new List<ServiceNowIncident>()
			{
			});

		// Mock the incident details return after a service now insert
		_mockServicNow.Setup(x => x.InsertAsync(It.IsAny<string>(), It.IsAny<ServiceNowIncident>(), It.IsAny<string>()))
            .ReturnsAsync(new ServiceNowIncident()
            {
                Number = "INC1685293",
                ShortDescription = "App Registration secret about to expire for App Registration MBG Test App Reg (5a82cbdb-552c-42a4-a9aa-be1948f789f2)"
            });

        var appRegistrationCore = new AppRegistrationCore(_mockConfig.Object,
										_mockLogger.Object,
										_mockGraphApplication.Object,
										_mockAppRegStorage.Object,
										_mockServicNow.Object);
		
		var result = await appRegistrationCore.CreateServiceNowIncident(appRegToCheck);

		Assert.IsNotNull(result, "New incident details expected. Null result means incident already existed.");
	}

	[TestMethod]
	public async Task CreateServiceNowIncident_WhenExistingIncidentExists()
	{
		// Mock Service Now to return an existing incident
		_mockServicNow.Setup(x => x.QueryAsync<List<ServiceNowIncident>>(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
			.ReturnsAsync(new List<ServiceNowIncident>()
			{
				new ServiceNowIncident()
				{
					Number = "INC1685293",
					ShortDescription = "App Registration secret about to expire for App Registration MBG Test App Reg (5a82cbdb-552c-42a4-a9aa-be1948f789f2)"
				}
			});

		var appRegistrationCore = new AppRegistrationCore(_mockConfig.Object,
										_mockLogger.Object,
										_mockGraphApplication.Object,
										_mockAppRegStorage.Object,
										_mockServicNow.Object);

		var appRegToCheck = new AppRegistration()
		{
			TenantId = "681f3fd6-2edc-40a4-8e7b-99ca665dbff0",
			ClientId = "5a82cbdb-552c-42a4-a9aa-be1948f789f2",
			Name = "MBG Test App Reg"
		};

		var result = await appRegistrationCore.CreateServiceNowIncident(appRegToCheck);

		Assert.IsNull(result, "Null expected to indicate incident already created.");
	}

	[TestMethod]
	public async Task IsSecretExpiringAsync_SecretIsExpired_ReturnsTrue()
	{
		// Setup two secrets that are expired
		_mockGraphApplication.Setup(x => x.GetApplicationAsync(It.IsAny<AppRegistration>())).ReturnsAsync(new AppRegistrationResult()
		{
			ClientId = "5a82cbdb-552c-42a4-a9aa-be1948f789f2",
			Name = "MBG Test App Reg",
			SecretExpireDateTimes = new Dictionary<string, DateTime?>()
			{
				{"TestSecret1", DateTime.Now.AddDays(-17) },
				{"TestSecret2", DateTime.Now.AddDays(-10) }
			}
		});
		
		var appRegistrationCore = new AppRegistrationCore(_mockConfig.Object,
										_mockLogger.Object,
										_mockGraphApplication.Object,
										_mockAppRegStorage.Object,
										_mockServicNow.Object);

		var appRegToCheck = new AppRegistration()
		{
			TenantId = "681f3fd6-2edc-40a4-8e7b-99ca665dbff0",
			ClientId = "5a82cbdb-552c-42a4-a9aa-be1948f789f2",
			Name = "MBG Test App Reg"
		};

		var isExpired = await appRegistrationCore.IsSecretExpiringAsync(appRegToCheck, 7);
		Assert.IsTrue(isExpired);
	}

	[TestMethod]
	public async Task IsSecretExpiringAsync_SecretIsNotExpired_ReturnsFalse()
	{
		// Setup two secrets that are not expired
		_mockGraphApplication.Setup(x => x.GetApplicationAsync(It.IsAny<AppRegistration>())).ReturnsAsync(new AppRegistrationResult()
		{
			ClientId = "5a82cbdb-552c-42a4-a9aa-be1948f789f2",
			Name = "MBG Test App Reg",
			SecretExpireDateTimes = new Dictionary<string, DateTime?>()
			{
				{"TestSecret1", DateTime.Now.AddDays(7) },
				{"TestSecret2", DateTime.Now.AddDays(10) }
			}
		});

		var appRegistrationCore = new AppRegistrationCore(_mockConfig.Object,
										_mockLogger.Object,
										_mockGraphApplication.Object,
										_mockAppRegStorage.Object,
										_mockServicNow.Object);

		var appRegToCheck = new AppRegistration()
		{
			TenantId = "681f3fd6-2edc-40a4-8e7b-99ca665dbff0",
			ClientId = "5a82cbdb-552c-42a4-a9aa-be1948f789f2",
			Name = "MBG Test App Reg"
		};

		var isExpired = await appRegistrationCore.IsSecretExpiringAsync(appRegToCheck, 7);
		Assert.IsFalse(isExpired);
	}

	[TestMethod]
	public async Task IsSecretExpiringAsync_AtLeastOneSecreIsNotExpired_ReturnsFalse()
	{
		// Setup two secrets that are not expired
		_mockGraphApplication.Setup(x => x.GetApplicationAsync(It.IsAny<AppRegistration>())).ReturnsAsync(new AppRegistrationResult()
		{
			ClientId = "5a82cbdb-552c-42a4-a9aa-be1948f789f2",
			Name = "MBG Test App Reg",
			SecretExpireDateTimes = new Dictionary<string, DateTime?>()
			{
				{"TestSecret1", DateTime.Now.AddDays(7) },
				{"TestSecret2", DateTime.Now.AddDays(10) }
			}
		});

		var appRegistrationCore = new AppRegistrationCore(_mockConfig.Object,
										_mockLogger.Object,
										_mockGraphApplication.Object,
										_mockAppRegStorage.Object,
										_mockServicNow.Object);

		var appRegToCheck = new AppRegistration()
		{
			TenantId = "681f3fd6-2edc-40a4-8e7b-99ca665dbff0",
			ClientId = "5a82cbdb-552c-42a4-a9aa-be1948f789f2",
			Name = "MBG Test App Reg"
		};

		var isExpired = await appRegistrationCore.IsSecretExpiringAsync(appRegToCheck, 7);
		Assert.IsFalse(isExpired);
	}
}