﻿CREATE USER [cspBillinguser] FOR LOGIN [cspBilling];

