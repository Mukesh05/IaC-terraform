﻿CREATE LOGIN [cspBilling] WITH PASSWORD = 'khbqtu_l|ofrfjweKikjZvuhmsFT7_&#$!~<t,vWW|XppdJb'
