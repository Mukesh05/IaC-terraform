﻿CREATE View vwCSPInvoiceUnbilledSummary
as

select 
	customerCountry
	,PartnerName
	,customerName
	,PricingCurrency
	,Avg(Margin) as Margin
from 
	InvoiceUnbilledSummary 
Group by 
	customerCountry
	,PartnerName
	,customerName
	,PricingCurrency
