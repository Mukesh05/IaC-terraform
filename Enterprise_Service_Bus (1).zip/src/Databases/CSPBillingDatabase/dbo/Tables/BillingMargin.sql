﻿CREATE TABLE [dbo].[BillingMargin] (
    [Id]                       INT              IDENTITY (1, 1) NOT NULL,
    [Client_Name]              VARCHAR (250)    NULL,
    [Customer_Id]              VARCHAR (250)    NULL,
    [Margin]                   DECIMAL (38, 17) NULL,
    [Discount_From_Web_Direct] DECIMAL (38, 17) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);
