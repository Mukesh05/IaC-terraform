﻿CREATE PROCEDURE [dbo].[usp_AddInvoiceUnbilledInfoRow] @InvoiceUnbilledInfoTable as InvoiceUnbilledInfoTableType READONLY

AS

BEGIN

declare 
	@MonthYear varchar(255) = (Select distinct MonthYear from @InvoiceUnbilledInfoTable)

--Empty detail table
Delete from [dbo].[InvoiceUnbilledSummary]
where 
	customerCountry in (Select distinct customerCountry from @InvoiceUnbilledInfoTable)
	And MonthYear = @MonthYear

INSERT INTO [dbo].[InvoiceUnbilledSummary]
    SELECT 

	[CustomerId] 
	,[customerName] 
	,[customerCountry] 
	,[PartnerName] 
	,[Currency] 
	,[pricingCurrency] 
	,[MonthYear] 
	,datename(month,DateAdd(M,-1,Cast(('01'+ MonthYear) as datetime))) + ' ' + Cast(year(DateAdd(M,-1,Cast(('01'+ MonthYear) as datetime))) as varchar(4))
	,[Subtotal] 

    ,[TaxTotal] 
    ,[TotalForCustomer] 
    ,[TotalForCustomerWithMargin] 
    ,[TaxTotalWithMargin] 
    ,[SubtotalWithMargin] 
    ,[Markup] 
    ,[Margin] 
    ,[DiscountFromWebDirect] 

	,[PCToBCExchangeRate]
	,[PCToBCExchangeRateDate]
	,[UsageCost]
	,[UsageCostWithMargin]
	,[PurchaseCost]
	,[PurchaseCostWithMargin]

    ,getdate() 
FROM 
	@InvoiceUnbilledInfoTable
END
