﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

IF NOT EXISTS (SELECT 1 FROM [dbo].[BillingMargin] WHERE [Client_Name] = 'Two Circles Ltd')
BEGIN
	INSERT INTO [dbo].[BillingMargin] (Client_Name, Customer_Id, Margin, Discount_From_Web_Direct)
		VALUES ('Two Circles Ltd', 'afa21132-558b-4712-9dd1-72dbaf33febb', 7.00000000000000000, NULL);
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[BillingMargin] WHERE [Client_Name] = 'JBA Group')
BEGIN
	INSERT INTO [dbo].[BillingMargin] (Client_Name, Customer_Id, Margin, Discount_From_Web_Direct)
		VALUES ('JBA Group', '3131e85c-e560-4bb3-a82f-8b339ad41833', 13.26530610000000000, NULL);
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[BillingMargin] WHERE [Client_Name] = 'WPA')
BEGIN
	INSERT INTO [dbo].[BillingMargin] (Client_Name, Customer_Id, Margin, Discount_From_Web_Direct)
		VALUES ('WPA', 'e4ab91f0-162d-414a-be02-0700ceeacce5', NULL, -4.11244143700000000);
END
