[CmdletBinding()]
Param(
    [Parameter(Mandatory = $true)]
    [string]$SourceResourceGroup = $(throw "-SourceResourceGroup is required."),
    [Parameter(Mandatory = $true)]
    [string]$BackupResourceGroup = $(throw "-BackupResourceGroup is required."),
    [Parameter(Mandatory = $true)]
    [string]$SourceStorageAccountName = $(throw "-SourceStorageAccountName is required."),
    [Parameter(Mandatory = $true)]
    [string]$BackupStorageAccountName = $(throw "-BackupStorageAccountName is required."),
    [Parameter(Mandatory = $true)]
    [string]$TableName = $(throw "-TableName is required."),
    [Parameter(Mandatory = $true)]
    [string]$ContainerName = $(throw "-ContainerName is required.")
)
<#
[CmdletBinding()]
Param(
    [string]$SourceResourceGroup = 'RG-DTI-QA-Apps',
    [string]$BackupResourceGroup = 'RG-DTI-QA-Backup',
    [string]$SourceStorageAccountName ='stsccmdataschedulerqa',
    [string]$BackupStorageAccountName = 'sadtiqaschdbackup',
    [string]$TableName = 'QuerySchedule',
    [string]$ContainerName = 'tablebackups'
)
#>

Import-Module Az.Accounts
Import-Module Az.Resources
Import-Module Az.Storage
Import-Module AzTable

function Save-StgTableContent {
    param(
        [Object]$TableContext,
        [string]$FileName
    )

    Write-Output ("Getting the Table content in " + $FileName)
    Get-AzTableRow -Table $TableContext `
            | Export-Csv -Path $FileName `
                         -NoTypeInformation
}
function UploadFileToBlobContainer {
    param(
        [Object]$StorageContext,
        [string]$FileName,
        [string]$ContainerName
    )

    $storageContainer = Get-AzStorageContainer -Name $ContainerName `
                                               -Context $StorageContext `
                                               -ErrorAction Ignore

    $storageContainer | Set-AzStorageBlobContent –File $FileName `
                                                 –Blob $FileName `
                                                 -StandardBlobTier Cool `
                                                 -ErrorAction Ignore `
                                                 | Out-Null
}

function Get-StgTable {
    param(
      [Object]$StorageContext,
      [string]$TableName,
      [string]$CreateIfNotExists
    )
    $Table = Get-AzStorageTable -Name $TableName `
                                -Context $StorageContext `
                                -ErrorAction Ignore

  if($Table) {
    return $table.CloudTable
  } else {
    if ($CreateIfNotExists) {
      $Table = New-AzStorageTable -Name $Tablename `
                                  -Context $StorageContext
      return $Table.CloudTable
    }
  }

  return $null
}

# Main execution starts here ...

try {
    Write-Output "Connecting to azure via  Connect-AzAccount -Identity"
    Connect-AzAccount -Identity
    Write-Output "Successfully connected with Automation account's Managed Identity"
}
catch {
    Write-Error -Message $_.Exception
    throw $_.Exception

}

# Connects as AzureRunAsConnection from Automation to ARM
try {
    $profile = Connect-AzAccount -Identity
    Write-Output "Connection to Az Account is successful for id $($profile.Context.Account.Id)"
}
catch {
    Write-Output "Unable to Connect-AzAccount using these parameters."
}

# get access to the table to back up
$sourceStg = Get-AzStorageAccount -StorageAccountName $SourceStorageAccountName `
                                  -ResourceGroupName $SourceResourceGroup `
                                  -ErrorAction SilentlyContinue
if(!$sourceStg) {
    Throw "Unable to read source storage account context"
}
$SourceStorageContext = $sourceStg.Context

# get access to the blob container
$destStg = Get-AzStorageAccount -StorageAccountName $BackupStorageAccountName `
                                -ResourceGroupName $BackupResourceGroup `
                                -ErrorAction SilentlyContinue

if(!$destStg) {
    Throw "Unable to read backup storage account context"
}

$destStorageContext = $destStg.Context

$FileName = [System.string]::Concat("Backup", `
                                    '-', `
                                    $SourceStorageAccountName, `
                                    '-', `
                                    $TableName, `
                                    '-', `
                                    (Get-Date).Tostring("s").Replace(":", "-"), `
                                    ".csv")

# ------- Start BackUp ---------
$Table = Get-StgTable -StorageContext $SourceStorageContext `
                      -TableName $TableName `
                      -CreateIfNotExists $false

if (!$Table) {
    Write-Output "Source table $TableName was not found"
    return
}

Save-StgTableContent -TableContext $Table `
                    -FileName $FileName

UploadFileToBlobContainer -StorageContext $destStorageContext `
                          -FileName $FileName `
                          -ContainerName $ContainerName

#------- End Backup ---------