
[CmdletBinding()]
Param(
  [Parameter(Mandatory = $true)]
  [string]$SourceResourceGroup = $(throw "-SourceResourceGroup is required."),
  [Parameter(Mandatory = $true)]
  [string]$BackupResourceGroup = $(throw "-BackupResourceGroup is required."),
  [Parameter(Mandatory = $true)]
  [string]$SourceStorageAccountName = $(throw "-SourceStorageAccountName is required."),
  [Parameter(Mandatory = $true)]
  [string]$BackupStorageAccountName = $(throw "-BackupStorageAccountName is required."),
  [Parameter(Mandatory = $true)]
  [string]$SccmTableName = $(throw "-SccmTableName is required."),
  [Parameter(Mandatory = $true)]
  [string]$IntuneTableName = $(throw "-IntuneTableName is required."),
  [Parameter(Mandatory = $true)]
  [string]$ContainerName = $(throw "-ContainerName is required.")
)

# [CmdletBinding()]
# Param(
#     [string]$SourceResourceGroup = 'RG-DTI-QA-Backup',
#     [string]$BackupResourceGroup = 'RG-DTI-QA-Backup',
#     [string]$SourceStorageAccountName ='sadtiqaschdbackup',
#     [string]$BackupStorageAccountName = 'sadtiqaschdbackup',
#     [string]$SsccmTableName = 'QuerySchedule',
#     [string]$IntuneTableName = 'schedule',
#     [string]$ContainerName = 'tablebackups'
# )

Import-Module Az.Accounts
Import-Module Az.Resources
Import-Module Az.Storage
Import-Module AzTable

function Get-SccmFileFromBlobContainer {
  param(
    [Object]$StorageContext,
    [string]$ContainerName,
    [string]$FileName
  )
  $Blob = Get-AzStorageBlob -Container $ContainerName `
                            -Context $StorageContext `
                            -ErrorAction Ignore

  if (!$Blob) {
    return $null
  }

  # Last 1 means latest backup by blob item/timestamp
  $Blob | Where-Object { $_.Name -match '^Backup-sa(.?)*sccm*' } `
        | Select-Object -Last 1 `
        | Get-AzStorageBlobContent -Destination $FileName `
                                   -ErrorAction Stop

  return $True
}

function Get-IntuneFileFromBlobContainer {
  param(
    [Object]$StorageContext,
    [string]$ContainerName,
    [string]$FileName
  )

  $Blob = Get-AzStorageBlob -Container $ContainerName `
                            -Context $StorageContext `
                            -ErrorAction Ignore

  if (!$Blob) {
    return $null
  }

  # Last 1 means latest backup by blob item/timestamp
  $Blob | Where-Object { $_.Name -match '^Backup-sa(.?)*intune*' } `
        | Select-Object -Last 1 `
        | Get-AzStorageBlobContent -Destination $FileName `
                                   -ErrorAction Stop

  return $True
}

function Restore-BlobToSccmStgTable {
  param(
    [Object]$StorageContext,
    [Object]$TableContext,
    [string]$FileName
  )

  if (Test-Path -Path $FileName) {
    $CSVData = Import-Csv -Path $FileName
    foreach ($RowItem in $CSVData) {
      $Entity = New-Object `
                          -TypeName Microsoft.Azure.Cosmos.Table.DynamicTableEntity `
                          -ArgumentList $RowItem.PartitionKey, $RowItem.RowKey

      $Entity.Properties.Add("ClientCode", $RowItem.ClientCode)
      $Entity.Properties.Add("LastQueryRowCount", $RowItem.LastQueryRowCount)
      $Entity.Properties.Add("LastQueryResult", $RowItem.LastQueryResult)
      $Entity.Properties.Add("Name", $RowItem.Name)
      $Entity.Properties.Add("Query", $RowItem.Query)
      $Entity.Properties.Add("SccmServer", $RowItem.SccmServer)
      $Entity.Properties.Add("Schedule", $RowItem.Schedule)
      $Entity.Properties.Add("Etag", $RowItem.Etag)

      $TableContext.ExecuteAsync((Invoke-Expression "[Microsoft.Azure.Cosmos.Table.TableOperation]::InsertOrReplace(`$Entity)"))
    }
  }
}

function Restore-BlobToIntuneStgTable {
  param(
    $StorageContext,
    $TableContext,
    $FileName
  )

  if (Test-Path -Path $FileName) {
    $CSVData = Import-Csv -Path $FileName
    foreach ($RowItem in $CSVData) {
      $Entity = New-Object `
                          -TypeName Microsoft.Azure.Cosmos.Table.DynamicTableEntity `
                          -ArgumentList $RowItem.PartitionKey, $RowItem.RowKey

      $Entity.Properties.Add("ReportName", $RowItem.ReportName)
      $Entity.Properties.Add("Schedule", $RowItem.Schedule)
      $Entity.Properties.Add("ScheduleType", $RowItem.ScheduleType)
      $Entity.Properties.Add("Select", $RowItem.Select)
      $Entity.Properties.Add("Etag", $RowItem.Etag)

      $TableContext.ExecuteAsync((Invoke-Expression "[Microsoft.Azure.Cosmos.Table.TableOperation]::InsertOrReplace(`$Entity)"))
    }
  }
}

function Get-StgTable {
  param(
    $StorageContext,
    $TableName,
    $CreateIfNotExists
  )
  $Table = Get-AzStorageTable -Name $TableName -Context $StorageContext -ErrorAction Ignore

  if (!$Table) {
    if ($CreateIfNotExists -eq $false) {
      return $null
    }

    $Table = New-AzStorageTable -Name $Tablename -Context $StorageContext
  }
  return $Table.CloudTable
}

try {
  Write-Output "Connecting to azure via  Connect-AzAccount -Identity"
  Connect-AzAccount -Identity
  Write-Output "Successfully connected with Automation account's Managed Identity"
}
catch {
  Write-Error -Message $_.Exception
  throw $_.Exception

}

# Connects as AzureRunAsConnection from Automation to ARM
try {
  $profile = Connect-AzAccount -Identity
  Write-Output "Connection to Az Account is successful for id $($profile.Context.Account.Id)"
}
catch {
  Write-Output "Unable to Connect-AzAccount using these parameters."
}


# get access to the blob container
$sourceStg = Get-AzStorageAccount -StorageAccountName $SourceStorageAccountName `
                                  -ResourceGroupName $SourceResourceGroup `
                                  -ErrorAction SilentlyContinue

if (!$sourceStg) {
  Throw "Unable to read storage account that has the backedup file "
}

$sourceStorageContext = $sourceStg.Context

# get access to the table to restore
$destStg = Get-AzStorageAccount -StorageAccountName $BackupStorageAccountName `
                                -ResourceGroupName $BackupResourceGroup `
                                -ErrorAction SilentlyContinue
if (!$destStg) {
  Throw "Unable to read destination storage account context"
}
$destStorageContext = $destStg.Context

$sccmFileName = [System.string]::Concat("Backup", `
                                        '-', `
                                        $SourceStorageAccountName, `
                                        '-', `
                                        $sccmTableName, `
                                        '-', `
                                        (Get-Date).Tostring("s").Replace(":", "-"), `
                                        ".csv")

$intuneFileName = [System.string]::Concat("Backup", `
                                          '-', `
                                          $SourceStorageAccountName, `
                                          '-', `
                                          $intuneTableName, `
                                          '-', `
                                          (Get-Date).Tostring("s").Replace(":", "-"), `
                                          ".csv")

#------- Start Restore ---------
# SCCM Restore
<#    $StorageContext,
    [string]$ContainerName,
    [string]$FileName#>
$Content = Get-SccmFileFromBlobContainer -StorageContext $sourceStorageContext `
                                         -ContainerName $ContainerName `
                                         -FileName $sccmFileName

if ($Content) {
    $sccmTable = Get-StgTable -StorageContext $destStorageContext `
                            -TableName $sccmTableName `
                            -CreateIfNotExists $true

    Restore-BlobToSccmStgTable -StorageContext $destStorageContext `
                            -TableContext $sccmTable `
                            -FileName $sccmFileName
} else {
    Write-Output "Getting SCCM Schedule Backup File from Blob Container failed"
}
# End SCCM restore

#Intune Restore
$Content = Get-IntuneFileFromBlobContainer -StorageContext $sourceStorageContext `
                                           -ContainerName $ContainerName `
                                           -FileName $intuneFileName

if ($Content) {
    $intuneTable = Get-StgTable -StorageContext $destStorageContext `
                                -TableName $intuneTableName `
                                -CreateIfNotExists $true

    Restore-BlobToIntuneStgTable -StorageContext $destStorageContext `
                                -TableName $intuneTable `
                                -FileName $intuneFileName
} else {
    Write-Output "Getting InTune Schedule Backup File from Blob Container failed"
}
# End Intune restore

#------- End Restore ---------
