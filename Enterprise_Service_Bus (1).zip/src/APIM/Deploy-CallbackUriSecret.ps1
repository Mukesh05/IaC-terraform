<#
  .Synopsis
    Goal - build a uri that includes the key parameter so that a call back can be made from a
    3rd party security service and write it to a given key vault secret.

    Requires an active Az PowerShell login with a connection to the Azure Subscription being
    updated.

  .Example
    Deploy-CallbackSecretUri -Environment 'qa'

  .Parameter Environment
    The deployment environment, e.g. dev, qa, prod - defaults to qa
  .Parameter ApimResourceGroup
    Resource Group where APIM is deployed
    e.g.
    "RG-DTI-$($Environment.ToUpperInvariant())-Core"
  .Parameter ApimName
    Resource Name of the APIM instance
    e.g.
    "apim-dti-$($Environment.ToLowerInvariant())-uks",
  .Parameter ApiId
    Id of the API in APIM
    e.g.
    "fa-dti-shsecevents-$($Environment.ToLowerInvariant())",
  .Parameter ApiName
    Name of the API in APIM
    e.g.
    "shsecevents",
  .Parameter KeyVaultName
    Name of the Azure Key Vault that the secret will be written to
    e.g.
    "kv-dti-$($Environment.ToLowerInvariant())-core",
  .Parameter SecretId
    Id of the Azure Key Vault Secret that the secret will be written to
    e.g.
    'sechealthsecevent-receiverurl',
  .Parameter SecSubscriptionId
    Name of the Azure Key Vault that the secret will be written to
    e.g.
    'security-events-client',
  .Parameter SecOperationId
    Name of the Azure Key Vault that the secret will be written to
    e.g.
    'post-receiver'
  .Notes
    NAME: Deploy-CallbackSecretUri
    AUTHOR: Simon Hawke / Engineering Platform Services Team
    LASTEDIT: 07/06/2021
    KEYWORDS: Azure, API Management

  .Link
    https://dev.azure.com/newsigcode/Engineering/_wiki/wikis/DTI%20-%20API%20and%20ESB%20Platform/3139/API-Management

    #Requires -Version 5.1
#>

[CmdLetBinding()]
Param (
  [string]$Environment        = 'qa',
  [string]$ApimResourceGroup  = "RG-DTI-$($Environment.ToUpperInvariant())-Core",
  [string]$ApimName           = "apim-dti-$($Environment.ToLowerInvariant())-uks",
  [string]$ApiId              = "fa-dti-shsecevents-$($Environment.ToLowerInvariant())",
  [string]$ApiName            = "shsecevents",
  [string]$KeyVaultName       = "kv-dti-$($Environment.ToLowerInvariant())-core",
  [string]$SecretId           = 'sechealthsecevent-receiverurl',
  [string]$SecSubscriptionId  = 'security-events-client',
  [string]$SecOperationId     = 'post-receiver'
)

Write-Output "Start: Reading values from API Management"

Write-Output "Reading Subscription Key from API Management"

$apimContext = New-AzApiManagementContext -ResourceGroupName $ApimResourceGroup `
                                          -ServiceName $ApimName

$keys = Get-AzApiManagementSubscriptionKey -Context $apimContext `
                                           -SubscriptionId $SecSubscriptionId

$primaryKey = $keys.PrimaryKey

# Goal - build a uri that includes the key parameter so that a call back can be made from a 3rd party security service and write it to a given key vault secret

$operation = Get-AzApiManagementOperation -Context $apimContext `
                                          -ApiId $ApiId `
                                          -OperationId $SecOperationId

Write-Output "Building Callback URI String"

$UriWithKey = "https://apim-dti-$($Environment.ToLowerInvariant())-uks.azure-api.net/$($ApiName)$($operation.UrlTemplate)?subscription-key=$($primaryKey)"

Write-Output "Writing Secret to Key Vault"

$secretvalue = ConvertTo-SecureString -String $UriWithKey `
                                      -AsPlainText `
                                      -Force

$secret = Set-AzKeyVaultSecret -VaultName $KeyVaultName `
                               -Name $SecretId `
                               -SecretValue $secretvalue

Write-Output "Finished: Created an updated version of the secret $($secret.Name) at $($secret.Created.ToUniversalTime())Z"
