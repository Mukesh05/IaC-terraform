$ESBPATH="$($ENV:USERPROFILE)\code\engineering\ESB"

<#
az deployment group `
    validate `
    --resource-group RG-DTI-QA-Core `
    --template-file "$($ESBPATH)\src\APIM\apim.template.json" `
    --mode Incremental
#>
<#
az deployment group `
    what-if `
    --resource-group RG-DTI-QA-Core `
    --template-file "$($ESBPATH)\src\APIM\apim.template.json" `
    --mode Incremental
#>
<#
$deploymentName = "Deployment-$((Get-Date).toString('yyyyyMMddHHmmss'))"

New-AzResourceGroupDeployment -Name $deploymentName `
                              -ResourceGroupName  RG-DTI-QA-Core `
                              -Mode Incremental `
                              -TemplateFile "$($ESBPATH)\src\APIM\apim.template.json" `
                              -sccmDataSchedulerFunctionKey 'e1xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
#>