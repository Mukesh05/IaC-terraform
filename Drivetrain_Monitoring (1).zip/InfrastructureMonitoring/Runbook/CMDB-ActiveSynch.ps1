<#
.SYNOPSIS
    This sample Automation runbook integrates with Azure event grid subscriptions to get notified when a
    write command is performed against an Azure VM.
    The runbook adds a cost tag to the VM if it doesn't exist. It also sends an optional notification
    to a Microsoft Teams channel indicating that a new VM has been created and that it is set up for
    automatic shutdown / start up tags.

.DESCRIPTION
    This sample Automation runbook integrates with Azure event grid subscriptions to get notified when a
    write command is performed against an Azure VM.
    The runbook adds a cost tag to the VM if it doesn't exist. It also sends an optional notification
    to a Microsoft Teams channel indicating that a new VM has been created and that it is set up for
    automatic shutdown / start up tags.
    A RunAs account in the Automation account is required for this runbook.

.PARAMETER WebhookData
    Optional. The information about the write event that is sent to this runbook from Azure Event grid.

.PARAMETER ChannelURL
    Optional. The Microsoft Teams Channel webhook URL that information will get sent.

.NOTES
    AUTHOR: Automation Team
    LASTEDIT: November 29th, 2017
#>

Param(
    [parameter (Mandatory = $false)]
    [object] $WebhookData,

    [parameter (Mandatory = $false)]
    $ChannelURL
)

$RequestBody = $WebhookData.RequestBody | ConvertFrom-Json
$Data = $RequestBody.data

if ($Data.operationName -match "Microsoft.Compute/virtualMachines/write" -and $Data.status -match "Succeeded") {
    # Get resource group and vm name
    $Resources = $Data.resourceUri.Split('/')
    $VMResourceGroup = $Resources[4]
    $VMName = $Resources[8]

    Write-Verbose "$VMName created in $VMResourceGroup" -Verbose
    Write-Output "$VMName created in $VMResourceGroup"
}
elseif ($Data.operationName -match "Microsoft.Compute/disks/delete" -and $Data.status -match "Succeeded") {
    Write-Verbose "VM Deleted" -Verbose
    Write-Output "VM Deleted"
}
else {
    Write-Error "Could not find VM write event"
}
