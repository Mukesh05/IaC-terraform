[CmdletBinding()]
Param
(
    [String] $mgName,
    [string] $rgName,
    [string] $runbookSubId
)

Import-Module Az.Accounts
Import-Module Az.NetAppFiles
Import-Module Az.Resources
Import-Module Az.Monitor
# Connects as AzureRunAsConnection from Automation to ARM
try {
  $profile = Connect-AzAccount -Identity
  Write-Output "Connection to Az Account is successful for id $($profile.Context.Account.Id)"
}
catch {
         Write-Output "Unable to Connect-AzAccount using these parameters."
      "Unable to Connect-AzAccount using these parameters."
}

# Connects using custom credentials if AzureRunAsConnection can't be used

function Get-ANFVolumes([String] $mgName,
                        [system.collections.arraylist] $netAppAccountVolumes) {

  $subscriptionList = new-object system.collections.arraylist


  ## Use this function to limit the scope to a specific resource group
  if ([string]::IsNullOrEmpty($mgName)) {
    $volumeresources = Get-AzResource | Where-Object {$_.ResourceType -eq "Microsoft.NetApp/netAppAccounts/capacityPools/volumes"}
    if($volumeresources.Count -ge 2){
      $netAppAccountVolumes.AddRange($volumeresources)
    }
    else{
        $netAppAccountVolumes.Add($volumeresources)
    }
  }
  else{
    #Root MG is the TenantID - note you have to use EXPAND
    $MGTree = Get-AzManagementGroup -GroupName $mgName  -Recurse -Expand

    FindSubInMGChildren -mg $MGTree -subscriptionids $subscriptionList
    if ($subscriptionList) {
        foreach($sub in $subscriptionList) {
            $context = Get-AzSubscription -SubscriptionId $sub
            Set-AzContext $context
            $volumeresources = Get-AzResource | Where-Object {$_.ResourceType -eq "Microsoft.NetApp/netAppAccounts/capacityPools/volumes"}
            if($volumeresources.Count -ge 2){
              $netAppAccountVolumes.AddRange($volumeresources)
            }
            else{
                $netAppAccountVolumes.Add($volumeresources)
            }
        }
    }
  }
  return $netAppAccountVolumes;
}

Function FindSubInMGChildren {
  [CmdletBinding()]
  Param
  (
      [Object] $MG,
      [system.collections.arraylist]$subscriptionids
  )
      #MG is a MG Object with populated children
      Write-Host "  Evaluating $($MG.DisplayName) "


      #No children in this MG
      If ($null -eq $MG.Children) {
          Write-Host "    $($MG.DisplayName) has no children"
          Return $null
      }

      #loop through all children, look for type = '/subscriptions' and name = subID
      foreach($child in $MG.Children) {
          if ($Child.Type -eq '/subscriptions') {
              Write-Host "    Sub $subID found as child in $($MG.DisplayName)"
              $subscriptionids.Add($child.Name)
              #Found
              #Return $subscriptionids
          }
          #Recurse
          if ($Child.Type -eq '/providers/Microsoft.Management/managementGroups') {
              FindSubInMGChildren -MG $child -subscriptionids $subscriptionids
          }
      }
      #Not found
      Return $subscriptionids
  }

function Deploy-ANFVMetric(){
        Write-Output "Deploying ANFVMetric"
   $templatecontents = @'
{
"$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
"contentVersion": "1.0.0.0",
"parameters": {
"netAppAccounts_volume_externalid":{
  "type": "string",
  "defaultValue":"__netAppAccounts_volume_externalid__"
},
"actionGroupResourceId": {
"type": "string",
"defaultValue":"__actionGroupResourceId__"
}
},
"variables": {
"metricAlertName": "[concat('NetApp Volume Consumed Size Percentage high critical ', uniquestring(parameters('netAppAccounts_volume_externalid')))]"
},
"resources": [
{
  "type": "microsoft.insights/metricAlerts",
  "apiVersion": "2018-03-01",
  "name": "[variables('metricAlertName')]",
  "location": "global",
  "properties": {
      "severity": 0,
      "enabled": true,
      "scopes": [
          "[parameters('netAppAccounts_volume_externalid')]"
      ],
      "evaluationFrequency": "PT30M",
      "windowSize": "PT1H",
      "criteria": {
          "allOf": [
              {
                  "threshold": 85,
                  "name": "Metric1",
                  "metricNamespace": "microsoft.netapp/netappaccounts/capacitypools/volumes",
                  "metricName": "VolumeConsumedSizePercentage",
                  "operator": "GreaterThan",
                  "timeAggregation": "Average",
                  "criterionType": "StaticThresholdCriterion"
              }
          ],
          "odata.type": "Microsoft.Azure.Monitor.MultipleResourceMultipleMetricCriteria"
      },
      "autoMitigate": true,
      "targetResourceType": "Microsoft.NetApp/netAppAccounts/capacityPools/volumes",
      "targetResourceRegion": "eastus",
      "actions": [
        {
          "actionGroupId": "[parameters('actionGroupResourceId')]"
        }
      ]
  }
}
]
}
'@
  $netAppAccountVolumes = new-object system.collections.arraylist
  Get-ANFVolumes -netAppAccountVolumes $netAppAccountVolumes -mgName $mgName
  Write-Output "NetApp Accounts Volumes, Found: $($netAppAccountVolumes.Count)"
  $context = Get-AzSubscription -SubscriptionId $runbookSubId
  Set-AzContext $context
  $ag = Get-AzActionGroup -ResourceGroupName $rgName -WarningAction SilentlyContinue
  if($null -ne $ag)
  {
  $ag = $ag |Where-Object { $_.Name -like "SNow" }
      Write-Output "actiongroup id: $($ag.Id)"
  }
  foreach($volume in $netAppAccountVolumes) {

    $temppath = ".\$(New-Guid).json"
          $modifiedtemplatecontents = $templatecontents
          $modifiedtemplatecontents = $modifiedtemplatecontents.Replace("__netAppAccounts_volume_externalid__", "$($volume.ResourceId)")
          $modifiedtemplatecontents = $modifiedtemplatecontents.Replace("__actionGroupResourceId__", "$($ag.Id)")

          Write-Output $modifiedtemplatecontents

    $templatefile = $modifiedtemplatecontents | Out-File $temppath -Force -Verbose
    Get-Content -Path $temppath
    $ResourceGroupNameMatches = $volume.ResourceId -match "/resourceGroups/(?<content>.*)/providers/"

    if($ResourceGroupNameMatches)
    {
      $ResourceGroupName = $matches['content']
    }

    $SubIdMatches = $volume.ResourceId -match "/subscriptions/(?<subidcontent>.*)/resourceGroups/"

    if($SubIdMatches)
    {
      $subId = $matches['subidcontent']
    }

    $context = Get-AzSubscription -SubscriptionId $subId
    Set-AzContext $context

    New-AzResourceGroupDeployment `
           -Name "netappalert$($(new-guid).tostring().substring(0,8))" `
           -templatefile $temppath `
           -ResourceGroupName $ResourceGroupName `
           -Verbose `
        }
    }

		Write-Output $finalResult
		Deploy-ANFVMetric