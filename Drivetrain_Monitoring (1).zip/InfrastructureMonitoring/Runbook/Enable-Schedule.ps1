Param(
    [parameter (Mandatory = $false)]
    [object] $WebhookData,

    [parameter (Mandatory = $false)]
    $ChannelURL
)

if($null -ne $WebhookData){
	$RequestBody = $WebhookData.RequestBody | ConvertFrom-Json
	$Data = $RequestBody.data
}

"Logging in to Azure..."
$conn = Get-AutomationConnection -Name AzureRunAsConnection 
Add-AzureRMAccount -ServicePrincipal -Tenant $conn.TenantID -ApplicationId $conn.ApplicationID -CertificateThumbprint $conn.CertificateThumbprint

"Selecting Azure subscription..."
$subId = Get-AutomationVariable -Name AzureSubscriptionId
Select-AzureRmSubscription -SubscriptionId $subId -TenantId $conn.TenantID 

"Enabling Schedule..."
$automationAccountName = Get-AutomationVariable -Name AutomationAccountName
$scheduleName = Get-AutomationVariable -Name ScheduleNameToEnable
$rgName = Get-AutomationVariable -Name ResourceGroupName
Set-AzureRmAutomationSchedule -ResourceGroupName $rgName -AutomationAccountName $automationAccountName -Name $scheduleName -IsEnabled $true