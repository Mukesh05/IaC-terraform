#Requires -Version 5.1
Using Module "..\Powershell\MonitoringCommon.psm1"
Import-Module -Name "$($PSScriptRoot)\..\Powershell\lib_pwsh\Instrumentation.psm1" -Force
Import-Module -Name "$($PSScriptRoot)\..\Powershell\lib_pwsh\AzureGeneral.psm1" -Force
Import-Module -Name "$($PSScriptRoot)\..\Powershell\lib_pwsh\UserInterface.psm1" -Force
Import-Module -Name "$($PSScriptRoot)\..\Powershell\AzureResources.psm1" -Force
Import-Module -Name "$($PSScriptRoot)\..\Powershell\Deploy-EventGridSubscription.psm1" -Force
Import-Module -Name "$($PSScriptRoot)\..\Powershell\Monitoring.psm1" -Force

Class Context {
  [string] $Name
}

Function New-Exception {
  try { throw "example error" }
  catch { return $_.exception }
}

Class TestMonitoringInstall : MonitoringInstall {
  ShowSummary() { }
}

Class TestMonitoringUninstall : MonitoringUninstall {
  ShowSummary() { }
}

InModuleScope -ModuleName Monitoring {
  Describe 'Get-Architecture Function' {
    It 'does not prompt the user to select an architecture, if the parameter was set elsewhere' {
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.Architecture = 'Single'
      Get-Architecture -controlParameters $controlParameters
      $controlParameters.ManualSelection | Should -Be $false
    }
    It 'prompts the user to select an architecture, if the parameters has not already been set' {
      Mock Clear-Scrollback
      Mock Show-Menu
      Mock Read-Host { return 1 }

      $controlParameters = [TestMonitoringInstall]::new()

      Get-Architecture -controlParameters $controlParameters

      Assert-MockCalled Show-Menu -Times 1 -Scope It
      $controlParameters.Architecture | Should -Be "Single"
      $controlParameters.ManualSelection | Should -Be $true
    }
  }

  Describe 'Get-ManagementGroup Function' {
    It 'does not prompt the user to select a Management Group, if the architecture is set to Single' {
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.Architecture = 'Single'
      Mock Clear-Scrollback
      Mock Show-Menu
      Mock Read-Host { return }

      Get-ManagementGroup -controlParameters $controlParameters

      Assert-MockCalled Read-Host -Exactly 0 -Scope It
    }
    It 'does not prompt the user to select a Management Group, if the architecture is set to Multiple and the management group parameter has already been set' {
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.Architecture = 'Multiple'
      $controlParameters.ManagementGroup = 'ManagementGroup'

      Mock Clear-Scrollback
      Mock Show-Menu
      Mock Get-AzManagementGroup
      Mock Read-Host { return }

      Get-ManagementGroup -controlParameters $controlParameters

      Assert-MockCalled Read-Host -Exactly 0 -Scope It
    }
    It 'prompts the user to select a Management Group, if the architecture is set to Multiple and the management group parameter has not already been set' {
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.Architecture = 'Multiple'
      $controlParameters.ManagementGroup = ''
      $controlParameters.AzureSubscriptionId = '1234'

      Mock Clear-Scrollback
      Mock Show-Menu
      Mock Get-AzManagementGroup { return @{} }
      Mock Select-AzSubscription
      Mock Read-Host { return }

      Get-ManagementGroup -controlParameters $controlParameters

      Assert-MockCalled Read-Host -Exactly 1 -Scope It
    }
  }

  Describe 'Get-ResourceGroupName Function' {
    It 'does not prompt the user to enter a resource group, if the parameter was set elsewhere and teh resource group does not already exist' {
      Mock Select-AzSubscription { return $null }
      Mock Read-Host
      Mock Send-Event
      Mock Get-AzResourceGroup { return $null }

      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.AzureSubscriptionId = "Azure Context"
      $controlParameters.ResourceGroupName = "Azure Context"

      Get-ResourceGroupName -controlParameters $controlParameters

      Assert-MockCalled Select-AzSubscription -Exactly 1 -Scope It
      Assert-MockCalled Read-Host -Exactly 0 -Scope It
    }
    It 'uses the existing resource group name and location, if they exists and are part of a previous drivetrain installation' {
      Mock Select-AzSubscription { return $null }
      Mock Read-Host
      Mock Send-Event
      Mock Get-AzResourceGroup { return @{ ResourceGroupName = "Azure Context"; Location = "uksouth" } }

      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.AzureSubscriptionId = "Azure Context"
      $controlParameters.ResourceGroupName = ""

      Get-ResourceGroupName -controlParameters $controlParameters

      Assert-MockCalled Select-AzSubscription -Exactly 1 -Scope It
      Assert-MockCalled Read-Host -Exactly 0 -Scope It
      $controlParameters.ResourceGroupName | Should -Be "Azure Context"
      $controlParameters.ResourceGroupLocation | Should -Be "uksouth"
    }
    It 'terminates the script if the resource group specified does not have the same name as an existing drivetrain resource group' {
      Mock Select-AzSubscription
      Mock Read-Host
      Mock Send-Event
      Mock Get-AzResourceGroup { return @{ ResourceGroupName = "Example-ResourceGroup"; Location = "uksouth" } }

      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.AzureSubscriptionId = "Azure Context"
      $controlParameters.ResourceGroupName = "Azure Context"
      { Get-ResourceGroupName -controlParameters $controlParameters } | Should -Throw "The existing NS-DriveTrain resource group (Example-ResourceGroup) and the one specified ($($controlParameters.ResourceGroupName)) do not match. Terminating"

      Assert-MockCalled Select-AzSubscription -Exactly 1 -Scope It
    }
    It 'prompts the user to enter a resource group name, if the parameters has not already been set and no installation of Monitoring already exists' {
      Mock Select-AzSubscription
      Mock Read-Host
      Mock Send-Event
      Mock Get-AzResourceGroup { return $null }

      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.AzureSubscriptionId = "Azure Context"
      Get-ResourceGroupName -controlParameters $controlParameters

      Assert-MockCalled Select-AzSubscription -Exactly 1 -Scope It
      Assert-MockCalled Read-Host -Exactly 1 -Scope It
    }
  }

  Describe 'Get-ServiceNowToken Function' {
    It 'does not prompt the user to enter a Service Now token, if the environment is DEV' {
      Mock Read-Host { return 1234 }
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.Environment = 'DEV'

      Get-ServiceNowToken -controlParameters $controlParameters

      Assert-MockCalled Read-Host -Exactly 0 -Scope It
    }
    It 'prompts the user to enter a Service Now token, if the environment is PROD' {
      Mock Clear-Scrollback
      Mock Read-Host { return 1234 }
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.Environment = 'PROD'

      Get-ServiceNowToken -controlParameters $controlParameters

      Assert-MockCalled Read-Host -Exactly 1 -Scope It
      $controlParameters.SNowToken | Should -Be '1234'
    }
    It 'does not prompt the user to enter a Service Now token, if the environment is PROD and the token has been set elsewhere' {
      Mock Clear-Scrollback
      Mock Read-Host { return 1234 }
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.Environment = 'PROD'
      $controlParameters.SNowToken = "6789"

      Get-ServiceNowToken -controlParameters $controlParameters

      Assert-MockCalled Read-Host -Exactly 0 -Scope It
      $controlParameters.SNowToken | Should -Be '6789'
    }
  }

  Describe 'Get-Plugin Function' {
    It 'does not prompt the user to select a plugin, if the parameter was set elsewhere' {
      Mock Get-ChildItem { return @('FirstSamplePlugin.json', 'SecondSamplePlugin.json') }
      $controlParameters = [TestMonitoringInstall]::new()

      $controlParameters.Plugin = 'FirstSamplePlugin.json'
      Get-Plugin -controlParameters $controlParameters -SourceFolder ".."
      $controlParameters.ManualSelection | Should -Be $false
    }
    It 'prompts the user to select a plugin, if the parameter has not already been set' {
      Mock Clear-Scrollback
      Mock Show-Menu
      Mock Get-ChildItem { return @('FirstSamplePlugin.json', 'SecondSamplePlugin.json') }
      Mock Read-Host { return 1 }
      Mock Get-AzStorageAccount -MockWith { return $null }
      $controlParameters = [TestMonitoringInstall]::new()

      Get-Plugin -controlParameters $controlParameters -SourceFolder ".."

      Assert-MockCalled Clear-Scrollback -Times 1 -Scope It
      $controlParameters.Plugin | Should -Be "FirstSamplePlugin.json"
      $controlParameters.ManualSelection | Should -Be $true
    }
  }

  Describe 'Get-UninstallArchitecture Function' {
    It 'prompts the user to select an architecture, if the parameter has not already been set' {
      Mock Clear-Scrollback
      Mock Send-Trace
      Mock Show-Menu
      Mock Read-Host -MockWith { return 2 }
      $controlParameters = [TestMonitoringUninstall]::new()
      $controlParameters.Architecture = ''
      Get-UninstallArchitecture -controlParameters $controlParameters

      $controlParameters.Architecture | Should -Be 'Multiple'
    }
  }

  Describe "Publish-Alerts Function" {
    It 'Checks that the function errors when the incorrect inputs are not provided' {
      $test = $false
      Mock Send-Error
      try { $x = Publish-Alerts } catch { $test = $true }
      $test | Should -Be $true
    }
    #It 'Checks that the function errors when it cannot find the Alert file path' {
    #  Mock Send-Error
    #  Mock Get-Item -Verifiable
    #  $ht = @{ #Defined a hashtable to get through the input type check.
    #    Test = "Value"
    #  }
    #  try { $x = Publish-Alerts -PublishResourceGroupOutputs $ht -AlertFilePath "X:\Dingus.txt" } catch { $test = $true }
    #  Assert-VerifiableMock
    #}
  }

  Describe "Test-ResourceGroup Function" {
    It "Shows that there is no previous install" {
      Mock Send-Trace
      Mock Select-AzSubscription
      Mock Get-AzResourceGroup -MockWith { return [System.Collections.ArrayList]::new() }
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.AzureSubscriptionId = "test"
      $controlParameters.ResourceGroupName = "test1"
      Test-ResourceGroup -controlParameters $controlParameters
      $controlParameters.WorkspaceName
    }
  }

  Describe "Get-SecurityMonitoringEnabled Function" {
    It 'Given a new install where value of securitycenter flag is not supplied: ask user for value - user types N - value in $controlParameters set to false/manual selection true ' {
      # setup
      Mock Clear-Scrollback
      Mock Show-Menu
      Mock Read-Host { return "N" }
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.EnableSecurity = $false
      $controlParameters.ManualSelection = $true
      # execute
      Get-SecurityMonitoringEnabled -controlParameters $controlParameters
      #verify
      $controlParameters.EnableSecurity | Should -Be $false
      $controlParameters.ManualSelection | Should -Be $true
    }
    It 'Given a new install where value of securitycenter flag is not supplied: ask user for value - user types y - value in $controlParameters set to true / manual selection true' {
      # setup
      Mock Show-Menu
      Mock Read-Host { return "y" }
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.ManualSelection = $false
      $controlParameters.SecurityCenterAlreadyEnabled = $false
      # execute
      Get-SecurityMonitoringEnabled -controlParameters $controlParameters
      # verify
      $controlParameters.EnableSecurity | Should -Be $true
      $controlParameters.ManualSelection | Should -Be $true
    }
    It 'Given a new install where value of securitycenter flag is not supplied: ask user for value - user types Y - value in $controlParameters set to true/manual selection true' {
      #setup
      Mock Show-Menu
      Mock Read-Host { return "Y" }
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.ManualSelection = $false
      $controlParameters.SecurityCenterAlreadyEnabled = $false
      # execute
      Get-SecurityMonitoringEnabled -controlParameters $controlParameters
      # verify
      $controlParameters.EnableSecurity | Should -Be $true
      $controlParameters.ManualSelection | Should -Be $true
    }
    It 'Given value of securitycenter flag is not supplied, previous install enabled it: user not prompted - value in $controlParameters set to true/manual selection true' {
      #setup
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.ManualSelection = $false
      $controlParameters.SecurityCenterAlreadyEnabled = $true
      # execute
      Get-SecurityMonitoringEnabled -controlParameters $controlParameters
      # verify
      $controlParameters.EnableSecurity | Should -Be $true
      $controlParameters.ManualSelection | Should -Be $false
    }
    It 'Given value of securitycenter flag is false: ask user for value - user types n - value in $controlParameters set to false / manual selection true' {
      #setup
      Mock Show-Menu
      Mock Read-Host { return "n" }
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.EnableSecurity = $false
      $controlParameters.ManualSelection = $true
      # execute
      Get-SecurityMonitoringEnabled -controlParameters $controlParameters
      # verify
      $controlParameters.EnableSecurity | Should -Be $false
      $controlParameters.ManualSelection | Should -Be $true
    }
    It 'Given value of securitycenter flag is not supplied, previous install was off: ask user for value - user types n - value in $controlParameters set to false / manual selection true' {
      #setup
      Mock Show-Menu
      Mock Read-Host { return "n" }
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.SecurityCenterAlreadyEnabled = $false
      $controlParameters.EnableSecurity = $null
      $controlParameters.ManualSelection = $true
      # execute
      Get-SecurityMonitoringEnabled -controlParameters $controlParameters
      # verify
      $controlParameters.EnableSecurity | Should -Be $false
      $controlParameters.ManualSelection | Should -Be $true
    }
    It 'Given value of securitycenter flag is false, previous install enabled it: Throw exception for invalid input.' {
      # setup
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.EnableSecurity = $false
      $controlParameters.SecurityCenterAlreadyEnabled = $true
      $controlParameters.ManualSelection = $true
      # execute
      { Get-SecurityMonitoringEnabled -controlParameters $controlParameters } | Should -Throw
      # verify
      $controlParameters.EnableSecurity | Should -Be $false
      $controlParameters.ManualSelection | Should -Be $true
    }
    It 'Given value of securitycenter flag is false: ask user for value - user types rubbish - value in $controlParameters set to false / manual selection false' {
      #setup
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.EnableSecurity = $false
      $controlParameters.ManualSelection = $true
      Mock Show-Menu
      #display lettters to compare against
      $randomUserValues = "asdfadfnglkaslkngalkfnk2342419!1342@sadfadsfad?123412341adfafa"
      #Split the characters
      $userRandomOption = $randomUserValues -split ''
      Mock Read-Host { return $userRandomOption }
      # execute
      Get-SecurityMonitoringEnabled -controlParameters $controlParameters
      #verify
      $controlParameters.EnableSecurity | Should -Be $false
      $controlParameters.ManualSelection | Should -Be $true
    }
    It 'Given value of securitycenter flag is true & manual selection is false: does not ask / manual selection (unchanged) false' {
      #setup
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.EnableSecurity = $true
      $controlParameters.ManualSelection = $false

      $enableSecurityQuestion = Mock Read-Host

      If ($enableSecurityQuestion -eq $true) {
        Mock Show-Menu
        $enableSecurityQuestion
      }

      # execute
      Get-SecurityMonitoringEnabled -controlParameters $controlParameters
      #verify
      $controlParameters.EnableSecurity | Should -Be $true
      $controlParameters.ManualSelection | Should -Be $false
    }
  }

  Describe 'Get-Scope Function' {
    It 'returns a valid scope for a single subscription deployment' {
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.AzureSubscriptionId = "dummyId"
      $controlParameters.Architecture = 'Single'
      $result = Get-Scope -controlParameters $controlParameters
      $result | Should -Be "/subscriptions/$($controlParameters.AzureSubscriptionId)"
    }
    It 'returns a valid scope for a single subscription deployment with provider in output resource uri' {
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.AzureSubscriptionId = "dummyId"
      $controlParameters.Architecture = 'Single'
      $result = Get-Scope -controlParameters $controlParameters -addProviders
      $result | Should -Be "/subscriptions/$($controlParameters.AzureSubscriptionId)/providers/"
    }
    It 'returns a valid scope for a multiple subscription deployment' {
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.AzureSubscriptionId = "dummyId"
      $controlParameters.ManagementGroup = "dummymg"
      $controlParameters.Architecture = 'Multiple'
      $result = Get-Scope -controlParameters $controlParameters
      $result | Should -Be "/providers/Microsoft.Management/managementgroups/dummymg"
    }
    It 'returns a valid scope for a multiple subscription deployment with provider in output resource uri' {
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.AzureSubscriptionId = "dummyId"
      $controlParameters.ManagementGroup = "dummymg"
      $controlParameters.Architecture = 'Multiple'
      $result = Get-Scope -controlParameters $controlParameters -addProviders
      $result | Should -Be "/providers/Microsoft.Management/managementgroups/dummymg/providers/"
    }
    It 'returns a valid scope for a multiple subscription uninstall with provider in output resource uri' {
      $controlParameters = [TestMonitoringUninstall]::new()
      $controlParameters.AzureSubscriptionId = "dummyId"
      $controlParameters.ManagementGroup = "dummymg"
      $controlParameters.Architecture = 'Multiple'
      $result = Get-Scope -controlParameters $controlParameters -addProviders
      $result | Should -Be "/providers/Microsoft.Management/managementgroups/dummymg/providers/"
    }
  }

  Describe 'Get-ModuleParamId Function' {
    It 'returns a valid subscription id param splat for a single subscription deployment where subscription object is supplied' {
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.AzureSubscriptionId = "dummyId"
      $controlParameters.Architecture = 'Single'
      $singleSubscription = @{ id = "testvalue" }
      $result = Get-ModuleParamId -controlParameters $controlParameters -sub $singleSubscription
      $result.keys.count | Should -Be 1
      $result.subscription | Should -Be "testvalue"
    }
    It 'returns a valid module param id for a single subscription deployment with no subscription object supplied' {
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.AzureSubscriptionId = "dummyId"
      $controlParameters.Architecture = 'Single'
      $result = Get-ModuleParamId -controlParameters $controlParameters
      $result.keys.count | Should -Be 1
      $result.SubscriptionId | Should -Be "dummyId"
    }
    It 'returns a valid module param id for a multiple subscription deployment where subscription object is supplied' {
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.AzureSubscriptionId = "dummyId"
      $controlParameters.Architecture = 'Multiple'
      $Subscription = @{ id = "testvalue" }
      $result = Get-ModuleParamId -controlParameters $controlParameters -sub $Subscription
      $result.keys.count | Should -Be 1
      $result.subscription | Should -Be $Subscription
    }
    It 'returns a valid module param id for a multiple subscription deployment where no subscription object is supplied' {
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.AzureSubscriptionId = "dummyId"
      $controlParameters.ManagementGroup = "dummyMgId"
      $controlParameters.Architecture = 'Multiple'
      $result = Get-ModuleParamId -controlParameters $controlParameters
      $result.keys.count | Should -Be 1
      $result.ManagementGroupId | Should -Be "dummyMgId"
    }
    It 'returns a valid module param id for a multiple subscription uninstall where no subscription object is supplied' {
      $controlParameters = [TestMonitoringUninstall]::new()
      $controlParameters.AzureSubscriptionId = "dummyId"
      $controlParameters.ManagementGroup = "dummyMgId"
      $controlParameters.Architecture = 'Multiple'
      $result = Get-ModuleParamId -controlParameters $controlParameters
      $result.keys.count | Should -Be 1
      $result.ManagementGroupId | Should -Be "dummyMgId"
    }
  }

  Describe 'Get-ModuleParamName Function' {
    It 'returns a valid subscription name param splat for a single subscription deployment' {
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.AzureSubscriptionId = "dummyId"
      $controlParameters.Architecture = 'Single'
      $result = Get-ModuleParamName -controlParameters $controlParameters
      $result.keys.count | Should -Be 1
      $result.SubscriptionId | Should -Be "dummyId"
    }
    It 'returns a valid module param name for a multiple subscription deployment' {
      $controlParameters = [TestMonitoringInstall]::new()
      $controlParameters.AzureSubscriptionId = "dummyId"
      $controlParameters.ManagementGroup = "dummyMgId"
      $controlParameters.Architecture = 'Multiple'
      $result = Get-ModuleParamName -controlParameters $controlParameters
      $result.keys.count | Should -Be 1
      $result.ManagementGroupName | Should -Be "dummyMgId"
    }

    It 'returns a valid module param name for a multiple subscription uninstall' {
      $controlParameters = [TestMonitoringUninstall]::new()
      $controlParameters.AzureSubscriptionId = "dummyId"
      $controlParameters.ManagementGroup = "dummyMgId"
      $controlParameters.Architecture = 'Multiple'
      $result = Get-ModuleParamName -controlParameters $controlParameters
      $result.keys.count | Should -Be 1
      $result.ManagementGroupName | Should -Be "dummyMgId"
    }
  }
}
