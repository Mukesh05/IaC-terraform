Then 'A Log Analytics Workspace is found in subscription' {
  $ws = Get-AzOperationalInsightsWorkspace
  $ws | Should Not Be $null
  $ws.Name -like "LA-*" | Should Be $true
}

Then 'The Parent Resource Group has a tag called DriveTrain' {
  $ws = Get-AzOperationalInsightsWorkspace
  $rg = Get-AzResourceGroup -Name ($ws.ResourceGroupName)
  $rg.tags.ContainsKey('NS-DriveTrain') | Should Be True
}

Then 'The Parent Resource Group contains an Automation Account' {
  $ws = Get-AzOperationalInsightsWorkspace
  $aa = Get-AzAutomationAccount

  $aa | Should Not Be NullOrEmpty

  $aa.ResourceGroupName | Should Be $ws.ResourceGroupName
}

When 'The Parent Resource Group contains an Action Group' {
  $ws = Get-AzOperationalInsightsWorkspace
  $ag = Get-AzActionGroup -WarningAction SilentlyContinue
  $ag | Should Not Be NullOrEmpty
  $ag = $ag |Where-Object { $_.Name -like "SNow" }
  $ag.ResourceGroupName | Should Be $ws.ResourceGroupName
}

Then 'The SKU of the Workspace is PerGB2018' {
  $ws = Get-AzOperationalInsightsWorkspace
  $ws.sku | Should Be 'pergb2018'
}

Then 'The Retention Period is 31 Days' {
  $ws = Get-AzOperationalInsightsWorkspace
  $ws.retentionInDays | Should Be 31
}

Then 'Monitoring has <number> Event Log Sources Registered for <kind> with <name> having <count>' {
  [CmdletBinding()]
  param (
      [Parameter()]
      $table
  )
  $table | Should Not BeNullOrEmpty
  $ws = Get-AzOperationalInsightsWorkspace
  foreach($row in $table) {
    $LogAnalyticsDataSources = Get-AzOperationalInsightsDataSource -ResourceGroupName $ws.ResourceGroupName `
                                                                  -WorkspaceName $ws.Name `
                                                                  -Kind $row.kind
    $LogAnalyticsDataSources.Count | Should Be $row.number

    if(![String]::IsNullOrEmpty($row.name)) {
      ($LogAnalyticsDataSources `
        | Where-Object { $_.Name -eq $row.name }).Properties.PerformanceCounters.Count `
        | Should Be $row.count
    }
  }
}

Then 'The Action Group has no Email Receivers or SMS Receivers' {
  $ag = Get-AzActionGroup -WarningAction SilentlyContinue
  $ag.SmsReceivers | Should Be $null
  $ag.EmailReceivers | Should Be $null
}

Then 'The Action Group ShortName is SNow' {
  $ag = Get-AzActionGroup -WarningAction SilentlyContinue
  $ag = $ag |Where-Object { $_.Name -like "SNow" }
  $ag.GroupShortName | Should Be 'SNow'
}

Then 'The Action Group has A Service Now Webhook' {
  $ag = Get-AzActionGroup -WarningAction SilentlyContinue
  $ag.WebHookReceivers | Should Not Be Null
  $ag.WebHookReceivers.Count | Should Be 1
  $wh = ($ag.WebHookReceivers |Select-Object -first 1)
  $wh.ServiceUri | Should BeLike '*service-now.com*'
}

Then 'There is One DriveTrain PolicyAssignment' {
  $PolicyAssignments = Get-AzPolicyAssignment
  $PolicyAssignments -is [Array] | Should Be $false
}

Then 'The PolicyAssignment Contains DriveTrainDiagPolicies' {
  $PolicyAssignments = Get-AzPolicyAssignment
  $PolicyAssignments.Name | Should Contain 'DriveTrainDiagPolicies'

}

Then 'There is only one Policy Initiative' {
  $PolicyAssignments = Get-AzPolicyAssignment
  $PolicyAssignments.Properties.policyDefinitionId | Should BeLike '*DriveTrain Diagnostic Policies'
}

Then 'The Policy Initiative contains 61 Policy Definitions' {
  $PolicySet = Get-AzPolicySetDefinition -Custom
  $PolicySet.Properties.policyDefinitions.Count | Should Be 61
}