Given 'We are connected to Azure' {
  <#
  NOTE : Go to https://aka.ms/azps-changewarnings for steps to suppress this breaking change warning,
  and other information on breaking changes in Azure PowerShell
  #>
  Set-Item Env:\SuppressAzurePowerShellBreakingChangeWarnings "true"
  { Get-AzContext | Should Not Be NullOrEmpty } | Should Not Throw
}

When 'We select the monitoring subscription' {
  (Get-AzContext).Subscription | Should Not Be NullOrEmpty
}

Given 'Monitoring is installed into subscription' {
  Get-AzResourceGroup | Should Not Be NullOrEmpty
  $true | Should Be True
}