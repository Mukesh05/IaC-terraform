Using Module '.\MonitoringCommon.psm1'

[CmdletBinding()]
Param(
  [ValidateSet('Single', 'Multiple')]
  [string] $Architecture = '',
  [string] $AzureTenantId = '',
  [string] $AzureSubscriptionId = '',
  [string] $ManagementGroupId = '',
  [string] $ResourceGroupName = '',
  [string] $SourceFolder = $PSScriptRoot,
  [switch] $SkipUserCheck
)

try {
  Import-Module -Name "$($PSScriptRoot)\lib_pwsh\Instrumentation.psm1" -Force
  Import-Module -Name "$($PSScriptRoot)\lib_pwsh\AzureGeneral.psm1" -Force
  Import-Module -Name "$($PSScriptRoot)\lib_pwsh\UserInterface.psm1" -Force
  Import-Module -Name "$($PSScriptRoot)\AzureResources.psm1" -Force
  Import-Module -Name "$($PSScriptRoot)\Deploy-EventGridSubscription.psm1" -Force
  Import-Module (Join-Path -Path $PSScriptRoot -ChildPath "\Monitoring.psm1") -Force

  Send-Event "Evaluating dependencies"

  $depCheck = Test-Dependencies

  if ($null -ne $depCheck){
    foreach ($_ in $depCheck){
        Send-Event $_ -WriteOutput
    }
    throw "Dependency evaluation failed. Terminating uninstallation. Please correct the dependency errors and try again."
  }

  Connect-Azure -SkipUserCheck:$SkipUserCheck

  $controlParameters = [MonitoringUninstall]::new()
  $controlParameters.Architecture = $Architecture
  $controlParameters.AzureTenant.Id = $AzureTenantId
  $controlParameters.AzureSubscriptionId = $AzureSubscriptionId
  $controlParameters.ManagementGroup = $ManagementGroupId
  $controlParameters.ResourceGroupName = $ResourceGroupName
  $controlParameters.ManualSelection = $false

  Do {
    Get-UninstallArchitecture -controlParameters $controlParameters
    Get-AzureTenant -controlParameters $controlParameters
    Get-AzureSubscription -controlParameters $controlParameters
    Get-ManagementGroup -controlParameters $controlParameters
    Get-ResourceGroupName -controlParameters $controlParameters
    Clear-Scrollback
  } Until ($controlParameters.IsValid())

  Uninstall -controlParameters $controlParameters
}
Catch {
  Send-Event -Message ("{0}`n{1}" -f $_.Exception.Message, $_.ScriptStackTrace) -WriteOutput

  Send-Error -Message "An error has occured:`n $_" -Exception $_.Exception

  If ([Environment]::UserInteractive) {
    Read-Host "Press enter to continue and exit"
  }

  Exit
}