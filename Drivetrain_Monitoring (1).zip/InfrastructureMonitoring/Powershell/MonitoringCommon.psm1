Using Module '.\lib_pwsh\Helpers.psm1'

Class MonitoringInstall : ControlParameters {
  [string] $Environment = ''
  [string] $SNowToken = ''
  [string] $WorkspaceName = ''
  [string] $AppInsightsName = ''
  [string] $AzureSubscriptionName = ''
  [string] $StorageAccount = ''
  [string] $AutomationAccountName = ''
  [string] $AlertEmailName = ''
  [string] $AlertEmailAddress = ''
  [string] $actionGroupResourceID = ''
  [string] $WorkspaceRetentionDays = ''
  [string[]] $SupportedRegions = @(
        "australiaeast",
        "australiasoutheast",
        "brazilsouth",
        "canadacentral",
        "centralindia",
        "centralus",
        "eastasia",
        "eastus",
        "eastus2",
        "francecentral",
        "japaneast",
        "koreacentral",
        "northeurope",
        "northcentralus",
        "norwayeast",
        "southcentralus",
        "southeastasia",
        "switzerlandnorth",
        "uksouth",
        "usgovvirginia",
        "usgovarizona",
        "uaenorth",
        "westcentralus",
        "westeurope",
        "westus",
        "westus2"
  )
  [Nullable[boolean]] $SecurityCenterAlreadyEnabled = $null
  [Nullable[boolean]] $EnableSecurity = $null
  [bool] $ChangeRetentionDays = $true
  [bool] $ContinueScript = $false
  [bool] $UsePreviousPluginJson = $false
  [bool] $UsePreviousAlertsJson = $false
  $Plugin = $null
  [array] $Subscriptions
  [bool] $EnableCAS = $false

  ShowSummary() {
    Write-Host "This will install the New Signature Drivetrain Monitoring solution."
    Write-Host ""
    Write-Host ""
    If ($this.Architecture -eq 'Single') {
      $message = "Deploying Monitoring to a single subscription."
      Send-Event $message
      Write-Host $message
    }
    If ($this.Architecture -eq 'Multiple') {
      $message = "Deploying Monitoring to multiple subscriptions."
      Send-Event $message
      Write-Host $message
    }
    If ($this.AzureTenant.Id -ne '') {
      $message = "Will deploy to Azure AD Tenant with ID -  $($this.AzureTenant.Id)"
      Send-Event $message
      Write-Host $message
    }
    If ($this.AzureTenant.Name -ne '') {
      $message = "Will deploy to the Azure AD Tenant with Name - $($this.AzureTenant.Name)"
      Send-Event $message
      Write-Host $message
    }
    If ($this.ManagementGroup -ne '') {
      $message = "Policies and blueprints will be deployed in management group - $($this.ManagementGroup)"
      Send-Event $message
      Write-Host $message
    }
    #Added logic to display message when subcription name is passed
    If ($this.AzureSubscriptionName -ne '') {
      If ($this.Architecture -eq 'Single') {
        $message = "Policy will be deployed to the subscription - $($this.AzureSubscriptionName)"
        Send-Event $message
        Write-Host $message
      }
      else {
        $message = "Core resources will be deployed to the subscription - $($this.AzureSubscriptionName)"
        Send-Event $message
        Write-Host $message
      }
    }
    If ($this.ResourceGroupName -ne '') {
      $message = "Core resources will be deployed in Group - $($this.ResourceGroupName)"
      Send-Event $message
      Write-Host $message
    }
    If ($this.ResourceGroupLocation -ne '') {
      $message = "Resources will be deployed in Azure Region - $($this.ResourceGroupLocation)"
      Send-Event $message
      Write-Host $message
    }
    If ($this.WorkspaceRetentionDays -ne '') {
      $message = "Workspace Retention days are set to - $($this.WorkspaceRetentionDays)"
      Send-Event $message
      Write-Host $message
    }
    If ($this.UsePreviousAlertsJson) {
      $message = "Will use alerts.json from a previous DriveTrain installation"
      Send-Event $message
      Write-Host $message
    }
    If ($this.UsePreviousPluginJson) {
      $message = "Will use Alerts plugin from a previous DriveTrain installation"
      Send-Event $message
      Write-Host $message
    }
    If ($this.Plugin -ne '' -and $null -ne $this.Plugin) {
      $message = "Additional alerts will be deployed from plugin - $($this.Plugin)"
      Send-Event $message
      Write-Host $message
    }
    If ($this.EnableSecurity -or $this.SecurityCenterAlreadyEnabled) {
      $beOrRemain = "be"
      If ($this.SecurityCenterAlreadyEnabled) {
        $beOrRemain = "remain"
      }

      $message = "Azure Security Center will $($beOrRemain) enabled on ALL subscriptions"
      Send-Event $message
      Write-Host $message
    }

    # This tests for an empty string, the token is only requested if the environment is 'Prod'.  If the string is empty the default in the ARM template will be used.
    If ($this.SNowToken -eq '') {
      $message = "!No ServiceNow token has been supplied - telemetry will be sent to NS ServiceNow Dev ONLY!"
      Send-Event $message
      Write-Host $message
    }
    Else {
      $message = "Service Now Token - $($this.SNowToken)"
      Send-Event $message
      Write-Host $message
    }
    Write-Host ""
    Write-Host ""
  }

  Reset() {
    $this.Architecture = ''
    $this.ManagementGroup = ''
    $this.AzureTenant = [AzureTenant]::new()
    $this.AzureSubscriptionId = ''
    $this.ResourceGroupName = ''
    $this.ResourceGroupLocation = ''
    $this.Environment = ''
    $this.WorkspaceName = ''
    $this.AutomationAccountName = ''
    $this.SNowToken = ''
    $this.UsePreviousAlertsJson = $false
    $this.UsePreviousPluginJson = $false
    $this.Plugin = ''
  }

  [bool] IsValid() {
    If ($this.ManualSelection) {
      Clear-Scrollback
      $this.ShowSummary()

      $deploymentConfirmed = Read-Host "Enter 'Y' to continue deployment or 'N' to start selection of parameters again"
      If ($deploymentConfirmed.ToUpperInvariant() -ne 'Y') {
        Send-Trace "User provided value $deploymentConfirmed in confirmation prompt, resetting"
        $this.Reset()
        return $false
      }
      else {
        return $true
      }
    }
    Else {
      Return $true
    }
  }
}

Class ClientInstall : MonitoringInstall {
  ShowSummary() {
    Write-Host "This will install the New Signature Drivetrain Monitoring solution."
    Write-Host ""
    Write-Host ""
    If ($this.Architecture -eq 'Single') {
      $message = "Deploying Monitoring to a single subscription."
      Send-Event $message
      Write-Host $message
    }
    If ($this.Architecture -eq 'Multiple') {
      $message = "Deploying Monitoring to multiple subscriptions."
      Send-Event $message
      Write-Host $message
    }
    If ($this.AzureTenant.Id -ne '') {
      $message = "Will deploy to Azure AD Tenant with ID -  $($this.AzureTenant.Id)"
      Send-Event $message
      Write-Host $message
    }
    If ($this.AzureTenant.Name -ne '') {
      $message = "Will deploy to the Azure AD Tenant with Name - $($this.AzureTenant.Id)"
      Send-Event $message
      Write-Host $message
    }
    If ($this.ResourceGroupName -ne '') {
      $message = "Core resources will be deployed in Group - $($this.ResourceGroupName)"
      Send-Event $message
      Write-Host $message
    }
    If ($this.ResourceGroupLocation -ne '') {
      $message = "Resources will be deployed in Azure Region - $($this.ResourceGroupLocation)"
      Send-Event $message
      Write-Host $message
    }
    #Added logic to display message when subcription name is passed
    If ($this.Architecture -eq 'Single') {
      If ($this.AzureSubscriptionName -ne '') {
        $message = "Policy will be deployed to the subscription - $($this.AzureSubscriptionName)"
        Send-Event $message
        Write-Host $message
      }
    }
    If ($this.UsePreviousAlertsJson) {
      $message = "Will use alerts.json from a previous DriveTrain installation"
      Send-Event $message
      Write-Host $message
    }
    If ($this.UsePreviousPluginJson) {
      $message = "Will use Alerts plugin from a previous DriveTrain installation"
      Send-Event $message
      Write-Host $message
    }
    If ($this.Plugin -ne '' -and $null -ne $this.Plugin) {
      $message = "Additional alerts will be deployed from plugin - $($this.Plugin)"
      Send-Event $message
      Write-Host $message
    }

    Write-Host ""
    Write-Host ""
  }

  Reset() {
    $this.Architecture = ''
    $this.AzureTenant = [AzureTenant]::new()
    $this.AzureSubscriptionId = ''
    $this.ResourceGroupName = ''
    $this.ResourceGroupLocation = ''
    $this.Environment = ''
    $this.WorkspaceName = ''
    $this.UsePreviousAlertsJson = $false
    $this.UsePreviousPluginJson = $false
    $this.Plugin = ''
  }

  [bool] IsValid() {
    If ($this.ManualSelection) {
      Clear-Scrollback
      $this.ShowSummary()

      $deploymentConfirmed = Read-Host "Enter 'Y' to continue deployment or 'N' to start selection of parameters again"
      If ($deploymentConfirmed.ToUpperInvariant() -ne 'Y') {
        Send-Trace "User provided value $deploymentConfirmed in confirmation prompt, resetting"
        $this.Reset()
        return $false
      }
      else {
        return $true
      }
    }
    Else {
      Return $true
    }
  }
}

Class MonitoringUninstall : ControlParameters {
  ShowSummary() {

    Write-Host "This will uninstall the New Signature Drivetrain Monitoring solution."
    Write-Host ""
    Write-Host ""
    If ($this.Architecture -eq 'Single') {
      $message = "Uninstalling monitoring from a single subscription."
      Send-Event $message
      Write-Host $message
      $message = "Uninstalling from Subscription - $($this.AzureSubscriptionName)"
      Send-Event $message
      Write-Host $message
    }
    If ($this.Architecture -eq 'Mutiple') {
      $message = "Uninstalling monitoring from  multiple subscriptions."
      Send-Event $message
      Write-Host $message
    }

    If ($this.AzureTenant.Id -ne '') {
      $message = "Removing from Azure Tenancy - $($this.AzureTenant.Name)"
      Send-Event $message
      Write-Host $message
    }
    If ($this.AzureSubscriptionId -ne '') {
      $message = "Removing from Azure Subscription - $($this.AzureSubscriptionName)"
      Send-Event $message
      Write-Host $message
    }

    If ($this.ResourceGroupName -ne '') {
      $message = "Removing Resource Group - $($this.ResourceGroupName)"
      Send-Event $message
      Write-Host $message
    }

    Write-Host ""
    Write-Host ""
  }

  Reset() {
    $this.Architecture = ''
    $this.ManagementGroup = ''
    $this.AzureTenant = [AzureTenant]::new()
    $this.AzureSubscriptionId = ''
    $this.ResourceGroupName = ''
    $this.WorkspaceName = ''
  }

  [bool] IsValid() {
    If ($this.ManualSelection) {
      Clear-Scrollback
      $this.ShowSummary()

      $deploymentConfirmed = Read-Host "Enter 'Y' to continue deployment or 'N' to start selection of parameters again"
      If ($deploymentConfirmed.ToUpperInvariant() -ne 'Y') {
        Send-Trace "User provided value $deploymentConfirmed in confirmation prompt, resetting"
        $this.Reset()
        return $false
      }
      else {
        return $true
      }
    }
    Else {
      Return $true
    }
  }
}