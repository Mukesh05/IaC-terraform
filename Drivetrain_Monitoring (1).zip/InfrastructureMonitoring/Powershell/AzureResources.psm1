#Requires -Version 5.1
#Requires -Modules Instrumentation, AzureGeneral
Using Module '.\MonitoringCommon.psm1'
function Format-ValidationOutput {
  param ($ValidationOutput, [int] $Depth = 0)
  Set-StrictMode -Off
  return @($ValidationOutput | Where-Object { $_ -ne $null } | ForEach-Object { @('  ' * $Depth + ': ' + $_.Message) + @(Format-ValidationOutput @($_.Details) ($Depth + 1)) })
}

Function Publish-TemplateLibraryTemplates {
  [CmdletBinding(DefaultParameterSetName = 'AllVariables')]
  Param (
    [string] $AzureSubscription = '',
    [string] $MonitoringLocation = '',
    [string] $MonitoringResourceGroup = '',
    [string] $Template = '',
    [string] $SourceFolder = $PSScriptRoot
  )

  Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState

  Select-AzSubscription -Subscription $AzureSubscription | Out-Null

  $DeploymentLibrary = New-AzResourceGroupDeployment -Name ("DeploymentLibrary" + '-' + ((Get-Date).ToUniversalTime()).ToString('MMdd-HHmm')) `
    -ResourceGroupName $MonitoringResourceGroup `
    -TemplateFile "$($SourceFolder)\ARM\DeploymentLibrary.json" `
    -Force `
    -ErrorVariable ErrorMessages

  $StorageAccount = (Get-AzStorageAccount | Where-Object { $_.StorageAccountName -eq $DeploymentLibrary.Outputs.item("storageAccount").value })
  $StorageContainerName = "uploadlocation"
  $ArtifactStagingDirectory = Join-Path -Path $SourceFolder -ChildPath 'ARM'
  $DSCSourceFolder = Join-Path -Path $SourceFolder -ChildPath 'Assets_DSC'
  $RunbookSourceFolder = Join-Path -Path $SourceFolder -ChildPath 'Runbook'

  # Copy files from the local storage staging location to the storage account container
  New-AzStorageContainer -Name $StorageContainerName -Context $StorageAccount.Context -ErrorAction SilentlyContinue | Out-Null

  Get-ChildItem $ArtifactStagingDirectory -Recurse -File | ForEach-Object -Process {
    #foreach ($SourcePath in $ArtifactFilePaths) {
    Set-AzStorageBlobContent -File $_.FullName -Blob $_.Name -Container $StorageContainerName -Context $StorageAccount.Context -Force | Out-Null
  }

  # Copy Runbooks to storage account
  if (Test-Path $RunbookSourceFolder) {
    $RunbookSourceFilePaths = Get-ChildItem $RunbookSourceFolder -Recurse -File | ForEach-Object -Process { $_.FullName }
    foreach ($RunbookSourceFilePath in $RunbookSourceFilePaths) {
      Set-AzStorageBlobContent -File $RunbookSourceFilePath -Blob $RunbookSourceFilePath.Substring($RunbookSourceFolder.length + 1) `
        -Container $StorageContainerName -Context $StorageAccount.Context -Force | Out-Null
    }
  }

  # Copy DSC's to storage account
  if (Test-Path $DSCSourceFolder) {
    $DSCSourceFilePaths = Get-ChildItem $DSCSourceFolder -Recurse -File | ForEach-Object -Process { $_.FullName }
    foreach ($DSCSourceFilePath in $DSCSourceFilePaths) {
      Set-AzStorageBlobContent -File $DSCSourceFilePath -Blob $DSCSourceFilePath.Substring($DSCSourceFolder.length + 1) `
        -Container $StorageContainerName -Context $StorageAccount.Context -Force | Out-Null
    }
  }

  return Get-TemplateToken -SubscriptionId $AzureSubscription `
    -StorageAccountName $DeploymentLibrary.Outputs.item("storageAccount").value `
    -StorageContainerName $StorageContainerName `
    -TemplateFile $Template
}

Function Get-TemplateToken {
  [CmdLetBinding(DefaultParameterSetName = 'AllVariables')]
  Param (
    [string] $SubscriptionId,
    [string] $StorageAccountName,
    [string] $StorageContainerName,
    [string] $TemplateFile
  )

  Select-AzSubscription -Subscription $SubscriptionId | Out-Null

  $StorageAccount = (Get-AzStorageAccount | Where-Object { $_.StorageAccountName -eq $StorageAccountName })
  $artifactLocation = $StorageAccount.Context.BlobEndPoint + $StorageContainerName + '/'
  $sas = (New-AzStorageContainerSASToken -Container $StorageContainerName -Context $StorageAccount.Context -Permission r -ExpiryTime (Get-Date).AddHours(4))

  return ($artifactLocation + $TemplateFile + $sas)
}

Function Publish-SubscriptionTemplates {
  [CmdletBinding(DefaultParameterSetName = 'AllVariables')]
  Param (
    [string] $DeploymentName = ("Subscription" + '-' + ((Get-Date).ToUniversalTime()).ToString('MMdd-HHmm')),
    [string] $TemplateFile = '',
    [Hashtable] $TemplateParameters
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    $deployment = New-AzDeployment -Name $DeploymentName `
                                    -Location $TemplateParameters["ResourceLocation"] `
                                    -TemplateUri $TemplateFile `
                                    -TemplateParameterObject $TemplateParameters `
                                    -ErrorAction SilentlyContinue `
                                    -ErrorVariable ErrorMessages `
                                    -Verbose

    If ($ErrorMessages) {
      Write-Error "Template deployment returned the following errors: `n $(@(@($ErrorMessages) | ForEach-Object { $_.Exception.Message.TrimEnd("`r`n") }))"
      Throw
    }

    Return $deployment
  }
  End { }
}

Function Publish-ManagementGroupTemplates {
  [CmdletBinding(DefaultParameterSetName = 'AllVariables')]
  Param (
    [string] $DeploymentName = ("ManagementGroup" + '-' + ((Get-Date).ToUniversalTime()).ToString('MMdd-HHmm')),
    [string] $TemplateFile = '',
    [Hashtable] $TemplateParameters
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    $deployment = New-AzManagementGroupDeployment -Name $DeploymentName `
                                                  -Location "eastus" `
                                                  -ManagementGroupId $TemplateParameters["ManagementGroupId"] `
                                                  -TemplateUri $TemplateFile `
                                                  -TemplateParameterObject $TemplateParameters `
                                                  -ErrorAction SilentlyContinue `
                                                  -ErrorVariable ErrorMessages `
                                                  -Verbose

    If ($ErrorMessages) {
      Write-Error "Template deployment returned the following errors: `n $(@(@($ErrorMessages) | ForEach-Object { $_.Exception.Message.TrimEnd("`r`n") }))"
      Throw
    }

    Return $deployment
  }
  End { }
}

Function Publish-ResourceGroupTemplates {
  [CmdletBinding(DefaultParameterSetName = 'AllVariables')]
  Param(
    [string] [Parameter(Mandatory = $true)] $ResourceGroupLocation,
    [string] $ResourceGroupName,
    [switch] $UploadArtifacts,
    [string] $StorageAccountName,
    [string] $StorageContainerName = $ResourceGroupName.ToLowerInvariant() + '-stageartifacts',
    [string] $TemplateFile = 'InfrastructureMonitoring.json',
    [string] $ArtifactStagingDirectory,
    [string] $DSCSourceFolder,
    [string] $RunbookSourceFolder,
    [switch] $ValidateOnly,
    [Hashtable] $CustomParams,
    [string] $BuildTag,
    [string] $DeploymentMode = 'Incremental'
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState

    if (-not $StorageContainerName) {
      if ($ResourceGroupName.Length -gt 49) {
          $Prefix = $ResourceGroupName.Substring(0, 49)
      } else {
          $Prefix = $ResourceGroupName
      }
      $StorageContainerName = $Prefix + '-stageartifacts'
    }

    $StorageContainerName = $StorageContainerName.ToLowerInvariant().Replace(' ', '-').Replace('_', '-')
  }

  Process {
    $ErrorActionPreference = 'Stop'

    $OptionalParameters = New-Object -TypeName Hashtable
    $OptionalParameters = $OptionalParameters + $CustomParams

    if ($UploadArtifacts) {
      # Convert relative paths to absolute paths if needed
      $ArtifactStagingDirectory = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($PSScriptRoot, $ArtifactStagingDirectory))
      $DSCSourceFolder = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($PSScriptRoot, $DSCSourceFolder))
      $RunbookSourceFolder = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($PSScriptRoot, $RunbookSourceFolder))

      # Create DSC configuration archive
      if (Test-Path $DSCSourceFolder) {
        $DSCSourceFilePaths = @(Get-ChildItem $DSCSourceFolder -File -Filter '*.ps1' | ForEach-Object -Process { $_.FullName })
        foreach ($DSCSourceFilePath in $DSCSourceFilePaths) {
          $DSCArchiveFilePath = $DSCSourceFilePath.Substring(0, $DSCSourceFilePath.Length - 4) + '.zip'
          $temp = Publish-AzVMDscConfiguration $DSCSourceFilePath -OutputArchivePath $DSCArchiveFilePath -Force -Verbose
        }
      }

      # Create a storage account name if none was provided
      if ($StorageAccountName -eq '') {
        $StorageAccountName = 'stage' + ((Get-AzContext).Subscription.SubscriptionId).Replace('-', '').substring(0, 19)
      }

      $StorageAccount = (Get-AzStorageAccount | Where-Object { $_.StorageAccountName -eq $StorageAccountName })

      # Create the storage account if it doesn't already exist
      if ($null -eq $StorageAccount ) {
        $StorageAccount = New-AzStorageAccount -StorageAccountName $StorageAccountName -Type 'Standard_LRS' -ResourceGroupName $ResourceGroupName -Location "$ResourceGroupLocation"
      }

      # Generate the value for artifacts location if it is not provided in the parameter file
      if ( $null -eq $OptionalParameters["_artifactsLocation"]) {
        $OptionalParameters["_artifactsLocation"] = $StorageAccount.Context.BlobEndPoint + $StorageContainerName + '/'
      }

      # Copy files from the local storage staging location to the storage account container
      New-AzStorageContainer -Name $StorageContainerName -Context $StorageAccount.Context -ErrorAction SilentlyContinue | Out-Null

      $ArtifactFilePaths = Get-ChildItem $ArtifactStagingDirectory -Recurse -File | ForEach-Object -Process { $_.FullName }
      foreach ($SourcePath in $ArtifactFilePaths) {
        Set-AzStorageBlobContent -File $SourcePath -Blob $SourcePath.Substring($ArtifactStagingDirectory.length + 1) `
          -Container $StorageContainerName -Context $StorageAccount.Context -Force | Out-Null
      }

      # Copy Runbooks to storage account
      if (Test-Path $RunbookSourceFolder) {
        $RunbookSourceFilePaths = Get-ChildItem $RunbookSourceFolder -Recurse -File | ForEach-Object -Process { $_.FullName }
        foreach ($RunbookSourceFilePath in $RunbookSourceFilePaths) {
          Set-AzStorageBlobContent -File $RunbookSourceFilePath -Blob $RunbookSourceFilePath.Substring($RunbookSourceFolder.length + 1) `
            -Container $StorageContainerName -Context $StorageAccount.Context -Force | Out-Null
        }
      }

      # Generate a 4 hour SAS token for the artifacts location.
      if ($null -eq $OptionalParameters["_artifactsLocationSasToken"]) {
        $OptionalParameters["_artifactsLocationSasToken"] = ConvertTo-SecureString -AsPlainText -Force `
        (New-AzStorageContainerSASToken -Container $StorageContainerName -Context $StorageAccount.Context -Permission r -ExpiryTime (Get-Date).AddHours(4))
      }
    }

    $TemplateFile = Join-Path -Path $ArtifactStagingDirectory -ChildPath $TemplateFile
    if ($ValidateOnly) {
      $ErrorMessages = Format-ValidationOutput (Test-AzResourceGroupDeployment -ResourceGroupName $ResourceGroupName `
          -TemplateFile $TemplateFile `
          @OptionalParameters)
      if ($ErrorMessages) {
        Send-Event '', 'Validation returned the following errors:', @($ErrorMessages), '', 'Template is invalid.' -WriteOutput
      }
      else {
        Send-Event '', 'Template is valid.' -WriteOutput
      }
    }
    else {
      $ResourceGroupDeployment = New-AzResourceGroupDeployment -Name ((Get-ChildItem $TemplateFile).BaseName + '-' + ((Get-Date).ToUniversalTime()).ToString('MMdd-HHmm')) `
        -ResourceGroupName $ResourceGroupName `
        -TemplateFile $TemplateFile `
        @OptionalParameters `
        -Force `
        -Mode $DeploymentMode `
        -ErrorVariable ErrorMessages

      if ($ErrorMessages) {
        Send-Trace 'Template deployment returned the following errors:', @(@($ErrorMessages) | ForEach-Object { $_.Exception.Message.TrimEnd("`r`n") })
      }

      Return $ResourceGroupDeployment
    }
  }
  End {
  }
}

Export-ModuleMember -Function Publish-ResourceGroupTemplates, Publish-SubscriptionTemplates, Publish-TemplateLibraryTemplates, Publish-ManagementGroupTemplates, Get-TemplateToken
