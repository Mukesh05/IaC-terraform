
#Requires -Version 5.1
#Requires -Modules @{ ModuleName="Az.Resources"; ModuleVersion="1.5.0"; MaximumVersion='1.*' }
#Requires -Modules @{ ModuleName="Az.Blueprint"; ModuleVersion="0.2.10"; MaximumVersion='0.2.*' }
#Requires -Modules @{ ModuleName="Az.ManagedServiceIdentity"; ModuleVersion="0.7.3"; MaximumVersion='0.7.*' }
Using Module '.\MonitoringCommon.psm1'
Using Module '.\lib_pwsh\Helpers.psm1'

[CmdletBinding()]
Param(
  [string] $AzureTenantId = '',
  [string] $AzureSubscription = '',
  [string] $ResourceGroupName = '',
  [string] $ResourceGroupLocation,
  [string] $workspaceName = '',
  [string] $SourceFolder = $PSScriptRoot,
  [string] $Plugin = $null,
  [switch] $SkipAutoUpdate,
  [switch] $SkipUserCheck
)

Try {
  Import-Module -Name "$($PSScriptRoot)\lib_pwsh\Instrumentation.psm1" -Force
  Import-Module -Name "$($PSScriptRoot)\lib_pwsh\AzureGeneral.psm1" -Force
  Import-Module -Name "$($PSScriptRoot)\lib_pwsh\AzureSecurity.psm1" -Force
  Import-Module -Name "$($PSScriptRoot)\lib_pwsh\UserInterface.psm1" -Force
  Import-Module -Name "$($PSScriptRoot)\AzureResources.psm1" -Force
  Import-Module -Name "$($PSScriptRoot)\Monitoring.psm1" -Force

  Send-Event "Starting Install - Infrastructure Monitoring" -WriteOutput

  $SourceFolder = Resolve-Path $SourceFolder

  Connect-Azure -SkipUserCheck:$SkipUserCheck

  $controlParameters = [ClientInstall]::new()
  $controlParameters.AzureTenant.Id = $AzureTenantId
  $controlParameters.AzureSubscriptionId = $AzureSubscription
  $controlParameters.ResourceGroupName = $ResourceGroupName
  $controlParameters.ResourceGroupLocation = $ResourceGroupLocation
  $controlParameters.Environment = $Environment
  If ($PSBoundParameters.ContainsKey("Plugin")) {
    $controlParameters.Plugin = $Plugin
  }

  Do {
    Get-AzureTenant -controlParameters $controlParameters
    Get-AzureSubscription -controlParameters $controlParameters
    Get-ResourceGroupName -controlParameters $controlParameters
    Get-ResourceGroupLocation -controlParameters $controlParameters
    Test-ResourceGroup -controlParameters $controlParameters
    Get-Plugin -controlParameters $controlParameters -SourceFolder $SourceFolder
    Clear-Scrollback
  } Until ($controlParameters.IsValid())

  Install-AlertPack -SourceFolder $SourceFolder -PkgVersion $packageVersion -controlParameters $controlParameters
}
Catch {
  Send-Event -Message ("{0}`n{1}" -f $_.Exception.Message, $_.ScriptStackTrace) -WriteOutput

  Send-Error -Message "An error has occured:`n $_" -Exception $_.Exception

  $SessionKey = Get-SessionId
  Write-Host "An error has occured, please report Session Key : $($SessionKey), along with the message, to support to aid issue resolution."

  If ([Environment]::UserInteractive) {
    Read-Host "Press enter to continue and exit"
  }

  Exit
}