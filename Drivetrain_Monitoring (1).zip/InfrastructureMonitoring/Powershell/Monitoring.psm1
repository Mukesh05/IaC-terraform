#Requires -Version 5.1
#Requires -Modules Instrumentation, AzureGeneral, UserInterface, AzureResources

#, "Deploy-EventGridSubscription"

Using Module '.\lib_pwsh\Helpers.psm1'
Using Module '.\lib_pwsh\AzureGeneral.psm1'
Using Module '.\MonitoringCommon.psm1'
Using Module '.\Deploy-EventGridSubscription.psm1'

$blueprintVersion = '1.4.1'

Function Get-Architecture {
  [CmdletBinding()]
  Param (
    [MonitoringInstall] $controlParameters
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    If ($controlParameters.Architecture -eq '') {
      Show-Menu -Title "Select Installation Architecture" -Options @( 'Single Subscription', 'Management Group (Single Log Analytics Workspace)')
      $LocationSelection = [int](Read-Host "Please make a selection")
      $LocationSelection--
      $controlParameters.Architecture = @('Single', 'Multiple')[$LocationSelection]
      $controlParameters.ManualSelection = $true
    }
  }
}

Function Get-Scope {
  [CmdletBinding()]
  Param (
    [ControlParameters] $controlParameters,
    [switch] $addProviders = $False
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    Switch ( $controlParameters.Architecture ) {
      'Single' {
        If ($addProviders) {
          $Scope = "/subscriptions/$($controlParameters.AzureSubscriptionId)/providers/"
        }
        Else {
          $Scope = "/subscriptions/$($controlParameters.AzureSubscriptionId)"
        }
        break
      }
      'Multiple' {
        If ($addProviders) {
          $Scope = "/providers/Microsoft.Management/managementgroups/$($controlParameters.ManagementGroup)/providers/"
        }
        Else {
          $Scope = "/providers/Microsoft.Management/managementgroups/$($controlParameters.ManagementGroup)"
        }
        break
      }
      default {
        Throw '$controlParameters.Architecture not set to a valid value'
      }
    }

    return $Scope
  }
}

Function Get-ModuleParamId {
  [CmdletBinding()]
  Param (
    [ControlParameters] $controlParameters,
    [Object] $sub = $null
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    Switch ( $controlParameters.Architecture ) {
      'Single' {
        If ($null -ne $sub) {
          $idParam = @{
            Subscription = $sub.Id
          }
        }
        Else {
          $idParam = @{
            SubscriptionId = $controlParameters.AzureSubscriptionId
          }
        }
      }
      'Multiple' {
        If ($null -ne $sub) {
          $idParam = @{
            Subscription = $sub
          }
        }
        Else {
          $idParam = @{
            ManagementGroupId = $controlParameters.ManagementGroup
          }
        }
      }
    }

    return $idParam
  }
}

Function Get-ModuleParamName {
  [CmdletBinding()]
  Param (
    [ControlParameters] $controlParameters
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    Switch ( $controlParameters.Architecture ) {
      'Single' {
        $nameParam = @{
          SubscriptionId = $controlParameters.AzureSubscriptionId
        }
      }
      'Multiple' {
        $nameParam = @{
          ManagementGroupName = $controlParameters.ManagementGroup
        }
      }
    }

    return $nameParam
  }
}

Function Get-SecurityMonitoringEnabled {
  [CmdletBinding()]
  Param (
    [MonitoringInstall] $controlParameters
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    $commandLineValueNotSupplied = [string]::IsNullOrEmpty($controlParameters.EnableSecurity)

    If ($commandLineValueNotSupplied) {
      If ($controlParameters.SecurityCenterAlreadyEnabled) {
        $controlParameters.EnableSecurity = $true # already enabled in Azure so we insist that it stays enabled
      }
      else {
        # ask, since it's not enabled and we can enable it if required
        $EnableSecurity = Read-Host "Do you want to enable Security Center on All Subscriptions monitored, 'N' will not change the current settings (Y/N)"
        If ($EnableSecurity.ToUpperInvariant() -eq 'Y') {
          # if user's option is 'N', then defaults to current settings
          $controlParameters.EnableSecurity = $true
        }
        else {
          $controlParameters.EnableSecurity = $false
        }
        $controlParameters.ManualSelection = $true # confirm that user supplied detail via UX
      }
    }
    else {
      # value has been supplied on command line - check that it's valid concerning current azure state
      if (!$controlParameters.EnableSecurity -and $controlParameters.SecurityCenterAlreadyEnabled) {
        Throw "Unable to remove security center settings on a Monitoring upgrade. Please check your command line settings."
      }
    }
  }
}

Function Get-UninstallArchitecture {
  [CmdletBinding()]
  Param (
    [MonitoringUninstall] $controlParameters
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    Send-Trace -Message "Get-UninstallArchitecture"
    If ($controlParameters.Architecture -eq '') {
      Show-Menu -Title "Select Installation Architecture" -Options @( 'Single Subscription', 'Management Group (Single Log Analytics Workspace)')
      $LocationSelection = [int](Read-Host "Please make a selection")
      $LocationSelection--
      $controlParameters.Architecture = @('Single', 'Multiple')[$LocationSelection]
      $controlParameters.ManualSelection = $true
    }
  }
}

Function Get-Plugin {
  [CmdletBinding()]
  Param (
    [MonitoringInstall] $controlParameters,
    [string] $SourceFolder = '.',
    [string] $PkgVersion = 'testing'
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    Send-Trace -Message "Get-Plugin"
    try {
      $PluginFolder = Join-Path -Path $SourceFolder -ChildPath Plugins -Resolve -ErrorAction Stop
    }
    catch {
      throw "Critical Error: Unable to find alert plugins folder!"
      exit
    }
    If ($null -eq $controlParameters.Plugin) {
      Clear-Scrollback

      $arrPluginSet = @( Get-ChildItem -Path $PluginFolder -Name -Exclude "*diagnostics.json" )
      Show-Menu -Title "Select Plugin" -Options $arrPluginSet
      $PluginSelection = [int](Read-Host "Please make a selection, press Enter for no selection")
      If ($PluginSelection -gt 0) {
        $PluginSelection--
        $controlParameters.Plugin = $arrPluginSet[$PluginSelection]
        $controlParameters.ManualSelection = $true

        If ($controlParameters.Plugin) {
          If ($true -ne $arrPluginSet.Contains($controlParameters.Plugin)) {
            $controlParameters.Plugin = ''
            Write-Error "Plugin $($controlParameters.Plugin) does not exist"
          }

          $StorageAccount = (Get-AzStorageAccount | Where-Object { $_.StorageAccountName -eq $controlParameters.DeploymentStorageAccount })
          If ($null -ne $StorageAccount) {
            $StorageBlob = Get-AzStorageBlob -Blob $controlParameters.PlugIn -Container "NS-Monitoring-$($PkgVersion)".Replace('.', '-').ToLower() -Context $StorageAccount.Context -ErrorAction SilentlyContinue
            If ($null -ne $StorageBlob) {
              If ((Read-Host "There is already a version of $($controlParameters.PlugIn) saved, do you want to resuse this file [Y/N]").ToUpper() -eq 'Y') {
                $plugInFile = Join-Path -Path $PluginFolder -ChildPath $controlParameters.PlugIn
                Get-AzStorageBlobContent -Blob $controlParameters.PlugIn -Container "NS-Monitoring-$($PkgVersion)".Replace('.', '-').ToLower() -Destination $plugInFile -Context $StorageAccount.Context -Force
              }
            }
          }
        }
      }
      else {
        $controlParameters.ManualSelection = $true
      }
    }
  }
}

Function Get-InvalidRoleAssignment {
  [CmdletBinding()]
  Param (
    [ControlParameters] $controlParameters
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    Send-Trace "Checking for valid RBAC!"
    Set-AzContext -SubscriptionId $controlParameters.AzureSubscriptionId -TenantId $controlParameters.AzureTenant.Id | Out-Null
    $Scope = Get-Scope -controlParameters $controlParameters
    $roleAssignments = Get-AzRoleAssignment -Scope $Scope | Where-Object {$_.ObjectType.Equals("Unknown")}
    If($roleAssignments){
      foreach ($roleAssignment in $roleAssignments){
        If ($roleAssignment.ObjectType -like 'Unknown') {
          $RemoveUnknownIdentitySelection = Read-Host "Unknown identity present on scope: $($roleAssignment.Scope) .Do you want to Remove the unknown identity (Y/N)?"
          If ($RemoveUnknownIdentitySelection.ToUpperInvariant() -eq 'Y') {
            Remove-AzRoleAssignment -ObjectId $roleAssignment.ObjectId -RoleDefinitionName $roleAssignment.RoleDefinitionName -Scope $roleAssignment.Scope
          }
          Else{
            Throw "Terminating install due to a active invalid role assignment in the subscription scope, please remove any invalid entries and re-run the installation.`n See https://docs.microsoft.com/en-us/azure/role-based-access-control/troubleshooting#role-assignments-with-identity-not-found for further information."
          }
        }
      }
    }
    Else {
      #Added logic of when there isn't invalid RBAC on the subscription scope
      If ($controlParameters.ContinueScript -ne $true) {
        Send-Event "No invalid RBAC assignments found, continuing with the installation!" -WriteOutput
      }
    }
  }
}

Function Get-ResourceGroupName {
  [CmdletBinding()]
  Param (
    [ControlParameters] $controlParameters
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    Send-Trace -Message "Get-ResourceGroupName"
    Set-AzContext -Subscription $controlParameters.AzureSubscriptionId | Out-Null
    Send-Event "Checking for existing monitoring installation in subscription $((Get-AzContext).Subscription.Id)" -WriteOutput
    Send-Trace -Message "Auto Sensing Resource Group"
    $ResourceGroup = Get-AzResourceGroup -Tag @{ 'NS-DriveTrain' = $null }
    If (($ResourceGroup | Measure-Object).Count -eq 0) {
      # If there is no resource group with the NS-Drivetrain tag.
      If ($controlParameters.ResourceGroupName -eq '') {
        # If no resource group already existing, and not provided via the command line, then ask the user for the Resource Group to create.
        Send-Trace -Message "Requesting User Input for Resource Group"
        $controlParameters.ResourceGroupName = (Read-Host -Prompt "Please enter the name of the resource group")
        $controlParameters.ManualSelection = $true
      }
    }
    ElseIf (($ResourceGroup | Measure-Object).Count -eq 1) {
      # If there is an existing Resource Group with the NS-Drivetrain tag
      Send-Event "Found existing Monitoring installation in $($ResourceGroup.ResourceGroupName)!" -WriteOutput
      If (($controlParameters.ResourceGroupName -eq '') -or $controlParameters.ResourceGroupName -eq $ResourceGroup.ResourceGroupName) {
        # Check to see if the command line and discovered resource group is the same
        $controlParameters.ResourceGroupName = $ResourceGroup.ResourceGroupName
        If ($controlParameters.ResourceGroupLocation -eq '') {
          $controlParameters.ResourceGroupLocation = $ResourceGroup.Location
        }
      }
      Else {
        throw "The existing NS-DriveTrain resource group ($($ResourceGroup.ResourceGroupName)) and the one specified ($($controlParameters.ResourceGroupName)) do not match. Terminating"
      }
    }
    Else {
      throw "There is more than one group with a DriveTrain tag this is unsupported. Terminating"
    }
  }
}

Function Get-ResourceGroupLocation {
  [CmdletBinding()]
  Param (
    [MonitoringInstall] $controlParameters
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    If ($controlParameters.ResourceGroupLocation -eq '') {
      Show-Menu -Title "Select Location" -Options $controlParameters.SupportedRegions
      $LocationSelection = [int](Read-Host "Please make a selection")
      $LocationSelection--
      $controlParameters.ResourceGroupLocation = ($controlParameters.SupportedRegions[$LocationSelection]).ToLower()
      $controlParameters.ManualSelection = $true
    }
  }
}


Function Get-RGPermissibleDrivetrainOrNot {
  param (
    [string]$ResourceGroupName
  )

  #Let's check whether the Resource Group Actually Exists

  try {
    $rg = Get-AzResourceGroup -Name $ResourceGroupName -ErrorAction Stop
  }
  catch {
    throw "Unable to find resource group called $ResourceGroupName in $((Get-AzContext).Subscription.Name): $_"
  }

  #Any resource group dedicated to Log Analytics / Monitoring should only have certain types of resources
  $PermittedTypes = @(
    "microsoft.alertsmanagement/smartDetectorAlertRules",
    "Microsoft.Automation/automationAccounts",
    "Microsoft.Automation/automationAccounts/runbooks",
    "Microsoft.EventGrid/systemTopics",
    "microsoft.insights/actiongroups",
    "Microsoft.Insights/actiongroups",
    "Microsoft.Insights/activityLogAlerts",
    "microsoft.insights/components",
    "Microsoft.Insights/metricalerts",
    "Microsoft.Insights/scheduledqueryrules",
    "Microsoft.KeyVault/vaults",
    "Microsoft.ManagedIdentity/userAssignedIdentities",
    "Microsoft.OperationalInsights/workspaces",
    "Microsoft.OperationsManagement/solutions",
    "Microsoft.Storage/storageAccounts"
  )

  #Lets check to see whether the RG supplied only contains resources of the permitted types

  $resources = $(Get-AzResource -ResourceGroupName $rg.ResourceGroupName)
  #We only care about type
  $resources = $resources.Type | Select-Object -Unique

  $results = $resources | Where-Object { $PermittedTypes -notcontains $_ }

  if ($results) {
    #We have found resources of a non-permitted type in the RG
    return $false
  }
  else {
    #All resources in the RG are of the correct type
    return $true
  }
}

Function Get-Environment {
  [CmdletBinding()]
  Param (
    [ControlParameters] $controlParameters
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    while ($controlParameters.Environment -eq '') {
      Show-Menu -Title "Select Environment Type" -Options @( 'Dev', 'Test', 'Prod')
      $EnvironmentSelection = [int](Read-Host "Please make a selection")
      $EnvironmentSelection--
      $controlParameters.Environment = @('Dev', 'Test', 'Prod')[$EnvironmentSelection]
      $controlParameters.ManualSelection = $true
    }
  }
}

Function Get-LogAnalyticsRetentionChanged {
  [CmdletBinding()]
  Param(
    [ControlParameters] $controlParameters,
    [Hashtable]$retentionGuide = @{ "DEV" = 31; "TEST" = 31; "QA" = 31; "PROD" = 365 }
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    $retentionDays = $retentionGuide[$controlParameters.Environment.ToUpperInvariant()]
    $controlParameters.WorkspaceRetentionDays = $retentionDays
    If ([string]::IsNullorEmpty($controlParameters.WorkspaceName)) {
      $controlParameters.ChangeRetentionDays = $true
      return
    }
    #Get Log Analytics Workspace
    Send-Trace "Looking to see if there is a current log analytics workspace..."
    $workspace = Get-AzOperationalInsightsWorkspace -ResourceGroupName $controlParameters.ResourceGroupName -Name $controlParameters.WorkspaceName -ErrorAction SilentlyContinue
    #store the environment options and values into retention $retentionDays
    $controlParameters.ChangeRetentionDays = $true

    #If the workspace isn't empty then make a the below statement
    If ($null -ne $workspace) {
      Send-Trace "Found current log analytics workspace $($workspace.Name) in $($workspace.ResourceGroupName)!"
      #Get the retention period from the workspace
      $workspaceRetentionValue = $workspace.retentionInDays
      Send-Trace "Current workspace retains data for $workspaceRetentionValue days"
      clear-scrollback

      Send-Trace "Deployment settings would set data retention for $retentionDays days."

      #check if the existing set retention days are not the same as expected retention days and act accordingly
      If ($retentionDays -gt $workspaceRetentionValue) {
        #Continue with the deployment
        $increaseRetentionDays = Read-Host "Do you want to increase the number of days from $($workspaceRetentionValue) to $($retentionDays)?, Increasing retention days could increase the cost. 'Y'/'N'"
        #If they aren't then ask user if they can be changed
        If ($increaseRetentionDays.ToUpperInvariant() -eq 'Y') {
            Send-Trace "New workspace retention set to $($retentionDays)."
            #$controlParameters.ChangeRetentionDays = $true
            #$controlParameters.WorkspaceRetentionDays = $retentionDays
        }
        else
        {
            Send-Trace "New workspace retention already set to $($workspaceRetentionValue)."
            $controlParameters.ChangeRetentionDays = $true
            $controlParameters.WorkspaceRetentionDays = $workspaceRetentionValue
        }
      }
      ElseIf ($retentionDays -eq $workspaceRetentionValue) {
        Send-Trace "New workspace retention setting of $retentionDays is greater or equal to the current $workspaceRetentionValue days."
        Write-Host "workspace retention setting of $($retentionDays)"
        #$controlParameters.ChangeRetentionDays = $true
        #$controlParameters.WorkspaceRetentionDays = $retentionDays
      }
      ElseIf ($retentionDays -le $workspaceRetentionValue) {
        #If not, then ask the below the question
        $ChangeRetentionDays = Read-Host "Do you want to reduce the number of days to retain logs from $($workspaceRetentionValue) to $($retentionDays)? 'Y'/'N'"
        #If they aren't then ask user if they can be changed
        If ($ChangeRetentionDays.ToUpperInvariant() -eq 'N') {
          Write-Host "By accepting to keep the number of days to retain logs to $($workspaceRetentionValue), you are accepting to incur the increased cost of storage."
          #If user says No, then assign the below parameter to false so the install will be stopped
          $controlParameters.ChangeRetentionDays = $false
          $controlParameters.WorkspaceRetentionDays = $workspaceRetentionValue
          #Warn the user that the retention period will need to be changed
          #throw "You will need to change the log retention period in days for the install to take place"
        }
        else {
          Write-Host "By accepting to reduce the number of days to retain logs from $($workspaceRetentionValue) to $($retentionDays), please be aware that there is risk that some of the workspace data might be lost"
          #otherwise carry on with the install if the
          #$controlParameters.ChangeRetentionDays = $true
          #$controlParameters.WorkspaceRetentionDays = $retentionDays
        }
        $controlParameters.ManualSelection = $true
      }
    }
  }
}

Function Get-ManagementGroup {
  [CmdletBinding()]
  Param (
    [ControlParameters] $controlParameters
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    Send-Trace -Message "Get-ManagementGroup"
    If ($controlParameters.Architecture -eq 'Multiple' -and $controlParameters.ManagementGroup -eq '') {
      Set-AzContext -Subscription $controlParameters.AzureSubscriptionId
      $managementGroups = Get-AzManagementGroup
      Show-Menu -Title "Select Management Group" -Options $managementGroups.DisplayName
      $groupSelection = [int](Read-Host "Please make a selection")
      $groupSelection--
      $controlParameters.ManagementGroup = $managementGroups[$groupSelection].Name
      $controlParameters.ManualSelection = $true
    }
  }
}

Function Get-ServiceNowToken {
  [CmdletBinding()]
  Param (
    [ControlParameters] $controlParameters
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    If ($controlParameters.Environment -eq 'Prod' -And $controlParameters.SNowToken -eq '') {
      $controlParameters.SNowToken = (Read-Host "Enter the service now token")
      $controlParameters.ManualSelection = $true
    }
  }
}

Function Publish-Policies {
  [CmdletBinding()]
  Param (
    [string] $SourceFolder = '.',
    [string] $PkgVersion = '',
    [MonitoringInstall] $controlParameters
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {

    $Scope = Get-Scope -controlParameters $controlParameters -addProviders
    $idParam = Get-ModuleParamName -controlParameters $controlParameters
    $PolicyFolder = Join-Path -Path $SourceFolder -ChildPath Policies\Policies -Resolve
    $Policies = Get-ChildItem -Recurse -Path $PolicyFolder -Include 'diagnostics*.json'

    ForEach ($policy In $policies) {
      $json = Get-Content $policy.FullName | ConvertFrom-Json
      $metadata = "{""category"": ""DriveTrain"", ""product"": ""New Signature DriveTrain""}"
      New-AzPolicyDefinition -Name $json.properties.name `
        -Description $json.properties.description `
        -DisplayName $json.properties.displayName `
        -Mode $json.properties.Mode `
        -Metadata $metadata `
        @idParam `
        -Policy (ConvertTo-Json $json.properties.policyRule -Depth 20).ToString() `
        -Parameter (ConvertTo-Json $json.properties.parameters -Depth 20).ToString() | Out-Null
    }

    $PolicySetFolder = Join-Path -Path $SourceFolder -ChildPath Policies\Initiatives -Resolve
    $PolicieSets = Get-ChildItem -Recurse -Path $PolicySetFolder -Include 'diagnostics.json'
    ForEach ($policy In $PolicieSets) {
      $json = Get-Content $policy.FullName | ConvertFrom-Json
      $metadata = "{""category"": ""DriveTrain"", ""product"": ""New Signature DriveTrain""}"
      New-AzPolicySetDefinition -Name $json.properties.name `
        -Description $json.properties.description `
        -Metadata $metadata `
        -PolicyDefinition (ConvertTo-Json $json.policyDefinitions -Depth 20).Replace("/providers/", $Scope).ToString() `
        @idParam `
        -Parameter (ConvertTo-Json $json.properties.parameters -Depth 20).ToString() | Out-Null
    }
  }
}

Function Install {
  [CmdletBinding()]
  Param (
    [string] $SourceFolder = '.',
    [string] $PkgVersion = '',
    [MonitoringInstall] $controlParameters,
    [bool] $alertsPublish = $true
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet `
      -SessionState $ExecutionContext.SessionState
  }
  Process {
    Clear-Scrollback
    $controlParameters.ShowSummary()

    Send-Event -Message "Installing Monitoring" -WriteOutput

    Join-Path -Path $SourceFolder -ChildPath 'ARM' -Resolve -OutVariable ArtifactStagingDirectory | Out-Null
    Join-Path -Path $SourceFolder -ChildPath 'ARM' -Resolve -OutVariable DSCSourceFolder | Out-Null
    Join-Path -Path $SourceFolder -ChildPath 'Runbook' -Resolve -OutVariable RunbookSourceFolder | Out-Null
    Join-Path -Path $SourceFolder -ChildPath 'Plugins' -Resolve -OutVariable PluginsFolder | Out-Null

    Set-AzContext -Subscription $controlParameters.AzureSubscriptionId | Out-Null
    Set-ResourceProviders -ResourceProviders @( "Microsoft.OperationsManagement",
      "Microsoft.Resources",
      "Microsoft.Security",
      "Microsoft.ManagedIdentity",
      "Microsoft.Authorization",
      "Microsoft.KeyVault",
      "Microsoft.Storage",
      "Microsoft.EventGrid",
      "Microsoft.Automation",
      "Microsoft.OperationalInsights",
      "Microsoft.AlertsManagement",
      "Microsoft.Insights",
      "Microsoft.Blueprint" )

    Send-Event -Message "Cleaning up workspace datasources..." -WriteOutput
    # Remove datasources = See https://dev.azure.com/newsigcode/DriveTrain/_boards/board/t/Platform%20Team/Stories/?workitem=24552
    $workspace = Get-AzResource -ResourceGroupName $controlParameters.ResourceGroupName -ResourceType "Microsoft.OperationalInsights/workspaces" -ErrorAction SilentlyContinue
    If ($null -ne $workspace ) {
      Foreach ($kind In @("AzureActivityLog", "CustomLog", "LinuxPerformanceObject", "LinuxSyslog", "WindowsEvent", "WindowsPerformanceCounter", "ApplicationInsights")) {
        Foreach ($i In $(Get-AzOperationalInsightsDataSource -ResourceGroupName $controlParameters.ResourceGroupName -WorkspaceName $controlParameters.WorkspaceName -Kind $kind -ErrorAction SilentlyContinue)) {
          Remove-AzOperationalInsightsDataSource -ResourceGroupName $controlParameters.ResourceGroupName -WorkspaceName $controlParameters.WorkspaceName -Name $i.name -Force | Out-Null
        }
      }
    }

    # This is removing configuration from Infrastructure Monitoring 1.1.x that has been replaced.
    Get-AzPolicyAssignment | Where-Object { $_.Properties.displayName -eq 'ASSIGNED NS-DriveTrainMonitoring' } | ForEach-Object {
      Remove-AzPolicyAssignment -Name $_.Name -Scope "/subscriptions/$($_.SubscriptionId)" | Out-Null
    }

    Get-AzPolicyAssignment | Where-Object { $_.Properties.displayName -eq 'ASSIGNED NS-DriveTrainManagement' } | ForEach-Object {
      Remove-AzPolicyAssignment -Name $_.Name -Scope "/subscriptions/$($_.SubscriptionId)" | Out-Null
    }

    Get-AzPolicySetDefinition | Where-Object { $_.Properties.metadata.product -Like 'New Signature DriveTrain' -and $_.Name -ne 'DriveTrain Diagnostic Policies' } | ForEach-Object {
      Remove-AzPolicySetDefinition -Id $_.PolicySetDefinitionId -Force | Out-Null
    }

    Get-AzPolicyDefinition | Where-Object { $_.Properties.metadata.product -Like 'New Signature DriveTrain' } | ForEach-Object {
      Remove-AzPolicyDefinition -Id $_.PolicyDefinitionId -Force -ErrorAction SilentlyContinue | Out-Null
    }

    Remove-AzPolicyDefinition -Name 'Deploy default Log Analytics VM Extension for Linux VMs' -Force | Out-Null

    $Scope = Get-Scope -controlParameters $controlParameters
    $nameParam = Get-ModuleParamName -controlParameters $controlParameters
    $idParam = Get-ModuleParamId -controlParameters $controlParameters

    Remove-AutomationAccountDiagnosticSettings
    Get-AzPolicyAssignment -Scope $Scope -Name "DriveTrainDiagPolicies" -ErrorAction SilentlyContinue | Remove-AzPolicyAssignment | Out-Null
    #end removing 1.1.x configuration

    # A default resource group is created in 1.2.x, this removes the resource group and the resources are re-created later.
    If ((Get-AzResource -ResourceGroupName "DEFAULT-EVENTGRID" -ErrorAction SilentlyContinue | Measure-Object).Count -eq 1) {
      Get-AzResourceGroup -Name "DEFAULT-EVENTGRID" | Remove-AzResourceGroup -Force
    }

    Remove-AutomationAccountJobSchedule

    Send-Event -Message "Publishing diagnostic policies..." -WriteOutput
    Publish-Policies -SourceFolder $SourceFolder -ControlParameters $controlParameters

    Send-Event -Message "Creating / updating resource group and core resources..." -WriteOutput
    Set-ResourceGroup -Name $controlParameters.ResourceGroupName `
      -Location $controlParameters.ResourceGroupLocation `
      -BuildTag $PkgVersion

    Send-Event -Message "Deploying bootstrap storage acccount for linked ARM deployments..." -WriteOutput
    $ArmDeploymentParameters = New-Object -TypeName Hashtable
    $ArmDeploymentParameters.Add("ResourceLocation", $controlParameters.ResourceGroupLocation.ToLower())
    $ArmDeployment = Publish-ResourceGroupTemplates -ResourceGroupName $controlParameters.ResourceGroupName `
      -ResourceGroupLocation $controlParameters.ResourceGroupLocation `
      -StorageAccountName $controlParameters.DeploymentStorageAccount `
      -StorageContainerName "NS-Monitoring-$($PkgVersion)".Replace('.', '-') `
      -TemplateFile "DeploymentLibrary.json" `
      -CustomParams $ArmDeploymentParameters `
      -ArtifactStagingDirectory $ArtifactStagingDirectory `
      -BuildTag $PkgVersion

    $controlParameters.DeploymentStorageAccount = $ArmDeployment.Outputs.item("storageAccount").value
    $controlParameters.DeploymentKeyVault = $ArmDeployment.Outputs.item("keyVault").value

      Send-Event -Message "Constructing parameters for core Azure ARM template..." -WriteOutput

    $ArmDeploymentParameters = New-Object -TypeName Hashtable
    $ArmDeploymentParameters['Environment'] = $controlParameters.Environment.ToUpper()
    $ArmDeploymentParameters['ResourceLocation'] = $controlParameters.ResourceGroupLocation.ToLower()

    If ($controlParameters.SNowToken -ne '') {
      $ArmDeploymentParameters['serviceNowToken'] = $controlParameters.SNowToken
    }

    If ($controlParameters.WorkspaceName -ne '') {
      $ArmDeploymentParameters['workspaceName'] = $controlParameters.WorkspaceName
    }

    If ($controlParameters.AppInsightsName -ne '') {
      $ArmDeploymentParameters['appInsightName'] = $controlParameters.AppInsightsName
    }

    If ($controlParameters.AutomationAccountName -ne '') {
      $ArmDeploymentParameters['AutomationAccountName'] = $controlParameters.AutomationAccountName
    }

    If ($controlParameters.EnableCAS) {
      $ArmDeploymentParameters['actionGroupUseCAS'] = $controlParameters.EnableCAS
    }

    If ($controlParameters.AlertEmailName -ne '') {
      $ArmDeploymentParameters['actionGroupEmailName'] = $controlParameters.AlertEmailName
    }

    If ($controlParameters.AlertEmailAddress -ne '') {
      $ArmDeploymentParameters['actionGroupEmail'] = $controlParameters.AlertEmailAddress
    }

    If ($controlParameters.WorkspaceRetentionDays -ne '') {
      $ArmDeploymentParameters['workspaceRetentionDays'] = $controlParameters.WorkspaceRetentionDays
    }

    If ($controlParameters.ManagementGroup -ne '') {
      $ArmDeploymentParameters['managementGroupName'] = $controlParameters.ManagementGroup
    }

    $ArmDeploymentParameters.Add("enableSecurityCenter", $controlParameters.EnableSecurity)

    Send-Event "Deploying core resources..." -WriteOutput
    $armDeployment = Publish-ResourceGroupTemplates -ResourceGroupName $controlParameters.ResourceGroupName `
      -ResourceGroupLocation $controlParameters.ResourceGroupLocation `
      -StorageAccountName $controlParameters.DeploymentStorageAccount `
      -StorageContainerName "NS-Monitoring-$($PkgVersion)".Replace('.', '-') `
      -TemplateFile "InfrastructureMonitoring.json" `
      -CustomParams $ArmDeploymentParameters `
      -ArtifactStagingDirectory $ArtifactStagingDirectory `
      -DSCSourceFolder $DSCSourceFolder `
      -RunbookSourceFolder $RunbookSourceFolder `
      -UploadArtifacts `
      -BuildTag $PkgVersion

    $publishresults = New-Object -TypeName Hashtable
    $publishresults.logAnalytics = $armDeployment.Outputs.item("logAnalytics").value
    $publishresults.workspaceID = $armDeployment.Outputs.item("workspaceID").value
    $publishresults.automationAccountName = $armDeployment.Outputs.item("automationAccountName").value
    $publishresults.actionGroupResourceID = $armDeployment.Outputs.item("actionGroupResourceID").value
    $publishresults.workspaceName = $armDeployment.Outputs.item("workspaceName").value
    $publishresults.appInsightName = $armDeployment.Outputs.item("appInsightName").value
    $publishresults.ResourceGroupName = $armDeployment.ResourceGroupName
    $publishresults.ResourceGroupLocation = $armDeployment.ResourceGroupLocation
    $publishresults.ArtifactStagingDirectory = $ArtifactStagingDirectory
    $publishresults.StorageAccount = $armDeployment.Outputs.item("storageAccount").value
    $userAssignedIdentityResourceId = $armDeployment.Outputs.item("userAssignedIdentityResourceId").value

    $controlParameters.WorkspaceName = $publishresults['workspaceName']

    $StorageAccount = Get-AzStorageAccount -Name $publishresults['StorageAccount'] -ResourceGroup $controlParameters.ResourceGroupName
    $SAS = (New-AzStorageAccountSASToken -Service Blob, File, Table, Queue `
        -ResourceType Service, Container, Object `
        -Permission "racwdlup" `
        -Context $StorageAccount.Context `
        -ExpiryTime (Get-Date).AddYears(5) `
    ).substring(1)

    $ArmEnvironmentParameters = New-Object -TypeName Hashtable
    $ArmEnvironmentParameters.Add("principalId", $armDeployment.Outputs.item("userAssignedIdentity").value)
    $ArmEnvironmentParameters.Add("ResourceLocation", $controlParameters.ResourceGroupLocation.ToLower())
    $ArmEnvironmentParameters.Add("logAnalyticsId", $publishresults['workspaceID'])
    $ArmEnvironmentParameters.Add("storageAccountId", $publishresults['StorageAccount'])
    $ArmEnvironmentParameters.Add("storageAccountSAS", $SAS)

    If ($null -ne $controlParameters.Plugin -And $controlParameters.PlugIn -ne '') {
      "Deploying selected plugin alerts..."
      $ClientInstall = [ClientInstall]::new()
      $ClientInstall.AzureTenant.Id = $controlParameters.AzureTenant.Id
      $ClientInstall.AzureSubscriptionId = $controlParameters.AzureSubscriptionId
      $ClientInstall.WorkspaceName = $controlParameters.WorkspaceName
      $ClientInstall.ResourceGroupName = $controlParameters.ResourceGroupName
      $ClientInstall.ResourceGroupLocation = $controlParameters.ResourceGroupLocation
      $ClientInstall.DeploymentStorageAccount = $controlParameters.DeploymentStorageAccount
      $ClientInstall.Environment = $controlParameters.Environment
      $ClientInstall.Plugin = $controlParameters.Plugin
      $ClientInstall.AppInsightsName = $publishresults.appInsightName
      $ClientInstall.actionGroupResourceID = $publishresults.actionGroupResourceID
      Install-AlertPack -SourceFolder $SourceFolder -PkgVersion $packageVersion -controlParameters $ClientInstall
    }


    Send-Event "Checking policies have published successfully..."
    $retries = 5
    $secondsDelay = 60
    $retrycount = 0
    $completed = $false

    While (-not $completed) {
      $policyAssignment = Get-AzPolicySetDefinition -Name "DriveTrain Diagnostic Policies" @nameParam -ErrorVariable errVar -ErrorAction "SilentlyContinue"
      $completed = ($errVar.Count -eq 0)
      If (-not $completed) {
        If ($retrycount -ge $retries) {
          Throw "`n There has been an issue retrieving the policy initiative, please review and restart the installer.`n"
        }
        $retrycount++
        Start-Sleep $secondsDelay
      }
    }

    # TODO - refactor me !!!!!!!
    $stamp = [System.DateTime]::UtcNow.ToString('yyyyMMddHHmmss') # Timstamp String for naming uniqueness

    $subscriptionArray = @( )
    Switch ( $controlParameters.Architecture ) {
      'Single' {
        Send-Event "Granting user assigned identity rights assignment on single subscription..." -WriteOutput

        New-AzRoleAssignment `
          -ObjectId $ArmEnvironmentParameters['principalId'] `
          -Scope (Get-AzContext).Subscription.Id `
          -RoleDefinitionName Contributor `
          -ErrorVariable $roleErr `
          -ErrorAction SilentlyContinue `
          -Verbose

        #Handle errors, ignoring errors for already existing assignment
        if (($null -ne $roleErr) -and ($roleErr -notmatch "The role assignment already exists.")) {
          throw "Issue assigning rights for user-assigned identity!"
        }

        Send-Event "Assigning policy to single subscription..." -WriteOutput

        $PolicyParams = New-Object -TypeName Hashtable
        $PolicyParams.Add("logAnalytics", $publishresults['workspaceID'])
        $PolicyParams.Add("storageAccount", $publishresults['StorageAccount'])
        $PolicyParams.Add("storageAccountSAS", $SAS)

        $policyDefinition = Get-AzPolicySetDefinition `
          -Name "DriveTrain Diagnostic Policies" `
          -SubscriptionId $((Get-AzContext).Subscription.Id)

        New-AzPolicyAssignment `
          -Name DriveTrainDiagPolicies `
          -PolicySetDefinition $policyDefinition `
          -DisplayName "ASSIGNED DriveTrain Diagnostic Policies" `
          -Description "New Signature Drivetrain Policy Remediation" `
          -AssignIdentity `
          -Location uksouth `
          -Scope "/subscriptions/$((Get-AzContext).Subscription.Id)" `
          -PolicyParameterObject $PolicyParams `
          -ErrorAction Stop `
          -WarningAction SilentlyContinue

        $subscriptionArray += Get-AzSubscription -SubscriptionId $controlParameters.AzureSubscriptionId
      }
      'Multiple' {

        Send-Event "Granting user assigned identity rights assignment on single subscription..." -WriteOutput

        New-AzRoleAssignment `
          -ObjectId $ArmEnvironmentParameters['principalId'] `
          -Scope "/providers/Microsoft.Management/managementGroups/$($controlParameters.ManagementGroup)" `
          -RoleDefinitionName Contributor `
          -ErrorVariable $roleErr `
          -ErrorAction SilentlyContinue `
          -Verbose

        #Handle errors, ignoring errors for already existing assignment
        if (($null -ne $roleErr) -and ($roleErr -notmatch "The role assignment already exists.")) {
          throw "Issue assigning rights for user-assigned identity!"
        }

        Send-Event "Assigning policy to management group..." -WriteOutput

        $PolicyParams = New-Object -TypeName Hashtable
        $PolicyParams.Add("logAnalytics", $publishresults['workspaceID'])
        $PolicyParams.Add("storageAccount", $publishresults['StorageAccount'])
        $PolicyParams.Add("storageAccountSAS", $SAS)

        $policyDefinition = Get-AzPolicySetDefinition `
          -Name "DriveTrain Diagnostic Policies" `
          -ManagementGroupName $($controlParameters.ManagementGroup)

        New-AzPolicyAssignment `
          -Name DriveTrainDiagPolicies `
          -PolicySetDefinition $policyDefinition `
          -DisplayName "ASSIGNED DriveTrain Diagnostic Policies" `
          -Description "New Signature Drivetrain Policy Remediation" `
          -AssignIdentity `
          -Location uksouth `
          -Scope "/providers/Microsoft.Management/managementGroups/$($controlParameters.ManagementGroup)" `
          -PolicyParameterObject $PolicyParams `
          -ErrorAction Stop `
          -WarningAction SilentlyContinue

        $subs = Get-ManagementGroupChildNodes -ManagementGroupId $controlParameters.ManagementGroup -Subscriptions

        #Construct the subscription array for Blueprint assignment later on
        $subscriptionArray = @( )
        ForEach ($sub In $subs) {
          $subscriptionArray += $sub.name
        }
      }
    }

    $retries = 5
    $secondsDelay = 60
    $retrycount = 0
    $completed = $false

    While (-not $completed) {
      Send-Event "Confirming policy has been assigned..."
      $policyAssignment = Get-AzPolicyAssignment -Name "DriveTrainDiagPolicies" -Scope $Scope -ErrorVariable errVar -ErrorAction "SilentlyContinue"
      $completed = ($errVar.Count -eq 0)
      If (-not $completed) {
        If ($retrycount -ge $retries) {
          Throw "There has been an issue retrieving the policy assignment, please review and restart the installer."
        }
        $retrycount++
        Start-Sleep $secondsDelay
      }
    }

    $completed = $false
    While (-not $completed) {
      Send-Event "Assigning rights to policy assignment to enable remediation..."
      New-AzRoleAssignment -Scope $Scope -ObjectId $policyAssignment.Identity.PrincipalId -RoleDefinitionName "Contributor" -ErrorVariable errVar -ErrorAction "SilentlyContinue"
      $completed = ($errVar.Count -eq 0)
      If (-not $completed) {
        If ($retrycount -ge $retries) {
          Send-Event -Message "There has been an issue assigning the Managed Identity with the role of Contributor for the policies, please complete manually." -WriteOutput
          break
        }
        $retrycount++
        Start-Sleep $secondsDelay
      }
    }

    Send-Event -Message "Assigning Contributor role to Automation Account MSI..." -WriteOutput

    $principalID = (Get-AzResource -Name $publishresults.automationAccountName -ResourceType Microsoft.Automation/automationAccounts -ApiVersion "2020-01-13-preview" -ResourceGroupName $controlParameters.ResourceGroupName).Identity.PrincipalId
    $isManagementGroupScope = ![string]::IsNullOrEmpty($controlParameters.ManagementGroup)
    if($isManagementGroupScope)
    {
      New-AzRoleAssignment `
          -ObjectId $principalID `
          -RoleDefinitionName Contributor `
          -Scope "/providers/Microsoft.Management/managementGroups/$($controlParameters.ManagementGroup)"
    }
    else {
      New-AzRoleAssignment `
          -ObjectId $principalID `
          -RoleDefinitionName Contributor `
          -Scope "/subscriptions/$($controlParameters.AzureSubscriptionId)"
    }

    Send-Event -Message "Deploying Blueprints..." -WriteOutput

    #Check if the blueprint already exists
    $blueprint = Get-AzBlueprint @idParam -Name "NSMonitoring" -ErrorVariable ErrorOutput -ErrorAction SilentlyContinue
    $publishBlueprint = $false

    #If the blueprint doesn't exist, flag that it needs to be published
    If ($ErrorOutput -eq '') {
      $publishBlueprint = $true
    }
    Else {
      If ($null -eq $blueprint.Versions) {
        $publishBlueprint = $true
      }
      Else {
        $publishBlueprint = (-not $blueprint.Versions.Contains($blueprintVersion))
      }
    }

    If ($publishBlueprint) {
      Import-AzBlueprintWithArtifact -Name "NSMonitoring" `
        @idParam `
        -InputPath (Join-Path -Path $SourceFolder -ChildPath "Blueprint") `
        -Force

      Get-AzBlueprint -Name "NSMonitoring" `
        @idParam `
        -OutVariable blueprint

      Publish-AzBlueprint -Blueprint $blueprint[0] `
        -Version $blueprintVersion | Out-Null

      start-sleep 60
    }

    # Generates the Uri that will be used to call an automation account runbook when new resources are created
    $Uri = "https://management.azure.com/subscriptions/{0}/resourceGroups/{1}/providers/Microsoft.Automation/automationAccounts/{2}/webhooks/generateUri?api-version=2015-10-31" -f $controlParameters.AzureSubscriptionId, $controlParameters.ResourceGroupName, $publishresults.automationAccountName
    $webhookURI = Invoke-PostRestMethod -Uri $Uri

    # Clean up any existing webhooks as you cannot modify an existing webhook.
    $Uri = "https://management.azure.com/subscriptions/{0}/resourceGroups/{1}/providers/Microsoft.Automation/automationAccounts/{2}/webhooks/{3}?api-version=2015-10-31" -f $controlParameters.AzureSubscriptionId, $controlParameters.ResourceGroupName, $publishresults.automationAccountName, "TestWebhook"
    Invoke-DeleteRestMethod -Uri $Uri

    If ($controlParameters.Environment -ne 'DIAG') {
      # Creates the webhook and attached it to the runbook.
      $body = @{
        "name"       = "TestWebhook";
        "properties" = @{
          "isEnabled"  = $true;
          "uri"        = $webhookURI[0];
          "expiryTime" = ([DateTime](get-date).addyears(2)).ToString('yyyy-MM-ddTHH:mm:ssZ');
          "runbook"    = @{
            "name" = "CMDBActiveSynch";
          }
        }
      } | ConvertTo-Json

      $Uri = "https://management.azure.com/subscriptions/{0}/resourceGroups/{1}/providers/Microsoft.Automation/automationAccounts/{2}/webhooks/{3}?api-version=2015-10-31" -f $controlParameters.AzureSubscriptionId, $controlParameters.ResourceGroupName, $publishresults.automationAccountName, "TestWebhook"
      Invoke-PutRestMethod -Uri $Uri -Body $body
    }

    #Assign the Blueprint to subscriptions
    $blueprintparams = New-Object -TypeName Hashtable
    $blueprintparams.Add("actionGroupResourceId", "/subscriptions/$($controlParameters.AzureSubscriptionId)/resourcegroups/$($publishresults.ResourceGroupName)/providers/microsoft.insights/actiongroups/snow")
    $blueprintparams.Add("logAnalyticsWorkspaceId", $publishresults.workspaceID)
    $blueprintparams.Add("WebhookUri", $webhookURI[0])
    $blueprintparams.Add("enableSecurityCenter", $controlParameters.EnableSecurity)
    $blueprintparams.Add("Environment", $controlParameters.Environment.ToUpper())
    $bpRGParameters = @{"RG-Monitoring" = @{name = "$($controlParameters.ResourceGroupName)"; location = "$($controlParameters.ResourceGroupLocation)" } }

    Send-Event "Assigning Blueprints..."
    ForEach ($sub In $subscriptionArray) {
      $idParam = Get-ModuleParamId -controlParameters $controlParameters -sub $sub
      Set-AzContext @idParam | Out-Null
      Set-ResourceProviders -ResourceProviders @( "Microsoft.Blueprint" )
      If (Get-AzBlueprintAssignment -Name "NSMonitoring" -ErrorAction SilentlyContinue) {
        Set-AzBlueprintAssignment -Name "NSMonitoring" `
          @idParam `
          -Blueprint $blueprint[0] `
          -Parameter $blueprintparams `
          -ResourceGroupParameter $bpRGParameters `
          -Location "eastus" `
          -UserAssignedIdentity $userAssignedIdentityResourceId | Out-Null
      }
      Else {
        New-AzBlueprintAssignment -Name "NSMonitoring" `
          @idParam `
          -Blueprint $blueprint[0] `
          -Parameter $blueprintparams `
          -ResourceGroupParameter $bpRGParameters `
          -Location "eastus" `
          -UserAssignedIdentity $userAssignedIdentityResourceId | Out-Null
      }
    }

    Send-Event -Message "Finished Install - Infrastructure Monitoring, Success" -WriteOutput
    If ($controlParameters.Architecture -ne 'Single') {
      $summary = Get-BrownfieldSummary -loganalytics $publishresults['workspaceID'] -subs $childsubs -rootsubid $controlParameters.AzureSubscriptionId
    }
    Else {
      $summary = Get-BrownfieldSummary -loganalytics $publishresults['workspaceID'] -rootsubid $controlParameters.AzureSubscriptionId
    }

    Send-Event "Found $($summary.resourceIDs.count) unique resource ids in installed scope `n NB: Not all resources support Azure Monitor. `n See https://docs.microsoft.com/en-us/azure/azure-monitor/platform/diagnostic-logs-schema for supported resources. " -WriteOutput
    Send-Event "Found $($summary.diagsettings.count) resources with pre-existing diagnostics settings in installed scope" -WriteOutput
    Send-Event "Found $($summary.setbyPolicy.count) resources with pre-existing diagnostics settings which look to have been set by Policy in installed scope" -WriteOutput
    Send-Event "Found $($summary.correctworkspace.count) resources with diagnostics settings that seem to be pointing to the correct workspace for monitoring already" -WriteOutput

    Write-Host "For pre-existing Azure Resources, please check for policy compliance and if necessary Create a Remediation Task!" -ForegroundColor Red
  }
}

Function Install-AlertPack {
  [CmdletBinding()]
  Param (
    [string] $SourceFolder = '.',
    [string] $PkgVersion = 'testing',
    [ClientInstall] $controlParameters
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {

    Join-Path -Path $SourceFolder -ChildPath 'ARM' -Resolve -OutVariable ArtifactStagingDirectory | Out-Null
    Join-Path -Path $SourceFolder -ChildPath 'ARM' -Resolve -OutVariable DSCSourceFolder | Out-Null
    Join-Path -Path $SourceFolder -ChildPath 'Runbook' -Resolve -OutVariable RunbookSourceFolder | Out-Null
    Join-Path -Path $SourceFolder -ChildPath 'Plugins' -Resolve -OutVariable PluginsFolder | Out-Null

    $StorageAccount = (Get-AzStorageAccount | Where-Object { $_.StorageAccountName -eq $controlParameters.DeploymentStorageAccount })
    If ($null -ne $StorageAccount) {
      Set-AzStorageBlobContent -Blob $controlParameters.PlugIn -Container "NS-Monitoring-$($PkgVersion)".Replace('.', '-').ToLower() -File (Join-Path -Path $PluginsFolder -ChildPath $controlParameters.PlugIn) -Context $StorageAccount.Context -Force | Out-Null
    }

    $armDeploymentParameters = New-Object -TypeName Hashtable

    $armDeploymentParameters.Add('ResourceLocation', $controlParameters.ResourceGroupLocation)
    $armDeploymentParameters.Add('pluginTemplate', $controlParameters.Plugin)
    $armDeploymentParameters.Add('workspaceName', $controlParameters.WorkspaceName)
    $armDeploymentParameters.Add('appInsightName', $controlParameters.AppInsightsName)
    $armDeploymentParameters.Add('actionGroupResourceId', $controlParameters.actionGroupResourceID)

    $ArmDeployment = Publish-ResourceGroupTemplates -ResourceGroupName $controlParameters.ResourceGroupName `
      -ResourceGroupLocation $controlParameters.ResourceGroupLocation `
      -StorageAccountName $controlParameters.DeploymentStorageAccount `
      -StorageContainerName "NS-Monitoring-$($PkgVersion)".Replace('.', '-').ToLower() `
      -TemplateFile 'PlugInDeploy.json' `
      -CustomParams $armDeploymentParameters `
      -ArtifactStagingDirectory $ArtifactStagingDirectory `
      -DSCSourceFolder $DSCSourceFolder `
      -RunbookSourceFolder $RunbookSourceFolder `
      -UploadArtifacts `
      -BuildTag $PkgVersion -DeploymentMode 'Incremental'
  }
}

Function Remove-AutomationAccountJobSchedule {
  [CmdletBinding()]
  Param ( )

  $AutomationAccounts = Get-AzAutomationAccount -ResourceGroupName $controlParameters.ResourceGroupName `
    -ErrorAction SilentlyContinue

  Send-Trace -Message "Removing Automation Account Schedules"
  ForEach ($AutomationAccount In $AutomationAccounts) {
    Send-Trace -Message "Removing Automation Account Job Schedules"
    $Uri = "https://management.azure.com/subscriptions/$($controlParameters.AzureSubscriptionId)/resourceGroups/$($controlParameters.ResourceGroupName)/providers/Microsoft.Automation/automationAccounts/$($AutomationAccount.AutomationAccountName)/jobSchedules?api-version=2015-10-31"
    $jobSchedules = Invoke-GetRestMethod -Uri $Uri

    ForEach ($jobschedulevalue In $jobSchedules) {
      If ($jobschedulevalue.properties.runbook.name -eq 'CMDBActiveSynch' -or $jobschedulevalue.properties.runbook.name -eq 'SampleSchedule') {
        $Uri = "https://management.azure.com/subscriptions/$($controlParameters.AzureSubscriptionId)/resourceGroups/$($controlParameters.ResourceGroupName)/providers/Microsoft.Automation/automationAccounts/$($AutomationAccount.AutomationAccountName)/jobSchedules/$($jobschedulevalue.properties.jobScheduleId)?api-version=2015-10-31"
        Invoke-DeleteRestMethod -Uri $Uri

        Remove-AzAutomationSchedule -Name $jobschedulevalue.properties.schedule.name `
          -ResourceGroupName $controlParameters.ResourceGroupName `
          -AutomationAccountName $Schedule.AutomationAccountName `
          -Force
      }
    }
  }
}

Function Remove-AutomationAccountDiagnosticSettings {
  [CmdLetBinding()]
  Param ( )

  #Get the Automation Accounts
  $AutomationAccounts = Get-AzAutomationAccount -ResourceGroupName $controlParameters.ResourceGroupName `
    -ErrorAction SilentlyContinue
  Send-Trace -Message "Checking for Automation Account v1.1.x Diagnostic Settings"

  #Foreach Automation Account - Ensures if none found nothing happens
  ForEach ($AutomationAccount In $AutomationAccounts) {

    #We need the resource ID to get the diagnostic setting, it isn't available in the results of Get-AzAutomationAccount.
    $resourceID = $(
      Get-AzResource -Name $AutomationAccount.AutomationAccountName `
        -ResourceGroupName $AutomationAccount.ResourceGroupName`
    ).ResourceId

    $diagSetting = Get-AzDiagnosticSetting -ResourceId $resourceID

    if ($diagSetting.name -eq "setByPolicy") {
      Send-Trace -Message "Removing Automation Account v1.1.x Diagnostic Setting from ($AutomationAccount.AutomationAccountName)."
      Remove-AzDiagnosticSetting -ResourceID $resourceID
    }
  }
}

Function IsDriveTrainResourceGroup {
  [CmdletBinding()]
  Param(
    $resourceGroup
  )

  #resource group with tags table doesn't exist
  If (($ResourceGroup.TagsTable | Measure-Object).Count -gt 0 -And $ResourceGroup.TagsTable.Contains('NS-DriveTrain')) {
    #if empty set to true
    $DriveTrainRG = $true
  }
  else {
    # otherwise false
    $DriveTrainRG = $false
  }

  return $DriveTrainRG
}

Function Test-ResourceGroup {
  [CmdletBinding()]
  Param (
    [ControlParameters] $controlParameters
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    Send-Trace -message "Checking Resource Group Exists"
    #Get the resource group from user
    Set-AzContext -Subscription $controlParameters.AzureSubscriptionId | Out-Null
    $ResourceGroup = Get-AzResourceGroup -Name $controlParameters.ResourceGroupName -ErrorAction SilentlyContinue

    #Check to see if the rg exists
    If (($ResourceGroup | Measure-Object).Count -eq 1) {

      $DriveTrainRG = IsDriveTrainResourceGroup -resourceGroup $ResourceGroup

      $Resources = Get-AzResource -ResourceGroupName $controlParameters.ResourceGroupName

      If (-not $DriveTrainRG -And ($Resources | Measure-Object).Count -gt 0) {
        If (-not (Get-RGPermissibleDrivetrainOrNot -ResourceGroupName $controlParameters.ResourceGroupName)) {
          Throw "This Resource Group contains resources outside of the DriveTrain this is unsupported. Terminating"
        }
      }

      $LogAnalytics = Get-AzResource -ResourceType "Microsoft.OperationalInsights/workspaces" -ResourceGroupName $controlParameters.ResourceGroupName
      If (($LogAnalytics | Measure-Object).Count -eq 1) {
        If ($controlParameters.WorkspaceName -ne '' -and $controlParameters.WorkspaceName -ne $LogAnalytics.Name) {
          Throw "The specified workspace name is not the same as one already existing in the Resouce Group. Terminating"
        }
        ElseIf ($LogAnalytics.Location -notin $controlParameters.SupportedRegions) {
          Throw "The specified workspace is not in a supported region, Terminating"
        }
        Else {
          $controlParameters.WorkspaceName = $LogAnalytics.Name
        }
      }
      ElseIf (($LogAnalytics | Measure-Object).Count -gt 1) {
        Throw "There is more than one workspace in the resource group, this is an unsupported condition. Terminating"
      }

      $AutomationAccount = Get-AzResource -ResourceType "Microsoft.Automation/automationAccounts" -ResourceGroupName $controlParameters.ResourceGroupName
      If (($AutomationAccount | Measure-Object).Count -eq 1) {
        If ($controlParameters.AutomationAccountName -ne '' -and $controlParameters.AutomationAccountName -ne $AutomationAccount.Name) {
          Throw "The specified automation account name is not the same as the one already existing in the Resource Group. Terminating"
        }
        # ensure LA and AA are in the same region with a special case for eastus eastus2
        ElseIf ($AutomationAccount.Location -ne $LogAnalytics.Location) {
          if ($AutomationAccount.Location -ne "eastus2" -and $LogAnalytics.Location -ne "eastus") {
            Throw "The specified automation account is not in a supported region.  It must be in the same region as the workspace (or in eastus2 for an eastus workspace). Terminating"
          }
        }
        Else {
          $controlParameters.AutomationAccountName = $AutomationAccount.Name
        }
      }

      # now test for security center settings in existing installation
      if ($DriveTrainRG) {
        # test to see if the security center was configured for log analytics in a previous install
        $controlParameters.SecurityCenterAlreadyEnabled = (Get-AzSecurityCenterTierSetting `
            -SubscriptionId $controlParameters.AzureSubscriptionId `
            -WorkspaceName $controlParameters.WorkspaceName `
            -WorkspaceResourceGroup $controlParameters.ResourceGroupName) -eq 'Standard'
      }

      $ApplicationInsights = Get-AzResource -ResourceType "Microsoft.Insights/components" -ResourceGroupName $controlParameters.ResourceGroupName
      If (($ApplicationInsights | Measure-Object).Count -eq 1) {
        If ($controlParameters.AppInsightsName -ne '' -and $controlParameters.AppInsightsName -ne $ApplicationInsights.Name) {
          Throw "The specified application insights name is not the same as the one already existing in the Resource Group, Terminating"
        }
        Else {
          $controlParameters.AppInsightsName = $ApplicationInsights.Name
        }
      }

      $storageAccounts = Get-AzResource -ResourceType "Microsoft.Storage/storageAccounts" -ResourceGroupName $controlParameters.ResourceGroupName
      If (($storageAccounts | Measure-Object).Count -eq 2) {
        $controlParameters.DeploymentStorageAccount = ($storageAccounts | Where-Object { $_.ResourceName -like 'salibrary*' }).ResourceName
      }

      # The filtering here is because Application Insights creates an Action Group, the timing of this creation is indeterminate.
      $actionGroups = Get-AzResource -ResourceType "Microsoft.Insights/actionGroups" -ResourceGroupName $controlParameters.ResourceGroupName
      $serviceNowActionGroup = $actionGroups | Where-Object { $_.Name -notlike 'Application Insights Smart Detection' }
      If (($serviceNowActionGroup | Measure-Object).Count -eq 1) {
        $controlParameters.actionGroupResourceID = $serviceNowActionGroup.ResourceId
      }
    }
  }
}

Function Get-BrownfieldSummary {
  Param (
    [object]$subs = $null,
    [string]$rootsubid = $null,
    [Parameter(Mandatory = $true)]
    [string]$loganalytics
  )

  $resourceids = @()
  $diagnosticSettings = @()

  If (($null -eq $sub) -and ($null -eq $rootsubid)) {
    Throw "Error in Get-BrownfieldSummary: Missing parameters supplied to function"
  }
  ElseIf ($null -ne $subs) {
    ForEach ($sub In $subs) {
      Set-AzContext -subscriptionID  $sub.name
      $resourceids += $(Get-AzResource).ResourceId
    }
  }
  ElseIf ($null -ne $rootsubid) {
    Set-AzContext -SubscriptionId $rootsubid
    $resourceids += $(Get-AzResource).ResourceId
  }

  $resourceIDs | Foreach-Object {
    If ($null -ne $_) {
      $diagnosticsettings += Get-AzDiagnosticSetting -ResourceId $_ -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
    } }

  $diagnosticSettings = $diagnosticSettings | Select-Object -Unique

  Return [PSCustomObject]@{
    'diagsettings'     = $diagnosticSettings
    'resourceIDs'      = $resourceIDs
    'setbyPolicy'      = $diagnosticSettings | Where-Object { $_.Name -match "setByPolicy" }
    'correctworkspace' = $diagnosticSettings | Where-Object { $_.WorkspaceID -match $loganalytics }
  }
}

Function Set-ResourceGroup {
  [CmdletBinding()]
  Param (
    [string] $Name,
    [string] $Location,
    [string] $BuildTag
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    Send-Trace -Message "Creating / Updating Resource Group"
    $ResourceGroup = Get-AzResourceGroup -Name $Name -ErrorAction SilentlyContinue
    If ($null -eq $ResourceGroup) {
      New-AzResourceGroup -Name $Name -Location $Location -Force | Out-Null
    }

    $Tags = (Get-AzResourceGroup -Name $Name).Tags

    if ($null -eq $Tags) {
      #no tags - add version
      $Tags = @{'NS-DriveTrain' = $BuildTag }
    }
    else {
      # found tags - add/update version
      if ($Tags.ContainsKey('NS-DriveTrain')) {
        # remove drivetrain key if present to avoid conflict
        $Tags.Remove('NS-DriveTrain')
      }

      $Tags += @{'NS-DriveTrain' = $BuildTag }
    }

    Set-AzResourceGroup -Name $Name -Tag $Tags | Out-Null
  }
}

Function Uninstall {
  [CmdletBinding()]
  Param (
    [MonitoringUninstall] $controlParameters
  )
  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }
  Process {
    Send-Event -Message "Removing Infrastructure Monitoring from the selected subscription" -WriteOutput

    $subscriptionArray = @( )

    $scopeParam = @{
      Scope = (Get-Scope -controlParameters $controlParameters)
    }
    $idParam = Get-ModuleParamId -controlParameters $controlParameters
    $nameParam = Get-ModuleParamName -controlParameters $controlParameters

    Switch ( $controlParameters.Architecture ) {
      'Single' {
        $subscriptionArray += Get-AzSubscription -SubscriptionId $controlParameters.AzureSubscriptionId
        $managedUser = Get-AzUserAssignedIdentity -ResourceGroupName $controlParameters.ResourceGroupName
      }
      'Multiple' {
        $subs = Get-ManagementGroupChildNodes -ManagementGroupId $controlParameters.ManagementGroup -Subscriptions
        ForEach ($sub In $subs) {
          $subscriptionArray += $sub.name
        }
      }
    }

    Send-Event -Message "Remove Policy Assignments" -WriteOutput
    Get-AzPolicyAssignment @scopeParam `
    | Where-Object { $_.Properties.displayName -eq 'ASSIGNED DriveTrain Diagnostic Policies' } `
    | Foreach-Object {
      Remove-AzRoleAssignment -ObjectId $_.Identity.PrincipalId -RoleDefinitionName "Contributor" @scopeParam
      Remove-AzPolicyAssignment -Id $_.PolicyAssignmentId | Out-Null
    }

    Send-Event -Message "Remove Policy Set Definition" -WriteOutput
    Get-AzPolicySetDefinition @nameParam `
    | Where-Object { $_.Properties.metadata.product -Like 'New Signature DriveTrain' } `
    | ForEach-Object { Remove-AzPolicySetDefinition -Id $_.PolicySetDefinitionId -Force | Out-Null }

    Send-Event -Message "Remove Policy Definition" -WriteOutput
    #Get-AzPolicyDefinition @nameParam | Where-Object { $_.Properties.metadata.product -Like 'New Signature DriveTrain' } | ForEach-Object { Remove-AzPolicyDefinition -Id $_.PolicyDefinitionId -Force | Out-Null }
    Get-AzPolicyDefinition @nameParam `
    | Where-Object { $_.Properties.metadata.product -Like 'New Signature DriveTrain' } `
    | ForEach-Object { Remove-AzPolicyDefinition -Id $_.PolicyDefinitionId -Force | Out-Null }

    ForEach ($sub In $subscriptionArray) {
      Set-AzContext -Subscription $sub | Out-Null
      $subscriptionId = $(Get-AzContext).Subscription.Id
      Send-Event -Message "Remove Blueprint Assignments" -WriteOutput
      Remove-AzBlueprintAssignment -Name "NSMonitoring" -SubscriptionId $subscriptionId
      #Defining timeout of 15 minutes
      $Timeout = 900 #seconds
      #Dynamically getting the provisional state
      $testItemsInDeletingState = [scriptblock] { `
          # return False when all blueprints in filter are deleted
          $itemsInDeletingState = (
          Get-AzBlueprintAssignment -Name 'NSMonitoring' `
            -SubscriptionId $subscriptionId `
            -ErrorAction SilentlyContinue `
          | Where-Object { $_.ProvisioningState -eq 'Deleting' } -ErrorAction SilentlyContinue
        )
        if ($null -eq $itemsInDeletingState){
          return $false
        }
        else{
          return $true
        }
      }
      $retryInterval = 5 #seconds
      $timer = [Diagnostics.Stopwatch]::StartNew()
      #Looping to check if timeout is less than the count
      while (($timer.Elapsed.TotalSeconds -lt $Timeout) -and ($testItemsInDeletingState.invoke())) {

        Start-Sleep -Seconds $retryInterval
        $totalSecs = [math]::Round($timer.Elapsed.TotalSeconds, 0)
        Send-Event "Blueprint deleted after $totalSecs seconds..." -WriteOutput
      }
      $timer.Stop()
      #Warning the user
      if ($timer.Elapsed.TotalSeconds -ge $Timeout) {
        Send-Event -WriteOutput 'Action did not complete before timeout period.'
      }
      else {
        Send-Event 'Blueprint Assignments deleted' -WriteOutput
      }
      Get-AzResourceGroup -ResourceGroupName $controlParameters.ResourceGroupName -ErrorAction SilentlyContinue `
      | Remove-AzResourceGroup -Force `
      | Out-Null
    }

    $Uri = "https://management.azure.com/$($scopeParam.Scope)/providers/Microsoft.Blueprint/blueprints/NSMonitoring?api-version=2018-11-01-preview"
    Invoke-DeleteRestMethod -Uri $Uri

    Send-Event -Message "Infrastructure Monitoring successfully removed" -WriteOutput
  }
}

Function Get-LatestArtifactVersion {
  [CmdletBinding()]
  Param ()

  $currentAzureContext = Get-AzContext
  $azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
  $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile)
  $token = $profileClient.AcquireAccessToken($currentAzureContext.Subscription.TenantId).AccessToken
  $feedId = "DriveTrain@Release"
  $packageId = "63382b6a-4ca1-4304-a930-8ccbfe86d55c"

  $headers = @{
    'Authorization' = "Bearer $token"
    'Host'          = "feeds.dev.azure.com"
    'Content-Type'  = 'application/json'
  }

  $uri = "https://feeds.dev.azure.com/newsigcode/_apis/packaging/Feeds/$($feedId)/packages/$($packageId)/versions?api-version=5.0-preview.1"
  $response = Invoke-WebRequest -Uri $uri -Headers $headers -Method Get -UseBasicParsing
  $releaseVersions = $response.content | ConvertFrom-Json
  $currentRelease = $releaseVersions.value `
                    | Where-Object { ($_.version -notlike "*rc*") -and ($_.version -notlike "*alpha*") } `
                    | Select-Object -First 1
  Return($currentRelease.version)
}

function Test-Dependencies {
  $depVersions = @{
    "PowerShell"                = "Desktop";
    "Az"                        = [version]"6.4.0";
    "Az.Blueprint"              = [version]"0.2.13";
    "Az.Resources"              = [version]"4.3.1";
    "Az.Security"               = [version]"0.8.0";
    "Az.ManagedServiceIdentity" = [version]"0.7.3"
  }

  $depErrors = @()

  ForEach ($_ in $depVersions.Keys) {
    if ($_ -like 'PowerShell') {
      if ($PSVersionTable.PSEdition -ne $depVersions[$_]) {
        $depErrors += "Dependency Error: PowerShell v5.1 required."
      }
    }
    else {
      $installedVersion = (Get-InstalledModule -Name $_ -ErrorAction SilentlyContinue -WarningAction SilentlyContinue).Version
      if ($null -ne $installedVersion) {
        if ([version]$installedVersion -lt [version]$depVersions[$_]) {
          $depErrors += "Dependency Error: $_ module version " + $depVersions[$_] + " required. Version $installedVersion is currently installed."
        }
      }
      else {
        $depErrors += "Missing Dependency: $_ version " + $depVersions[$_]
      }
    }
  }
  return $depErrors
}

Export-ModuleMember -Function Uninstall, `
  Install, `
  Install-AlertPack, `
  Get-Architecture, `
  Get-UninstallArchitecture, `
  Get-Environment, `
  Get-LatestArtifactVersion, `
  Get-ManagementGroup, `
  Get-ResourceGroupName, `
  Get-ResourceGroupLocation, `
  Get-ServiceNowToken, `
  Get-Plugin, `
  Publish-Alerts, `
  Test-ResourceGroup, `
  Get-SecurityMonitoringEnabled, `
  Get-LogAnalyticsRetentionChanged, `
  Get-InvalidRoleAssignment, `
  Get-Scope, `
  Get-ModuleParamId, `
  Get-ModuleParamName, `
  Test-Dependencies
