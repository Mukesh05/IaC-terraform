#Requires -Version 5.1
#Requires -Modules Instrumentation, AzureGeneral

Function New-EventGridSubscriptionWithWebhook {
  [CmdletBinding()]Param (
    [Parameter(Mandatory = $true)]
    [String] $ResourceGroupName,

    [Parameter(Mandatory = $true)]
    [String[]] $IncludedEventTypes,

    [Parameter(Mandatory = $true)]
    [String] $workspaceId
  )

  Begin {
    Get-CallerPreference -Cmdlet $PSCmdlet -SessionState $ExecutionContext.SessionState
  }

  Process {

    #Check Event Grid is registered
    $rps = Get-AzResourceProvider -ListAvailable
    $namespace = $rps | Where-Object { $_.ProviderNamespace -eq "Microsoft.EventGrid" }
    Send-Trace -Message "Found Provider Namespace for Event Grid in state $($namespace.registrationstate)"
    if ($namespace.RegistrationState -ne "Registered") {
      Send-Trace -Message "Registering Namespace Provider Microsoft.EventGrid"
      Register-AzResourceProvider -ProviderNamespace $namespace.ProviderNamespace
      $i = 0
      do {
        Start-Sleep 2
        $i++
        $rps = Get-AzResourceProvider -ListAvailable
        $namespace = $rps | Where-Object { $_.ProviderNamespace -eq "Microsoft.EventGrid" }
      }
      while (
        ($namespace.RegistrationState -ne "Registered" ) -and `
        ($i -lt 60)
      )
      if ($namespace.RegistrationState -ne "Registered") {
        throw "Unable to register event provider namespace" | Send-Error $_
      }
    }


    $ProjectName = "DriveTrain"
    $AutomationAccounts = Get-AzAutomationAccount `
      -ResourceGroupName $ResourceGroupName `
      -ErrorAction SilentlyContinue

    $AutomationAccountCounts = $AutomationAccounts | measure

    if (1 -gt $AutomationAccountCounts.Count) {
      Send-Trace -Message "Due to multiple Automation accounts, error creating Webhook and Eventgrid subscription."
      exit
    }

    $AutomationAccountName = $AutomationAccounts.AutomationAccountName

    $Runbooks = Get-AzAutomationRunbook `
      -ResourceGroupName $ResourceGroupName `
      -AutomationAccountName $AutomationAccounts.AutomationAccountName `
      -ErrorAction SilentlyContinue

    $Runbooks = $Runbooks | Where-Object { $_.Name -Like '*NetAppMetricAlert*' }

    foreach ($Runbook in $Runbooks) {
      $RunbookName = $Runbook.Name
      $WebhookName = "WH$AutomationAccountName-$RunbookName"
      $EventSubscriptionName = "Egs-$WebhookName"
      Send-Trace -Message "Starting creation of webhook:$WebhookName and event grid subscription:$EventSubscriptionName"
      $Webhook = Get-AzAutomationWebhook `
        -Name $WebhookName `
        -ResourceGroupName $ResourceGroupName `
        -AutomationAccountName $AutomationAccountName `
        -ErrorAction SilentlyContinue

      if ($null -eq $Webhook) {
        $Webhook = New-AzAutomationWebhook `
          -ResourceGroupName $ResourceGroupName `
          -AutomationAccountName $AutomationAccountName `
          -Name $WebhookName  `
          -RunbookName $RunbookName  `
          -IsEnabled $True  `
          -ExpiryTime (Get-Date).AddYears(1)  `
          -Force

        #WebhookURI is displayed only first time.
        if ($null -ne $Webhook.WebhookURI) {
          Send-Trace -Message "New Valid Webhook created for runbook: $RunbookName"

          $EventGridSubscription = Get-AzEventGridSubscription `
            -EventSubscriptionName $EventSubscriptionName `
            -ErrorAction SilentlyContinue

          if ($null -ne $EventGridSubscription.Id) {
            Remove-AzEventGridSubscription `
              -EventSubscriptionName $EventSubscriptionName
          }

          Send-Trace -Message "Now creating EventGrid Subscription for Webhook: $WebhookName"
          try {
            $EventGridSubscription = New-AzEventGridSubscription `
              -Endpoint $Webhook.WebhookUri `
              -EventSubscriptionName $EventSubscriptionName `
              -IncludedEventType $IncludedEventTypes `
              -Label $ProjectName  `
              -SubjectBeginsWith "Microsoft.NetApp/netAppAccounts"
          }
          catch {
            try { $EventGridSubscription = New-AzEventGridSubscription `
              -Endpoint $Webhook.WebhookUri `
              -EventSubscriptionName $EventSubscriptionName `
              -IncludedEventType $IncludedEventTypes `
              -Label $ProjectName `
              -SubjectBeginsWith "Microsoft.NetApp/netAppAccounts"
            }
            catch {
              Write-Warning -Message $_
              Send-Trace -Message $_
            }
          }

          $EventGridSubscriptionId = $EventGridSubscription.Id
          if ($null -ne $EventGridSubscriptionId) {
            Send-Trace -Message "New EventGrid Subscription with Id : $EventGridSubscriptionId created"
                      #Add Diagnostics Setting to Event Grid
          $templatecontents = @'
{
                "$schema": "http://schema.management.azure.com/schemas/2015-01-01/deploymentTemplate.json#",
                "contentVersion": "1.0.0.0",
                "parameters": {
                  "resourceName": {
                    "type": "string"
                  },
                  "logAnalytics": {
                    "type": "string"
                  },
                  "RGlocation": {
                    "type": "string"
                  },
                },
                "variables": {},
                "resources": [
                  {
                    "type": "Microsoft.EventGrid/eventSubscriptions/providers/diagnosticSettings",
                    "apiVersion": "2017-05-01-preview",
                    "name": "[concat(parameters('resourceName'), '/', 'Microsoft.Insights/setByPolicy')]",
                    "location": "[parameters('RGlocation')]",
                    "dependsOn": [],
                    "properties": {
                      "workspaceId": "[parameters('logAnalytics')]",
                      "metrics": [
                        {
                          "category": "AllMetrics",
                          "enabled": true,
                          "retentionPolicy": {
                            "days": 0,
                            "enabled": false
                          },
                          "timeGrain": null
                        }
                      ],
                      "logs": []
                    }
                  }
                ],
                "outputs": {}
              }
'@

          $templateparams = @{
            'resourceName' = $EventSubscriptionName;
            'logAnalytics' = $workspaceId;
            'RGlocation' = $AutomationAccounts.Location
          }
          $temppath = ".\$(New-Guid).json"

          $templatefile = $templatecontents | Out-File $temppath -Force -Verbose

          New-AzDeployment `
            -Name "eventsubdiag$($(new-guid).tostring().substring(0,8))" `
            -templatefile $temppath `
            -TemplateParameterObject $templateparams `
            -Location $AutomationAccounts.Location `
            -Verbose

          Remove-Item $temppath -Force
          }
          else {
            Send-Trace -Message "Error in EventGrid Subscription creation for Webhook: $WebhookName"
          }
        }
        else {
          Send-Trace -Message "Error in Valid Webhook creation for runbook: $RunbookName"
          continue
        }
      }
      else {
        Send-Trace -Message "New Webhook creation not required as there is an existing one with name: $WebhookName"

        $EventGridSubscription = Get-AzEventGridSubscription `
          -EventSubscriptionName $EventSubscriptionName `
          -ErrorAction SilentlyContinue

        if ($null -ne $EventGridSubscription.Id) {
          $EventGridSubscription = Update-AzEventGridSubscription `
            -EventSubscriptionName $EventSubscriptionName `
            -IncludedEventType $IncludedEventTypes `
            -Label $ProjectName `
            -SubjectBeginsWith "Microsoft.NetApp/netAppAccounts"

          if ($null -ne $EventGridSubscription.Id) {
            Send-Trace -Message "Successfully Updated EventGrid Subscription: $EventSubscriptionName"
          }
          else {
            Send-Trace -Message "Update of EventGrid Subscription: $EventSubscriptionName failed."
          }
        }
        else {
          Send-Trace -Message "Webhook $WebhookName is present, but Eventgrid Subscription $EventSubscriptionName is not. Manual Cleanup & Creation required."
        }
      }
    }
  }
  End { }
}

Export-ModuleMember `
	 -Function New-EventGridSubscriptionWithWebhook