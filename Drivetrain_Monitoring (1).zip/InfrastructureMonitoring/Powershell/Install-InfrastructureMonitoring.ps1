Using Module '.\MonitoringCommon.psm1'
Using Module '.\lib_pwsh\Helpers.psm1'

[CmdletBinding()]
Param(
  [ValidateSet('Single', 'Multiple')]
  [string] $Architecture = '',
  [string] $AzureTenantId = '',
  [string] $AzureSubscription = '',
  [string] $ResourceGroupName = '',
  [string] $ResourceGroupLocation,
  [string] $ManagementGroupId = '',
  [ValidateSet('DEV', 'TEST', 'DIAG', 'PROD')]
  [string] $Environment,
  [string] $ServiceNowToken,
  [string] $workspaceName = '',
  [string] $appInsightName = '',
  [string] $automationAccountName = '',
  [string] $SourceFolder = $PSScriptRoot,
  [switch] $EnableCAS,
  [string] $AlertEmailName = '',
  [string] $AlertEmailAddress = '',
  [string] $Plugin = $null,
  [switch] $SkipAutoUpdate,
  [switch] $SkipUserCheck,
  [switch] $Force,
  [bool] $EnableSecurity,
  [bool] $ChangeRetentionDays
)

Try {
  Import-Module -Name "$($PSScriptRoot)\lib_pwsh\Instrumentation.psm1" -Force
  Import-Module -Name "$($PSScriptRoot)\lib_pwsh\AzureGeneral.psm1" -Force
  Import-Module -Name "$($PSScriptRoot)\lib_pwsh\AzureSecurity.psm1" -Force
  Import-Module -Name "$($PSScriptRoot)\lib_pwsh\UserInterface.psm1" -Force
  Import-Module -Name "$($PSScriptRoot)\AzureResources.psm1" -Force
  Import-Module -Name "$($PSScriptRoot)\Deploy-EventGridSubscription.psm1" -Force
  Import-Module -Name "$($PSScriptRoot)\Monitoring.psm1" -Force

  Send-Event "Evaluating dependencies"

  $depCheck = Test-Dependencies

  if ($null -ne $depCheck){
    foreach ($_ in $depCheck){
        Send-Event $_ -WriteOutput
    }
    throw "Dependency evaluation failed. Terminating installation. Please correct the dependency errors and try again."
  }

  Send-Event "Starting Install - Infrastructure Monitoring"

  $SourceFolder = Resolve-Path $SourceFolder

  Connect-Azure -SkipUserCheck:$SkipUserCheck

  If (-not $SkipAutoUpdate) {
    $context = Get-AzContext;
    If ('a1a2578a-8fd3-4595-bb18-7d17df8944b0' -eq $context.Tenant.Id) {
      $latestArtifactVersion = Get-LatestArtifactVersion
      If ($packageVersion -ne $latestArtifactVersion) {
        If ('Y' -eq (Read-Host "Latest version of the package is available. Do you want to install the version $($latestArtifactVersion), 'Y' / 'N'")) {
          $TempFolder = (Split-Path $PSScriptRoot -Parent) + "\InfrastructureMonitoring-$($latestArtifactVersion)"
          if (!(Test-Path $TempFolder)) {
            New-Item -ItemType Directory -Force -Path $TempFolder
          }

          az artifacts universal download `
            --organization "https://dev.azure.com/newsigcode/"  `
            --feed "DriveTrain" `
            --name "newsig.arm.infrastructure" `
            --version "$($latestArtifactVersion)" `
            --path $TempFolder

          Send-Event "Downloaded the latest version($($latestArtifactVersion)) of the package to $($TempFolder)" -WriteOutput
          Break
        }
      }
    }
  }

  $controlParameters = [MonitoringInstall]::new()
  $controlParameters.Architecture = $Architecture
  $controlParameters.AzureTenant.Id = $AzureTenantId
  $controlParameters.AzureTenant.Name = "N/A - Supplied by Command Line"
  $controlParameters.AzureSubscriptionId = $AzureSubscription
  $controlParameters.ResourceGroupName = $ResourceGroupName
  $controlParameters.ResourceGroupLocation = $ResourceGroupLocation
  $controlParameters.ManagementGroup = $ManagementGroupId
  $controlParameters.Environment = $Environment
  $controlParameters.ChangeRetentionDays = $ChangeRetentionDays
  $controlParameters.ContinueScript = $ContinueScript
  $controlParameters.SNowToken = $ServiceNowToken
  $controlParameters.WorkspaceName = $workspaceName
  $controlParameters.AutomationAccountName = $automationAccountName
  $controlParameters.AppInsightsName = $appInsightName
  $controlParameters.EnableCAS = $EnableCAS
  $controlParameters.AlertEmailName = $AlertEmailName
  $controlParameters.AlertEmailAddress = $AlertEmailAddress

  If ($PSBoundParameters.ContainsKey('EnableSecurity')) {
    $controlParameters.EnableSecurity = $EnableSecurity
  }
  If ($PSBoundParameters.ContainsKey("Plugin")) {
    $controlParameters.Plugin = $Plugin
  }

  Do {
    Get-Architecture -controlParameters $controlParameters
    Get-AzureTenant -controlParameters $controlParameters
    Get-AzureSubscription -controlParameters $controlParameters
    Get-ManagementGroup -controlParameters $controlParameters
    Get-InvalidRoleAssignment -controlParameters $controlParameters
    Get-ResourceGroupName -controlParameters $controlParameters
    Get-ResourceGroupLocation -controlParameters $controlParameters
    Test-ResourceGroup -controlParameters $controlParameters
    Get-Environment -controlParameters $controlParameters
    Get-ServiceNowToken -controlParameters $controlParameters

    If(!$Force) {
      # skipped if we are forcing the deployment
      Get-Plugin -controlParameters $controlParameters -SourceFolder $SourceFolder
    }
    Get-SecurityMonitoringEnabled -controlParameters $controlParameters
    Get-LogAnalyticsRetentionChanged -controlParameters $controlParameters

    Clear-Scrollback
  } Until ($controlParameters.IsValid() -or $Force)

  Install -SourceFolder $SourceFolder -PkgVersion $packageVersion -controlParameters $controlParameters

}
Catch {
  Send-Event -Message ("{0}`n{1}" -f $_.Exception.Message, $_.ScriptStackTrace) -WriteOutput

  Send-Error -Message "An error has occured:`n $_" -Exception $_.Exception

  $SessionKey = Get-SessionId
  Write-Host "As an error has occured, please report Session Key : $($SessionKey), along with the message, to support to aid issue resolution."

  If ([Environment]::UserInteractive) {
    Read-Host "Press enter to continue and exit"
  }

  Exit
}