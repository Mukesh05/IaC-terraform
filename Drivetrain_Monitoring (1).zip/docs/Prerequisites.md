## PreRequisites

- .Net Framework v4.6 or higher
- PowerShell 5.1 (Default on Windows 10)
- Internet Explorer enhanced security mode disabled
- If deploying to multiple subscriptions, all subscriptions will need to be under a single root management group to be targeted for installation.
- Azure CLI
- Azure CLI Extension for Azure DevOps
- Az PowerShell Module Version 3.5.0
- - Az.Blueprints PowerShell Module Version 0.2.10
- - Az.ManagedServiceIdentity PowerShell Module Version 0.7.3

- At least the rights specified in the "Custom Role" in the main subscriptions

* Not AzureRM