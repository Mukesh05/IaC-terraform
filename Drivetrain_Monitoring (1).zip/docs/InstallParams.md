The template requires some parameters to ensure the deployment is correct

    "Architecture": Single Subscription or Hub and Spoke, Valid values - Single/Multiple
    "AzureTenantId": The Azure Tenant Id to deploy the solution into.
    "AzureSubscription": The Azure Subscription Id to deploy the solution into.
    "ResourceGroupName": Overrides the default resource group name, to allow when a client has implemented their own solution.
    "ResourceGroupLocation": The geographic location to deploy the solution into.
    "ManagementGroupId": (Multi-subscription only) Defines the Id of the root management group of all subscriptions to be monitored
    "Environment": The environment (DEV, TEST or PROD). PROD will deploy with a 365 day retention and route alerts to the Production Service Now instance. DEV or TEST use 31 day retention and route to the DEV or TEST  ServiceNow instances respectively. Default - prompted for selection
    "ServiceNowToken": The customer's Service Now Token, determines what company name Alerts are bound to in ServiceNow. DEV and TEST deployments use the "NS Development" company name token ('0CB387C5-EDB0-4A5E-8956-12E64DFC041B'). PROD deployment will prompt for the customer specific token. The token from the deployment is forms part of the URL set in the action group Webhook during deployment.
    "workspaceName": Override the default Log Analytics Name, should only be used when the client has an exisitng Log Analytics Workspace
    "appInsightName": Override the default Log Analytics Name, should only be used when the client has an existing App Insights Workspace, in the same resource group as the Log Analytics Workspace.
    "automationAccountName": Override the default Automation Account Name, should only be used when the client has an existing Automation Account, in the same resource group as the Log Analytics Workspace.
    "EnableCAS": Enables the Common Alert Schema, this should ony be used under direction of Jason Cotton.
    "SkipAutoUpdate": Skips the check for auto downloading newer version, should only be used in a pipeline.
    "AlertEmailName": If set, sets the alert action for the actiongroup (AlertEmailName + AlertEmailAddress must both be set together)
    "AlertEmailAddress": If set, sets the alert action for the actiongroup (AlertEmailName + AlertEmailAddress must both be set together)
    "Plugin": If set, Name of the file containing the custom alert rules to be deployed
    "SkipUserCheck": Switch parameter; set to use existing Azure session in PowerShell
    "SourceFolder": "Dev Only, DO NOT USE"
