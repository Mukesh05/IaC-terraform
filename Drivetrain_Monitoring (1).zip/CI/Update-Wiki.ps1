Write-Output "Updating documentation with current package version."

$docs = ".\wiki\Overview\Installation.md", ".\wiki\Overview\Post-Installation.md"

ForEach($docPath in $docs){
  $content = Get-Content $docPath

  $newcontent = $content -replace '##BUILD_VER##', $env:PackageVersion

  $newcontent | Set-Content $docPath

  Write-Output "Updated $docPath!"
}