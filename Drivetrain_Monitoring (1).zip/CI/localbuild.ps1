Param (
  [switch]$clean
)

if (!(Get-ChildItem -Path ".\InfrastructureMonitoring" -ErrorAction SilentlyContinue)) {
  Write-Error "Please ensure you are running this script with the repo root as your current/working directory"
}

$ARMDir = ".\InfrastructureMonitoring\ARM\Assets_ARM"
$PoliciesDir = ".\InfrastructureMonitoring\Policies"
$PWSHDir = ".\InfrastructureMonitoring\PowerShell\lib_pwsh\"
. .\ci\packageversion.ps1

if ($clean) {
  If (Test-Path -Path $PoliciesDir) { Remove-Item -path $PoliciesDir -Force -Recurse }
  If (Test-Path -Path $PWSHDir) { Remove-Item -path $PWSHDir -Force -Recurse }
  If (Test-Path -Path $ARMDir) { Remove-Item -path $ARMDir -Force -Recurse }
}

if ($null -eq $(Get-Item $PWSHDir -ErrorAction SilentlyContinue)) {
  az artifacts universal download --organization "https://dev.azure.com/newsigcode/" --feed "DriveTrain_Dependencies"  --name "newsig.powershell" --version $ver_PwshPkg --path $PWSHDir
}

if ($null -eq $(Get-Item "$PoliciesDir\Policies" -ErrorAction SilentlyContinue)) {
  az artifacts universal download --organization "https://dev.azure.com/newsigcode/" --feed "DriveTrain_Dependencies"  --name "newsig.policies" --version $ver_Policies --path "$PoliciesDir"
}

#if ($null -eq $(Get-Item $ARMDir -ErrorAction SilentlyContinue)) {
#  az artifacts universal download --organization "https://dev.azure.com/newsigcode/" --feed "DriveTrain_Dependencies"  --name "newsig.arm" --version $ver_ARMPkg --path $ARMDir
#}
