$ver_Policies = "*"
$ver_PwshPkg = "*"
#$ver_ARMPkg = "*"

if ($env:Build_SourcesDirectory) {
    "##vso[task.setvariable variable=ver_Policies;]$ver_Policies"
    "##vso[task.setvariable variable=ver_PwshPkg;]$ver_PwshPkg"
#    "##vso[task.setvariable variable=ver_ARMPkg;]$ver_ARMPkg"
}