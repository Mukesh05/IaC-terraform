### CI Folder

This folder is for containing PowerShell scripts and other components required for CI of this product.

When trying to build directly from the repo, run ```.\ci\localbuild.ps1 -clean``` from the repository root to pull down dependencies from upstream repos. 