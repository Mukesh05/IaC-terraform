Write-Output "Getting Drivetrain Monitoring release branches..."
$releaseBranches = git branch -r -l 'origin/Release/*.*.*'
Write-Output "Found $($releaseBranches.Count) release branches."

# Create the alert archive directory
New-Item -Path .\InfrastructureMonitoring\ARM\oldAlerts -ItemType Directory

foreach ($branch in $releaseBranches){
  #$formatBranchName = $releaseBranches[0].Trim().Substring(7)
  $formatBranchName = $branch.Trim().Substring(7)
  $destDirName = $formatBranchName.Replace("/", "")

  Write-Output "Cloning $formatBranchName branch..."
  git -c http.extraheader="AUTHORIZATION: bearer $env:SYSTEM_ACCESSTOKEN" clone https://newsigcode.visualstudio.com/InnerSource/_git/Drivetrain_Monitoring --branch $formatBranchName  .\$destDirName

  if ($formatBranchName -eq 'Release/1.1.0'){
    $alertsFile = (Get-ChildItem -Path .\$destDirName -Include alertDeploy.json -Recurse).FullName
  }
  else{
    $alertsFile = (Get-ChildItem -Path .\$destDirName -Include alerts.json -Recurse).FullName
  }

  Write-Output "Copying alerts.json file for $formatBranchName from $alertsFile ..."
  Copy-Item -Path $alertsFile -Destination ".\InfrastructureMonitoring\ARM\oldAlerts\$($destDirName)_alerts.json"

  Write-Output "Removing files for $formatBranchName."
  Remove-Item -Path .\$destDirName -Recurse -Force
}