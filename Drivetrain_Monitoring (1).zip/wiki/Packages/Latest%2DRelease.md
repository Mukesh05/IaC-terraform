# DriveTrain - Infrastructure Monitoring 



## Overview

DriveTrain Infrastructure Monitoring deploys a collection of Azure Resources to one or more Azure Subscriptions in order to facilitate monitoring of an Azure Estate. 

This is intended to allow implementation engineers a time-saving method to deploy New Signature best practice monitoring framework to a client. 

It deploys the following items: 
- A Log Analytics Workspace
- An Automation Account
- Azure Policy to enable diagnostics & link to the Log Analytics workspace for all supported resource types
- Pre-sets the deployed Log Analytics workspace to integrate with Security Centre, for cases where it may be enabled. 
- An Action Group to forward all alert information via REST to New Signature ServiceNow
- 80+ Alerts 
- Supporting configuration such as Solutions and Datasources into the Log Analytics workspace. 
- If management group deployment is chosen, an Azure Blueprint is utilised to configure all subscriptions beneath the management group. 

It supports either single-subscription, or management group deployment. 

Please review the [Product Wiki](https://dev.azure.com/newsigcode/f8287ead-8d77-4249-b430-6fef6fc3e559/_wiki/wikis/cef39718-fb70-448d-a834-55b738c579d1) for more information and instructions on how to download and install.


### Prerequisites
- PowerShell 5.1 (Default on Windows 10 - PowerShell Core is not currently supported)
- Internet Explorer enhanced security mode disabled
- If deploying to multiple subscriptions, all subscriptions will need to be under a single root management group to be targeted for installation. 
- [Azure CLI](https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-windows?view=azure-cli-latest#install-or-update)
- [Azure CLI Extension for Azure DevOps](https://github.com/Azure/azure-devops-cli-extension#quick-start)
- [Az PowerShell Module](https://docs.microsoft.com/en-us/powershell/azure/install-az-ps?view=azps-2.7.0#install-the-azure-powershell-module-1)*
- [.Net Framework v4.6 or higher](https://docs.microsoft.com/en-gb/dotnet/framework/install/on-windows-10)
- At least the rights specified in the ["Custom Role"](https://dev.azure.com/newsigcode/DriveTrain/_git/Drivetrain_Monitoring?path=%2FInfrastructureMonitoring%2FRBAC.json&version=GBmaster) in the main subscriptions

_*Not AzureRM_


### Feedback
Any product feedback is very welcome! Please direct your feedback to:

- The _Infrastructure Monitoring_ teams channel in the Drivetrain Teams site. 
- Jason Cotton - Service Design Lead (Product Owner)

Please note the use of Azure CLI is only for package download, due to the fact that PowerShell does not currently handle the download of [Universal Packages](https://devblogs.microsoft.com/devops/getting-started-with-universal-packages/).

**New Features** 


**Improvements**



## Legal

It is required that a Master Services Agreement (MSA) is in place between New Signature and any customer where Drivetrain is used.

Please ensure that any code you contribute is either your own work, released under a permissive (non-copyleft) licence, or has been developed on a customer engagement where a Master Services Agreement is in place.

If you have any questions or queries about this, please contact legal@newsignature.com.
