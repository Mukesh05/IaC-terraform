In this folder are all individual release notes for each version of the Infrastructure Monitoring ARM templates that are for general consumption. Each release notes includes any new features that have been added, since the last release note, and any issues that have been addressed.

Each release note, also contains the instructions on how to obtain the package and how to run the simplified deployment process.

The releases are numbered as major.minor.build

So Release 1.1.0 might be superseded by 1.1.5 with issues addressed within that release.  Once new functionality is added the new release will become 1.2.0 (or greater).  For release with the same major version, there should be forward and backwards compatibility.  If there is a change that requires extra work in the release process then the major version will be incremented by 1, so a Release 2.0.0 would require extra work to deploy over the top of a Release 1.x.x.
