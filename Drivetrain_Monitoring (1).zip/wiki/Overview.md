# Infrastructure Monitoring

## Introduction

This wiki is for the Infrastructure Monitoring package from DriveTrain, as part of the GMS-120 service line. The left navigation will lead you to important information regards installation and customisations for the product. As part of DriveTrain the package is [Inner Source](https://dev.azure.com/newsigcode/InnerSource) and open to contributions from all employees of New Signature, the link will explain in more details and also how to contribute.

## Overview

DriveTrain Infrastructure Monitoring deploys a collection of Azure Resources to one or more Azure Subscriptions in order to facilitate monitoring of an Azure Estate.

This is intended to allow implementation engineers a time-saving method to deploy New Signature best practice monitoring framework to a client.

It deploys the following items:

- A Log Analytics Workspace
- An Automation Account
- Azure Policy to enable diagnostics & link to the Log Analytics workspace for all supported resource types
- Pre-sets the deployed Log Analytics workspace to integrate with Security Centre, for cases where it may be enabled.
- An Action Group to forward all alert information via REST to New Signature ServiceNow
- 80+ Alerts
- Supporting configuration such as Solutions and Data Sources into the Log Analytics workspace.
- Security center configuration, and does not change pre-existing settings if using a pre-existing.

It supports either single-subscription,
or management group deployment.

### Alerting

The table below shows the severity of the alert after the criteria specified in the alert rule is met. Severity can range from 0 to 4.

| Severity | Description |
|-----------|:-----------:|
| 0 | Critical |
| 1 | Error |
| 2 | Warning |
| 3 | Informational |
| 4 | Verbose |

### Supporting materials
[NS:GO /Platform > GMS-120 IaaS and PaaS Management](https://cognizantlz1.sharepoint.com/portfoliocentral)

### Feedback

Any product feedback is very welcome! Please direct your feedback to:

- The _Infrastructure Monitoring_ teams channel in the Drivetrain Teams site.
- Jason Cotton - Service Architect
- Kevin Rickey - Product Owner

## Legal

It is required that a Master Services Agreement (MSA) is in place between New Signature and any customer where Drivetrain is used.

Please ensure that any code you contribute is either your own work, released under a permissive (non-copyleft) licence, or has been developed on a customer engagement where a Master Services Agreement is in place.
New Signature must retain the intellectual property rights in the customer MSA  in order to submit that content into DriveTrain.

If you have any questions or queries about this, please contact legal@newsignature.com.

**Add some work items** to breathe life into your release notes.
