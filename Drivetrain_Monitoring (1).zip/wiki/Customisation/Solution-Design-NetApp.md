# NetApp Storage Monitoring

This article describes Solution Design for adding Monitoring Alerts for NetApp Storage Volumes. It is divided into the following sections.

[[_TOC_]]

## Requirement

- SDM, needs to monitor the percentage of consumed volume size within NetApp to prevent P1 outages in an customer's business applications.

## Solution Design

![NetApp Monitoring Infrastructure Diagram](../.attachments/NetApp.png)

## Implementation Steps

- Arm template to create the metric alert for NetApp needs to be added to the package.
- Azure Automation Runbook that invokes Arm templated is deployed with monitoring package.
- Monitoring package installation will create the EventGridSubscription along with Webhook linking to runbook.
- NetApp creation should send the event to the EventGridSubscription that will trigger Webhook runbook execution and the NetApp ids will be passed in the context object to runbook. Runbook will then register the metric alert from Arm template with the ids from the context object.
