# Introduction

As part of the ongoing evolution of Cloud Native Monitoring, it was recognized that no single solution would be able to cover every requirement out of the box.
To address this it is possible to add customisations to the package after deployment.

## Customizations

- **New Rules Package** - [Add Customer Alert](../Customisation/Add-Custom-Alert-Package.md)
