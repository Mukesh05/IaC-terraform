# Overview

This article describes region support in the monitoring product. It is divided into the following sections:

- [Currently Supported Regions](#currently-supported-regions): describes the Microsoft defined region pairings that are currently available

- [Temporary workaround to add region support for releases 1.7.6 and earlier](#Temporary-Workaround-for-Region-Support): describes how to create the list of additional regions not currently listed for support in the monitoring product

- [Point in Time List of Regions and Region Pairings for the temporary workaround](#List-of-Regions-and-Pairings): a point-in-time copy of the above, for reference purposes

- [Unpaired Regions](#Unpaired-Regions): while these regions may support automation account resource types, these regions which have no listed/supported automation account pairings by Microsoft, and are therefore unsupported because they do not have the full feature set we require for the monitoring product

- [Unsupported Regions](#Unsupported-Regions): these regions are unsupported by the monitoring product because they lack the automation account resource type, and therefore cannot support features required by the monitoring product.

## Currently supported regions

These regions and automation account pairings are provided via the UI and available via the command line as well as of release v1.7.7.

| **Workspace Region Display Name** | **Workspace Region** |**Paired Automation Account Region Display Name**|**Paired Automation Account Region**|
|--|--|--|--|
|**US**|-|-|-|
|East US|	eastus|East US 2	|eastus2	|
|East US 2	|eastus2	|East US|	eastus|
|West US	|westus	|West US|	westus|
|West US 2	|westus2	|West US 2|	westus2|
|North Central US	|northcentralus|	North Central US|	northcentralus|
|Central US|	centralus	|Central US|	centralus|
|South Central US	|southcentralus	|South Central US|	southcentralus|
|**Brazil**|-|-|-|
|Brazil South|	brazilsouth	|Brazil South	|brazilsouth|
|**Canada**|-|-|-|
|Canada Central|canadacentral|Canada Central|canadacentral|
|**Asia Pacific**|-|-|-|
|East Asia	|eastasia	|East Asia	|eastasia|
|South East Asia	|southeastasia	|South East Asia	|southeastasia|
|**India**|-|-|-|
|Central India	|centralindia	|Central India|	centralindia|
|**Japan**|-|-|-|
|Japan East|japaneast|Japan East|japaneast|
|**Australia**|-|-|-|
|Australia East|	australiaeast	|Australia East	|australiaeast|
|Australia South East|	australiasoutheast|Australia South East|	australiasoutheast|
|**Korea**|-|-|-|
|Korea Central|	koreacentral	|Korea Central|	koreacentral|
|**Norway**|-|-|-|
|Norway East	|norwayeast|	Norway East|	norwayeast|
|**Europe**|-|-|-|
|West Europe|	westeurope|West Europe|	westeurope|
|North Europe|	northeurope	|North Europe|	northeurope|
|**France**|-|-|-|
|France Central	|francecentral	|France Central	|francecentral|
|**United Kingdom**|-|-|-|
|UK South|uksouth|UK South|uksouth|
|**Switzerland**|-|-|-|
|Switzerland North|	switzerlandnorth	|Switzerland North|	switzerlandnorth|
|**United Arab Emirates**|-|-|-|
|UAE North|	uaenorth|	UAE North	|uaenorth|
|**US Gov**|-|-|-|
|US Gov Virginia|usgovvirginia|US Gov Virginia|usgovvirginia|
|US Gov Arizona|usgovarizona|US Gov Arizona|usgovarizona|

US Government requires special terms and conditions to utilize (US Government), but is a supported region. Change tracking and inventory are currently not available in Arizona, but Patching is.

## Temporary Workaround for Region Support

**At your own risk**, you may add an Azure region for log analytics, and an automation account pairing directly into the JSON templates of our deployment.
Refer to the next table below for a region list and automation account pairing.
Alternately, to obtain the very latest region information, use the powershell command below and refer to Microsoft's support article.

```powershell
$ReleasedRegions = "australiaeast",
        "australiasoutheast",
        "brazilsouth",
        "canadacentral",
        "centralindia",
        "centralus",
        "eastasia",
        "eastus",
        "eastus2",
        "francecentral",
        "japaneast",
        "koreacentral",
        "northeurope",
        "northcentralus",
        "norwayeast",
        "southcentralus",
        "southeastasia",
        "switzerlandnorth",
        "uksouth",
        "usgovvirginia",
        "usgovarizona",
        "uaenorth",
        "westeurope",
        "westus",
        "westus2"

$newRegions = Get-AzLocation | Where-Object {$_.Location -notin $ReleasedRegions } `
                             | Where-Object {$_.Providers -Contains "Microsoft.OperationalInsights"}

# Show names only as a list
$newRegions.DisplayName
```

Once the region of interest is determined, refer to this article to determine the linked region that should be used

[Official List of Automation and Log Analytics Region Mappings](https://docs.microsoft.com/en-us/azure/automation/how-to/region-mappings#supported-mappings)

With the necessary region code information obtained, update two files in the deployment.

.\ARM\infrastructuremonitoring.json - parameters section

Use the list below and insert a new line with the Log Analytics region you are adding if it doesn't appear here.

``` ARM
    "ResourceLocation": {
        "type": "string",
        "defaultValue": "[resourceGroup().location]",
        "allowedValues": [
        "australiaeast",
        "australiasoutheast",
        "brazilsouth",
        "canadacentral",
        "centralindia",
        "centralus",
        "eastasia",
        "eastus",
        "eastus2",
        "francecentral",
        "japaneast",
        "koreacentral",
        "northeurope",
        "northcentralus",
        "norwayeast",
        "southcentralus",
        "southeastasia",
        "switzerlandnorth",
        "uksouth",
        "usgovvirginia",
        "usgovarizona",
        "uaenorth",
        "westeurope",
        "westus",
        "westus2"
        ],
        "metadata": {
        "description": "Location of resource"
        }
    }
```

.\ARM\workspaceDeploy.json - parameters section.

Use the code block below and insert a new line with the Log Analytics region you are adding if it's not present already.

``` ARM
    "ResourceLocation": {
      "type": "string",
      "defaultValue": "[resourceGroup().location]",
      "allowedValues": [
        "australiaeast",
        "australiasoutheast",
        "brazilsouth",
        "canadacentral",
        "centralindia",
        "centralus",
        "eastasia",
        "eastus",
        "eastus2",
        "francecentral",
        "japaneast",
        "koreacentral",
        "northeurope",
        "northcentralus",
        "norwayeast",
        "southcentralus",
        "southeastasia",
        "switzerlandnorth",
        "uksouth",
        "usgovvirginia",
        "usgovarizona",
        "uaenorth",
        "westeurope",
        "westus",
        "westus2"
      ],
      "metadata": {
        "description": "Location of resource"
      }
    },
```

.\ARM\workspaceDeploy.json
Use tne code block below and insert a new key value pair the region mapping. The key (first part) is the log analytics workspace region, the value (second part) is the automation account region if it's not present already.

``` ARM
    "LA-AutomationLinkedRegions": {
      "type": "object",
      "defaultValue": {
        "australiaeast": "australiaeast",
        "australiasoutheast": "australiasoutheast",
        "brazilsouth": "brazilsouth",
        "canadacentral": "canadacentral",
        "centralindia": "centralindia",
        "centralus": "centralus",
        "eastasia": "eastasia",
        "eastus": "eastus2",
        "eastus2": "eastus",
        "francecentral": "francecentral",
        "japaneast": "japaneast",
        "koreacentral": "koreacentral",
        "northeurope": "northeurope",
        "northcentralus": "northcentralus",
        "norwayeast": "norwayeast",
        "southcentralus": "southcentralus",
        "southeastasia": "southeastasia",
        "switzerlandnorth": "switzerlandnorth",
        "uksouth": "uksouth",
        "usgovvirginia": "usgovvirginia",
        "usgovarizona": "usgovarizona",
        "uaenorth": "uaenorth",
        "westeurope": "westeurope",
        "westus": "westus",
        "westus2": "westus2"
      },
      "metadata": {
        "description": "List of mapped Log Analytics regions to Azure Automation Account regions"
      }
    },
```

## Unpaired Regions

These Log Analytics regions have no paired Automation Account region. While they may have the necessary resource types in the region, they may not work for Virtual Machine Patching, Inventory, or VM Start/Stop Automation tasks.

| **Workspace Region Display Name** | **Workspace Region** |
|--|--|
|South Africa North|southafricanorth|
|Germany West Central|germanywestcentral|
|Switzerland West|switzerlandwest|
|Norway West|norwaywest|
|Brazil Southeast|brazilsoutheast|
|Japan West|japanwest|
|UK West|ukwest|
|South India|southindia|
|France South|francesouth|
|Australia Central|australiacentral|
|Australia Central 2|australiacentral2|
|UAE Central|uaecentral|

## Unsupported Regions

These regions do not support having a Microsoft Automation account resource type, and thus cannot support deployment of Monitoring as the resources cannot be fully deployed there.

| **Workspace Region Display Name** | **Workspace Region** |
|--|--|
|West India|westindia|
|Canada East|canadaeast|
|Korea South|koreasouth|
|South Africa West|southafricawest|
|Germany North|germanynorth|
|China East|chinaeast|

China East operated by 21 Vianet is currently an unsupported deployment location as it requires an alternate Azure Service Management API destination (China)
