# Introduction

Cloud Native Monitoring, has the ability to load an extra alert package, post install.  In order for the system to detect, and provide the installer the option to load this package, the ARM template containing the custom alerts needs to be written to a specific schema and placed in the correct location.

If the package is committed back to the DriveTrain repository, it will then become part of the standard package for future releases.

## Package Creation

All alert packages are to be placed into the Plugin folder, pre-installation, these are a basic arm template that the provided script will detect and inject into the installation with the correct parameters.  If you require more customization in your alerts, then you would have to do this in a different manner.

A basic file has been created, to get you started, this can be found at [ClientAlertTemplate.json](https://dev.azure.com/newsigcode/InnerSource/_git/Drivetrain_Monitoring?path=%2FInfrastructureMonitoring%2FARM%2FclientAlertsTemplate.json&version=GBRelease%2F1.4.1&_a=contents)

See the file [psgalerts.json](https://dev.azure.com/newsigcode/InnerSource/_git/Drivetrain_Monitoring?path=%2FInfrastructureMonitoring%2FPlugins%2FpsgAlerts.json&version=GBRelease%2F1.4.1&_a=contents) as an example of a custom alert pack with metric alerts.

## Alert Types

There are three Azure Monitor Alerts Types that are currently supported :-

- Metric Alerts. More information can be found [here](https://docs.microsoft.com/en-us/rest/api/monitor/metricalerts/createorupdate)
- Stored Query Alert (SQLAlerts)
- Stored Query Metric Alert. More information can be found [here](https://docs.microsoft.com/en-us/azure/azure-monitor/platform/alerts-unified-log#metric-measurement-alert-rules)

Each alert definition is stored within a variable array in the template, and passed to the actual ARM template that is used for the actual deployment.

## Schemas

All fields are mandatory.

### Metric Alerts

```json
{
    "name": "<string>",
    "description": "<string>",
    "severity": <integer>,
    "autoMitigate": <boolean>,
    "evaluationFrequency": "<string>",
    "windowSize": "<string>",
    "criterion": {
    "threshold": <integer>,
    "name": "<string>",
    "metricName": "<string>",
    "dimensions": [
        {
            "name": "<string>",
            "operator": "<string>",
            "values": [
                "*"
            ]
        }
    ],
    "operator": "<string>",
    "timeAggregation": "<string>
    }
}
```

### SQR Alerts

```json
{
    "name": "<string>",
    "description": "<string>",
    "severity": "<integer>",
    "schedule": {
    "frequency": <integer>,
    "timeWindow": <integer>
    },
    "source": {
        "dataQuery": "<string>",
        "sourceId": "[resourceId('microsoft.operationalinsights/workspaces', parameters('workspaceName'))]",
        "queryType": "ResultCount"
    },
    "trigger": {
        "operator": "<string>",
        "threshold": "<integer>"
    }
}
```

### SQL Metrics

```json
{
    "description": "<string>",
    "severity": "2",
    "schedule": {
        "frequency": <integer>,
        "timeWindow": <integer>
    },
    "source": {
        "query": "<string>",
        "dataSourceId": "[resourceId('microsoft.operationalinsights/workspaces', parameters('workspaceName'))]",
        "queryType": "ResultCount"
    },
    "trigger": {
        "thresholdOperator": "<string>",
        "threshold": "<integer>"
    },
    "metricTrigger": {
        "thresholdOperator": "<string>",
        "threshold": "<integer>",
        "metricTriggerType": "<string>",
        "metricColumn": "<string>"
    }
}
```
