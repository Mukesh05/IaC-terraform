# Installing Drivetrain monitoring while maintaining data configuration

There are situations whereby clients/IT Ops would decide to install Drivetrain infrastructure monitoring while attempting to maintain their log analytics and automation account configuration. In this area, I will explain the issues that I could be faced while attempting to achieve the above.

## Key Findings

- When drivetrain monitoring is deployed to the same resource group using the existing automation account, then the  deployment would fail and returns the following error,

*Account already exists in another resource group in a subscription. ResourceGroupName: xxx*

![](/.attachments/issue1.png)

- When drivetrain monitoring is deployed to the resource group which contains unsupported resources such as Virtual Machines which maybe the sources for data collection, then the deployment will return this error,

*This Resource Group contains resources outside of the Drivetrain this is unsupported. Terminating*

![](/.attachments\issue2.png)

- When drivetrain monitoring is deployed to the resource group with the automation account and log analytics only then the deployment will return the below error,

![](/.attachments/Picture3.png)

To fix the above error, the IT ops admin would have to check the log analytics workspace and untick the the following options in the diagnostic settings,

![](/.attachments/Picture4.png)
![](/.attachments/Picture5.png)





