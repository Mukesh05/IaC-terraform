# Introduction

This area attempts to document a list of of network requirements so that a project team can fullfil the requirements in Azure or on-premises to allow monitoring and related services such as, ASR, Backup, Update Management to function in a client's environment once monitoring is deployed and onboarded. This is important for clients/servers that block outbound internet access by default and require firewall rules to permit network communication to the above services.

## Require addition of NSG and/or Firewall rules for all of the following Service Tags

- AzureAdvancedThreatProtection
- AzureBackup
- AzureMonitor
- AzureSiteRecovery
- Storage
- AzureActiveDirectory
- AzureKeyVault
- EventHub
- GuestAndHybridManagement

## Require addition of rules on NSG and/or Firewall using FQDN (Preview) wildcard addresses for all of these Windows Update addresses

- http://windowsupdate.microsoft.com
- http://*.windowsupdate.microsoft.com
- https://*.windowsupdate.microsoft.com
- http://*.update.microsoft.com
- https://*.update.microsoft.com
- http://*.windowsupdate.com
- http://download.windowsupdate.com
- https://download.microsoft.com
- http://*.download.windowsupdate.com
- http://wustat.windows.com
- http://ntservicepack.microsoft.com
- http://go.microsoft.com
- http://dl.delivery.mp.microsoft.com
- https://dl.delivery.mp.microsoft.com

## More Information

- https://docs.microsoft.com/en-us/azure/virtual-network/service-tags-overview

- https://docs.microsoft.com/en-us/azure/automation/update-management/update-mgmt-overview

- https://docs.microsoft.com/en-us/windows-server/administration/windows-server-update-services/deploy/2-configure-wsus
