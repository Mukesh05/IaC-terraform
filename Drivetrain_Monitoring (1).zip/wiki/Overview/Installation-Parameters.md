# Overview

Whilst the basic installation of Infrastructure Monitoring is UI driven, this mode makes a lot of assumptions and will only ask for the basic information required. If it is required to override items such as basic naming conventions, deployable locations etc or if it is required to be able to script the complete installation then the use of the command line parameters is recommended.

The following outlines the complete command line parameters and defines when these should be used to override the defaults.

## Installation Parameters

Running the installer will prompt you interactively to supply needed parameters.
Below is a list of the supported parameters for installation, these parameters may also be supplied as command line parameters to the installer for use in non-interactive scenarios.

The template requires some parameters to ensure the deployment is correct

|**Parameter**|**Default**|**Valid Values**|**Usage**|
|--|--|--|--|
|Architecture|Single|Single \| Multiple|Deployment for a Single Subscription, or Hub and Spoke using a Management Group|
|AzureTenantId|none/prompted|[<Tenant GUID>](https://docs.microsoft.com/en-us/onedrive/find-your-office-365-tenant-id)|The Azure Tenant Id to deploy the solution into.|
|AzureSubscription|none/prompted|[<Subscription GUID>](https://docs.microsoft.com/en-us/powershell/module/az.accounts/get-azsubscription?view=azps-4.2.0)|The Azure Subscription Id to deploy the solution into|
|ResourceGroupName|none/prompt|[Azure Resource Group Name](https://docs.microsoft.com/en-us/powershell/module/az.resources/new-azresourcegroup?view=azps-4.2.0)|Overrides the default resource group name, to allow when a client has implemented their own solution|
|ResourceGroupLocation|none/prompt|[Azure Region Name Syntax](https://docs.microsoft.com/en-us/powershell/module/az.resources/get-azlocation?view=azps-4.2.0) |The geographic location ID to deploy the solution into|
|ManagementGroupId|none/prompt|[A Pre-existing Management Group ID](https://docs.microsoft.com/en-us/powershell/module/az.resources/get-azmanagementgroup?view=azps-4.2.0)|(Multi-subscription only) Defines the Id of the root management group of all subscriptions to be monitored|
|Environment|none/prompt|DEV \| TEST \| PROD|The environment (DEV, TEST or PROD). PROD will deploy with a 365 day retention and route alerts to the Production Service Now instance. DEV or TEST use 31 day retention and route to the DEV or TEST  ServiceNow instances respectively.|
|ServiceNowToken|0CB387C5-EDB0-4A5E-8956-12E64DFC041B|<Token GUID>|The customer's Service Now Token assigned by New Signature. <br><br>The token determines what company name Alerts are bound to in ServiceNow. <br><br>DEV and TEST deployments use the "NS Development" company name token ('0CB387C5-EDB0-4A5E-8956-12E64DFC041B'). <br><br>PROD deployment will prompt for the customer specific token if it is not specified.<br><br> The token from the deployment is forms part of the URL set in the action group Webhook during deployment||workspaceName|Override the default Log Analytics Name, should only be used when the client has an exisitng Log Analytics Workspace|
|workspaceName|System Generated|[Globally Unique Workspace Name](https://docs.microsoft.com/en-us/azure/azure-monitor/platform/powershell-workspace-configuration)|Override the default Log Analytics workspace name. Can be used to create a new workspace with a specific name, or to utilize a named workspace in the Resource Group specified with the ResourceGroupName parameter|
|appInsightName|System Generated|[Applicaton Insights Workspace Resource Name](https://docs.microsoft.com/en-us/azure/azure-monitor/app/powershell)| Override the default Application Insights workspace name. Should only be used when the client has an existing App Insights Workspace, in the same resource group as the Log Analytics Workspace, or to specify a name for a new application insights workspace name|
|automationAccountName|System Generated|[Automation Account Resource Name](https://docs.microsoft.com/en-us/azure/automation/automation-create-standalone-account)|Override the default Automation Account Name. Should only be used when the client has an existing Automation Account, in the same resource group as the Log Analytics Workspace.|
|EnableCAS|No|Yes \| No|Enables the Common Alert Schema, this should ony be used under direction of the Product Owner|
|SkipAutoUpdate|_No_ | n/a |Switch parameter, does not accept a value<br><br>When set, skips the check for auto downloading newer version in the release branch. Recommended only for use in fully automated deployments|
|AlertEmailName|none|[Contact Name](https://docs.microsoft.com/en-us/azure/azure-monitor/platform/action-groups)|If set, appends an Email action to the Action Group. Also requires the AlertEmailAddress parameter to be set|
|AlertEmailAddress|none|[Email Address](https://docs.microsoft.com/en-us/azure/azure-monitor/platform/action-groups)|If set, appends an Email action to the Action Group.  Also requires the AlertEmailName parameter to be set|
|Plugin|None/prompt|Filename|If set, Name of the file containing the custom alert rules to be deployed. <br><br>Specify empty string '' for automated deployments|
|SkipUserCheck|_No_|n/a|Switch parameter, does not accept a value<br><br> When set, uses the existing Azure session in PowerShell|
|EnableSecurity|None/prompt| $True \| $False | Enables Security Center Standard at deployment time|
|SourceFolder|none|Folder Path Variable|Developer use only|

## Samples

### Specify Existing Resource Group and Log Analytics Workspace

``` PowerShell
.\Install-InfrastructureMonitoring.ps1 -ResourceGroupName "ExistingResourceGroup" -workspaceName "ExistingWorkspaceName"
```

### Specify Existing Resource Group with Resources in Different Location

``` PowerShell
.\Install-InfrastructureMonitoring.ps1 -ResourceGroupName "ExistingResourceGroup" -ResourceGroupLocation "EastUS"
```

### After Authentication to a None New Signature Tenancy

``` PowerShell
.\Install-InfrastructureMonitoring.ps1 -SkipUserCheck -SkipAutoUpdate
```

### Deploy to DEV in a single subscription

``` PowerShell
.\Install-InfrastructureMonitoring.ps1 -Architecture "Single" -Environment "Dev"
```

### Deploy to PROD with Security Center Standard enabled

``` PowerShell
.\Install-InfrastructureMonitoring.ps1 -Environment "Prod" -EnableSecurity "Y"
```

### Deploy to PROD with HLD and management group

``` PowerShell
.\Install-InfrastructureMonitoring.ps1 -Architecture "Multiple" -Environment "Prod"
```

### Deploy format using all available parameters

``` PowerShell
.\Install-InfrastructureMonitoring.ps1 -Architecture 'single' `
                                       -AzureTenantId 'UserTenantId' `
                                       -AzureSubscription 'UserSubscriptionId' `
                                       -ResourceGroupName 'mygrouprg' `
                                       -ResourceGroupLocation 'uksouth' `
                                       -ManagementGroupId 'ExsitingManagementGroupId' `
                                       -Environment 'Dev' `
                                       -workspaceName 'ExistingWorkspaceName' `
                                       -EnableSecurity $false `
                                       -SkipUserCheck
```

### Deploy to PROD without alerts for non-managed service customers

``` PowerShell
.\Install-InfrastructureMonitoring.ps1 -Environment "Prod" -EnableCAS "N"
```
