# Overview

This page is used to document the alert rules deployed with Infrastructure Monitoring, including their out of the box configuration. While it is possible to adjust the settings/thresholds for an alert rule to fit the needs of a given customer (a process referred to as 'Tuning') it is important to note that these changes are not permanent, and will be reverted to OOTB configuration upon upgrading to a new version of Infrastructure Monitoring. It is for this reason that we strongly recommend filing change requests before any tuning takes place, to ensure the settings can be recreated accurately following an upgrade.

[[_TOC_]]

## Table Column Legend

Below is a description of the columns used by tables through the rest of this page.

|**Category**|**Description**|
|----|----|
|Category| Logical grouping based on the Azure Resource or service this alert applies to|
|Azure Alert Name|The name of the Alert rule as it appears in the Azure Portal|
|Affected Resource|The Azure Resource that generates the data for this alert|
|Azure Severity|The severity of the Alert as seen in the Azure Portal|
|Threshold Type|The type of threshold for the alert based on the alert class|
|Threshold|The condition and value of the threshold|
|Data Period|How far back in time the query analyzes data for the alert|
|Evaluation Frequency|How frequently the alert rule is executed, also the minimum time period the alert would be generated|
|Event Log|The Event Log that contains the Event IDs, as seen in Log Analytics Advanced Settings|
|Event IDs|The Event IDs that are monitored for the alert|
|Object|The performance counter object that contains the performance counter|
|Performance Counter|The performance counter that is monitored by this alert|
|Schema|The alert class that determines what JSON payload is sent to ServiceNow|
|Source|The log analytics table or other source of Azure data where the data is stored|
|Released|The Infrastructure Monitoring version this alert introduced in|

## Log Analytics Workspace

The sections below detail the alert rules, data sources and solutions that are deployed with the Log Analytics workspace.

## Data Sources

This section details the Data Sources that are ingested by Log Analytics on Virtual Machines.

### Windows Event Logs

- The following event logs are collected from Windows Virtual Machines running the Microsoft Management Agent

| **Windows Event Log**                             | **Error** | **Warning** | **Information** |
| ------------------------------------------------- | --------- | ----------- | --------------- |
| Application                                       | X         | X           | X               |
| CloudBackup/Operational                           | X         | X           | X               |
| DNS-Server                                        | X         | X           | X               |
| Microsoft-Windows-Backup                          | X         | X           | X               |
| Microsoft-Windows-Backup/Operational              | X         | X           | X               |
| Microsoft-Windows-CloudBackup/Operational         | X         | X           | X               |
| Microsoft-Windows-GroupPolicy/Operational         | X         | X           | X               |
| Microsoft-Windows-Ntfs/Operational                | X         | X           | X               |
| Microsoft-Windows-WindowsUpdateClient/Operational | X         | X           | X               |
| MicrosoftAzureRecoveryServices/Replication        | X         | X           | X               |
| Setup                                             | X         | X           | X               |
| System                                            | X         | X           | X               |
| DFS-Replication                                   | X         | X           | X               |
| DhcpAdminEvents                                   | X         | X           | X               |

### Windows Performance Counters

- The following performance counters are collected from Windows Virtual Machines running the Microsoft Management Agent

| **Object**              | **Performance Counter**        | **Interval (sec)** |
| ----------------------- | ------------------------------ | ------------------ |
| LogicalDisk(*)          | % Free Space                   | 60                 |
| LogicalDisk(*)          | % Idle time                    | 60                 |
| LogicalDisk(*)          | Avg. Disk Queue Length         | 60                 |
| LogicalDisk(*)          | Avg. Disk sec/Read             | 60                 |
| LogicalDisk(*)          | Avg. Disk sec/Write            | 60                 |
| LogicalDisk(*)          | Current Disk Queue Length      | 60                 |
| LogicalDisk(*)          | Disk Bytes/sec                 | 60                 |
| LogicalDisk(*)          | Disk Reads/sec                 | 60                 |
| LogicalDisk(*)          | Disk Transfers/sec             | 60                 |
| LogicalDisk(*)          | Disk Writes/sec                | 60                 |
| LogicalDisk(*)          | Free Megabytes                 | 60                 |
| LogicalDisk(*)          | Idle time                      | 60                 |
| Memory(*)               | % Committed Bytes In Use       | 60                 |
| Memory(*)               | Available MBytes               | 60                 |
| Memory(*)               | Free System Page Table Entries | 60                 |
| Memory(*)               | Pages/sec                      | 60                 |
| Network Adapter(*)      | Bytes Received/sec             | 60                 |
| Network Adapter(*)      | Bytes Sent/sec                 | 60                 |
| Network Adapter(*)      | Bytes Total/sec                | 60                 |
| Network Interface(*)    | Bytes Total/sec                | 60                 |
| Processor(_Total)       | % Processor Time               | 60                 |
| Processor(*)            | CPU Utilization                | 60                 |
| SQLServer:Locks(_Total) | Average Wait Time (ms)         | 900                |
| System(*)               | Processor Queue Length         | 60                 |

### Linux Performance Counters

- The following performance counters are collected from Linux Virtual Machines running the MMA Agent
- Where the object and counter name are an exact match for the Windows equivalent, metric and log search alerts using those counters will fire alerts
- Where counters do not match a unique alert rule is required for Linux operating systems

| **Object**      | **Performance Counter** | **Interval (sec)** |
| --------------- | ----------------------- | ------------------ |
| Logical Disk(*) | % Used Inodes           | 60                 |
| Logical Disk(*) | Free Megabytes          | 60                 |
| Logical Disk(*) | % Used Space            | 60                 |
| Logical Disk(*) | Disk Transfers/sec      | 60                 |
| Logical Disk(*) | Disk Reads/sec          | 60                 |
| Logical Disk(*) | Disk Writes/sec         | 60                 |
| Logical Disk(*) | % Used Swap Space       | 60                 |
| Memory(*)       | % Used Memory           | 60                 |
| Memory(*)       | Available MBytes Memory | 60                 |
| Memory(*)       | % Used Swap Space       | 60                 |
| Processor(*)    | % Processor Time        | 60                 |
| System(*)       | Uptime                  | 60                 |

### Linux System Logs

- Log data is collected for the following facilities on Linux

| **Facility Name** | **Emergency** | **Alert** | **Critical** | **Error** | **Warning** | **Notice** | **Info** | **Debug** |
| ----------------- | ------------- | --------- | ------------ | --------- | ----------- | ---------- | -------- | --------- |
| kern              | x             | x         | x            | x         | x           |            | x        |           |
| syslog            | x             | x         | x            | x         |             | x          | x        |           |

### Solutions

The following solutions are deployed with the Log Analytics workspace. These solutions provide a dashboard for their respective solution areas

| Solution                  | Description                                   | Link                                                         |
| ------------------------- | --------------------------------------------- | ------------------------------------------------------------ |
| ADAssessment              | Health checks on Active Directory             | [Details](https://docs.microsoft.com/en-us/azure/azure-monitor/insights/ad-assessment) |
| ADReplication             | Monitoring for Active Directory replication   | [Details](https://docs.microsoft.com/en-us/azure/azure-monitor/insights/ad-replication-status) |
| AzureActivity             | Details on Azure subscription activity        |                                                              |
| AzureAppGatewayAnalytics  | Application Gateway Analytics                 | [Details](https://docs.microsoft.com/en-us/azure/azure-monitor/insights/azure-networking-analytics) |
| AzureDataFactoryAnalytics | Data Factory Analytics                        | [Details](https://docs.microsoft.com/en-us/azure/data-factory/monitor-using-azure-monitor) |
| AzureSQLAnalytics         | Azure SQL Analytics                           | [Details](https://docs.microsoft.com/en-us/azure/azure-monitor/insights/azure-sql) |
| ChangeTracking            | Change Tracking                               | [Details](https://docs.microsoft.com/en-us/azure/automation/change-tracking) |
| CompatibilityAssessment   | Upgrade Readiness for Windows 10              |                                                              |
| Containers                | Container Monitoring Solution                 | [Details](https://docs.microsoft.com/en-us/azure/azure-monitor/insights/containers) |
| InfrastructureInsights    | Infrastructure Insights                       |                                                              |
| KeyVaultAnalytics         | Key Vault Analytics                           |                                                              |
| LogicAppsManagement       | Logic Apps Management                         |                                                              |
| NetworkMonitoring         | Network Performance Monitoring                | [Details](https://docs.microsoft.com/en-us/azure/azure-monitor/insights/azure-networking-analytics) |
| Security                  | Security and Audit (Security Center Standard) |                                                              |
| SecurityCenterFree        | Free version of Security Center               |                                                              |
| SecurityInsights          | Security Insights for Azure Sentinel          |                                                              |
| ServiceMap                | Application component discovery               | [Details](https://docs.microsoft.com/en-us/azure/azure-monitor/insights/service-map) |
| Updates                   | System Update Assessment                      |                                                              |
| WaaSUpdateInsights        | Updates Compliance                            |                                                              |
| WireData2                 | Wire Data 2.0                                 | [Details](https://docs.microsoft.com/en-us/azure/azure-monitor/insights/wire-data) |

## Virtual Machine Alerts

This section and it's subsections describe the alert rules in place for monitoring Azure Virtual Machine resources and, to a lesser extent, servers that reside outside of Azure but are configured to report to the Infrastructure Monitoring Log Analytics workspace.

### Windows Virtual Machine Event Log Alerts

|**Service Code/SKU**|**Category**|**Azure Alert Name**|**Affected Resource**|**Azure Severity**|**Threshold Type**|**Threshold**|**Data Period**|**Evaluation Frequency**|**Schema**|**Source**|**Event Log**|**Event IDs**|**Released**|
|--|--|--|--|--|--|--|--|--|--|--|--|--|--|
|GMS-SOSM  |Virtual Machine  |VM Availability - Restart or Shutdown Event  |MMA Agents  |1  |Static  |Total > 0 |5 minutes|5 minutes |Metric  |Events|System|1074|1.1.0|
|GMS-SOSM  |Virtual Machine  |VM Stop Error  |MMA Agents  |1  |Static  |Total > 0 |5 minutes|5 minutes |Metric  |Events|System|1001|1.1.0|
|GMS-SOSM  |Virtual Machine  |Windows Service unexpected error  |MMA Agents  |1  |Static  |Count > 0|5 minutes|5 minutes  |Metric |Events|System|7024, 7031, 7034|1.1.0|
|GMS-SOSM  |Virtual Machine  |VM Application Fault|MMA Agents  |3  |Results|Count > 0 |5 minutes|5 minutes |Log Search|Events|Application|1000|1.1.0|
|GMS-ADMA  |Virtual Machine  |Active Directory GPO lookup failure|MMA Agents  | 2 |Results|Count > 0 |5 minutes|5 minutes  |Log Search  |Events|Microsoft-Windows-GroupPolicy/Operational|1030|1.1.0|
|GMS-DR |Backup |Backup - VM Mars Agent Backup Failure|MMA Agent  |1  |Results  | Count > 0 |1 hour|1 hour|Log Search  |Event Log|Microsoft-Windows-CloudBackup/Operational|n/a|1.1.0|
|GMS-SOSM  |Security  |Local security group changed|MMA Agent  |2  |Results  |Count > 0 |5 minutes|5 minutes |Log Search  |Events|Security|4732, 4733, 4735|1.1.0|
|GMS-SOSM  |Virtual Machine Availability  |NTFS Errors|MMA Agents  |2  | Results |Count > 0   |5 minutes|5 minutes|Log Search  |Events|Microsoft-Windows-Ntfs/Operational|n/a|1.1.0|
|GMS-SOSM  |Security  |Security - VM Cleared Security Event Logs|MMA Agents  |1  |Results  |Count  |5 minutes|5 minutes|Log Search  |Events|Security|517, 1102|1.1.0|
|GMS-SOSM  |Security  |Security - VM Multiple Account Logon Failure|MMA Agents  | 1 | Results |Count > 0  |5 minutes|5 minutes|Log Search  |Events|Security|4625|1.1.0|
|GMS-SWM|SQL Server Workload|SQL Server agent job failed|MMA Agents  |3  |Results  |Count > 0  |5 minutes|5 minutes|Log Search  |Events|Application|208|1.3.0|
|GMS-SWM  |SQL Server Workload  |SQL Server Availability Group failover|MMA Agents  |2  | Results |Count > 0 |5 minutes|5 minutes |Log Search  |Events|Application|26069|1.3.1|
|GMS-SWM  |SQL Server Workload  |SQL Server Database Backup Failed|MMA Agents  |1  |Results  |Coount > 0   |5 minutes|5 minutes|Log Search  |Events|Application|3041|1.1.0|
|GMS-SWM  |SQL Server Workload  |SQL Server filegroup out of space|MMA Agents  | 1 |Results  |Count > 0 |5 minutes|5 minutes |Log Search  |Events|Application|1101|1.1.0|
|GMS-SWM  |SQL Server Workload  |SQL Server logon failed|MMA Agents  | 2 |Results  |Count > 0  |30 minutes|30 minutes|Log Search  |Events|Application|18456|1.1.0|
|GMS-SWM  |SQL Server Workload  |SQL Server Replica role changed|MMA Agents  |2|Results| Count > 0 | 5 minutes  | 5 minutes |Log Search  |Events|Application|19406|1.1.0|
|GMS-SOSM |Virtual Machine |VM Availability - Unexpected Shutdown|MMA Agents  |1  |Results  |Count > 0  |5 minutes|5 minutes|Log Search  |Events|System|6008|1.1.0|
|GMS-ADMA|Active Directory Workload|Active Directory Domain Services service has stopped running|MMA Agents|1|Results|Count > 0|5 minutes|5 minutes|Log Search|Events|System|7036|1.5.0|
|GMS-ADMA|Active Directory Workload|DFS Replication Service has stopped running|MMA Agents|1|Results|Count > 0|5 minutes|5 minutes|Log Search|Events|System|7036|1.5.0|
|GMS-ADMA|Active Directory Workload|DNS Server service has stopped running|MMA Agents|1|Results|Count > 0|5 minutes|5 minutes|Log Search|Events|System|7036|1.5.0|
|GMS-ADMA|Active Directory Workload|Group Policy Client service has stopped running|MMA Agents|1|Results|Count > 0|5 minutes|5 minutes|Log Search|Events|System|7036|1.5.0|
|GMS-ADMA|Active Directory Workload|Kerberos Key Distribution Center service has stopped running|MMA Agents|1|Results|Count > 0|5 minutes|5 minutes|Log Search|Events|System|7036|1.5.0|
|GMS-ADMA|Active Directory Workload|Netlogon service has stopped running|MMA Agents|1|Results|Count > 0|5 minutes|5 minutes|Log Search|Events|System|7036|1.5.0|
|GMS-ADMA|Active Directory Workload|Windows Time service has stopped running|MMA Agents|1|Results|Count > 0|5 minutes|5 minutes|Log Search|Events|System|7036|1.5.0|
|GMS-ADMA|Active Directory Workload|DHCP Server service has stopped running|MMA Agents|1|Results|Count > 0|5 minutes|5 minutes|Log Search|Events|System|7036|1.5.0|
|GMS-ADMA|Active Directory Workload|AD Federation Services service has stopped running|MMA Agents|1|Results|Count > 0|5 minutes|5 minutes|Log Search|Events|System|7036|1.5.0|
|GMS-ADMA|Active Directory Workload|SYSVOL replication failure|MMA Agents|1|Results|Count > 0|5 minutes|5 minutes|Log Search|Events|DFS-Replication|7036|1.5.0|
|GMS-ADMA|Active Directory Workload|Active Directory - DNS Integration failure|MMA Agents|1|Results|Count > 0|5 minutes|5 minutes|Log Search|Events|DNS-Server|n/a|1.5.0|
|GMS-ADMA|Active Directory Workload|Netlogon failed to create a share|MMA Agents|1|Results|Count > 0|5 minutes|5 minutes|Log Search|Events|System|5706|1.5.0|
|GMS-ADMA|Active Directory Workload|DHCP Server - No addresses available for lease|MMA Agents|1|Results|Count > 0|5 minutes|5 minutes|Log Search|Events|DhcpAdminEvents|1063|1.5.0|
|GMS-ADMA|Active Directory Workload|DHCP Server - Scope is low on leasable addresses|MMA Agents|1|Results|Count > 0|5 minutes|5 minutes|Log Search|Events|DhcpAdminEvents|1020|1.5.0|
|GMS-ADMA|Active Directory Workload|Local clock is not syncing|MMA Agents|1|Results|Count > 0|5 minutes|5 minutes|Log Search|Events|System|142|1.5.0|
<br>

### Windows Virtual Machine Performance Metric Alerts

|**Service Code/SKU**|**Category**|**Azure Alert Name**|**Affected Resource**|**Azure Severity**|**Threshold Type**|**Threshold**|**Data Period**|**Evaluation Frequency**|**Schema**|**Source**|**Object**|**Performance Counter**|**Released**|
|--|--|--|--|--|--|--|--|--|--|--|--|--|--|
|GMS-SOSM  |Virtual Machine  |Average Disk Queue length is high  |MMA Agents  |1  |Static| Average > 40 |1 hour|1 hour |Metric  |Performance Metrics|LogicalDisk(*)|Current Disk Queue Length|1.1.0|
|GMS-SOSM  |Virtual Machine  |Committed Memory percentage is high - Metric  |MMA Agents  |1  |Static|Average > 70 |1 hour  |1 hour  |Metric  |Performance Metrics|Memory(*)|% Committed Bytes|1.1.0|
|GMS-SOSM  |Virtual Machine  |Linux VM Swap  |MMA Agents  | 2 |Static  |Maximum > 95|15 minutes|5 minutes |Metric  |Performance Metrics|Memory(*)|% Used Swap Space|1.1.0|
|GMS-SOSM |Virtual Machine |Processor utilization is high  |MMA Agents  | 2 |Static|Maximum > 90 |1 hour |1 hour |Metric  |Performance Metrics|Processor(_Total)|% Processor Time|1.1.0|
|GMS-SOSM  |Virtual Machine  |VM - Free disk space MB critical  |MMA Agents  |1  |Static  |Minimum < 1000|5 minutes|1 minute |Metric  |Performance Metrics|LogicalDisk(*)|Free Megabytes|1.4.0|
|GMS-SOSM  |Virtual Machine  |VM - Free disk space MB warning  |MMA Agents  |1  |Static  |Minimum < 5000 |1 hour|1 hour |Metric  |Performance Metrics|LogicalDisk(*)|Free Megabytes|1.4.0|
|GMS-SOSM  |Virtual Machine  |VM - Free disk space percentage critical  |MMA Agents|1  |Static  |Minimum < 1  |1 hour|1 hour |Metric  |Performance Metrics|LogicalDisk(*)|% Free Space|1.4.0|
|GMS-SOSM  |Virtual Machine  |VM - Free disk space percentage warning  |MMA Agents  |1  |Static  |Minimum < 5 |1 hour|1 hour |Metric  |Performance Metrics|LogicalDisk(*)|% Free Space|1.4.0|
|GMS-SOSM  |Virtual Machine  |VM - Low Available MB Memory  |MMA Agents  |2  |Static |Minimum < 100|1 hour|1 hour  |Metric  |Performance Metrics|Memory(*)|Available MBytes|1.1.0|
|GMS-SOSM  |Virtual Machine  |Linux free disk space|MMA Agent  |2  |Results  |Count > 0|5 minutes|5 minutes |Log Search  |Performance Metrics|Logical Disk(*)|Free Megabytes|1.1.0|
|GMS-SWM|SQL Server Workload|SQL Lock Wait Time high|MMA Agents  | 1 |Results  |Count > 0  |5 minutes|5 minutes|Log Search  |Performance Metrics|SQLServer:Locks(_Total)|Average Wait Time (ms)|1.2.0|
<br><br>

### Virtual Machine Availability

|**Service Code/SKU**|**Category**|**Azure Alert Name**|**Affected Resource**|**Azure Severity**|**Threshold Type**|**Threshold**|**Data Period**|**Evaluation Frequency**|**Schema**|**Source**|**Released**|
|--|--|--|--|--|--|--|--|--|--|--|--|
|GMS-SOSM |Virtual Machine |VM Availability|MMA Agents  | 2 |Results  |Count > 0 |5 minutes|5 minutes |Log Search  |Heartbeat|1.1.0|
|GMS-SOSM |Virtual Machine |VM Availability - VM Stopped in Portal|Virtual Machines | 1 |Results  |Count > 0 |30 minutes|30 minutes  |Log Search  |Subscription Activity Log|1.1.0|
|GMS-SOSM  |Virtual Machine  |New Azure Virtual Machine Created|Virtual Machines  |3  | Results |Count > 0  |1 hour | 1 hour|Log Search  |Subscription Activity Log|1.2.0|
|GMS-SOSM  |Virtual Machine  |VM Availability - Heartbeat Failure  |MMA Agents  |2  |Results  |Count > 0  |30 minutes|5 minutes|Metric  |Heartbeat|1.5.0|
|GMS-SOSM  |Virtual Machine  |VM Availability - Linux Uptime below threshold  |MMA Agents  |2  |Static  |Minimum < 600 |15 minutes|5 minutes |Metric  |Uptime|1.1.0|

<br><br>

### Windows Server Patching/Defender Hygiene

|**Service Code/SKU**|**Category**|**Azure Alert Name**|**Affected Resource**|**Azure Severity**|**Threshold Type**|**Threshold**|**Data Period**|**Evaluation Frequency**|**Schema**|**Source**|**Released**|
|--|--|--|--|--|--|--|--|--|--|--|--|
|GMS-SOSP-*  |Patching  |Servers Pending Reboot for Update Installation|MMA Agents  |3  | Results |Count > 0  |24 hours|24 hours|Log Search  |Windows as a Service Deployment Status|1.1.0|
|GMS-SOSP-*  |Patching  |Updates Pending Restart|MMA Agent  | 3 |Results  |Count > 0  |5 minutes|5 minutes|Log Search  |Update Summary|1.1.0|
|GMS-WSDH|Endpoint Protection|Missing endpoint protection|MMA Agent  | 2 |Results  |Count > 0  |24 hours|24 hours|Log Search  |Protection Status|1.1.0|
|GMS-WSDH|Endpoint Protection|Windows Defender - Potential threat detected|MMA Agent  |1  |Results  |Count > 0  |1 hour|1 hour|Log Search  |Protection Status|1.5.0|
|GMS-WSDH|Endpoint Protection|Windows Defender - Protection vulnerability detected|MMA Agent  |2  |Results  |Count > 0  |4 hours|4 hours|Log Search  |Protection Status|1.5.0|

<br><br>

### Backup and Disaster Recovery

|**Service Code/SKU**|**Category**|**Azure Alert Name**|**Affected Resource**|**Azure Severity**|**Threshold Type**|**Threshold**|**Data Period**|**Evaluation Frequency**|**Schema**|**Source**|**Released**|
|--|--|--|--|--|--|--|--|--|--|--|--|
|GMS-DR  |Backup  |Azure Site Recovery Critical Health|Recovery Services Vault  |1  |Results  |Count > 0  |5 minutes|5 minutes|Log Search  |Diagnostics|1.2.0|
|GMS-BR  |Backup  |Backup - Azure VM Managed Backup Failure|Recovery Services Vault  |2  |Results  |Count > 0  |1 hour|1 hour|Log Search  |Diagnostics|1.2.0|

<br><br>

## Azure Platform Services/Resource Alerts

The following sections describe the alert rules built to monitor Azure PaaS services (i.e. Azure SQL, Data Factories etc.).

### Azure SQL/MySQL

|**Service Code/SKU**|**Category**|**Azure Alert Name**|**Affected Resource**|**Azure Severity**|**Threshold Type**|**Threshold**|**Data Period**|**Evaluation Frequency**|**Schema**|**Source**|**Released**|
|--|--|--|--|--|--|--|--|--|--|--|--|
|GMS-PM  |Azure SQL  |Azure SQL - Managed Instance CPU Utilization High|Azure SQL Managed Instance  |2  |Metric Measurement  |Metric > 85 and Consecutive braeches > 0 |1 hour|1 hour |Log Search  |Diagnostics|1.2.0|
|GMS-PM  |Azure SQL  |Azure SQL - Managed Instance Storage Quota Consumption|Azure SQL Managed Instance  | 2  |Metric Measurement  |Metric > 85 and Consecutive braeches > 0 |1 hour|1 hour |Log Search  |Diagnostics|1.2.0|
|GMS-PM  |Azure SQL  |Azure SQL Delete Activity|Azure SQL Server  |1  | Results |Count > 0  |1 hour|1 hour|Log Search  |Subscription Activity Log|1.2.0|
|GMS-PM  |Azure SQL  |Azure SQL log write iops above threshold|Azure SQL  |2  |Metric Measurement  |Metric > 75 and Consecutive breaches > 0  |5 minutes|5 minutes|Log Search  |Metrics|1.2.0|
|GMS-PM  |Azure SQL  |Azure SQL oltp storage quota above threshold|Azure SQL  |2  |Metric Measurement  |Metric > 90 and Consecutive breaches > 0  |5 minutes|5 minutes|Log Search  |Metrics|1.2.0|
|GMS-PM  |Azure SQL  |Azure SQL read IOPS above threshold|Azure SQL  |2  |Metric Measurement  |Metric > 75 and Consecutive breaches > 0 |5 minutes|5 minutes|Log Search  |Metrics|1.2.0|
|GMS-PM  |Azure SQL  |Azure SQL sessions above threshold|Azure SQL  |2 |Metric Measurement  |Metric > 80 and Consecutive breaches > 0  |5 minutes|5 minutes|Log Search  |Metrics|1.2.0|
|GMS-PM  |Azure SQL  |Azure SQL Storage capacity warning|Azure SQL  | 1 |Results  |Count > 0 |1 hour|1 hour |Log Search  |Metrics|1.1.0|
|GMS-PM  |Azure SQL  |Azure SQL storage quota above threshold|Azure SQL  |2|Metric Measurement  |Metric > 0 and Consecutive breaches > 0  |1 hour|1 hour|Log Search  |Metrics|1.2.0|
|GMS-PM  |Azure SQL  |Azure SQL workers above threshold|Azure SQL  |2  |Metric Measurement  |Metric > 80 and Consecutive breaches > 0 |5 minutes|5 minutes |Log Search  |Metrics|1.2.0|
|GMS-PM  |Azure SQL  |SQL Connection Failed|MMA Agents  |0  |Metric Measurement  |Metric > 5  and Consecutive breaches > 0 |5 minutes|5 minutes|Log Search  |Metrics|1.2.0|
|GMS-PM|Azure SQL|SQL CPU Percentage High|MMA Agents  |1  |Metric Measurement |Metric > 95 and Consecutive breaches > 5  |5 minutes|5 minutes|Log Search  |Metrics|1.2.0|
|GMS-PM|Azure SQL|SQL High DTU|MMA Agents  | 1 | Metric Measurement|Metric > 75 and Consecutive breaches > 3|5 minutes|5 minutes  |Log Search  |Metrics|1.1.0|
|GMS-PM  |Azure MySQL  |MySQL - Failed Connections|Azure MySQL  | 2 |Metric Measurement  |Metric > 5 and Consecutive breaches > 5 |5 minutes|5 minutes |Log Search  |Metrics|1.2.0|
|GMS-PM  |Azure MySQL  |MySQL - High CPU Percentage|Azure MySQL  | 2 |Metric Measurement |Metric > 95 and Consecutive breaches > 0 |30 minutes|5 minutes |Log Search  |Metrics|1.2.0|
|GMS-PM  |Azure MySQL  |MySQL - High Database Storage Quota|Azure MySQL  |2  |Metric Measurement  |Metric > 75 and Consecutive breaches > 0 |5 minutes|5 minutes |Log Search  |Metrics|1.2.0|
|GMS-PM  |Azure MySQL  |MySQL - High IO Consumption|Azure MySQL  |2  |Metric Measurement  |Metric > 75 and Consecutive breaches > 0 |5 minutes|5 minutes |Log Search  |Metrics|1.2.0|
|GMS-PM  |Azure MySQL  |MySQL - High Log Storage Quota|Azure MySQL  |2  |Metric Measurement  |Metric > 75 and Consecutive breaches > 0 |5 minutes|5 minutes |Log Search  |Metrics|1.2.0|
|GMS-PM  |Azure MySQL  |MySQL - High Memory Percentage|Azure MySQL  |1  |Metric Measurement  |Metric > 95 and Consecutive breaches > 4 |30 minutes|5 minutes |Log Search  |Metrics|1.2.0|
|GMS-PM  |Azure MySQL  |MySQL - Instance was Deleted|Azure MySQL  | 0 |Results  |Count > 0  |30 minutes|30 minutes |Log Search  |Subscription Activity Log|1.2.0|
|GMS-PM  |Azure MySQL  |MySQL - Instance was Restarted|Azure MySQL  |0  |Results  |Count > 0 |30 minutes|30 minutes|Log Search  |Subscription Activity Log|1.2.0|
<br>

### Networking

|**Service Code/SKU**|**Category**|**Azure Alert Name**|**Affected Resource**|**Azure Severity**|**Threshold Type**|**Threshold**|**Data Period**|**Evaluation Frequency**|**Schema**|**Source**|**Released**|
|--|--|--|--|--|--|--|--|--|--|--|--|
|GMS-NDM  |Network  |Application Gateway Failed Requests|Application Gateway  |1  |Metric Measurement  |Metric > 15 and Consecutive breaches > 5 |5 minutes|5 minutes |Log Search  |Metrics|1.2.0|
|GMS-NDM  |Network  |NET Availability - VPN Connectivity State Change|Virtual Network Gateway  |2  | Results |Count > 0 |5 minutes|5 minutes|Log Search  |Diagnostics|1.2.0|
|GMS-NDM  |Network  |NET Performance - Expressroute High bandwidth utilization|Expressroute Circuit  |2  | Results |Count > 0   |5 minutes|5 minutes|Log Search  |Metrics|1.1.0|
|GMS-NDM |Network |NET Performance - VPN High bandwidth utilization|VPN Gateway  |3  | Results | Count > 0  |5 minutes|5 minutes|Log Search  |Metrics|1.1.0|

<br><br>

### Analysis Services

|Service Code/SKU|**Category**|**Azure Alert Name**|**Affected Resource**|**Azure Severity**|**Threshold Type**|**Threshold**|**Data Period**|**Evaluation Frequency**|**Schema**|**Source**|**Released**|
|--|--|--|--|--|--|--|--|--|--|--|--|
|GMS-PM  |Analysis Services  |AAS Server was Deleted|Analysis Services  |0  |Results |Count > 0 |30 minutes|30 minutes |Log Search  |Subscription Activity Log|1.2.0|
|GMS-PM  |Analysis Services  |AAS Server was Suspended|Analysis Services  |0  |Results  |Count > 0  |30 minutes|30 minutes|Log Search  |Subscription Activity Log|1.2.0|

<br><br>

### API Management

|Service Code/SKU|**Category**|**Azure Alert Name**|**Affected Resource**|**Azure Severity**|**Threshold Type**|**Threshold**|**Data Period**|**Evaluation Frequency**|**Schema**|**Source**|**Released**|
|--|--|--|--|--|--|--|--|--|--|--|--|
|GMS-PM  |API Management  |API Manager Capacity High|API Management  |2  |Metric Measurement|> 95 and Consecutive breaches > 0 |5 minutes|5 minutes |Log Search  |Metrics|1.2.0|
|GMS-PM  |API Management  |API Manager Failed Requests|API Management  |2  |Metric Measurement  |Metric > 15 and Consecutive breaches > 0 |15 minutes|15 minutes |Log Search  |Metrics|1.1.0|
|GMS-PM  |API Management  |API Manager Unauthorized Requests|API Management  |2  |Metric Measurement  |Metric > 15 and Consecutive breaches > 0 |15 minutes|15 minutes |Log Search  |Metrics|1.1.0|
<br><br>

### Automation Accounts

|Service Code/SKU|**Category**|**Azure Alert Name**|**Affected Resource**|**Azure Severity**|**Threshold Type**|**Threshold**|**Data Period**|**Evaluation Frequency**|**Schema**|**Source**|**Released**|
|--|--|--|--|--|--|--|--|--|--|--|--|
|GMS-PM  |Automation  |Automation Account Runbook Job Fails|Automation Account  |2  |Results |Count > 0  |15 minutes |15 minutes |Log Search  |Diagnostics|1.3.0|
<br><br>

### Data Factory

|Service Code/SKU|**Category**|**Azure Alert Name**|**Affected Resource**|**Azure Severity**|**Threshold Type**|**Threshold**|**Data Period**|**Evaluation Frequency**|**Schema**|**Source**|**Released**|
|--|--|--|--|--|--|--|--|--|--|--|--|
|GMS-PM  |Data Factory  |Azure Data Factory Pipeline has failed|Data Factory  | 2 |Results  |Count > 0  |15 minutes|15 minutes|Log Search  |Data Factory Activity|1.3.0|
|GMS-PM  |Data Factory  |DataFactory - High CPU Percentage|Data Factory  |2  |Metric Measurement  |Metric > 95 and Consecutive breaches > 3|5 minutes|5 minutes |Log Search  |Metrics|1.2.0|
|GMS-PM  |Data Factory  |DataFactory - Instance was Deleted|Data Factory  |0  |Results  |Count > 0 |30 minutes|30 minutes |Log Search  |Subscription Activity Log|1.2.0|
|GMS-PM  |Data Factory  |Failed Activity Run Threshold Breached|Data Factory  |1  |Metric Measurement  | Metric > 0 and Consecutive breaches > 0 |5 minutes|5 minutes|Log Search  |Metrics|1.2.0|
|GMS-PM  |Data Factory  |Failed Trigger Run Threshold Breached|Data Factory  | 1  |Metric Measurement  | Metric > 0 and Consecutive breaches > 0 |5 minutes|5 minutes|Log Search  |Metrics|1.2.0|

<br><br>

### Azure Websites/Web Apps

|Service Code/SKU|**Category**|**Azure Alert Name**|**Affected Resource**|**Azure Severity**|**Threshold Type**|**Threshold**|**Data Period**|**Evaluation Frequency**|**Schema**|**Source**|**Released**|
|--|--|--|--|--|--|--|--|--|--|--|--|
|GMS-PM  |Azure Websites  |Web High CPU Percentage|Web  | 2 | Metric Measurement | Metric > 95 and Consecutive breaches > 3 |5 minutes|5 minutes|Log Search  |Metrics|1.1.0|
|GMS-PM  |Azure Websites  |Web High CPU Time|Web  |2 | Metric Measurement | Metric > 95 and Consecutive breaches > 3 |5 minutes|5 minutes|Log Search  |Metrics|1.1.0|
|GMS-PM  |Azure Websites  |Web High Disk Queue Length|Web  | 2 | Metric Measurement | Metric > 40 and Consecutive breaches > 5 |5 minutes|5 minutes |Log Search  |Metrics|1.1.0|
|GMS-PM  |Azure Websites  |Web High HTTP Queue Length|Web  |1 | Metric Measurement | Metric > 500 and Consecutive breaches > 5 |5 minutes|5 minutes|Log Search  |Metrics|1.2.0|
|GMS-PM  |Azure Websites  |Web High Memory Percentage|Web  | 2 | Metric Measurement | Metric > 95 and Consecutive breaches > 3 |5 minutes|5 minutes|Log Search  |Metrics|1.1.0|

<br><br>

### Azure Kubernetes Service

|**Service Code/SKU**  |**Category**  |**Azure Alert Name**  |**Affected Resource**  |**Azure Severity**  |**Threshold Type** |**Threshold**  |**Data Period** |**Frequency**  |**Schema**  |**Source** |**Released** |
|--|--|--|--|--|--|--|--|--|--|--|--|
|GMS-PM |Kubernetes |Kubernetes All Nodes High Average CPU |Kubernetes Cluster |2 |Metric Measurement |Metric > 95 and Consecutive Breaches > 1 |60 minutes |30 minutes |Log Search |Metrics| 1.7.0|
|GMS-PM |Kubernetes |Kubernetes All Nodes High Average Memory Utilization |Kubernetes Cluster |2 |Metric Measurement |Metric > 95 and Consecutive Breaches > 1 |60 minutes |30 minutes |Log Search |Metrics| 1.7.0 |
|GMS-PM |Kubernetes |Kubernetes Average container CPU high |Kubernetes Container |2 |Metric Measurement |Metric > 95 and Consecutive Breaches > 1 |60 minutes |30 minutes |Log Search |Metrics| 1.7.0 |
|GMS-PM |Kubernetes |Kubernetes Average node disk usage percent |Kubernetes Node |2 |Metric Measurement |Metric > 80 and Consecutive Breaches > 1 |30 minutes |15 minutes |Log Search |Metrics| 1.7.0 |
|GMS-PM |Kubernetes |Kubernetes Average PV usage per pod high |Kubernetes Pod |2 |Metric Measurement |Metric > 80 and Consecutive Breaches > 1 |60 minutes |30 minutes |Log Search |Metrics| 1.7.0 |
|GMS-PM |Kubernetes |Kubernetes Average container working set memory utilization is high |Kubernetes Container |2 |Metric Measurement |Metric > 95 and Consecutive Breaches > 1 |60 minutes |30 minutes |Log Search |Metrics| 1.7.0 |
|GMS-PM |Kubernetes |Kubernetes Failed Pod Counts |Kubernetes Pod |2 |Metric Measurement |Metric > 0 and Consecutive Breaches > 0 |60 minutes |30 minutes |Log Search |Metrics| 1.7.0 |
|GMS-PM |Kubernetes |Kubernetes Node NotReady status |Kubernetes Cluster |2 |Metric Measurement |Metric > 0 and Consecutive Breaches > 0 |60 minutes |30 minutes |Log Search |Metric| 1.7.0 |

### Azure Firewall

| **Service Code/SKU** | **Category** | **Azure Alert Name**                 | **Affected Resource** | **Azure Severity** | **Threshold Type** | **Threshold**                             | **Data Period** | **Frequency** | **Schema** | **Source** | **Released** |
| -------------------- | ------------ | ------------------------------------ | --------------------- | ------------------ | ------------------ | ----------------------------------------- | --------------- | ------------- | ---------- | ---------- | ------------ |
| GMS-NDM              | Network      | Firewall health state degraded       | Azure Firewall        | 1                  | Metric Measurement | Metric <= 50 and Consecutive Breaches > 0 | 10 minutes      | 5 minutes     | Log Search | Metrics    | 1.7.0        |
| GMS-NDM              | Network      | Firewall Source NAT port utilization | Azure Firewall        | 2                  | Metric Measurement | Metric <= 50 and Consecutive Breaches > 0 | 10 minutes      | 5 minutes     | Log Search | Metrics    | 1.7.0        |
<br>

### NetApp Volume


| **Service Code/SKU** | **Category** | **Azure Alert Name**                 | **Affected Resource** | **Azure Severity** | **Threshold Type** | **Threshold**                             | **Data Period** | **Frequency** | **Schema** | **Source** | **Released** |
| -------------------- | ------------ | ------------------------------------ | --------------------- | ------------------ | ------------------ | ----------------------------------------- | --------------- | ------------- | ---------- | ---------- | ------------ |
| GMS-PM              | Storage      | NetApp Volume Consumed Size Percentage high critical*       | NetApp Volume       | 0                  | Metric Measurement | Avg VolumeConsumedSizePercentage > 85| 60 minutes      | 30 minutes     | Metric | Metrics    | 1.7.7        |

# Application Insights

This section details alert rules that are created along side the Application Insights workspace deployed with Infrastructure Monitoring. Alert Rules for this section are limited due to the fact that it is impossible to build an application monitoring solution that will work for every custom application built. In the case of an Application Health engagement, it is incumbent on the project/development team to:

a) Build their application(s) with appropriate logging capability to connect to Application Insights and

b) Develop and test alert rules for the monitoring of their application if a given failure scenario is not covered by an alert rule detailed on this page.

|Service Code/SKU  |**Category**  |**Azure Alert Name**  |**Affected Resource**  |**Azure Severity**  |**Threshold Type**|**Threshold**  |**Data Period**|**Frequency**  |**Schema**  |**Source**|**Released**|
|--|--|--|--|--|--|--|--|--|--|--|--|
|GMS-AMTR |Web Availability |Application Insights - Web Test Availability|Web Test  |1  | Results | Count > 0| 5 minutes|5 minutes |Log Search  |Availability Results|1.2.0|
|GMS-AMTR  |Web Availability  |Application Insights - Web Test HTTP 4xx Errors|Web Test  |1  |Results  |count > 0 | 5 minutes|5 minutes  |Log Search  |Requests|1.2.0|
|GMS-AMTR  |Web Availability  |Application Insights - Web Test HTTP 5xx Errors|Web Test  |1  |Results  |count > 0 | 5 minutes|5 minutes  |Log Search  |Requests|1.2.0|
|GMS-AMTR  |Web Performance  |Application Insights - Web Test Latency|Web Test  | 1  |Results  |count > 0 | 5 minutes|5 minutes |Log Search  |Availability Results|1.2.0|
<br>

# Azure Monitor Alerts

- These alerts are queried directly from the platform in Azure Monitor
- Data for these are stored in the Log Analytics workspace but the alerts are queried directly from the platform

|Service Code/SKU|**Category**|**Azure Alert Name**|**Affected Resource**|**Azure Severity**|**Threshold Type**|**Threshold**|**Data Period**|**Frequency**|**Schema**|**Source**|**Released**|
|--|--|--|--|--|--|--|--|--|--|--|--|
|GMS-PM  |Availability  |Azure Monitor Service Health Alert|Any Azure Resource  |Dynamic  |Result | Count > 0| n/a|n/a |Service notifications  |Service Health|1.1.0|
<br>

## Azure Advisor Alerts

- These alerts are queried directly from the platform in Azure Monitor
- Data for these are stored in the Log Analytics workspace but the alerts are queried directly from the platform

|Service Code/SKU|**Category**|**Azure Alert Name**|**Affected Resource**|**Azure Severity**|**Threshold Type**|**Threshold**|**Data Period**|**Frequency**|**Schema**|**Source**|**Released**|
|--|--|--|--|--|--|--|--|--|--|--|--|
|GMS-PM  |Proactive Care  |Azure Advisor Activity Log Alert|Any Azure Resource   |Dynamic  |Result | Count > 0| n/a|n/a |Service notifications  |Azure Advisor|1.3.0|

## Supplemental Information

### Obsolete Alert Rules

The following alert rules have been removed from the Infrastructure Monitoring solution.

|**Alert Name**  |**Last Released In**  |
|--|--|
|SQL Lock Wait Time over 500ms|1.1.4|
|API Manager Capacity over 95|1.1.4|
|Missing Critical or Security Update|1.2.1|
|Logical Disk Free Space Percentage Low|1.3.1|
|VM Availability - Disk Free MB Low|1.3.1|
|SQL Server agent job completed|1.2.1|
|windows free disk space|1.3.1|
|Failed Pipeline Run Threshold Breached|1.2.1|
|Computer with detected threats|1.4.0|
|VM Availability - Heartbeat Total Less than 3|1.4.0|

### Azure/ServiceNow Severity Mapping

- This table describes the integer values for alerts and the mapping from that number to ServiceNow
- Azure contains multiple severities from 0 to 5, with labels differing depending on the alert schema.
- To simplify severities, this integer mapping is used to set the severity in ServiceNow
- Note that severity 5 (Info) alerts in ServiceNow are not sent to the Operations Centre to be actioned.

|**Azure #**  |**Azure Label** |**ServiceNow #**  | **ServiceNow Label** |
|--|--|--|--|
|0 |Critical  |1  | Critical |
|1|Error  | 2 | Major |
|2|Warning| 4| Warning |
|3|Informational| 5 | Info |
|4|Verbose  | 5| Info |


