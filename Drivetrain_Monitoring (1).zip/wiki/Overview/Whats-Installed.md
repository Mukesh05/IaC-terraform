# Installation

DriveTrain Infrastructure Monitoring is designed to be installed into a single Azure Subscription and Management Group, with the addition of spoke subscriptions to push information back to the central location.  The basic installation will always remain the same, however some of the ancillary configuration will be performed on a different scope when remote spokes are specified.

## Azure Location

Due to limitations within Azure Log Analytics being linked with Azure Automation Account, the location is limited to a few set geographic data centers.  The locations are constantly reviewed and will be expanded as and when possible. Regardless of where Log Analytics can be deployed, Azure resources can write to these workspaces in these regions:

## US

- East US
- East US 2
- West US 2
- South Central US
- West Central US

## Canada

- Canada Central

## Asia Pacific

- Australia South East
- South East Asia
- Central India
- China East 2
- Japan East

## Europe

- UK South
- West Europe
- Switzerland North

## US Gov

- US Gov Virginia
- US Gov Arizona

For more details on the regions supported with Log Analytics thats linked with Azure Automation. Please refer the (https://docs.microsoft.com/en-us/azure/automation/how-to/region-mappings)

## Core Subscription Resources

The core of DriveTrain Infrastructure Monitoring is a single Resource Group in a single Azure geographic location, in this resource group the following is installed and configured:-
| Resource | Default Name | Overridable |
| --- | --- | :---: |
| Log Analytics Workspace | LA-SystemHealth<UniqueString> | * |
| Automation Account | automationaccount<UniqueString> | * |
| Application Insight | AI-AppHealth | * |
| Key Vault | kv-library-<LocationCode>-<UniqueString> |
| Storage Accounts | salibrary<LocationCode><UniqueString> |
| Storage Accounts Diagnostic Data | storage<UniqueString> |
| Action Group | SNow |
|Automation Runbooks|CMDB Sync, NetApp Alerts|

_note: to override the default name, where possible, See [Installation Parameters](../Overview/Installation-Parameters.md)

The following are installed into the hub subscription, and into any additional subscriptions via blueprint assignment:

- Azure Service Health Alerts
- Azure Advisor Recommendations

Depending on the scope of the installation the following will be installed to the main subscription or a nominated management group :-

- Azure Policy diagnostic settings
- Azure Policy Definitions
- Azure Policy Assignments
- Azure Blueprint Definitions
- Azure Blueprint Assignments

Additional resources are deployed to the single or hub subscription

|Workspace Solutions| Alert Rules | Scheduled query rules | Activity log rules |
|--|--|--|--|
| See [Installation Parameters](../Overview/Installation-Parameters.md)| See [Installation Parameters](../Overview/Installation-Parameters.md)  | See [Installation Parameters](../Overview/Installation-Parameters.md) | See [Installation Parameters](../Overview/Installation-Parameters.md) | 

## Management Group Deployments

Under a Management Group deployment all subscriptions under the management group will contain the following resources:

- Resource Group (Having same name as Monitoring Resource Group in primary subscription)
- Event Grid

The subscription will also be configured with the following:

- Security Center (if enabled in installer)
- Log Analytics binding to Workspace in primary subscription
- Inherited Policy Assignments from Management Group
