# DriveTrain - Infrastructure Monitoring

[[_TOC_]]

## Foreword

- Release Date - October 2021
- Release Version - ##BUILD_VER##
- [Known Issues](../Overview/Known-Issues.md)
- Please note that we support programmatic deployment and further details can be found on the ["Installation Parameters Page"](../Overview/Installation-Parameters.md)
- If deploying to multiple subscriptions, all subscriptions will need to be under a single root management group to be targeted for installation. Please remember that it is possible to have a [nested hierarchy of up to 6 management groups](https://docs.microsoft.com/en-us/azure/governance/management-groups/overview#important-facts-about-management-groups)

## Installation – Latest Release

Before Installation, review the [Whats Installed](../Overview/Whats-Installed.md) page.

***Please note at deploy time, it is best practice to deploy this solution to a new or existing dedicated resource group. with no pre-existing resources.***

### Prerequisites - You

It is expected that the engineer deploying DriveTrain Monitoring has a clear understanding of the Azure Platform and the Scope of the client's Azure Estate. They should also hold a minimum of the following certification:

- [AZ-900 Exam AZ-900: Microsoft Azure Fundamentals](https://docs.microsoft.com/en-us/learn/certifications/exams/az-900)

and ideally one or more of:

- [Exam AZ-104: Microsoft Azure Administrator](https://docs.microsoft.com/en-us/learn/certifications/exams/az-104)
- [Exam AZ-300: Microsoft Azure Architect Technologies](https://docs.microsoft.com/en-us/learn/certifications/exams/az-300)
- [Exam AZ-301: Microsoft Azure Architect Design](https://docs.microsoft.com/en-us/learn/certifications/exams/az-301)
- [Exam AZ-400: Designing and Implementing Microsoft DevOps Solutions](https://docs.microsoft.com/en-us/learn/certifications/exams/az-400)

### Prerequisites - Technology

The engineer deploying DriveTrain Monitoring must have the following Operating System and tools installed on their working computing device.

- Windows 10 64bit
- PowerShell 5.1 (default on Windows 10 64bit)
- Internet Explorer enhanced security mode disabled
- [Azure CLI](https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-windows?view=azure-cli-latest#install-or-update)
- [Azure CLI Extension for Azure DevOps](https://github.com/Azure/azure-devops-cli-extension#quick-start)
- [.Net Framework v4.6 or higher](https://docs.microsoft.com/en-gb/dotnet/framework/install/on-windows-10)
    - Check with Powershell: (Get-ItemProperty "HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full").Release
    - Check version with releases [here](https://docs.microsoft.com/en-us/dotnet/framework/migration-guide/how-to-determine-which-versions-are-installed)
- [Az PowerShell Module](https://docs.microsoft.com/en-us/powershell/azure/install-az-ps?view=azps-2.7.0#install-the-azure-powershell-module-1)*
    - Check with Powershell: Get-InstalledModule -Name Az -AllVersions | select-object -property Name,Version
-[Az Module](https://docs.microsoft.com/en-us/powershell/azure/?view=azps-5.1.0)Install-Module -Name Az -RequiredVersion 6.4
- [Az.Blueprint Module](https://docs.microsoft.com/en-us/powershell/module/az.blueprint/?view=azps-3.8.0) (Install-Module -Name Az.Blueprint -RequiredVersion 0.2.13)
- [Az.ManageIdentity Module](https://docs.microsoft.com/en-us/powershell/module/az.managedserviceidentity/?view=azps-3.8.0) (Install-Module -Name Az.ManagedServiceIdentity -RequiredVersion 0.7.3)
- [Az.Resources Module](https://docs.microsoft.com/en-us/powershell/module/az.resources/?view=azps-5.1.0) (Install-Module -Name Az.Resources -RequiredVersion 4.3.1)
- [Az.Security Module](https://docs.microsoft.com/en-us/powershell/module/az.security/?view=azps-3.8.0) (Install-Module -Name Az.Security -RequiredVersion 0.8.0)
- [Azure API limitation](https://docs.microsoft.com/en-us/azure/role-based-access-control/custom-roles)
- Please note that if you are deploying this to a New Signature customer who has or will purchase Managed Services, you will need to contact the on-boarding team to obtain the REST token to input during installation. If this is not completed, then no alerts will flow through to ServiceNow.
- Please note that deploying to the root management group is not recommended.
- No Unknown Identities
    - There must be no unknown identities assigned to Roles on the subscription or management group Access Control (IAM) panel
    - If these are present during installation you will be notified and the install will need to be stopped, the identities removed, and the install repeated
- Deployment of the System Health Enterprise App is required before or after Monitoring deployment, to bind Alerts to Configuration Items in ServiceNow
   - Global Admin on the customer tenant is required to for this step, to install the New Signature System Health enterprise application
   - System Health App is used to discover resources in the Azure Subscription(s)
   - System Health App uses subscription resource metadata to bind Alerts to CIs (Azure Resources) in ServiceNow
   - A customer-specific enrollment URL is required to activate, which contains the customer account number in the URL string.
 - It is recommended to have a ServiceNow token when deploying customer environments, this can be supplied on the command line
   - If not available during the initial deployment, manually update the Action Group webhook after deployment with the customer ServiceNow token

### Supported regions for linked Log Analytics workspace

As an IT admin, you can enable the Update Management for your servers and vms. These features have a dependency on a Log Analytics workspace, and therefore require linking the workspace with an Automation Account. However, only certain regions are supported to link together. Generally, the mapping is not applicable if you plan to link an Automation account to a workspace that won't have these features enabled. For more information, please read these documentations,
- [Supported regions for linked Log Analytics workspace](https://docs.microsoft.com/en-us/azure/automation/how-to/region-mappings)
- [Products available by region](https://azure.microsoft.com/en-ca/global-infrastructure/services/?products=monitor&regions=non-regional%2cus-east%2cus-east-2%2cus-central%2cus-north-central%2cus-south-central%2cus-west-central%2cus-west%2cus-west-2%2ccanada-east%2ccanada-central%2csouth-africa-north%2csouth-africa-west%2casia-pacific-east%2casia-pacific-southeast%2caustralia-central%2caustralia-central-2%2caustralia-east%2caustralia-southeast%2cusgov-non-regional%2cus-dod-central%2cus-dod-east%2cusgov-arizona%2cusgov-texas%2cusgov-virginia%2cbrazil-south%2cbrazil-southeast%2cchina-non-regional%2cchina-east%2cchina-east-2%2cchina-north%2cchina-north-2%2ceurope-north%2ceurope-west%2cunited-kingdom-south%2cunited-kingdom-west%2cuae-central%2cuae-north%2cswitzerland-north%2cswitzerland-west%2cnorway-east%2cnorway-west%2ckorea-central%2ckorea-south%2cjapan-east%2cjapan-west%2ccentral-india%2csouth-india%2cwest-india%2cgermany-non-regional%2cgermany-central%2cgermany-north%2cgermany-northeast%2cgermany-west-central%2cfrance-central%2cfrance-south)

Please note that the appropriate location aligned with the correct mapping is selected during installation.

**__Not AzureRM__**

Please note the use of Azure CLI is only for package download, due to the fact that PowerShell does not currently handle the download of [Universal Packages](https://devblogs.microsoft.com/devops/getting-started-with-universal-packages/).

#### Single Subscription

- At least the rights specified in the ["Custom Role"](https://dev.azure.com/newsigcode/InnerSource/_git/Drivetrain_Monitoring?path=%2FInfrastructureMonitoring%2FRBAC.json&version=GBmaster) in the main subscriptions
- “Owner” is also acceptable
- Ongoing management and upgrades requires the custom RBAC role if Owner or equivalent access is unavailable

#### Management Groups

- If deploying with [Management Groups](https://docs.microsoft.com/en-us/azure/governance/management-groups/overview), Owner access is required on the child management group
    - Owner on the Management Group must be retained for installation and maintenance as there are [limitations on custom IAM roles](https://docs.microsoft.com/en-us/azure/governance/management-groups/overview#limitations)
- Monitoring requires at least 1 subscription to be a member of the management group before installation
    - The [Global Admin user must elevate](https://docs.microsoft.com/en-us/azure/role-based-access-control/elevate-access-global-admin) to move subscriptions from root management group to child.
    - Verify the user moving the subscription is Owner on both the source and destination management groups before moving
- Ongoing management and upgrades requires the custom RBAC role, assigned to the Management Group if Owner or equivalent access is unavailable

## Download Installation Package

Please run following in a PowerShell instance on your machine to download the package of latest version.

``` PowerShell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Force
az login
az artifacts universal download --organization "https://dev.azure.com/newsigcode/" --feed "DriveTrain@Release" --name "newsig.arm.infrastructure" --version "##BUILD_VER##" --path C:\Temp\InfrastructureMonitoring-##BUILD_VER##
C:\Temp\InfrastructureMonitoring-##BUILD_VER##\Install-InfrastructureMonitoring.ps1
```

- Please note that when running the installer, if you are prompted for a "custom plugin" and you are unaware of what this means, please press enter to continue.
- This feature is available to allow the deployment of per-customer custom alerts by the Managed Services on-boarding team only.
- The installer will deploy using defaults where possible, to override the defaults there are a set of command line parameters that can be utilised. See the [Installation Parameters](../Overview/Installation-Parameters.md) for more information and guidance.

## Uninstall

Please run following in a Powershell instance on your machine to uninstall the latest version.

``` PowerShell
Set-ExecutionPolicy -ExecutionPolicy Unrestricted
C:\Temp\InfrastructureMonitoring-##BUILD_VER##\Uninstall-InfrastructureMonitoring.ps1
```
Please refer [Invoking Uninstall](../Overview/Uninstallation.md) wiki page for more granular details on DriveTrain uninstallation.

- Please note that uninstall will delete the resource group, which could include any other non NewSignature resources

## Upgrade

The Infrastructure Monitoring installer has the ability to detect existing installations of the monitoring solution. If an existing installation is found in the in-context subscription, the installer will assume an upgrade needs to take place instead of a clean installation. As of v1.7.2, the installer deploys resources in **Incremental mode** in order to accommodate and preserve customizations made to the solution (i.e. update schedules for Update Management). NOTE: This change to upgrades does not impact Alert Rules. Any customizations to alert rules are overwritten with the OOTB alert rules from the version of monitoring which is being deployed.
