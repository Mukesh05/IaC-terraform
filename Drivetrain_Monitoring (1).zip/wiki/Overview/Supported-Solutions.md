# Supported Solutions

[[_TOC_]]

## Introduction

This area explains on the resources and solutions supported by the DriveTrain Infrastructure Monitoring application.

## Architecture

*Figure 1* [Architecture](https://docs.microsoft.com/en-us/azure/cloud-adoption-framework/_images/decision-guides/decision-guide-subscriptions-hierarchy.png).

![Architecture](https://docs.microsoft.com/en-us/azure/cloud-adoption-framework/_images/decision-guides/decision-guide-subscriptions-hierarchy.png "architecture")

As per the image illustrated above, Implementation Engineers are able to deploy to a management group. By deploying at management group level, an Azure Blueprint is utilized to configure all subscriptions beneath the management group. The user is also given an option to deploy the Infrastructure Monitoring to a subscription.

## Log Analytics Workspace

*Figure 2* [Log Analytics Workspace](https://docs.microsoft.com/en-us/azure/azure-monitor/learn/media/quick-create-workspace/azure-portal-01.png).

![Log Analytics Workspace](https://docs.microsoft.com/en-us/azure/azure-monitor/learn/media/quick-create-workspace/azure-portal-01.png "log analytics workspace").

 The DriveTrain Infrastructure Monitoring deploys a log analytics workspace to an azure subscription or management group in order to facilitate monitoring of an Azure Estate. An Implementation Engineer can override a default log analytics workspace by creating a new workspace with a specific name, or utilise a named workspace in the Resource Group specified with the ResourceGroupName parameter.

 When deploying to an existing log analytics workspace, you should consider the following,
 * Because the ARM template for DT Monitoring is set to  complete mode, the Resource Manager deletes the existing data that already resides inside the log analytics workspace.Therefore, It is recommended to deploy DT Monitoring in a separate resource group and set the existing resources to use the log analytics workspace resource which gets deployed with the DT Monitoring.

## Azure Policy

Azure diagnostic policy initiative exists consisting of diagnostic policies for all supported resources. The policy assignments exists to the subscription or management group as selected during deployment.

[Assets_Policies](https://dev.azure.com/newsigcode/InnerSource/_git/Assets_Policies).
