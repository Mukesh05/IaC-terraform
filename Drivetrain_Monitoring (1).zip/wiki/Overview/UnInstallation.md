# DriveTrain - Infrastructure Monitoring

[[_TOC_]]

## Invoking Uninstall

DriveTrain related components/modules can be uninstalled by invoking
``` PowerShell
Set-ExecutionPolicy -ExecutionPolicy Unrestricted
C:\Temp\InfrastructureMonitoring-##BUILD_VER##\Uninstall-InfrastructureMonitoring.ps1
```

The template requires some parameters to ensure the uninstall is correct

```powershell
    "Architecture": Single Subscription or Hub & Spoke, Valid values - Single/Multiple
    "AzureTenantId": The Azure Tenant Id where the solution is deployed into.
    "AzureSubscriptionId": The Azure Subscription Id where the solution is deployed into.
    "ManagementGroupId": (Multi-subscription only) Defines the Id of the root management group of all subscriptions to be monitored
    "ResourceGroupName": The resource group name where the solution is deployed to.
    "SkipUserCheck": Switch parameter; set to use existing Azure session in PowerShell
```
- Please note that uninstall will delete the resource group, which could include any other non NewSignature resources

## What gets uninstalled

Uninstallation of DriveTrain monitoring includes :

- Deletion of Azure Policy (Name: ASSIGNED DriveTrain Diagnostic Policies).
- Deletion of Azure Policy set definitions created as part of above Azure Policy (Name matching 'New Signature DriveTrain').
- Deletion of Azure Policy definitions created as part of above Azure Policy (Name matching 'New Signature DriveTrain').
- Deletion of Blueprints assignments created as part of DriveTrain installation (Name matching 'NSMonitoring').
- Deletion of the log analytics and application insights workspaces associated with drivetrain (Name : LA-SystemHealth<random 13 characters>).
- Deletion of the automation account used for drivetrain and associated runbooks, schedules, and patching configuration (Name : automationaccount<random 13 characters>).
- Deletion of the historical diagnostics and metrics data stored in drivetrain workspaces.
- Deletion of alert definitions created as part of drivetrain.
- Deletion of managed identities used for Azure policy remediation.
- Deletion of the action group associated to drivetrain alerts (Name : Application Insights Smart Detection).
- Deletion of the resource group tagged to drivetrain (Tag : 'NS-DriveTrain : <ver>') and any other resources (if any) contained within the resource group which might have been created apart from drivetrain installation.

## Other cleanup items

- Removing the enterprise app for CMDB Sync
- Removing reader permissions for the enterprise app
- Removing unknown identities on in scope subscriptions
- Cleanup of metric based alerts created in resource groups other than the drivetrain monitoring resource group.
- Custom alerts

Only custom alerts on the resources themselves would need to be deleted. Any resources within the resource group (ie, log analytics custom alerts) would be removed during uninstall automatically.