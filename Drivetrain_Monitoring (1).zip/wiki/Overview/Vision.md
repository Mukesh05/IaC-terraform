# Product Overview

DriveTrain Infrastructure Monitoring is the further development of the Managed-Services-derived System Health product. It is a quickly deploy-able product which aims to leverage cloud-native capabilities to provide monitoring of New Signature customer environments that are monitored under managed services agreements with New Signature.

## Goals

- Provide a base level of monitoring using cloud-native tools
- Reduce the cost to New Signature of monitoring customer Azure environments
- Standardized monitoring of customer Azure environments
- Reduced time to deploy monitoring of customer Azure environments
- Integrate with current New Signature service management tooling (ServiceNow)

## Organization

- Development will be primarily completed by the Platform Services Team
- The Product Owner will be represented by Kevin Rickey and the Service Architect will be Jason Cotton. These roles are subject to change and for more information regarding this, please check the [Overview Page](../../wiki/Overview.md).
- Acceptance Testing and Roll-Out will be coordinated by the Product Owner
- Service Management Tooling integration will be coordinated by the Product Owner

## Guiding Principles

- Ease of Deployment
- Ease of Maintenance
- Leverage native tooling with minimal custom development

## Priorities

- Working and deployable software
- Ease of use for Managed Services Teams

