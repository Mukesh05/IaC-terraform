# Overview

The minimum required permissions to deploy infrastructure monitoring solution to pass security scrutiny at customers, and service those customers where we do not have owner or contributor, below RBAC role json needs to deployed/applied at the subscription level. After successful deployment of this role, this role needs to be assigned to the Azure user who is responsible for the infrastructure monitoring installation.

[[_TOC_]]

## Instructions

Powershell Cmdlets to work with this role definition

Create the role from the above definition<br>
Substitute the Subscription ID in the JSON file with the Subscription ID where the solution will be deployed.<br>
If multiple subscriptions are required, extend this value with the additional subscription IDs with a comma as shown here: [Custom Roles](https://docs.microsoft.com/en-us/azure/role-based-access-control/custom-roles)

### Create the role

``` Powershell
New-AzRoleDefinition -InputFile .\SystemHealthDeployment.json
```

### Assign a user to the new role

``` Powershell
New-AzRoleAssignment -RoleDefinitionName "DriveTrain Monitoring" -SignInName jdoe@organization.domain.com
```

In a multiple subscription scenario, it is necessary to add the user to the role on each subscription that was scoped in the definition earlier.

To delete the role, first remove the assignment of users from the role

### Get the users assigned this role

``` PowerShell
Get-AzRoleAssignment -RoleDefinitionName "DriveTrain Monitoring"
```

### Remove any users currently holding the role

``` PowerShell
Remove-AzRoleAssignment  -RoleDefinitionName "DriveTrain Monitoring"-SignInName jdoe@organization.domain.com
```

### Finally, remove the role definition

``` PowerShell
Remove-AzRoleDefinition -Id ee22e99d-7f51-414c-b5cd-51932ea4e5ad
```

Please access the RBAC Json File from the link below:
[**RBAC Json file**](https://dev.azure.com/newsigcode/InnerSource/_git/Drivetrain_Monitoring?path=%2FInfrastructureMonitoring%2FRBAC.json&version=GBmaster)
