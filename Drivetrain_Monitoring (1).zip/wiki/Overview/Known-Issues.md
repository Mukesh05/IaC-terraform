# Introduction

This area attempts to record any known issues with the current version of New Signature Infrastructure Monitoring package, where known any workaround will also be documented.

## A known issue is

1. A problem that cannot be fixed due to complexity, platform or area outside our control.
2. Presents only in specific technical configurations.
3. Represents uncommon knowledge that is likely to present itself given what and how we deploy this solution.

## Items to track would include

- Tracking
- Reported Date
- First affected version
- Fixed in version
- Symptoms
- Workaround

**Note:** *Only need to display symptoms and workarounds to users*.

We might include common steps that are likely to be overlooked, for example

- To promote an environment to prod
  - Update the webhook to point to ServiceNow prod.
  - Change the security configuration of Security Center on log analytics workspace to "Standard".

- The failure when unknown managed identity RBAC role exists on the management group.
- The Disconnect-AzAccount, Connect-AzAccount and -SkipUserCheck problem and solution, which is also a solution to the multiple MFA requests for many tenants on sign-in.

## Azure Portal Policy Assignment Display Issue

When inspecting Policy Assignments within the Azure Portal, the Log Analytics Workspace field appears to be blank.  This is a known issue and does not effect functionality.

If you try and modify the Policy Assignment, you will then need to select the correct Log Analytics Workspace before saving the policy.

![Missing Log Analytics Workspace](../.attachments/5219d552-a549-4c9e-94a8-b1e0a59fe25c.png)

## [Azure Advisor Recommendations](https://dev.azure.com/newsigcode/engineering/_workitems/edit/34777)

See ["Query used in a log alert is not valid"](https://docs.microsoft.com/en-us/azure/azure-monitor/platform/alert-log-troubleshoot)

Azure Advisor warns you about this behavior. A recommendation is added for the specific log alert rule on Azure Advisor, under the category of High Availability with medium impact and a description of "Repair your log alert rule to ensure monitoring." If an alert query in the log alert rule isn't rectified after Azure Advisor has provided a recommendation for seven days, Azure Monitor will disable the log alert and ensure that you're not billed unnecessarily when the rule can't run continually for a sizable period (like a week)

## Location Limitation Policy

If there is a policy that limits the locations resources can be deployed to, then it __MUST__ include the **Global** location to support the deployment of Cloud Native Monitoring and associated alerts definitions.

## Warning/Error Microsoft.Blueprint resource provider registration

Rarely, when deploying at Management Group level to more complex, multi-subscription hub and spoke topologies the following error can be encountered.

![Unregistered Resource Providers](../.attachments/1bb2f84a-cd60-4cd9-9ad2-88b88b2ec6d3.png)

Monitoring should be deployed correctly, though it is wise to check that the resource provider is present for any applicable subscriptions under the deployment.

This may simply be a timing issue.

## NetApp Alerts

NetApp Alerts are dynamically configured by Automation RunBook and are automatically created after installation. NetApp volumes are discovered within the scope of the monitoring deployment (management group or subscription). Upon un-installation, some NetApp Alert Rules may remain and must be manually deleted.

## Brownfield Deployment with mixed locations
Out of the Box, Drivetrain Monitoting does not support brownfield deployments where the resource group and underlying resources reside in different locations. To facilitate such a deployment, you will need to make manual updates to some of the ARM templates included in the installer.

If the brownfield configuration is such that the Resource Group is in one location and all the target resources (Automation Account, App inisghts, Log Analytics) are in another (but all in the same) location, then adjusting the deployment is simple; Open the workspaceDeploy.json, appInsightsDeploy.json and alertDeploy.json files in VS Code and use the Find and Replace feature to replace all instances of "[parameters('ResourceLocation')]" (excluding quotes) with the location shortcode (refer to the allowedValues of the ResourceLocation parameter).

If your situation is more complex than described above (i.e. RG in EastUS, LA in EastUS 2 and App Insights in WestUS) you will need to take a more fine tuned approach, setting the resource locations manually for each resource. Below are the JSON paths for the relevant ARM resource location parameters:

Log Analytics Workspace Location: workspaceDeploy.json > resources[1] > location
Automation Account: workspaceDeploy.json > resources[2] > location
Log Analytics Solutions: workspaceDeploy.json > resources[14] > location

Application Insights: appInsightsDeploy.json > resources[0] > location

SQR Alerts: alertDeploy.json > resources[1] > properties > parameters > ResourceLocation > value
SQR Metric Alerts: alertDeploy.json > resources[2] > properties > parameters > ResourceLocation > value