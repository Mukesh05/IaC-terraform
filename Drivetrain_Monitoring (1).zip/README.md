
# DriveTrain_Monitoring

## Overview

DriveTrain Infrastructure Monitoring deploys a collection of Azure Resources to one or more Azure Subscriptions in order to facilitate monitoring of an Azure Estate.

This is intended to allow implementation engineers a time-saving method to deploy a New Signature best practice monitoring framework to a client.

### Prerequisites

- [Azure CLI](https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-windows?view=azure-cli-latest#install-or-update)
- [Azure CLI Extension for Azure DevOps](https://github.com/Azure/azure-devops-cli-extension#quick-start)
- [Az PowerShell Module](https://docs.microsoft.com/en-us/powershell/azure/install-az-ps?view=azps-2.7.0#install-the-azure-powershell-module-1)*
- [.Net Framework v4.6 or higher](https://docs.microsoft.com/en-gb/dotnet/framework/install/on-windows-10)
- At least ["Owner"](https://docs.microsoft.com/en-us/azure/role-based-access-control/built-in-roles#owner) role in the target subscriptions
_*Not AzureRM_

### Feedback

Any product feedback is very welcome! Please direct your feedback to:

- The _Monitoring_ teams channel in the Drivetrain Teams site.
- Jason Cotton, Service Design Lead (Product Owner)

## Build and Test

To locally build this repository for testing please run .\CI\localbuild.ps1 from the repository root. See the readme.md file in the CI folder. 
When running .\Install-InfrastructureMonitoring.ps1 with the ```-SourceFolder ..\``` switch.

### Dependencies

This repository is dependent on the output of the following repositories, these are added at build time in the CI Pipeline, or as above can be retrieved locally using the provided script. These dependencies are retrieved from the [DriveTrain Dependencies Artifact Feed](https://dev.azure.com/newsigcode/InnerSource/_packaging?_a=feed&feed=Drivetrain_Dependencies)

The versions of the dependencies are specified in .\CI\packageversion.ps1 **This is the only location which should be used for dependency versioning**

**Repositories:**

- [Assets_ARM](https://dev.azure.com/newsigcode/InnerSource/_git/Assets_ARM?_a=readme)
- [Assets_Policies](https://dev.azure.com/newsigcode/InnerSource/_git/Assets_Policies?_a=readme)
- [Assets_PowerShell](https://dev.azure.com/newsigcode/InnerSource/_git/Assets_PowerShell?_a=readme)

### Testing / Releases
Unit and Integration Tests are configured on the following pipelines

- CI Pipeline : [![CI Pipeline](https://dev.azure.com/newsigcode/DriveTrain/_apis/build/status/Azure%20Go/Drivetrain_Monitoring?branchName=master)](https://dev.azure.com/newsigcode/DriveTrain/_build/latest?definitionId=119&branchName=master)
- Nightly Build : [![Nightly Build](https://vsrm.dev.azure.com/newsigcode/_apis/public/Release/badge/f8287ead-8d77-4249-b430-6fef6fc3e559/1/55)](https://dev.azure.com/newsigcode/DriveTrain/_release?_a=releases&view=mine&definitionId=1)
- Release for QA : [![Release for QA](https://vsrm.dev.azure.com/newsigcode/_apis/public/Release/badge/f8287ead-8d77-4249-b430-6fef6fc3e559/1/3)](https://dev.azure.com/newsigcode/DriveTrain/_release?_a=releases&view=mine&definitionId=1)
- Production Release: [![Production Release](https://vsrm.dev.azure.com/newsigcode/_apis/public/Release/badge/f8287ead-8d77-4249-b430-6fef6fc3e559/1/20)](https://dev.azure.com/newsigcode/DriveTrain/_release?_a=releases&view=mine&definitionId=1)

## Contribute

We welcome contributions from *anybody* into this repository.
To ensure that the repository contains good-quality code, to make a contribution you will need to make a *pull request* from a branch that you have created. This ensures that the contents of the repository have been peer-reviewed.

As above, please ensure your are ensuring your DSC configuration both achieves what it sets out to do, and builds successfully with the latest versions of all it's dependencies.

## Legal
Please note the contents of the .LICENSE file stored in this repository.

It is required that a Master Services Agreement (MSA) is in place between New Signature and any customer where Drivetrain is used.

Please ensure that any code you contribute is either your own work, released under a permissive (non-copyleft) licence, or has been developed on a customer engagement where a Master Services Agreement is in place.

If you have any questions or queries about this, please contact legal@newsignature.com.

### Using Git

If you are unfamiliar with Git, or you do not understand how to create a pull request or git branch, the following references may be helpful for you if you are new to Git source control.

- https://git-scm.com/videos
- https://docs.microsoft.com/en-us/azure/devops/repos/git/gitworkflow?view=azure-devops

If you are still stuck after reviewing the above, message the Platform Services team in the Drivetrain Teams -> General Channel and someone will be happy to walk you through how to get started.
