# Assets_Terraform

This repository is intended to hold standalone (i.e. nested non-linked, or normal non-nested ) Terraform Modules.
These modules may be consumed as part of the DriveTrain product assemblies, or used by themselves by individual engineers as single-solutions.

## Getting Started

If you've never worked with Terraform modules before, it may be a good idea to create your own one from scratch in a personal test environment first.

There are many good resources on how to interact with Azure using ARM modules:

- https://learn.hashicorp.com/terraform/azure/intro_az
- https://www.azuredevopslabs.com/labs/vstsextend/terraform/
- https://blog.gruntwork.io/a-comprehensive-guide-to-terraform-b3d32832baca (Examples are AWS, but everything is equally applicable to Terraform)
- https://channel9.msdn.com/Shows/DevOps-Lab/Deploying-your-Azure-Infrastructure-with-Terraform 
- https://www.terraform.io/docs/providers/azurerm/index.html

## Build and Test

At the moment, there is only a basic _"terraform validate"_ test configured on this repository. You may deploy any of the modules by copying them, and deploying them into Azure. If you are unsure how to deploy an ARM module into Azure, please see the resources above.

To run this test locally, run _Invoke-Pester_ from the root of the repository on your local machine. If you are not running Windows 10 you will need Pester installed.

## Contribute

We welcome contributions from *anybody* into this repository.
To ensure that the repository contains good-quality modules, to make a contribution you will need to make a *pull request* from a branch that you have created. This ensures that the contents of the repository have been peer-reviewed

## Legal
Please note the contents of the .LICENSE file stored in this repository. 

It is required that a Master Services Agreement (MSA) is in place between New Signature and any customer where Drivetrain is used.

Please ensure that any code you contribute is either your own work, released under a permissive (non-copyleft) licence, or has been developed on a customer engagement where a Master Services Agreement is in place. 

If you have any questions or queries about this, please contact legal@newsignature.com. 

### Naming Convention

All branches should be in the format feature/< your feature name here >

ARM modules should be named in the following convention:
%azure_resource_type%_%details%
or %azure_resource_type%_%subcategory%_%details%

I.e. vm-winServer or vnet-withazurebastion

### Code Formatting & Terraform Version

Please ensure your terraform code is formatted in compliance with the standard conventions by running _terraform fmt_ in your module directory before checking it into source control. 
All modules should be written for Terraform 0.12.x unless there is a compelling reason you have to write the module in Terraform 0.11.x

### Using Git

If you are unfamiliar with Git, or you do not understand how to create a pull request or git branch, the following references may be helpful for you if you are new to Git source control.

- https://git-scm.com/videos
- https://docs.microsoft.com/en-us/azure/devops/repos/git/gitworkflow?view=azure-devops

If you are still stuck after reviewing the above, message the Platform Services team in the Drivetrain Teams -> General Channel and someone will be happy to walk you through how to get started.
