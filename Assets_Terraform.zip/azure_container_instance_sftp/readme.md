# Azure Container Instance - SFTP

## Background

This is a clone of the excellent Microsoft ARM template here that works very nicely: https://github.com/Azure-Samples/sftp-creation-template

## Description 

This template creates a container in a pre-existing resource group, configures the container for SFTP and maps a pre-existing fileshare to the /upload directory of the user.
It will prompt for username and password. 

## Usage
1. Copy the folder to your machine
2. Run terraform init 
3. Run terraform apply

You will be prompted for the relevant content in the variables. 

Please ensure you are logged into Azure CLI in the same shell session where you run this, to the same subscription you wish this to be set up in. 