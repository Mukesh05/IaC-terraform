## Description

This module creates an API Backend and related Named Value leveraging Key Vault to securely store the Azure logic Host Key so it is not exposed in Azure API Management's Named Value. The Backend Id/Name is outputed from the module to be able to be used in APIM Policy configuration upstream from the module.

## Configuration

Main module configuration settings

```yml
{
    apim_name = "" #API Management Instance name
    apim_resource_group_name = "" #API Management Instance Resource Group Name
    apim_api = {} #Passes in the Azure API Managment API configuration object from terraform to use in the module
    apim_api_operation_configuration = {} #Configures the API Operation to create in Azure API Managment to represent the logic app
    logic_app_name = "" #Azure Logic App Name
    logic_app_resource_group_name = "" #Azure Logic App Resource Group Name
    create_kv_access_policy = true #Controls whether to provision the Access Policy for APIM to be able to interact with the key vault or not. If you have multiple logic apps sharing a key vault and one of them is already owning the configuration of the access policy for APIM then set this to false.
    key_vault_id = "" #Key Vault Resource Id for storing the Azure logic Host Key
}
```

## Example

APIM and logic App in the Same Subscription

```terraform
module "logic_app_api_example" {
    source = "git::https://dev.azure.com/MyOrg/MyProject/_git/Common.Terraform//modules/apim-api-logic-app"

    apim_name                        = data.azurerm_api_management.example.name
    apim_resource_group_name         = data.azurerm_api_management.example.resource_group_name
    apim_api                         = azurerm_api_management_api.example
    apim_api_operation_configuration = {
        operation_id = "manual-invoke"
        display_name = "Example Logic App Operation"
        method       = "POST"
        url_template = "/manual/paths/invoke"
        description  = "Trigger a run of the logic app."
    }
    logic_app_name                   = azurerm_logic_app.example.name
    logic_app_resource_group_name    = azurerm_logic_app.example.resource_group_name
    create_kv_access_policy          = true
    key_vault_id                     = azurerm_key_vault.example.id

    providers = {
        azurerm.logic = azurerm
        azurerm.apim  = azurerm
    }
}
```

APIM and logic App in the Different Subscriptions

```terraform
module "logic_app_api_example" {
    source = "git::https://dev.azure.com/MyOrg/MyProject/_git/Common.Terraform//modules/apim-api-logic-app"

    apim_name                        = data.azurerm_api_management.example.name
    apim_resource_group_name         = data.azurerm_api_management.example.resource_group_name
    apim_api                         = azurerm_api_management_api.example
    apim_api_operation_configuration = {
        operation_id = "manual-invoke"
        display_name = "Example Logic App Operation"
        method       = "POST"
        url_template = "/manual/paths/invoke"
        description  = "Trigger a run of the logic app."
    }
    logic_app_name                   = azurerm_logic_app.example.name
    logic_app_resource_group_name    = azurerm_logic_app.example.resource_group_name
    create_kv_access_policy          = true
    key_vault_id                     = azurerm_key_vault.example.id

    providers = {
        azurerm.logic = azurerm
        azurerm.apim  = azurerm.apim
    }
}
```
