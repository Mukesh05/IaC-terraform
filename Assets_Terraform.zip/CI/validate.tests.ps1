#Import Modules
foreach (
    $module in $(
        Get-ChildItem -Path "$PSScriptRoot\Modules" | Where-Object { $_.Extension -eq ".psm1" }
    )
) {
    Write-Output "Importing $($module.name)"
    Import-Module $module.fullname -Force
}

Describe "Testing Terraform Module Folders" {

    foreach ($folder in $(Get-ChildItem "$PSScriptRoot\..\" | Where-Object { $_.psiscontainer -eq $true })) {

        if ($(Get-ChildItem $folder -recurse) -match ".tf") {

            Context -Name $folder.name {

                It "$($folder.name) contains valid terraform" {
                    #Set control variables and run terraform cmdlets from module
                    Write-Output "Setting backend settings"
                    $backendsettings.tfpath = $folder.fullname

                    Write-Output "Running Terraform Init"
                    Initialize-Terraform
                    Write-Output "Checking Terraform is Valid"
                    Confirm-TerraformIsValid
                }
           
                It "$($folder.name) contains a README.md file" {
                    { $(Get-ChildItem $folder -recurse) -match "readme.md" } | Should -be $true
                }
            }
        }
    }

}