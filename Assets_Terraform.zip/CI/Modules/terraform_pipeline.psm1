function Invoke-Terraform {
    param ( 
        [Parameter(Mandatory = $false, Position = 1)]
        [string[]]$ArgumentList,
        [Parameter(Mandatory = $false, Position = 2)]
        [string]$Path,
        [Parameter(Mandatory = $false, Position = 3)]
        [switch]$Attach
    )
    Write-Output $Path
    $Params = @{ }

    if ($PSBoundParameters['ArgumentList']) {
        $Params['ArgumentList'] = $PSBoundParameters['ArgumentList']
    }

    $Params['Attach'] = $PSBoundParameters['Attach']

    # Set location to folder if specified.
    if ($Path) {
        Push-Location 
        Set-Location $Path
    }
        
    Write-Output "Executing Terraform in location [$(Get-Location)]"
    Invoke-Expression "terraform $($params['ArgumentList'])" 

    if ($Path) {
        Pop-Location
    }
}
function Initialize-Terraform {
    #Terraform Init
    Invoke-Terraform -Path $backendsettings.tfpath -ArgumentList "init -input=false"
}

function Publish-TerraformPlan {
    Invoke-Terraform -Path $backendsettings.tfpath -ArgumentList "plan -out=tfplan -input=false"
}
function Publish-TerraformDestroyPlan {
    Invoke-Terraform -Path $backendsettings.tfpath -ArgumentList "plan -out=tfplan -input=false -destroy"
}
function Invoke-TerraformApply {
    Invoke-Terraform -Path $backendsettings.tfpath -ArgumentList "apply -input=false tfplan"
}

function Confirm-TerraformisValid {
    Invoke-Terraform -Path $backendsettings.tfpath -ArgumentList "validate"
}



class backendSettings {
    [string] $tfpath = ''
}

$backendsettings = [backendSettings]::new()

Export-ModuleMember `
    -Function Invoke-Terraform, `
    Initialize-Terraform, `
    Publish-TerraformPlan, `
    Publish-TerraformDestroyPlan, `
    Invoke-TerraformApply, `
    Confirm-TerraformIsValid `
    -Variable $backendsettings