$subId = Get-AutomationVariable -Name 'subId'
$resourceGroupName = Get-AutomationVariable -Name 'resourceGroupName'
$jobName = Get-AutomationVariable -Name 'jobName'
$minSU = Get-AutomationVariable -Name 'minSU'
$targetSU = 0
"Executing StepScaleDown with subscription id: $subId; resource group name: $resourceGroupName; job name: $jobName;"

$ErrorActionPreference = 'Stop'

try
{

    #Login to Azure using Managed Identity
    "Logging in to Azure..."
    Connect-AzAccount -Identity 

}
catch {
    Write-Error -Message $_.Exception
    throw $_.Exception
}

$accessToken = Get-AzAccessToken

$headers = @{
    'Content-Type' = 'application/json'
    'Authorization' = 'Bearer ' + $accessToken.Token
}
$WarningPreference = 'Continue'
$getJobUri = "https://management.azure.com/subscriptions/$subId/resourceGroups/$resourceGroupName/providers/Microsoft.StreamAnalytics/streamingjobs/$jobName" + '?$expand=transformation&api-version=2017-04-01-preview'

$jobState = Invoke-RestMethod -Uri $getJobUri -Method Get -Headers $headers 
$curState = $jobState.properties.jobState
$curSU = $jobState.properties.transformation.properties.streamingUnits
$response = $jobState.properties.transformation.properties.validStreamingUnits | Sort-Object

$lengthArray = $response.Count
$index = $response.IndexOf($curSU)

if($index -gt 0) {
    #there are valid SU options job can scale down to
    if($response[$index-1] -ge $minSU){ $targetSU = $response[$index-1]}
    else {
        $targetSU = $response[$index-1]
        Write-Warning –Message "Cannot scale down to $targetSU SUs as minSU variable is set to $minSU SUs."
        exit
    }
}
else {
    #no valid SU options job can scale down to
    $targetSU = $curSU
    Write-Warning –Message "Job is running with $curSU SUs and cannot be scaled down further."
    exit
}
"Current Job state: $curState; Current SU: $curSU; List of valid SUs: $response; Min SU for autoscale: $minSU; Target SU to scale down to now: $targetSU"

$scaleUri = "https://management.azure.com/subscriptions/$subId/resourceGroups/$resourceGroupName/providers/Microsoft.StreamAnalytics/streamingjobs/$jobName/scale?api-version=2017-04-01-preview"

$scaleForm = @{
    "streamingUnits" = $targetSU
}

$jsonBody = $scaleForm | ConvertTo-Json
"Sending scale request with new SU: $targetSU"
Invoke-RestMethod -Uri $scaleUri -Method Post -Headers $headers -Body $jsonBody

# Check scale result
Start-Sleep -Seconds 3

$pollingCount = 0
while ($pollingCount -ne 30)
{
  $pollingCount++
  $jobState = Invoke-RestMethod -Uri $getJobUri -Method Get -Headers $headers 
  if ($jobState.properties.jobState.equals("Running") -and $jobState.properties.transformation.properties.streamingUnits -eq $targetSU.ToString()) { break }
  "Waiting for the job to scale."
  Start-Sleep -Seconds 5
}

$jobState = Invoke-RestMethod -Uri $getJobUri -Method Get -Headers $headers 
$finalState = $jobState.properties.jobState
$finalSU = $jobState.properties.transformation.properties.streamingUnits
"Final Job state: $finalState; Final SU: $finalSU"

if ($finalState.equals("Running") -and $finalSU -eq $targetSU.ToString()) { "Scaling has completed." }
else { throw 'Failed to scale the job' }