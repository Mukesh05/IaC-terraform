$subId = Get-AutomationVariable -Name 'subId'
$resourceGroupName = Get-AutomationVariable -Name 'resourceGroupName'
$jobName = Get-AutomationVariable -Name 'jobName'
$targetSU = Get-AutomationVariable -Name 'increasedSU'
"Executing with subscription id: $subId; resource group name: $resourceGroupName; job name: $jobName; target SU: $targetSU"

$ErrorActionPreference = 'Stop'

try
{

    #Login to Azure using Managed Identity
    "Logging in to Azure..."
    Connect-AzAccount -Identity 

}
catch {
    Write-Error -Message $_.Exception
    throw $_.Exception
}

$accessToken = Get-AzAccessToken

$headers = @{
    'Content-Type' = 'application/json'
    'Authorization' = 'Bearer ' + $accessToken.Token
}

$getJobUri = "https://management.azure.com/subscriptions/$subId/resourceGroups/$resourceGroupName/providers/Microsoft.StreamAnalytics/streamingjobs/$jobName" + '?$expand=transformation&api-version=2017-04-01-preview'

$jobState = Invoke-RestMethod -Uri $getJobUri -Method Get -Headers $headers 
$curState = $jobState.properties.jobState
$curSU = $jobState.properties.transformation.properties.streamingUnits
"Current Job state: $curState; Current SU: $curSU"

$scaleUri = "https://management.azure.com/subscriptions/$subId/resourceGroups/$resourceGroupName/providers/Microsoft.StreamAnalytics/streamingjobs/$jobName/scale?api-version=2017-04-01-preview"

$scaleForm = @{
    "streamingUnits" = $targetSU
}

$jsonBody = $scaleForm | ConvertTo-Json
"Sending scale request..."
Invoke-RestMethod -Uri $scaleUri -Method Post -Headers $headers -Body $jsonBody

# Check scale result
Start-Sleep -Seconds 3

$pollingCount = 0
while ($pollingCount -ne 30)
{
  $pollingCount++
  $jobState = Invoke-RestMethod -Uri $getJobUri -Method Get -Headers $headers 
  if ($jobState.properties.jobState.equals("Running") -and $jobState.properties.transformation.properties.streamingUnits -eq $targetSU.ToString()) { break }
  "Waiting for the job to scale."
  Start-Sleep -Seconds 5
}

$jobState = Invoke-RestMethod -Uri $getJobUri -Method Get -Headers $headers 
$finalState = $jobState.properties.jobState
$finalSU = $jobState.properties.transformation.properties.streamingUnits
"Final Job state: $finalState; Final SU: $finalSU"

if ($finalState.equals("Running") -and $finalSU -eq $targetSU.ToString()) { "Scaling has completed." }
else { throw 'Failed to scale the job' }