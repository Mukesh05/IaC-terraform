## Description

This module creates an autoscaling configuration for an Azure Stream Analytics Job that is provided as an input. The autoscaling configuration supports both scheduled-based and load-based scaling with support for both integrated load-based scaling from inside the module and also supports external configuration from outside the module via references to the action groups.

## Configuration

This module supports scaling only a single Azure Stream Analytics Job at a time and is recomended to be deployed to the same resource group as the stream analytics job and to use a rule of one stream analytics job with autoscaling per resources group.

Main module configuration settings

```yml
{
    stream_analytics_job_name = "" #Configures the stream analytics job to apply the autoscaling support to
    stream_analytics_job_resource_group_name = "" ##Configures the stream analytics job resource group to apply the autoscaling support to
    autoscaling_configuration_type = "" #Configures the autoscaling configuration type - supported values: "schedule", "load"
    schedule_based_autoscaling_configuration = {} #Configuration block for Schedule-Based scaling - See below
    load_based_autoscaling_configuration = {} #Configuration block for Load-Based scaling - See below
}
```

### Schedule-Based Scaling

Top level configuration for Schedule-Based scaling

```yaml
{
    scale_up_schedule = []
    scale_down_schedule = []
    scaled_up_streaming_unit_amount = 12 #Configures the amount of streaming units to scale up to during peak-hours
    scaled_down_streaming_unit_amount = 1 #Configures the amount of streaming units to scale down to during off-hours
}
```

Scale up/Scale down Schedule configuration

```yml
{
    schedule_name = "Scale Up Schedule" #Configures the name for the automation account schedule
    schedule_frequency = "Day" #Configures the frequency for the schedule - can be either "Day", "Hour"
    schedule_description = "" #Configures a friendly description for this Schedule
    schedule_interval = 1 #Configures the number of frequencies between runs
    schedule_start_time = "" #Configures the Start time of the schedule. Must be at least five minutes in the future from when the schedule is created.
    schedule_timezone = "UTC" #Configures the timezone of the start time For possible values see: https://s2.automation.ext.azure.com/api/Orchestrator/TimeZones?_=1594792230258
}

```

### Load-Based Scaling

Top level configuration for Load-Based scaling

```yaml
{
    max_streaming_units = 12 #Configures the maximum amount of streaming units to step up to when scaling up the job
    min_streaming_units = 1 #Configures the minimum amount of streaming units to step down to when scaling down the job
    scale_up_trigger = []
    scale_down_trigger = []
}
```

Scale up/Scale down Trigger configuration

```yaml
{
    name = "" #The name of the scaling trigger. Changing this forces a new resource to be created.
    description = "" #The description of this scaling trigger.
    evaluation_frequency = "PT1M" #Configures the evaluation frequency for the condition to trigger a scaling action - Possible values are "PT1M", "PT5M", "PT15M", "PT30M" and "PT1H"
    evaluation_window_size = "PT1M" #Configures the period of time that is used to monitor for the condition to trigger a scaling action. This value must be greater than or equal to the evaluation_frequency. Possible values are "PT1M", "PT5M", "PT15M", "PT30M", "PT1H", "PT6H", "PT12H", "P1D"
    static_criteria = []
    dynamic_criteria = []
}
```

Static Criteria for Trigger configuration

```yml
{
    metric_name = "" #One of the metric names to be monitored for triggering a scaling action
    aggregation = "" #The statistic that runs over the metric values. Possible values are Average, Count, Minimum, Maximum and Total.
    operator = "" #The criteria operator. Possible values are Equals, NotEquals, GreaterThan, GreaterThanOrEqual, LessThan and LessThanOrEqual
    threshold = "" #The criteria threshold value that activates the scaling action.
}
```

Dynamic Criteria for Trigger configuration

```yml
{
    metric_name = "" #One of the metric names to be monitored for triggering a scaling action
    aggregation = "" #The statistic that runs over the metric values. Possible values are Average, Count, Minimum, Maximum and Total.
    operator = "" #The criteria operator. Possible values are LessThan, GreaterThan and GreaterOrLessThan.
    deviation_threshold = "Medium" #The extent of deviation required to trigger a scaling action. Possible values are Low, Medium and High.
}
```

## Examples

Load based Autoscaling example

```terraform
module "example_job_autoscaling" {
  source = "git::https://dev.azure.com/MyOrg/MyProject/_git/Common.Terraform//modules/azure-streamanalyticsjob-autoscaling?ref=feature/asa-job-scaling"
  
  stream_analytics_job_name                 = azurerm_stream_analytics_job.example.name
  stream_analytics_job_resource_group_name  = azurerm_stream_analytics_job.example.resource_group_name
  autoscaling_configuration_type            = "load"
  load_based_autoscaling_configuration = {
    max_streaming_units = 6
    min_streaming_units = 1
    scale_up_trigger = [
        {
            name                   = "Scale up ${azurerm_stream_analytics_job.example.name} 1"
            description            = "Scales up ${azurerm_stream_analytics_job.example.name} due to High SU utilization"
            evaluation_frequency   = "PT1M"
            evaluation_window_size = "PT1M"
            static_criteria = [
                {
                    metric_name = "ResourceUtilization"
                    aggregation = "Maximum"
                    operator    = "GreaterThan"
                    threshold   = "80"
                }
            ]
            dynamic_criteria = []
        },
        {
            name                   = "Scale up ${azurerm_stream_analytics_job.example.name} 2"
            description            = "Scales up ${azurerm_stream_analytics_job.example.name} due to rising Watermark Delay"
            evaluation_frequency   = "PT1M"
            evaluation_window_size = "PT5M"
            static_criteria = [
                {
                    metric_name = "OutputWatermarkDelaySeconds"
                    aggregation = "Average"
                    operator    = "GreaterThan"
                    threshold   = "300"
                }
            ]
            dynamic_criteria = []
        },
        {
            name                   = "Scale up ${azurerm_stream_analytics_job.example.name} 3"
            description            = "Scales up ${azurerm_stream_analytics_job.example.name} due to rising Backlogged Input Events"
            evaluation_frequency   = "PT5M"
            evaluation_window_size = "PT30M"
            static_criteria = [
                {
                    metric_name = "InputEventsSourcesBacklogged"
                    aggregation = "Average"
                    operator    = "GreaterThan"
                    threshold   = "1"
                }
            ]
            dynamic_criteria = []
        }
    ]
    scale_down_trigger = [
        {
            name                   = "Scale down ${azurerm_stream_analytics_job.example.name} 1"
            description            = ""
            evaluation_frequency   = "PT15M"
            evaluation_window_size = "PT30M"
            static_criteria = [
                {
                    metric_name = "ResourceUtilization"
                    aggregation = "Average"
                    operator    = "LessThan"
                    threshold   = "10"
                },
                {
                    metric_name = "OutputWatermarkDelaySeconds"
                    aggregation = "Average"
                    operator    = "LessThan"
                    threshold   = "10"
                },
                {
                    metric_name = "InputEventsSourcesBacklogged"
                    aggregation = "Maximum"
                    operator    = "LessThan"
                    threshold   = "50"
                }
            ]
            dynamic_criteria = []
        },
        {
            name                   = "Scale down ${azurerm_stream_analytics_job.example.name} 2"
            description            = "Scales down ${azurerm_stream_analytics_job.example.name} when input events are low"
            evaluation_frequency   = "PT15M"
            evaluation_window_size = "PT30M"
            static_criteria = [
                {
                    metric_name = "InputEvents"
                    aggregation = "Total"
                    operator    = "LessThanOrEqual"
                    threshold   = var.stream_analytics_scale_down_min_input_events
                }
            ]
            dynamic_criteria = []
        }
    ]
  }
}
```

## Known Issues

* Azure Automation Account Managed Identity must be manually activated and assigned contributor role directly to the specified Azure Stream Analytics Job.
  * Run AzCLI command to set permissions properly substituting the correct values for your job
  `az role assignment create --assignee "{automation job managed identity object id}" --role "Contributor" --scope "/subscriptions/{subscriptionId}/resourcegroups/{resourceGroupName}/providers/Microsoft.StreamAnalytics/streamingjobs/{resourceName}"`