# Azure Audit / Health Check


<ul>

| Attribute  | Description |
| ------------- | ------------- |
| `FileName`     | Azure_Health_Check.ps1  |
| `Author`   | Craig Fretwell |
| `Company`     | New Signature |
| `Version`    | 1.1 |
| `Date`     | 07-August-2019  |
| `Updated`     | 31-August-2019 |
| `Requires`     | PowerShell Version 5.1 or later|
| `Module`     | Az Version 2.5.0 |
| `Runas`     | Administrator {Set-ExecutionPolicy Un-Restricted} |
| `Bug Report`     | Craig.Fretwell@NewSignature.com |

</ul>

-----------------------

## Synopsis
--------
<ul> 
    This PowerShell script will audits an entire Azure Subscription for specific resources including;

    Resource Groups
    Virtual Machines - IP Address, SKU, Disks, VM Size, Availability Set, Number of NICs
    NSGs
    NSG Rules
    Load Balancers
    Virtual Networks
    All Resources (High Level)
    Storage Accounts
    VM Backups
    Backup Policies
    Locks
    Key Vault 
    Route Tables
    Azure Monitor (Action Groups)
    WAF / Application Gateway.
    RBAC
    Azure Advisor
------
Please Note:

All collected information gets compiled into CSV then converts them to XLSX and formats the tables to New Signatures colour branding,
    the tables and information can be easily copied and pasted into the Azure Health Check / Audit Document.
    
If there's no information within the excel file, that normally means there's no resource present, but double check in the portal if you're unsure.

Please use the following document as a build template:

* https://newsignature1.sharepoint.com/:w:/r/sites/UKAzurePractice/Shared%20Documents/General/Azure_Health_Check_Audit_v.01.docx?d=w4e4121ea7cc8452d8983e814a5541e69&csf=1&e=uVIz8t 