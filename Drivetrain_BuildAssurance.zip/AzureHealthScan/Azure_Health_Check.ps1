<#
.SYNOPSIS
    Audits resources in Azure for health check, a template document is located here: 

.LINK  "https://newsignature1.sharepoint.com/:w:/r/sites/UKAzurePractice/Shared%20Documents/General/Azure_Health_Check_Audit_v.01.docx?d=w4e4121ea7cc8452d8983e814a5541e69&csf=1&e=uVIz8t" 

.DESCRIPTION
    Audits an entire Azure Subscription for specific resources including; 

    Resource Groups
    Virtual Machines - IP Address, SKU, Disks, VM Size, Availability Set, Number of NICs
    NSGs
    NSG Rules
    Load Balancers
    Virtual Networks
    All Resources (High Level)
    Storage Accounts
    VM Backups
    Backup Policies
    Locks
    Key Vault 
    Route Tables
    Azure Monitor (Action Groups)
    WAF / Application Gateway
    RBAC - All Roles assigned at User Level (Not Group Level) per Subscription

    Please Note:

    All collected information gets compiled into CSV then converts them to XLSX and formats the tables to New Signatures colour branding,
    the tables and information can be easily copied and pasted into the Azure Health Check / Audit Document.
    If there's no information within the excel file, that normally means there's no resource present, but double check in the portal if you're unsure.

    Audits yet to come;
    
    Total No. Resources in Regions
    SQL Backups
    Azure Firewall
    Log Analytics 
    Alerts

    #### Pre Reqs ###

    Minimum of Reader Access to the Azure portal (Reader must also be able to see all resources provisioned within Azure)
    For getting Key Vault Secrets, you need to be added into Access Policies or results will return 'Forbidden'

.NOTES
    File Name : Azure_Health_Check.ps1
    Author    : Craig Fretwell
    Company   : New Signature
    Version   : 1.1
    Date      : 07-August-2019
    Updated   : 22-October-2019
    Requires  : PowerShell Version 5.1 or later
    Module    : Az Version 2.5.0
    RunAs     : Administrator {Set-ExecutionPolicy Un-Restricted}
    Bug Report: Craig.Fretwell@NewSignature.com

.OUTPUTS 
Background Intellectual Property Rights means all Intellectual Property Rights that arise or that are obtained
or developed by or on behalf of New Signature prior to, or otherwise outside, the scope of the Services to be provided under this Agreement. 
 
The parties acknowledge and agree that all Background Intellectual Property Rights shall be and remain the property of New Signature, 
its suppliers and/or its licensors, and under no circumstances shall any of the Background Intellectual Property Rights 
be deemed to have been assigned to the Customer unless explicitly stated in a Statement of Work


.EXAMPLE
    .\Azure_Health_Check.ps1

 /$$   /$$                                /$$$$$$  /$$                                 /$$                                  
| $$$ | $$                               /$$__  $$|__/                                | $$                                  
| $$$$| $$  /$$$$$$  /$$  /$$  /$$      | $$  \__/ /$$  /$$$$$$  /$$$$$$$   /$$$$$$  /$$$$$$   /$$   /$$  /$$$$$$   /$$$$$$ 
| $$ $$ $$ /$$__  $$| $$ | $$ | $$      |  $$$$$$ | $$ /$$__  $$| $$__  $$ |____  $$|_  $$_/  | $$  | $$ /$$__  $$ /$$__  $$
| $$  $$$$| $$$$$$$$| $$ | $$ | $$       \____  $$| $$| $$  \ $$| $$  \ $$  /$$$$$$$  | $$    | $$  | $$| $$  \__/| $$$$$$$$
| $$\  $$$| $$_____/| $$ | $$ | $$       /$$  \ $$| $$| $$  | $$| $$  | $$ /$$__  $$  | $$ /$$| $$  | $$| $$      | $$_____/
| $$ \  $$|  $$$$$$$|  $$$$$/$$$$/      |  $$$$$$/| $$|  $$$$$$$| $$  | $$|  $$$$$$$  |  $$$$/|  $$$$$$/| $$      |  $$$$$$$
|__/  \__/ \_______/ \_____/\___/        \______/ |__/ \____  $$|__/  |__/ \_______/   \___/   \______/ |__/       \_______/
                                                       /$$  \ $$                                                            
                                                      |  $$$$$$/                                                            
                                                       \______/
#>

[CmdletBinding()]
Param

(
    [Parameter(Mandatory=$false)]
    [ValidateNotNullOrEmpty()]
    [string]$foldername = 'C:\Azure Audit' # This is the folder location for all audits to be saved too.
)

Function AreYouAuthenticated {

    % {Write-Host ""}
    Write-Host "Checking if you're logged into Azure..." -ForegroundColor Yellow; 
    % {Write-Host ""}
    Start-Sleep -s 2
    if ([string]::IsNullOrEmpty($(Get-AzContext).Account)) {Login-AzAccount} 
    
}

Function Importing_Modules {
    % {Write-Host ""}
    Write-Host "Importing the Az modules..." -ForegroundColor Yello; 
    % {Write-Host ""}
    Remove-Module Az.Accounts -Force -Verbose
    Import-Module Az.RecoveryServices -MinimumVersion 1.4.3 -Force -Verbose
    Import-Module Az.Accounts -MinimumVersion 1.6.1 -Force -Verbose
    Install-Module Az.Security -Force
    Import-Module Az.Security -Force
    
}

Function Select-Subscription {
    Clear-Host
    $ErrorActionPreference = 'SilentlyContinue'
    $Menu = 0
    $Subs = @(Get-AzSubscription | select Name, ID, TenantId)

    Write-Host "Please select the subscription you want to Audit:" -ForegroundColor Green;
    % {Write-Host ""}
    $Subs | % {Write-Host "[$($Menu)]" -ForegroundColor Cyan -NoNewline ; Write-host ". $($_.Name)"; $Menu++; }
    % {Write-Host ""}
    % {Write-Host "[S]" -ForegroundColor Yellow -NoNewline ; Write-host ". To switch Azure Account."}
    % {Write-Host ""}
    % {Write-Host "[Q]" -ForegroundColor Red -NoNewline ; Write-host ". To quit."}
    % {Write-Host ""}
    $selection = Read-Host "Please select the Subscription Number - Valid numbers are 0 - $($Subs.count -1), S to switch Azure Account or Q to quit"
    If ($selection -eq 'S') { 
        Get-AzContext | ForEach-Object {Clear-AzContext -Scope CurrentUser -Force}
        Select-Subscription
    }
    If ($selection -eq 'Q') { 
        Clear-Host
        Exit
    }
    If ($Subs.item($selection) -ne $null)
    { Return @{name = $subs[$selection].Name; ID = $subs[$selection].ID} 
    }

}

$Sub = Select-Subscription
Select-AzSubscription -SubscriptionName $Sub.Name -ErrorAction Stop
% {Write-Host ""}
Write-Host "You're currently logged into Subscription" -ForegroundColor Yellow; 
% {Write-Host ""}
Write-Host $sub.Name -ForegroundColor Red; 

Function CreateDirectory {

    Clear-Host
    Write-Host "Creating a new directory called C:\Azure Audit..." -ForegroundColor Yellow; 
    % {Write-Host ""}
    New-item $foldername -ItemType Directory -Force -Verbose 
    % {Write-Host ""}
    Write-Host "New directory has been created $foldername"-ForegroundColor Green; 
    % {Write-Host ""}
    Start-Sleep -s 5
}

Function Resource_Group_Audit {
    
    Clear-Host

    % {Write-Host ""}
    Write-Host "Performing Resource Group Audit, please be patient..." -Verbose -ForegroundColor Yellow
    % {Write-Host ""}
    $rgfilename = "$foldername\ResourceGroupsAudit.csv"
    $allResources = @()
    
    
        $resourcegroups = Get-AzResourceGroup
        foreach ($resourcegroup in $resourcegroups)
        {
            $customPsObject = New-Object -TypeName PsObject
            $tags = $resource.Tags.Keys + $resource.Tags.Values -join ':'
    
            $customPsObject | Add-Member -MemberType NoteProperty -Name ResourceGroupName -Value $resourcegroup.ResourceGroupName -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name Location -Value $resourcegroup.Location -Verbose

            $allResources += $customPsObject
        }

    $allResources | Export-Csv $rgfilename -NoTypeInformation -Verbose

    $xl = new-object -comobject excel.application
    $xl.visible = $False
    $wb = $xl.workbooks.open("$rgfilename")
    $table=$wb.ActiveSheet.ListObjects.add( 1,$wb.ActiveSheet.UsedRange,0,1)
    $wb.ActiveSheet.UsedRange.EntireColumn.AutoFit()
    $xl.DisplayAlerts=$False
    $wb.SaveAs("$foldername\Resource Group Audit.xlsx",51)
    $xl.Quit()

    Start-Sleep -Seconds 3
    
}

Function VM_Audit {

    Clear-Host

    % {Write-Host ""}
    Write-Host "Performing Azure VM Audit, please be patient..." -Verbose -ForegroundColor Yellow
    % {Write-Host ""}
    $vmfilename = "$foldername\VMAudit.csv"
    $allResources = @()
    $resources = Get-AzVM
    
    foreach ($vm in $resources) 
    {
        $customPsObject = New-Object -TypeName PsObject
        
        If ($vm.StorageProfile.OsDisk.ManagedDisk.Id -ne $null)
        {
            $osDiskStorageAccount = 'Managed Disk'
        }
        
        else
        {
            $osDiskStorageAccount = ([uri]$vm.StorageProfile.OsDisk.Vhd.Uri).Host
        }
        
        $nics = $vm.NetworkProfile.NetworkInterfaces
        $dataDiskS = $vm.StorageProfile.DataDisks
                
        $customPsObject | Add-Member -MemberType NoteProperty -Name "VM Name" -Value $vm.Name -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name "RG" -Value $vm.ResourceGroupName -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name "Location" -Value $vm.Location -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name "Size" -Value $vm.HardwareProfile.VmSize -Verbose
        $customPsObject | Add-Member -MemberType Noteproperty -Name "OS version" -Value $vm.StorageProfile.OsDisk.OsType -Verbose
        $customPsObject | Add-Member -MemberType Noteproperty -Name "OS type" -Value $vm.StorageProfile.ImageReference.Sku -Verbose

        $i = 0
        foreach ($adapter in $nics)
        {
            $nic = Get-AzResource -ResourceId $adapter.Id
            $vnet = ($nic.Properties.ipConfigurations.properties.subnet -split '/')[-3]
            $subnet = ($nic.Properties.ipConfigurations.properties.subnet -split '/')[-1]
            $privateIpAddress = $nic.Properties.ipConfigurations.properties.privateIPAddress
            $publicIpId = $nic.Properties.ipConfigurations.properties.publicIPAddress.id
            
            if ($publicIpId -eq $null)
            {
                $publicIpAddress = $null
            }
            Else
            {
                $publicIpResource = Get-AzResource -ResourceId $publicIpId -ErrorAction SilentlyContinue
                $publicIpAddress = $publicIpResource.Properties.ipAddress
            }
            
            $availabilitySet = ($vm.AvailabilitySetReference.Id -split '/')[-1]        
            $customPsObject | Add-Member -MemberType NoteProperty -Name ("NIC-" + $i + "-Vnet") -Value $vnet -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name ("NIC-" + $i + "-Subnet")  -Value $subnet -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name ("NIC-" + $i + "-PrivateIpAddress") -Value $privateIpAddress -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name ("NIC-" + $i + "-PublicIpAddress") -Value $publicIpAddress -Verbose
            $i++
        }

        $customPsObject | Add-Member -MemberType NoteProperty -Name AvailabilitySet -Value $availabilitySet -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name osDisk -Value $osDiskStorageAccount -Verbose

        $i = 0
        foreach ($dataDisk in $dataDiskS)
        {
            if ($DataDisk.ManagedDisk.Id -ne $null)
            {
                $dataDiskHost = 'Managed Disk'
            }
            Else
            {
                $dataDiskHost = ([uri]($dataDisk.Vhd.Uri)).Host
            }
            $customPsObject | Add-Member -MemberType NoteProperty -Name ("dataDisk-" + $i) -Value $dataDiskHost
            $i++
        }
        
        $allResources += $customPsObject 
    }

    $allResources | Export-Csv $vmfilename -NoTypeInformation -Verbose 

    $xl = new-object -comobject excel.application
    $xl.visible = $fale
    $wb = $xl.workbooks.open("$vmfilename")
    $table=$wb.ActiveSheet.ListObjects.add( 1,$wb.ActiveSheet.UsedRange,0,1)
    $wb.ActiveSheet.UsedRange.EntireColumn.AutoFit()
    $xl.DisplayAlerts=$False
    $wb.SaveAs("$foldername\VM Audit.xlsx",51)
    $xl.Quit()
    #Remove-Item -Path "$foldername\*.csv" # This will remove all CSV's in current folder

}

Function NSG_Audit {
    % {Write-Host ""}
    Write-Host "Performing NSG Audit, please be patient..." -Verbose -ForegroundColor Yellow
    % {Write-Host ""}
    $NSGfilename = "$foldername\NSGAudit.csv"
    
    $allResources = @()
    
        $resources = Get-AzNetworkSecurityGroup
        foreach ($resource in $resources)
        {
            $customPsObject = New-Object -TypeName PsObject
            $tags = $resource.Tags.Keys + $resource.Tags.Values -join ':'
            $nics = $resource.NetworkInterfaces
            $subnets = $resource.Subnets
    
            $customPsObject | Add-Member -MemberType NoteProperty -Name ResourceName -Value $resource.Name
            $customPsObject | Add-Member -MemberType NoteProperty -Name ResourceGroup -Value $resource.ResourceGroupName
            $customPsObject | Add-Member -MemberType NoteProperty -Name Location -Value $resource.Location
    
            $i = 0
            foreach ($subnet in $subnets)
            {
                $subnetString = ($subnet.Id -split '/')[-3] + "\" + ($subnet.Id -split '/')[-1]
                $customPsObject | Add-Member -MemberType NoteProperty -Name ("AssignedSubnet-" + $i) -Value $subnetString
                $i++
            }
    
            $i = 0
            foreach ($nic in $nics)
            {
                $nicString = ($nic.Id -split '/')[-1]
                $customPsObject | Add-Member -MemberType NoteProperty -Name ("AssignedNic-" + $i) -Value $subnetString
                $i++
            }
    
            $allResources += $customPsObject
    
        }
    
    $allResources | Export-Csv $NSGfilename -NoTypeInformation -Verbose
    
    $xl = new-object -comobject excel.application
    $xl.visible = $False
    $wb = $xl.workbooks.open("$NSGfilename")
    $table=$wb.ActiveSheet.ListObjects.add( 1,$wb.ActiveSheet.UsedRange,0,1)
    $wb.ActiveSheet.UsedRange.EntireColumn.AutoFit()
    $xl.DisplayAlerts=$False
    $wb.SaveAs("$foldername\NSG Audit.xlsx",51)
    $xl.Quit()
    #Remove-Item -Path "C:\Azure Audit\*.csv" # This will remove all CSV's in current folder
}

Function NSG_Rules {

    % {Write-Host ""}
    Write-Host "Performing NSG Rules, please be patient..." -Verbose -ForegroundColor Yellow
    % {Write-Host ""}
    $Newfoldername = "$foldername\NSGRules"
    New-item $Newfoldername -ItemType Directory -Force 
    $exportPath = "$Newfoldername"
    
    $nsgs = Get-AzNetworkSecurityGroup
    
    Foreach ($nsg in $nsgs) {
        $nsgRules = $nsg.SecurityRules
        foreach ($nsgRule in $nsgRules) {
            $nsgRule | Select-Object Name,Description,Priority,@{Name='SourceAddressPrefix';Expression={[string]::join("", ($_.SourceAddressPrefix))}},@{Name='SourcePortRange';Expression={[string]::join("", ($_.SourcePortRange))}},@{Name='DestinationAddressPrefix';Expression={[string]::join("", ($_.DestinationAddressPrefix))}},@{Name='DestinationPortRange';Expression={[string]::join("", ($_.DestinationPortRange))}},Protocol,Access,Direction `
            | Export-Csv "$exportPath\$($nsg.Name).csv" -NoTypeInformation -Encoding ASCII -Verbose -Append
        }
    }
    Foreach($file in (Get-ChildItem "$exportPath")) {
        $newname = $file.FullName -replace '.csv', '.xlsx'
        $xl = new-object -comobject excel.application
        $xl.visible = $false 
        $wb = $xl.workbooks.open($file.FullName) 
        $table=$wb.ActiveSheet.ListObjects.add( 1,$wb.ActiveSheet.UsedRange,0,1)
        $wb.ActiveSheet.UsedRange.EntireColumn.AutoFit() 
        $xl.DisplayAlerts=$False
        $wb.SaveAs($newname,51)
        $xl.Quit()  
        
        }
    
}
    
Function LoadBalancer_Audit {

    % {Write-Host ""}
    Write-Host "Performing Load Balancer Audit, please be patient..." -Verbose -ForegroundColor Yellow
    % {Write-Host ""}
    $LoadBalancerfilename = "$foldername\LoadBalancerAudit.csv"
    
    $allResources = @()
    
        $resources = Get-AzLoadBalancer
        foreach ($resource in $resources)
        {
            $customPsObject = New-Object -TypeName PsObject
            $tags = $resource.Tags.Keys + $resource.Tags.Values -join ':'
    
            If ($resource.FrontendIpConfigurations.PrivateIpAddress -eq $null -ne $null)
            {
                $privIp = $resource.FrontendIpConfigurations.PrivateIpAddress
                
            }
            Else
            {
                $privIp = $null
            }
    
            If ($resource.FrontendIpConfigurations.PublicIpAddress -ne $null)
            {
                $pubIp = (Get-AzResource -ResourceId $resource.FrontendIpConfigurations.PublicIpAddress.Id).Properties.ipAddress
                
            }
            Else
            {
                $pubIp = $null
            }
    
            $customPsObject | Add-Member -MemberType NoteProperty -Name ResourceName -Value $resource.Name
            $customPsObject | Add-Member -MemberType NoteProperty -Name ResourceGroup -Value $resource.ResourceGroupName
            $customPsObject | Add-Member -MemberType NoteProperty -Name Location -Value $resource.Location
            $customPsObject | Add-Member -MemberType NoteProperty -Name FrontEndPrivateIp -Value $privIp
            $customPsObject | Add-Member -MemberType NoteProperty -Name FrontEndPublicIp -Value $pubIp      
            $customPsObject | Add-Member -MemberType NoteProperty -Name BackEndPools -Value $resource.BackendAddressPools.Name
    
            $i = 0
            foreach ($lbRule in $resource.LoadBalancingRules)
            {
                $ruleString = "Name=" + $lbRule.Name + ", " + "FrontendPort=" + $lbRule.FrontendPort + ", " + "Protocol=" + $lbRule.Protocol + ", " + "BackendPort=" + $lbRule.BackendPort
                $customPsObject | Add-Member -MemberType NoteProperty -Name ("lbRule-" + $i) -Value $ruleString
                $i++
            }
    
            $i = 0
            foreach ($probe in $resource.Probes)
            {
                $probeString = "Name=" + $lbRule.Name + ", " + "Port=" + $probe.Port + ", " + "Protocol=" + $probe.Protocol + ", " + "Interval=" + $lbRule.IntervalInSeconds + ", " + "Count=" + $lbRule.NumberOfProbes
                $customPsObject | Add-Member -MemberType NoteProperty -Name ("probe-" + $i) -Value $probeString
                $i++
            }
    
            $customPsObject | Add-Member -MemberType NoteProperty -Name Tags -Value $tags
            $customPsObject | Add-Member -MemberType NoteProperty -Name Subscription -Value $subscription.Name
            $allResources += $customPsObject
    
        }
    
    $allResources | Export-Csv $LoadBalancerfilename -NoTypeInformation -Verbose

    $xl = new-object -comobject excel.application
    $xl.visible = $False
    $wb = $xl.workbooks.open("$Loadbalancerfilename")
    $table=$wb.ActiveSheet.ListObjects.add( 1,$wb.ActiveSheet.UsedRange,0,1)
    $wb.ActiveSheet.UsedRange.EntireColumn.AutoFit()
    $xl.DisplayAlerts=$False
    $wb.SaveAs("$foldername\Loadbalancer Audit.xlsx",51)
    $xl.Quit()
}

Function Vnet_Audit {

    % {Write-Host ""}
    Write-Host "Performing Vnet Audit, please be patient..." -Verbose -ForegroundColor Yellow
    % {Write-Host ""}
    $Vnetfilename = "$foldername\VnetAudit.csv"
    
    $allResources = @()
    
        $resources = Get-AzVirtualNetwork
        foreach ($vnet in $resources)
        {
            $customPsObject = New-Object -TypeName PsObject
    
            $customPsObject | Add-Member -MemberType NoteProperty -Name VnetName -Value $vnet.Name -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name Location -Value $vnet.Location -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name Subscription -Value $sub.Name -Verbose
    
    
            $i = 0
            foreach ($prefix in $vnet.AddressSpace)
            {
                $customPsObject | Add-Member -MemberType NoteProperty -Name ("AddressSpace-" + $i) -Value $vnet.AddressSpace[$i].AddressPrefixes[0]
                $i++
            }
    
            $i = 0
            foreach ($subnet in $vnet.Subnets)
            {
                $subnetString = $subnet.Name + ":" + $vnet.Subnets[$i].AddressPrefix
                $customPsObject | Add-Member -MemberType NoteProperty -Name ("Subnet-" + $i) -Value $subnetString
                $i++
            }
    
            $i = 0
            foreach ($peering in $vnet.virtualNetworkPeerings)
            {
                $customPsObject | Add-Member -MemberType NoteProperty -Name ("VNetPeering" + $i) -Value $vnet.VirtualNetworkPeerings[$i].Name -Verbose
                $customPsObject | Add-Member -MemberType NoteProperty -Name ("VNetPeering" + $i + "-(State)") -Value $vnet.VirtualNetworkPeerings[$i].PeeringState -Verbose
                $customPsObject | Add-Member -MemberType NoteProperty -Name ("VNetPeering" + $i + "-(RemoteVirtualNetwork)") -Value ($vnet.VirtualNetworkPeerings[$i].RemoteVirtualNetwork.Id -split '/')[-1] -Verbose
                $customPsObject | Add-Member -MemberType NoteProperty -Name ("VNetPeering" + $i + "-(AllowVnetAccecss)") -Value $vnet.VirtualNetworkPeerings[$i].AllowVirtualNetworkAccess -Verbose
                $customPsObject | Add-Member -MemberType NoteProperty -Name ("VNetPeering" + $i + "-(AllowForwardedTraffic)") -Value $vnet.VirtualNetworkPeerings[$i].AllowForwardedTraffic -Verbose
                $customPsObject | Add-Member -MemberType NoteProperty -Name ("VNetPeering" + $i + "-(AllowGatewayTransit)") -Value $vnet.VirtualNetworkPeerings[$i].AllowGatewayTransit -Verbose
                $customPsObject | Add-Member -MemberType NoteProperty -Name ("VNetPeering" + $i + "-(UseRemoteGateway)") -Value $vnet.VirtualNetworkPeerings[$i].UseRemoteGateways -Verbose
                $i++
            }
            
            $allResources += $customPsObject
        }
    
    $allResources | Export-Csv $Vnetfilename -NoTypeInformation -Verbose
    $xl = new-object -comobject excel.application
    $xl.visible = $False
    $wb = $xl.workbooks.open("$Vnetfilename")
    $table=$wb.ActiveSheet.ListObjects.add( 1,$wb.ActiveSheet.UsedRange,0,1)
    $wb.ActiveSheet.UsedRange.EntireColumn.AutoFit()
    $xl.DisplayAlerts=$False
    $wb.SaveAs("$foldername\Vnet Audit.xlsx",51)
    $xl.Quit()
}

Function Resource_Audit {

    % {Write-Host ""}
    Write-Host "Performing a full Resource Audit, please be patient..." -Verbose -ForegroundColor Yellow
    % {Write-Host ""}
    $resourcefilename = "$foldername\ResourceAudit.csv"
    $allResources = @()
    
    
        $resources = Get-AzResource
        foreach ($resource in $resources)
        {
            $customPsObject = New-Object -TypeName PsObject
            $tags = $resource.Tags.Keys + $resource.Tags.Values -join ':'
    
            $customPsObject | Add-Member -MemberType NoteProperty -Name ResourceName -Value $resource.Name -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name ResourceGroup -Value $resource.ResourceGroupName -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name ResourceType -Value $resource.ResourceType -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name Kind -Value $resource.Kind -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name Location -Value $resource.Location -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name Tags -Value $tags -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name Sku -Value $resource.Sku -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name ResourceId -Value $resource.ResourceId -Verbose
            $allResources += $customPsObject
        }
    $allResources | Export-Csv $resourcefilename -NoTypeInformation -Verbose

    $xl = new-object -comobject excel.application
    $xl.visible = $False
    $wb = $xl.workbooks.open("$resourcefilename")
    $table=$wb.ActiveSheet.ListObjects.add( 1,$wb.ActiveSheet.UsedRange,0,1)
    $wb.ActiveSheet.UsedRange.EntireColumn.AutoFit()
    $xl.DisplayAlerts=$False
    $wb.SaveAs("$foldername\Resource Audit.xlsx",51)
    $xl.Quit()
}

Function Storage_Audit {

    
    % {Write-Host ""}
    Write-Host "Performing Storage Account Audit, please be patient..." -Verbose -ForegroundColor Yellow
    % {Write-Host ""}
    $storagefilename = "$foldername\StorageAudit.csv"
    $allResources = @()
    
    
        $saresources = Get-AzStorageAccount
        foreach ($saresource in $saresources)
        {
            $customPsObject = New-Object -TypeName PsObject
            $tags = $resource.Tags.Keys + $resource.Tags.Values -join ':'
    
            $customPsObject | Add-Member -MemberType NoteProperty -Name StorageAccountName -Value $saresource.StorageAccountName -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name ResourceGroup -Value $saresource.ResourceGroupName -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name Location -Value $saresource.Location -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name Sku -Value $saresource.Sku.Name -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name Kind -Value $saresource.Kind -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name AccessTier -Value $saresource.AccessTier -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name EnableHttpsTrafficOnly -Value $saresource.EnableHttpsTrafficOnly -Verbose

            $allResources += $customPsObject
        }

    $allResources | Export-Csv $storagefilename -NoTypeInformation -Verbose

    $xl = new-object -comobject excel.application
    $xl.visible = $False
    $wb = $xl.workbooks.open("$storagefilename")
    $table=$wb.ActiveSheet.ListObjects.add( 1,$wb.ActiveSheet.UsedRange,0,1)
    $wb.ActiveSheet.UsedRange.EntireColumn.AutoFit()
    $xl.DisplayAlerts=$False
    $wb.SaveAs("$foldername\Storage Audit.xlsx",51)
    $xl.Quit()
}

Function VM_Backup_Audit {
   
    % {Write-Host ""}
    Write-Host "Performing Azure VM Backup Audit, please be patient..." -Verbose -ForegroundColor Yellow
    % {Write-Host ""}
    $backupfilename = "$foldername\BackupAudit.csv"
    $allResources = @()
    
    Import-Module Az.RecoveryServices
    Import-Module Az.Accounts 
    
    $azure_recovery_services_vault_list = Get-AzRecoveryServicesVault 
    
    foreach($azure_recovery_services_vault_list_iterator in $azure_recovery_services_vault_list) { 
     
        #Set-AzRecoveryAsrServicesVaultContext -Vault $azure_recovery_services_vault_list_iterator 
     
        $container_list = Get-AzRecoveryServicesBackupContainer -ContainerType 'AzureVM' -VaultId $azure_recovery_services_vault_list_iterator.id
     
        foreach($container_list_iterator in $container_list){ 
     
             
            $backup_item = Get-AzRecoveryServicesBackupItem -Container $container_list_iterator -WorkloadType 'AzureVM' -VaultId $azure_recovery_services_vault_list_iterator.id
            $backup_item_array = ($backup_item.ContainerName).split(';') 
            $backup_item_resource_name = $backup_item_array[1] 
            $backup_item_vm_name = $backup_item_array[2] 
            $backup_item_last_backup_status = $backup_item.LastBackupStatus 
            $backup_item_latest_recovery_point = $backup_item.LatestRecoveryPoint 
     
            $customPsObject = New-Object psobject 
            $tags = $resource.Tags.Keys + $resource.Tags.Values -join ':'
     
            $customPsObject | Add-Member -MemberType NoteProperty -Name "ResourceGroupName" -Value $backup_item_resource_name 
            $customPsObject | Add-Member -MemberType NoteProperty -Name "VMName" -Value $backup_item_vm_name 
            $customPsObject | Add-Member -MemberType NoteProperty -Name "VaultName" -Value $azure_recovery_services_vault_list_iterator.Name 
            $customPsObject | Add-Member -MemberType NoteProperty -Name "BackupStatus" -Value $backup_item_last_backup_status 
            $customPsObject | Add-Member -MemberType NoteProperty -Name "LatestRecoveryPoint" -Value $backup_item_latest_recovery_point 
    
            $allResources += $customPsObject
     
        } 
     
    } 
    
        $allResources | Export-Csv $backupfilename -NoTypeInformation -Verbose
    
        $xl = new-object -comobject excel.application
        $xl.visible = $False
        $wb = $xl.workbooks.open("$backupfilename")
        $table=$wb.ActiveSheet.ListObjects.add( 1,$wb.ActiveSheet.UsedRange,0,1)
        $wb.ActiveSheet.UsedRange.EntireColumn.AutoFit()
        $xl.DisplayAlerts=$False
        $wb.SaveAs("$foldername\Backup Audit.xlsx",51)
        $xl.Quit() 
    
}

Function BackUp_Policy_Audit {
    
    % { Write-Host "" }
    Write-Host "Performing Azure Backup Policy Audit, please be patient..." -Verbose -ForegroundColor Yellow
    % { Write-Host "" }
    $backuppolicyfilename = "$foldername\BackupPolicyAudit.csv"
    $allResources = @()

    $azure_recovery_services_vault_list = Get-AzRecoveryServicesVault 
    
    foreach ($azure_recovery_services_vault_lists in $azure_recovery_services_vault_list) { 
 
        $policy_list = Get-AzRecoveryServicesBackupProtectionPolicy -VaultId $azure_recovery_services_vault_lists.id
 
        foreach ($policy_lists in $policy_list) { 
     
            $customPsObject = New-Object psobject 
            $tags = $resource.Tags.Keys + $resource.Tags.Values -join ':'
 
            $customPsObject | Add-Member -MemberType NoteProperty -Name "Name" -Value $policy_lists.Name 
            $customPsObject | Add-Member -MemberType NoteProperty -Name "WorkloadType" -Value $policy_lists.WorkloadType 
            $customPsObject | Add-Member -MemberType NoteProperty -Name "BackupManagementType" -Value $policy_lists.BackupManagementType 
            $customPsObject | Add-Member -MemberType NoteProperty -Name "Schedule" -Value $policy_lists.SchedulePolicy
            $customPsObject | Add-Member -MemberType NoteProperty -Name "SnapshotRetentionInDays" -Value $policy_lists.SnapshotRetentionInDays
            $customPsObject | Add-Member -MemberType NoteProperty -Name "DailyScheduleEnabled" -Value $policy_lists.RetentionPolicy.IsDailyScheduleEnabled
            $customPsObject | Add-Member -MemberType NoteProperty -Name "MonthlyScheduleEnabled" -Value $policy_lists.RetentionPolicy.IsMonthlyScheduleEnabled
            $customPsObject | Add-Member -MemberType NoteProperty -Name "WeeklyScheduleEnabled" -Value $policy_lists.RetentionPolicy.IsWeeklyScheduleEnabled
            $customPsObject | Add-Member -MemberType NoteProperty -Name "YearlyScheduleEnabled" -Value $policy_lists.RetentionPolicy.IsYearlyScheduleEnabled
            $customPsObject | Add-Member -MemberType NoteProperty -Name "DailySchedule" -Value $policy_lists.RetentionPolicy.DailySchedule
            $customPsObject | Add-Member -MemberType NoteProperty -Name "MonthlySchedule" -Value $policy_lists.RetentionPolicy.MonthlySchedule
            $customPsObject | Add-Member -MemberType NoteProperty -Name "WeeklySchedule" -Value $policy_lists.RetentionPolicy.WeeklySchedule
            $customPsObject | Add-Member -MemberType NoteProperty -Name "YearlySchedule" -Value $policy_lists.RetentionPolicy.YearlySchedule

            $allResources += $customPsObject
        } 
    }

    $allResources | Export-Csv $backuppolicyfilename -NoTypeInformation -Verbose

    $xl = new-object -comobject excel.application
    $xl.visible = $False
    $wb = $xl.workbooks.open("$backuppolicyfilename")
    $table = $wb.ActiveSheet.ListObjects.add( 1, $wb.ActiveSheet.UsedRange, 0, 1)
    $wb.ActiveSheet.UsedRange.EntireColumn.AutoFit()
    $xl.DisplayAlerts = $False
    $wb.SaveAs("$foldername\Backup Policy Audit.xlsx", 51)
    $xl.Quit()
}

Function Locks_Audit {
    
    % { Write-Host "" }
    Write-Host "Performing Azure Locks Audit, please be patient..." -Verbose -ForegroundColor Yellow
    % { Write-Host "" }
    $lockfilename = "$foldername\LockAudit.csv"
    % { Write-Host "" }
    $allResources = @()
    
    $lock = Get-AzResourceLock
     
            foreach ($locks in $lock) { 
         
                $customPsObject = New-Object psobject 
                $tags = $resource.Tags.Keys + $resource.Tags.Values -join ':'
     
                $customPsObject | Add-Member -MemberType NoteProperty -Name "Name" -Value $locks.Name
                $customPsObject | Add-Member -MemberType NoteProperty -Name "ResourceGroupName" -Value $locks.ResourceGroupName
                $customPsObject | Add-Member -MemberType NoteProperty -Name "ExtensionResourceName" -Value $locks.ExtensionResourceName
                $customPsObject | Add-Member -MemberType NoteProperty -Name "ExtensionResourceType" -Value $locks.ExtensionResourceType
                $customPsObject | Add-Member -MemberType NoteProperty -Name "Properties" -Value $locks.Properties
                $customPsObject | Add-Member -MemberType NoteProperty -Name "ResourceName" -Value $locks.ResourceName
                $customPsObject | Add-Member -MemberType NoteProperty -Name "ResourceType" -Value $locks.ResourceType
                
                $allResources += $customPsObject
    
                }
    
                $allResources | Export-Csv $lockfilename -NoTypeInformation -Verbose
    
                $xl = new-object -comobject excel.application
                $xl.visible = $False
                $wb = $xl.workbooks.open("$lockfilename")
                $table=$wb.ActiveSheet.ListObjects.add( 1,$wb.ActiveSheet.UsedRange,0,1)
                $wb.ActiveSheet.UsedRange.EntireColumn.AutoFit()
                $xl.DisplayAlerts=$False
                $wb.SaveAs("$foldername\Lock Audit.xlsx",51)
                $xl.Quit()
    
}

Function Key_Vault_Audit {
    
    % { Write-Host "" }
    Write-Host "Performing Key Vault Audit, please be patient..." -Verbose -ForegroundColor Yellow
    % { Write-Host "" }
    $keyvaultfilename = "$foldername\KeyVaultAudit.csv"
    % { Write-Host "" }
    $allResources = @()
    
    $keyvault1 = Get-AzKeyVault
     
            foreach ($keyvaults in $keyvault1) { 
    
                $keyvaultsecret = Get-AzKeyVaultSecret -VaultName $keyvaults.VaultName
    
                foreach ($keyvaultsecrets in $keyvaultsecret) {
         
            $customPsObject = New-Object psobject 
            $tags = $resource.Tags.Keys + $resource.Tags.Values -join ':'
     
            $customPsObject | Add-Member -MemberType NoteProperty -Name "VaultName" -Value $keyvaults.VaultName
            $customPsObject | Add-Member -MemberType NoteProperty -Name "ResourceGroupName" -Value $keyvaults.ResourceGroupName
            $customPsObject | Add-Member -MemberType NoteProperty -Name "Location" -Value $keyvaults.Location
            $customPsObject | Add-Member -MemberType NoteProperty -Name "KeyVaultSecretName" -Value $keyvaultsecrets.Name
            $customPsObject | Add-Member -MemberType NoteProperty -Name "KeyVaultSecretEnabled" -Value $keyvaultsecrets.Enabled
            $customPsObject | Add-Member -MemberType NoteProperty -Name "KeyVaultSecretCreated" -Value $keyvaultsecrets.Created
            $customPsObject | Add-Member -MemberType NoteProperty -Name "KeyVaultSecretExpires" -Value $keyvaultsecrets.Expires
                  
                        
            $allResources += $customPsObject
    
            }
        }
    
            $allResources | Export-Csv $keyvaultfilename -NoTypeInformation -Verbose
            
            $xl = new-object -comobject excel.application
            $xl.visible = $False
            $wb = $xl.workbooks.open("$keyvaultfilename")
            $table=$wb.ActiveSheet.ListObjects.add( 1,$wb.ActiveSheet.UsedRange,0,1)
            $wb.ActiveSheet.UsedRange.EntireColumn.AutoFit()
            $xl.DisplayAlerts=$False
            $wb.SaveAs("$foldername\Key Vault Audit.xlsx",51)
            $xl.Quit()
    
}

Function Log_Analytics_Audit {

    % {Write-Host ""}
    Write-Host "Performing Azure Log Analytics Audit, please be patient..." -Verbose -ForegroundColor Yellow
    % {Write-Host ""}
    $filename = "$foldername\LogAnalyticsAudit.csv"
    $allResources = @()
    
    
        $resource = Get-AzOperationalInsightsWorkspace
        foreach ($resources in $resource)
        {
            $customPsObject = New-Object -TypeName PsObject
            $tags = $resource.Tags.Keys + $resource.Tags.Values -join ':'
    
            $customPsObject | Add-Member -MemberType NoteProperty -Name LogAnalyticsName -Value $resources.Name -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name ResourceGroupName -Value $resources.ResourceGroupName -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name Location -Value $resources.Location -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name Sku -Value $resources.Sku -Verbose

            $allResources += $customPsObject
        }

    $allResources | Export-Csv $filename -NoTypeInformation -Verbose

    $xl = new-object -comobject excel.application
    $xl.visible = $False
    $wb = $xl.workbooks.open("$filename")
    $table=$wb.ActiveSheet.ListObjects.add( 1,$wb.ActiveSheet.UsedRange,0,1)
    $wb.ActiveSheet.UsedRange.EntireColumn.AutoFit()
    $xl.DisplayAlerts=$False
    $wb.SaveAs("$foldername\Log Analytics Audit.xlsx",51)
    $xl.Quit()
    
}

Function Azure_Monitor_Audit {

    % { Write-Host "" }
    Write-Host "Performing Azure Monitor Audit, please be patient..." -Verbose -ForegroundColor Green
    
Function ActionGroups {

    $azfilename = "$foldername\ActionGroupsAudit.csv"
    $allResources = @()
    if ([string]::IsNullOrEmpty($(Get-AzActionGroup).EmailReceivers)) {Get-AzActionGroup} 

    $azresources = Get-AzActionGroup 
    foreach ($azresource in $azresources)
    {

        $email = $azresources.EmailReceivers 

        foreach ($emails in $email) {
        $customPsObject = New-Object -TypeName PsObject 
        $tags = $resource.Tags.Keys + $resource.Tags.Values -join ':' 
        
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'Name' -Value $azresources.Name -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'ResourceGroupName' -Value $azresources.ResourceGroupName -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'Location' -Value $azresources.Location -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'EmailReceivers0' -Value $email.EmailAddress[0]
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'EmailReceivers1' -Value $email.EmailAddress[1]
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'EmailReceivers2' -Value $email.EmailAddress[2]
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'EmailReceivers3' -Value $email.EmailAddress[3]
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'EmailReceivers4' -Value $email.EmailAddress[4]
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'EmailReceivers5' -Value $email.EmailAddress[5]
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'GroupEnabled' -Value $azresources.Enabled -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'GroupShortName' -Value $azresources.GroupShortName -Verbose
        
        $allResources += $customPsObject
    }
}

    $allResources | Export-Csv $azfilename -NoTypeInformation -Verbose

    $xl = new-object -comobject excel.application
    $xl.visible = $False
    $wb = $xl.workbooks.open("$azfilename")
    $table=$wb.ActiveSheet.ListObjects.add( 1,$wb.ActiveSheet.UsedRange,0,1)
    $wb.ActiveSheet.UsedRange.EntireColumn.AutoFit()
    $xl.DisplayAlerts=$False
    $wb.SaveAs("$foldername\Action Groups Audit.xlsx",51)
    $xl.Quit()

    }

    Function AlertRules {

    $azfilename = "$foldername\AlertRulesAudit.csv"
    $allResources = @()

    $azruleresources = Get-AzAlertRule -TargetResourceId
 
    foreach ($azruleresource in $azruleresources)
    {
        $customPsObject = New-Object -TypeName PsObject
        $tags = $resource.Tags.Keys + $resource.Tags.Values -join ':'

        $customPsObject | Add-Member -MemberType NoteProperty -Name 'Name' -Value $azruleresources.Name -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'Email' -Value $azruleresources.Email -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'ResourceGroupName' -Value $azruleresources.ResourceGroupName -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'Location' -Value $azruleresources.Location -Verbose

        $allResources += $customPsObject
    }

    $allResources | Export-Csv $azfilename -NoTypeInformation -Verbose

    $xl = new-object -comobject excel.application
    $xl.visible = $False
    $wb = $xl.workbooks.open("$azfilename")
    $table=$wb.ActiveSheet.ListObjects.add( 1,$wb.ActiveSheet.UsedRange,0,1)
    $wb.ActiveSheet.UsedRange.EntireColumn.AutoFit()
    $xl.DisplayAlerts=$False
    $wb.SaveAs("$foldername\Alert Rules Audit.xlsx",51)
    $xl.Quit()

    }

    ActionGroups
    #AlertRules
}

Function Azure_Sec_Center_Audit {

    % { Write-Host "" }
    Write-Host "Performing Azure Security Center Audit, please be patient..." -Verbose -ForegroundColor Green
    Function SecContactInfo {

    $secfilename = "$foldername\ContactInfoAudit.csv"
    $allResources = @()

    $secresources = Get-AzSecurityContact 
    foreach ($secresource in $secresources)
    {
        $customPsObject = New-Object -TypeName PsObject
        $tags = $resource.Tags.Keys + $resource.Tags.Values -join ':'

        $customPsObject | Add-Member -MemberType NoteProperty -Name 'Name' -Value $secresource.Name -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'Email' -Value $secresource.Email -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'Phone' -Value $secresource.Phone -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'AlertNotifications' -Value $seccontact.AlertNotifications -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'AlertsToAdmins' -Value $seccontact.AlertsToAdmins -Verbose

        $allResources += $customPsObject
    }

    $allResources | Export-Csv $secfilename -NoTypeInformation -Verbose

    $xl = new-object -comobject excel.application
    $xl.visible = $False
    $wb = $xl.workbooks.open("$secfilename")
    $table=$wb.ActiveSheet.ListObjects.add( 1,$wb.ActiveSheet.UsedRange,0,1)
    $wb.ActiveSheet.UsedRange.EntireColumn.AutoFit()
    $xl.DisplayAlerts=$False
    $wb.SaveAs("$foldername\Security Center Contact Info Audit.xlsx",51)
    $xl.Quit()

    }

    Function SecPricingInfo {

        $sec1filename = "$foldername\PricingAudit.csv"
        $allResources = @()
    
        $secresources = Get-AzSecurityPricing
        foreach ($secresource in $secresources)
        {
            $customPsObject = New-Object -TypeName PsObject
            $tags = $resource.Tags.Keys + $resource.Tags.Values -join ':'
    
            $customPsObject | Add-Member -MemberType NoteProperty -Name 'Name' -Value $secresource.Name -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name 'PricingTier' -Value $secresource.PricingTier -Verbose
    
            $allResources += $customPsObject
        }
    
        $allResources | Export-Csv $sec1filename -NoTypeInformation -Verbose
    
        $xl = new-object -comobject excel.application
        $xl.visible = $False
        $wb = $xl.workbooks.open("$sec1filename")
        $table=$wb.ActiveSheet.ListObjects.add( 1,$wb.ActiveSheet.UsedRange,0,1)
        $wb.ActiveSheet.UsedRange.EntireColumn.AutoFit()
        $xl.DisplayAlerts=$False
        $wb.SaveAs("$foldername\Security Center Pricing Audit.xlsx",51)
        $xl.Quit()
    
    }

    SecContactInfo
    SecPricingInfo
}

Function Route_Table_Audit {

% {Write-Host ""}
Write-Host "Performing Route Table Audit, please be patient..." -Verbose -ForegroundColor Green
% {Write-Host ""}
$rtfilename = "$foldername\RouteTableAudit.csv"
$allResources = @()

    $routetable = Get-AzRouteTable | Get-AzRouteTable -Name $routetable.Name

    foreach($routetables in $routetable) { 

    $routesobject = ConvertFrom-Json -InputObject $routetable.RoutesText

    foreach($routesobjects in $routesobject) {
  
        $customPsObject = New-Object psobject 
        $tags = $resource.Tags.Keys + $resource.Tags.Values -join ':'
 
        $customPsObject | Add-Member -MemberType NoteProperty -Name "Name" -Value $routetable.Name
        $customPsObject | Add-Member -MemberType NoteProperty -Name "ResourceGroupName" -Value $routetable.ResourceGroupName
        $customPsObject | Add-Member -MemberType NoteProperty -Name "Location" -Value $routetable.Location
        $customPsObject | Add-Member -MemberType NoteProperty -Name "RouteName" -Value $routesobject.Name
        $customPsObject | Add-Member -MemberType NoteProperty -Name "AddressPrefix" -Value $routesobject.AddressPrefix
        $customPsObject | Add-Member -MemberType NoteProperty -Name "NextHopIpAddress" -Value $routesobject.NextHopIpAddress
        $customPsObject | Add-Member -MemberType NoteProperty -Name "NextHopType" -Value $routesobject.NextHopType

        $allResources += $customPsObject

        }
  } 

$allResources | Export-Csv $rtfilename -NoTypeInformation -Verbose

    $xl = new-object -comobject excel.application
    $xl.visible = $False
    $wb = $xl.workbooks.open("$rtfilename")
    $table=$wb.ActiveSheet.ListObjects.add( 1,$wb.ActiveSheet.UsedRange,0,1)
    $wb.ActiveSheet.UsedRange.EntireColumn.AutoFit()
    $xl.DisplayAlerts=$False
    $wb.SaveAs("$foldername\Route Table Audit.xlsx",51)
    $xl.Quit() 

}

Function WAF_Audit {

% {Write-Host ""}
Write-Host "Performing WAF Audit, please be patient..." -Verbose -ForegroundColor Yellow
% {Write-Host ""}
$filename = "$foldername\WAFAudit.csv"
$allResources = @()
    
    
    
    $resources = Get-AzApplicationGateway
    foreach ($resource in $resources)
    {
        $customPsObject = New-Object -TypeName PsObject

        $customPsObject | Add-Member -MemberType NoteProperty -Name ApplicationGatewayName -Value $resource.Name -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name Location -Value $resource.Location -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name ResourceGroupName -Value $resource.ResourceGroupName -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name BackendAddressPools -Value $resource.BackendAddressPools.Name
        $customPsObject | Add-Member -MemberType NoteProperty -Name Sku -Value $resource.Sku.Tier
        $customPsObject | Add-Member -MemberType NoteProperty -Name WAFEnabled -Value $resource.WebApplicationFirewallConfiguration
        $customPsObject | Add-Member -MemberType NoteProperty -Name PrivateIPConfig -Value $resource.FrontendIPConfigurations.privateipaddress  
        $customPsObject | Add-Member -MemberType NoteProperty -Name PublicIPConfig -Value $resource.FrontendIPConfigurations.publicipaddresstext   
        $i = 0
        
        foreach ($listener in $resource.HTTPListeners)
        {
            $subnetString = $resource.HTTPListeners[$i].Name
            $subnetString1 = $resource.HTTPListeners[$i].Protocol
            $subnetString2 = $resource.HTTPListeners[$i].HostName
            $customPsObject | Add-Member -MemberType NoteProperty -Name ("HTTPListeners-" + $i) -Value $subnetString
            $customPsObject | Add-Member -MemberType NoteProperty -Name ("HTTPProtocol-" + $i) -Value $subnetString1
            $customPsObject | Add-Member -MemberType NoteProperty -Name ("Hostname-" + $i) -Value $subnetString2
            $i++
        }
       
        $allResources += $customPsObject
    }



$allResources | Export-Csv $filename -NoTypeInformation -Append -Force


$xl = new-object -comobject excel.application
$xl.visible = $False
$wb = $xl.workbooks.open("$filename")
$table=$wb.ActiveSheet.ListObjects.add( 1,$wb.ActiveSheet.UsedRange,0,1)
$wb.ActiveSheet.UsedRange.EntireColumn.AutoFit()
$xl.DisplayAlerts=$False
$wb.SaveAs("$foldername\WAF Audit.xlsx",51)
$xl.Quit()


}

Function RBAC_User_Audit {
    
    Clear-Host

    % {Write-Host ""}
    Write-Host "Performing RBAC Owners Audit, please be patient..." -Verbose -ForegroundColor Yellow
    % {Write-Host ""}
    $rgfilename = "$foldername\RBACUserAudit.csv"
    $allResources = @()
    
    
        $resourcegroups = Get-AzRoleAssignment #| Where-Object {$_.RoleDefinitionName -eq "Owner"}
        foreach ($resourcegroup in $resourcegroups)
        {
            $customPsObject = New-Object -TypeName PsObject
            $tags = $resource.Tags.Keys + $resource.Tags.Values -join ':'
            
            $customPsObject | Add-Member -MemberType NoteProperty -Name SignInName -Value $resourcegroup.SignInName -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name DisplayName -Value $resourcegroup.DisplayName -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name Role -Value $resourcegroup.RoleDefinitionName -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name ObjectType -Value $resourcegroup.ObjectType -Verbose
            

            $allResources += $customPsObject
        }

    $allResources | Export-Csv $rgfilename -NoTypeInformation -Verbose

    $xl = new-object -comobject excel.application
    $xl.visible = $False
    $wb = $xl.workbooks.open("$rgfilename")
    $table=$wb.ActiveSheet.ListObjects.add( 1,$wb.ActiveSheet.UsedRange,0,1)
    $wb.ActiveSheet.UsedRange.EntireColumn.AutoFit()
    $xl.DisplayAlerts=$False
    $wb.SaveAs("$foldername\RBAC User Audit.xlsx",51)
    $xl.Quit()

    Start-Sleep -Seconds 3
    
}

Function All_Functions{
    
    AreYouAuthenticated
    Importing_Modules
    CreateDirectory
    Resource_Group_Audit
    VM_Audit 
    NSG_Audit 
    NSG_Rules 
    LoadBalancer_Audit 
    Vnet_Audit
    Resource_Audit
    Storage_Audit 
    VM_Backup_Audit
    BackUp_Policy_Audit
    Locks_Audit
    Key_Vault_Audit
    Log_Analytics_Audit
    Azure_Monitor_Audit
    Azure_Sec_Center_Audit
    Route_Table_Audit
    WAF_Audit
    RBAC_User_Audit
}

All_Functions

Function CleanUp {

    Write-Host "Removing CSVs from C:\Azure Audit Folder..." -ForegroundColor Red; 
    % {Write-Host ""}
    Remove-Item -Path "$foldername\*.csv" # This will remove all CSV's in Azure Audit folder
    % {Write-Host ""}
    Clear-Host
    Start-Sleep -s 3
    Write-Host "Removing CSVs from C:\Azure Audit\NSG Rules Folder..." -ForegroundColor Red; 
    Remove-Item -Path "$foldername\NSGRules\*.csv" # This will remove all CSV's in NSG Rules folder
    % {Write-Host ""}
    Clear-Host
    Start-Sleep -s 3
    Write-Host "Renaming Azure Audit folder too include Subscription Name..." -ForegroundColor Red; 
    $newfoldername = 'C:\Azure Audit '+$sub.Name
    % {Write-Host ""}
    Rename-Item $foldername -NewName $newfoldername -Verbose
    % {Write-Host ""}
    Start-Sleep -s 3
    Clear-Host
    % {Write-Host ""}
    % {Write-Host ""}
    Write-Host "Azure Health Check Audit Successfully completed, this window will close in 10 seconds" -ForegroundColor Green; 
    Start-Sleep -s 10 
    Clear-Host
}

CleanUp