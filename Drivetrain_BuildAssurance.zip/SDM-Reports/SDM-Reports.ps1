[CmdletBinding()]
Param

(
    [Parameter(Mandatory = $false)]
    [switch]$sendtobackend,

    [Parameter(Mandatory = $false)]
    [switch]$unittesting,

    [Parameter(Mandatory = $false)]
    [switch]$skipimportmodules,

    [Parameter(Mandatory = $false)]
    [switch]$skipazauth,

    [Parameter(Mandatory = $false)]
    [object]$subscription,

    [Parameter(Mandatory = $false)]
    [switch]$allSubscriptions = $false
)


Function AreYouAuthenticated {
    
    if ($true -eq $skipazauth) {
        return
    }
    Write-Host "Checking if you're logged into Azure..." -ForegroundColor Yellow; 
  
    Start-Sleep -s 2
    if ([string]::IsNullOrEmpty($(Get-AzContext).Account)) { Login-AzAccount } 
    
}

Function Send-PostToBackend {
    param (
        [object]$object,
        [string]$name,
        [switch]$sendtobackend
    ) 

    try {
        $postobj = [PSCustomObject]@{
            ReportName = $name
            Content    = $object
        }
        $postobj = $postobj | ConvertTo-Json -Depth 100 
        $postobj | Out-File "$env:temp\$name"
    }
    catch {
        Write-Warning "Error converting object to JSON to send to backend: $_"
        return $null
    }
    
    if ($sendtobackend) {

        $action
        $context = Get-AzContext;
        if($context.Tenant.Id -eq "f3ee2a7e-7235-4d28-ab42-617c4c17f0c1") {
            # MPS Logic App
            $action = Invoke-WebRequest `
            -UseBasicParsing `
            -Uri "https://prod-15.uksouth.logic.azure.com:443/workflows/6636b9c9c6a649baa296039a2d87ef34/triggers/manual/paths/invoke?api-version=2016-10-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=9RxtJbxkmVKOsMavJh-SAcLlNo4nntcGFOiJxg7K-UA" `
            -Body $postobj `
            -Method Post `
            -ContentType 'application/json'
        }
        else {
            #default logic app
            $action = Invoke-WebRequest `
            -UseBasicParsing `
            -Uri "https://prod-00.uksouth.logic.azure.com:443/workflows/c986a9e3e81f4dc5bad60f77aafbed29/triggers/manual/paths/invoke?api-version=2016-10-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=qunZnP4bheT5Nlhd7YQZy53XRB_vnUv1ekslpqBQGgg" `
            -Body $postobj `
            -Method Post `
            -ContentType 'application/json'
        }
    }
}

Function Get-AzTenantListfromREST {
    [CmdletBinding()] Param ()
    $currentAzureContext = Get-AzContext
    $azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
    $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile)
    $token = $profileClient.AcquireAccessToken($currentAzureContext.Subscription.TenantId).AccessToken

    $headers = @{
        'Authorization' = "Bearer $token"
        'Host'          = "management.azure.com"
        'Content-Type'  = 'application/json'
    }
    $uri = "https://management.azure.com/tenants?api-version=2017-08-01"

    $response = Invoke-WebRequest -Uri $uri -Headers $headers -Method Get -UseBasicParsing
    $tenants = $response.content | ConvertFrom-Json
    $tenants = $tenants.value

    Return $tenants
}


Function Select-Subscription {
   
    $ErrorActionPreference = '"SilentlyContinue"'
    $Menu = 0
    $Subs = @(Get-AzSubscription | Select-Object Name, ID, TenantId)
    $Subs | ForEach-Object { Write-Host "[$($Menu)]" -ForegroundColor Cyan -NoNewline ; Write-host ". $($_.Name)"; $Menu++; }
  
    ForEach-Object { Write-Host "[S]" -ForegroundColor Yellow -NoNewline ; Write-host ". To switch Azure Account." }
    ForEach-Object { Write-Host "[Q]" -ForegroundColor Red -NoNewline ; Write-host ". To quit." }
  
    $selection = Read-Host "Please select the Subscription Number - Valid numbers are 0 - $($Subs.count -1), S to switch Azure Account or Q to quit"
    If ($selection -eq 'S') { 
        Get-AzContext | ForEach-Object { Clear-AzContext -Scope CurrentUser -Force }
        Select-Subscription
    }
    If ($selection -eq 'Q') { 
       
        Exit
    }

    If ($null -ne $Subs.item($selection)) {
        Return @{
            name     = $subs[$selection].Name
            ID       = $subs[$selection].ID
            TenantID = $subs[$selection].TenantID
        } 
    }
    return $Subs
}


Function Resource_Group_Audit {
  
    Write-Host "Performing Resource Group Audit, please be patient..." -Verbose -ForegroundColor Yellow
    $allResources = @()
    $resourcegroups = Get-AzResourceGroup

    foreach ($resourcegroup in $resourcegroups) {
        $customPsObject = New-Object -TypeName PsObject
    
        $customPsObject | Add-Member -MemberType NoteProperty -Name ResourceGroupName -Value $resourcegroup.ResourceGroupName -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name Location -Value $resourcegroup.Location -Verbose

        $allResources += $customPsObject
    }
    $post.Resource_Group_Audit = $allResources 
}

Function VM_Audit {
    Write-Host "Performing Azure VM Audit, please be patient..." -Verbose -ForegroundColor Yellow
    $allResources = @()
    $resources = Get-AzVM
    
    foreach ($vm in $resources) {
        $customPsObject = New-Object -TypeName PsObject
        
        If ($null -ne $vm.StorageProfile.OsDisk.ManagedDisk.Id) {
            $osDiskStorageAccount = 'Managed Disk'
        }
        
        else {
            $osDiskStorageAccount = ([uri]$vm.StorageProfile.OsDisk.Vhd.Uri).Host
        }
        
        $nics = $vm.NetworkProfile.NetworkInterfaces
        $dataDiskS = $vm.StorageProfile.DataDisks
                
        $customPsObject | Add-Member -MemberType NoteProperty -Name "VM Name" -Value $vm.Name -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name "RG" -Value $vm.ResourceGroupName -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name "Location" -Value $vm.Location -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name "Size" -Value $vm.HardwareProfile.VmSize -Verbose
        $customPsObject | Add-Member -MemberType Noteproperty -Name "OSType" -Value $vm.StorageProfile.OsDisk.OsType -Verbose
        $customPsObject | Add-Member -MemberType Noteproperty -Name "OS version" -Value $vm.StorageProfile.ImageReference.Sku -Verbose
        
        $i = 0
        foreach ($adapter in $nics) {
            $nic = Get-AzResource -ResourceId $adapter.Id
            $vnet = ($nic.Properties.ipConfigurations.properties.subnet -split '/')[-3]
            $subnet = (($nic.Properties.ipConfigurations.properties.subnet -split '/')[-1]).Replace('}', '')
            $privateIpAddress = $nic.Properties.ipConfigurations.properties.privateIPAddress
            $publicIpId = $nic.Properties.ipConfigurations.properties.publicIPAddress.id
            
            if ($null -eq $publicIpId ) {
                $publicIpAddress = $null
            }
            Else {
                $publicIpResource = Get-AzResource -ResourceId $publicIpId -ErrorAction "SilentlyContinue"
                $publicIpAddress = $publicIpResource.Properties.ipAddress
            }
            
            $availabilitySet = ($vm.AvailabilitySetReference.Id -split '/')[-1]        
            $customPsObject | Add-Member -MemberType NoteProperty -Name ("NIC-" + $i + "-Vnet") -Value $vnet -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name ("NIC-" + $i + "-Subnet")  -Value $subnet -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name ("NIC-" + $i + "-PrivateIpAddress") -Value $privateIpAddress -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name ("NIC-" + $i + "-PublicIpAddress") -Value $publicIpAddress -Verbose
            $i++
        }

        $customPsObject | Add-Member -MemberType NoteProperty -Name AvailabilitySet -Value $availabilitySet -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name osDisk -Value $osDiskStorageAccount -Verbose

        $i = 0
        foreach ($dataDisk in $dataDiskS) {
            if ($null -ne $DataDisk.ManagedDisk.Id) {
                $dataDiskHost = 'Managed Disk'
            }
            Else {
                $dataDiskHost = ([uri]($dataDisk.Vhd.Uri)).Host
            }
            $customPsObject | Add-Member -MemberType NoteProperty -Name ("dataDisk-" + $i) -Value $dataDiskHost
            $i++
        }
        
        $allResources += $customPsObject 
    }
    $post.VM_Audit = $allResources 
}

Function Vnet_Audit {
    Write-Host "Performing Vnet Audit, please be patient..." -Verbose -ForegroundColor Yellow
    $allResources = @()
    $resources = Get-AzVirtualNetwork

    foreach ($vnet in $resources) {
        $customPsObject = New-Object -TypeName PsObject
        $customPsObject | Add-Member -MemberType NoteProperty -Name VnetName -Value $vnet.Name -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name Location -Value $vnet.Location -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name Subscription -Value $sub.Name -Verbose
        
        $i = 0
        foreach ($prefix in $vnet.AddressSpace) {
            $customPsObject | Add-Member -MemberType NoteProperty -Name ("AddressSpace-" + $i) -Value $vnet.AddressSpace[$i].AddressPrefixes[0]
            $i++
        }
        
        ## Create an empty array to build the subnet list
        $SubnetNsgArray = @()

        ## Loop through all subnets and build the list
        ForEach ($Subnet in $vnet.Subnets) {
    
            If ($null -ne $subnet.NetworkSecurityGroup) {
                $nsgName = $subnet.NetworkSecurityGroup.Id.split('/')[-1]
            }

            $SubnetNsgArray += $Subnet.Name + ":" + $nsgName
        }

        $customPsObject | Add-Member -MemberType NoteProperty -Name "Subnet_NSG" -Value $SubnetNsgArray
        
        $i = 0
        foreach ($peering in $vnet.virtualNetworkPeerings) {
            $customPsObject | Add-Member -MemberType NoteProperty -Name ("VNetPeering" + $i) -Value $vnet.VirtualNetworkPeerings[$i].Name -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name ("VNetPeering" + $i + "-(State)") -Value $vnet.VirtualNetworkPeerings[$i].PeeringState -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name ("VNetPeering" + $i + "-(RemoteVirtualNetwork)") -Value ($vnet.VirtualNetworkPeerings[$i].RemoteVirtualNetwork.Id -split '/')[-1] -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name ("VNetPeering" + $i + "-(AllowVnetAccecss)") -Value $vnet.VirtualNetworkPeerings[$i].AllowVirtualNetworkAccess -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name ("VNetPeering" + $i + "-(AllowForwardedTraffic)") -Value $vnet.VirtualNetworkPeerings[$i].AllowForwardedTraffic -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name ("VNetPeering" + $i + "-(AllowGatewayTransit)") -Value $vnet.VirtualNetworkPeerings[$i].AllowGatewayTransit -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name ("VNetPeering" + $i + "-(UseRemoteGateway)") -Value $vnet.VirtualNetworkPeerings[$i].UseRemoteGateways -Verbose
            $i++
        }
            
        $allResources += $customPsObject
    }
    $post.Vnet_Audit = $allResources 
}

Function Resource_Audit {  
    Write-Host "Performing a full Resource Audit, please be patient..." -Verbose -ForegroundColor Yellow
    $allResources = @()      
    $resources = Get-AzResource

    foreach ($resource in $resources) {
        $customPsObject = New-Object -TypeName PsObject
        $tags = $resource.Tags.Keys + $resource.Tags.Values -join ':'
    
        $customPsObject | Add-Member -MemberType NoteProperty -Name ResourceName -Value $resource.Name -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name ResourceGroup -Value $resource.ResourceGroupName -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name ResourceType -Value $resource.ResourceType -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name Kind -Value $resource.Kind -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name Location -Value $resource.Location -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name Tags -Value $tags -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name Sku -Value $resource.Sku -Verbose
        $customPsObject | Add-Member -MemberType NoteProperty -Name ResourceId -Value $resource.ResourceId -Verbose
        
        $resourceDiagnosticsSettings = Get-AzDiagnosticSetting -ResourceId $resource.ResourceId -ErrorVariable ProcessError -ErrorAction SilentlyContinue -WarningAction SilentlyContinue

        If (0 -eq $ProcessError.Count) {
            If (@($resourceDiagnosticsSettings.Logs | Where-Object Enabled -eq $true).Count -gt 0) {
                $customPsObject | Add-Member -MemberType NoteProperty -Name LogsEnabled -Value 1 -Verbose
            }
            else {
                $customPsObject | Add-Member -MemberType NoteProperty -Name LogsEnabled -Value 0 -Verbose
            }

            If (@($resourceDiagnosticsSettings.Metrics | Where-Object Enabled -eq $true).Count -gt 0) {
                $customPsObject | Add-Member -MemberType NoteProperty -Name MetricsEnabled -Value 1 -Verbose
            }
            else {
                $customPsObject | Add-Member -MemberType NoteProperty -Name MetricsEnabled -Value 0 -Verbose
            }

            If ($null -ne $resourceDiagnosticsSettings.Workspaceid) {
                $LAWorkSpaceName = @($resourceDiagnosticsSettings.workspaceid.Split('/'))[8]
                $customPsObject | Add-Member -MemberType NoteProperty -Name LogsAnalyticsWorkSpaceName -Value $LAWorkSpaceName -Verbose
            }
        }
        $allResources += $customPsObject
    }
    $post.Resource_Audit = $allResources 
}

Function VM_Backup_Audit {
    Write-Host "Performing Azure VM Backup Audit, please be patient..." -Verbose -ForegroundColor Yellow
    $allResources = @()
    
    $azure_recovery_services_vault_list = Get-AzRecoveryServicesVault 
    
    foreach ($azure_recovery_services_vault_list_iterator in $azure_recovery_services_vault_list) { 
        $container_list = Get-AzRecoveryServicesBackupContainer -ContainerType 'AzureVM' -VaultId $azure_recovery_services_vault_list_iterator.id
     
        foreach ($container_list_iterator in $container_list) { 
            $backup_item = Get-AzRecoveryServicesBackupItem -Container $container_list_iterator -WorkloadType 'AzureVM' -VaultId $azure_recovery_services_vault_list_iterator.id
            $backup_item_array = ($backup_item.ContainerName).split(';') 
            $backup_item_resource_name = $backup_item_array[1] 
            $backup_item_vm_name = $backup_item_array[2] 
            $backup_item_last_backup_status = $backup_item.LastBackupStatus 
            $backup_item_latest_recovery_point = $backup_item.LatestRecoveryPoint 
     
            $customPsObject = New-Object psobject 
     
            $customPsObject | Add-Member -MemberType NoteProperty -Name "ResourceGroupName" -Value $backup_item_resource_name 
            $customPsObject | Add-Member -MemberType NoteProperty -Name "VMName" -Value $backup_item_vm_name 
            $customPsObject | Add-Member -MemberType NoteProperty -Name "VaultName" -Value $azure_recovery_services_vault_list_iterator.Name 
            $customPsObject | Add-Member -MemberType NoteProperty -Name "BackupStatus" -Value $backup_item_last_backup_status 
            $customPsObject | Add-Member -MemberType NoteProperty -Name "LatestRecoveryPoint" -Value $backup_item_latest_recovery_point 
    
            $allResources += $customPsObject
        } 
    } 
    $post.VM_Backup_Audit = $allResources     
}

Function BackUp_Policy_Audit {
    Write-Host "Performing Azure Backup Policy Audit, please be patient..." -Verbose -ForegroundColor Yellow
    $allResources = @()
    $azure_recovery_services_vault_list = Get-AzRecoveryServicesVault 
    
    foreach ($azure_recovery_services_vault_lists in $azure_recovery_services_vault_list) { 
        $policy_list = Get-AzRecoveryServicesBackupProtectionPolicy -VaultId $azure_recovery_services_vault_lists.id
 
        foreach ($policy_lists in $policy_list) { 
            $customPsObject = New-Object psobject 
            $customPsObject | Add-Member -MemberType NoteProperty -Name "Name" -Value $policy_lists.Name 
            $customPsObject | Add-Member -MemberType NoteProperty -Name "WorkloadType" -Value $policy_lists.WorkloadType 
            $customPsObject | Add-Member -MemberType NoteProperty -Name "BackupManagementType" -Value $policy_lists.BackupManagementType 
            $customPsObject | Add-Member -MemberType NoteProperty -Name "Schedule" -Value $policy_lists.SchedulePolicy
            $customPsObject | Add-Member -MemberType NoteProperty -Name "SnapshotRetentionInDays" -Value $policy_lists.SnapshotRetentionInDays
            $customPsObject | Add-Member -MemberType NoteProperty -Name "DailyScheduleEnabled" -Value $policy_lists.RetentionPolicy.IsDailyScheduleEnabled
            $customPsObject | Add-Member -MemberType NoteProperty -Name "MonthlyScheduleEnabled" -Value $policy_lists.RetentionPolicy.IsMonthlyScheduleEnabled
            $customPsObject | Add-Member -MemberType NoteProperty -Name "WeeklyScheduleEnabled" -Value $policy_lists.RetentionPolicy.IsWeeklyScheduleEnabled
            $customPsObject | Add-Member -MemberType NoteProperty -Name "YearlyScheduleEnabled" -Value $policy_lists.RetentionPolicy.IsYearlyScheduleEnabled
            $customPsObject | Add-Member -MemberType NoteProperty -Name "DailySchedule" -Value $policy_lists.RetentionPolicy.DailySchedule
            $customPsObject | Add-Member -MemberType NoteProperty -Name "MonthlySchedule" -Value $policy_lists.RetentionPolicy.MonthlySchedule
            $customPsObject | Add-Member -MemberType NoteProperty -Name "WeeklySchedule" -Value $policy_lists.RetentionPolicy.WeeklySchedule
            $customPsObject | Add-Member -MemberType NoteProperty -Name "YearlySchedule" -Value $policy_lists.RetentionPolicy.YearlySchedule

            $allResources += $customPsObject
        } 
    }
    $post.BackUp_Policy_Audit = $allResources 
}

Function Azure_Monitor_Audit {
    Write-Host "Performing Azure Monitor Audit, please be patient..." -Verbose -ForegroundColor Yellow
    $WarningPreference = "SilentlyContinue"
    Function ActionGroups {
        $allResources = @()
        if ([string]::IsNullOrEmpty($(Get-AzActionGroup).EmailReceivers)) { Get-AzActionGroup } 
        $WarningPreference = "SilentlyContinue"
        $azresources = Get-AzActionGroup 
        foreach ($azresource in $azresources) {

            $email = $azresources.EmailReceivers 

            foreach ($emails in $email) {
                $customPsObject = New-Object -TypeName PsObject 
        
                $customPsObject | Add-Member -MemberType NoteProperty -Name 'Name' -Value $azresources.Name -Verbose
                $customPsObject | Add-Member -MemberType NoteProperty -Name 'ResourceGroupName' -Value $azresources.ResourceGroupName -Verbose
                $customPsObject | Add-Member -MemberType NoteProperty -Name 'Location' -Value $azresources.Location -Verbose
                $customPsObject | Add-Member -MemberType NoteProperty -Name 'EmailReceivers0' -Value $email.EmailAddress[0]
                $customPsObject | Add-Member -MemberType NoteProperty -Name 'EmailReceivers1' -Value $email.EmailAddress[1]
                $customPsObject | Add-Member -MemberType NoteProperty -Name 'EmailReceivers2' -Value $email.EmailAddress[2]
                $customPsObject | Add-Member -MemberType NoteProperty -Name 'EmailReceivers3' -Value $email.EmailAddress[3]
                $customPsObject | Add-Member -MemberType NoteProperty -Name 'EmailReceivers4' -Value $email.EmailAddress[4]
                $customPsObject | Add-Member -MemberType NoteProperty -Name 'EmailReceivers5' -Value $email.EmailAddress[5]
                $customPsObject | Add-Member -MemberType NoteProperty -Name 'GroupEnabled' -Value $azresources.Enabled -Verbose
                $customPsObject | Add-Member -MemberType NoteProperty -Name 'GroupShortName' -Value $azresources.GroupShortName -Verbose
        
                $allResources += $customPsObject
            }
        }
        return $allResources 
    }

    Function AlertRules {
        $allResources = @()
        $azruleresources = @()
        foreach ($rg in Get-AzResourceGroup) {
            foreach ($alert in $(Get-AzAlertRule -ResourceGroupName $rg.ResourceGroupName)) {
                $azruleresources += $alert
            }
        }

        $WarningPreference = "SilentlyContinue"
        foreach ($azruleresource in $azruleresources) {
            $customPsObject = New-Object -TypeName PsObject
            $customPsObject | Add-Member -MemberType NoteProperty -Name 'Name' -Value $azruleresources.Name -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name 'Email' -Value $azruleresources.Email -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name 'ResourceGroupName' -Value $azruleresources.ResourceGroupName -Verbose
            $customPsObject | Add-Member -MemberType NoteProperty -Name 'Location' -Value $azruleresources.Location -Verbose

            $allResources += $customPsObject
        }
        return $allResources
    }
    $post.Azure_Monitor_Audit = [PSCustomObject]@{
        ActionGroups = ActionGroups 
        AlertRules   = AlertRules 
    }
}
Function Azure_Advisor_Audit {
    Write-Host "Performing Azure Advisor Audit, please be patient..." -Verbose -ForegroundColor Yellow
    $subTable = @{ }
    $recomendations = Get-AzAdvisorRecommendation
    $allReccomendations = @()

    foreach ($r in $recomendations) {
        $resourceValues = $r.ResourceId.Split('/')
        #Get Subscription Name
        if (!$subTable.ContainsKey($resourceValues[2])) {
            $subscription = Get-AzSubscription -SubscriptionId $resourceValues[2]
            $subTable.Add($resourceValues[2], $subscription.Name)
        }

        #Not all Azure Advisor Reccomendations have a Resource Name
        if ($null -eq "$resourceValues[8]") { $resourcename = "N/A"} else {$resourcename = "$resourceValues[8]"}
        $customPsObject = New-Object -TypeName PsObject
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'ResourceGroup' -Value $resourceValues[4]
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'ResourceName' -Value $resourcename
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'ResourceType' -Value "$($resourceValues[6])/$($resourceValues[7])"
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'SubscriptionName' -Value $subTable.Item($resourceValues[2])
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'Category' -Value $($r.Category)
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'Impact' -Value $($r.Impact)
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'Problem'-Value $($r.shortDescription.problem)
        $customPsObject | Add-Member -MemberType NoteProperty -Name 'Solution' -Value $($r.shortDescription.solution)
      
        $allReccomendations += $customPsObject
    }
    $post.Azure_Advisor_Audit = $allReccomendations
}


if (!$unittesting) {
    if (!$allSubscriptions) {
        AreYouAuthenticated
        $tenants = Get-AzTenantListfromREST

        $post = [PSCustomObject]@{
            Customer_Information   = @{
                Subscription_Name = ""
                SubscriptionID    = ""
                TenantID          = ""
                Tenant_Name       = ""
            }
            Resource_Group_Audit   = @()
            VM_Audit               = @()
            NSG_Audit              = @()
            NSG_Rules              = @()
            LoadBalancer_Audit     = @()
            Vnet_Audit             = @()
            Resource_Audit         = @()
            Storage_Audit          = @()
            VM_Backup_Audit        = @()
            BackUp_Policy_Audit    = @()
            Locks_Audit            = @()
            Key_Vault_Audit        = @()
            Log_Analytics_Audit    = @()
            Azure_Monitor_Audit    = @()
            Azure_Sec_Center_Audit = @()
            Route_Table_Audit      = @()
            WAF_Audit              = @()
            RBAC_User_Audit        = @()
            Azure_Advisor_Audit    = @()
        }

        $Sub = Select-Subscription
        $subselected = Select-AzSubscription -SubscriptionName $Sub.Name -ErrorAction Stop
        $post.Customer_Information.SubscriptionID = $sub.Id
        $post.Customer_Information.Subscription_Name = $sub.Name
        $post.Customer_Information.TenantID = $sub.TenantID 
        $post.Customer_Information.Tenant_Name = $(
            $tenants | Where-Object { $_.TenantId -eq $post.Customer_Information.TenantID }
        ).DisplayName

        if ($null -eq $post.Customer_Information.Tenant_Name) {
            throw "Unable to find tenant $($post.Customer_Information.TenantID ) in list `n $tenants `n $_"
        }
      
        Write-Host "You're currently logged into Subscription" -ForegroundColor Yellow; 
        Write-Host ($post.Customer_Information | Format-List *) -ForegroundColor Red; 

        Resource_Group_Audit
        Azure_Advisor_Audit
        Azure_Monitor_Audit
        BackUp_Policy_Audit
        VM_Audit 
        Vnet_Audit
        Resource_Audit
        VM_Backup_Audit
        Write-Host "Converting results for JSON and uploading to central backend... please be patient." -ForegroundColor Yellow
        Send-PostToBackend -object $post -name "azurehealthcheck$(new-guid)" -sendtobackend
        Write-Host "Finished inventory" -ForegroundColor Gray
    }
    else {
        Write-Warning "Running in All Subscriptions Mode, if this is incorrect please select N and exit"
        $x = Read-Host -Prompt "Continue? (Y/N)"
        while ("Y", "N" -notcontains $x) {
            $x = Read-Host -Prompt "Continue? (Y/N)"
        }
        if ($x -ne "Y") {
            Write-Warning "Script Aborting"
            Start-Sleep 5
            exit
        }
        $tenants = Get-AzTenantListfromREST
        foreach ($sub in $(Get-AzSubscription | 
        Where-Object {$_.TenantId -ne "a1a2578a-8fd3-4595-bb18-7d17df8944b0"} | 
        Where-Object {$_.TenantId -ne "6f1aa459-4cba-45cc-a9a9-3b24a8334aee"}))  {
            $post = [PSCustomObject]@{
                Customer_Information   = @{
                    Subscription_Name = ""
                    SubscriptionID    = ""
                    TenantID          = ""
                    Tenant_Name       = ""
                }
                Resource_Group_Audit   = @()
                VM_Audit               = @()
                NSG_Audit              = @()
                NSG_Rules              = @()
                LoadBalancer_Audit     = @()
                Vnet_Audit             = @()
                Resource_Audit         = @()
                Storage_Audit          = @()
                VM_Backup_Audit        = @()
                BackUp_Policy_Audit    = @()
                Locks_Audit            = @()
                Key_Vault_Audit        = @()
                Log_Analytics_Audit    = @()
                Azure_Monitor_Audit    = @()
                Azure_Sec_Center_Audit = @()
                Route_Table_Audit      = @()
                WAF_Audit              = @()
                RBAC_User_Audit        = @()
                Azure_Advisor_Audit    = @()
            }

            Select-AzSubscription -SubscriptionName $Sub.Name -ErrorAction Stop
            $post.Customer_Information.SubscriptionID = $Sub.Id
            $post.Customer_Information.Subscription_Name = $Sub.Name
            $post.Customer_Information.TenantID = $Sub.TenantID 
            $post.Customer_Information.Tenant_Name = $(
                $tenants | Where-Object { $_.TenantId -eq $post.Customer_Information.TenantID }
            ).DisplayName

            if ($null -eq $post.Customer_Information.Tenant_Name) {
                throw "Unable to find tenant $($post.Customer_Information.TenantID ) in list `n $tenants `n $_"
            }

            Write-Host "You're currently logged into Subscription $($post.Customer_Information.Subscription_Name)" -ForegroundColor Yellow;
            Azure_Advisor_Audit
            Azure_Monitor_Audit
            BackUp_Policy_Audit
            Resource_Audit
            Resource_Group_Audit
            VM_Audit 
            VM_Backup_Audit
            Vnet_Audit
            Write-Host "Converting results for JSON and uploading to central backend... please be patient." -ForegroundColor Yellow
            Send-PostToBackend -object $post -name "azurehealthcheck$(new-guid)" -sendtobackend
            Write-Host "Finished inventory" -ForegroundColor Gray
        }
    }
}
 