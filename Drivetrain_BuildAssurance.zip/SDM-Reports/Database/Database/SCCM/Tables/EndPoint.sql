﻿CREATE TABLE [SCCM].[EndPoint] (
    [ClientName]                          NVARCHAR (255) NULL,
    [ResourceID]                          NVARCHAR (255) NULL,
    [Computer Name]                       NVARCHAR (255) NULL,
    [EP_DeploymentState]                  INT            NULL,
    [EP_PolicyApplicationState]           INT            NULL,
    [EP_AntivirusSignatureVersion]        NVARCHAR (255) NULL,
    [EP_AntivirusSignatureUpdateDateTime] DATETIME       NULL,
    [EP_InfectionStatus]                  INT            NULL,
    [IsClient]                            INT            NULL,
    [IsObsolete]                          INT            NULL,
    [EpAtRisk]                            INT            NULL,
    [EpProtected]                         INT            NULL,
    [EpNotYetInstalled]                   INT            NULL
);

