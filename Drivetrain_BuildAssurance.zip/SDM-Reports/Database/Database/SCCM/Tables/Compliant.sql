﻿CREATE TABLE [SCCM].[Compliant] (
    [ClientName]                 NVARCHAR (255) NULL,
    [ResourceID]                 NVARCHAR (255) NULL,
    [Computer Name]              NVARCHAR (255) NULL,
    [CompliantStatus]            NVARCHAR (255) NULL,
    [Active Status]              NVARCHAR (255) NULL,
    [AD Site]                    NVARCHAR (255) NULL,
    [OS]                         NVARCHAR (255) NULL,
    [EnforcementExitCode]        NVARCHAR (255) NULL,
    [LastEnforcementMessage]     NVARCHAR (255) NULL,
    [LastEnforcementMessageTime] DATETIME       NULL,
    [MissingUpdates]             INT            NULL,
    [LastBootDays]               INT            NULL,
    [WUA Scan Exit Code]         INT            NULL,
    [Last WUA Scan Age]          INT            NULL
);

