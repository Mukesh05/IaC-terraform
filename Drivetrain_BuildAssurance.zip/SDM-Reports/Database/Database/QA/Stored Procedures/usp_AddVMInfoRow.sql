﻿
CREATE PROCEDURE [QA].[usp_AddVMInfoRow] 
@TenantName nvarchar(255),
@SubscriptionID nvarchar(255),
@SubscriptionName nvarchar(255),
@Tenant_ID nvarchar(255),
@VMName nvarchar(255) ,
@RG nvarchar(255) ,
@Location nvarchar(255) ,
@Size nvarchar(255) ,
@OSversion nvarchar(255) ,
@OStype nvarchar(255) ,
@NIC0Vnet nvarchar(255) ,
@NIC0Subnet nvarchar(255) ,
@NIC0PrivateIpAddress nvarchar(255) = null ,
@NIC0PublicIpAddress nvarchar(255) = null ,
@AvailabilitySet nvarchar(255) ,
@osDisk nvarchar(255) ,
@dataDisk0 nvarchar(255) = null


AS

Delete from [QA].[VMAudit]
where 
	Cast(BatchDateTime as Date) = Cast(getdate() as Date)
	and Tenant_ID = @Tenant_ID
	and SubscriptionID = @SubscriptionID
	and [VM Name] = @VMName


INSERT INTO [QA].[VMAudit]
VALUES
(
@TenantName ,
@SubscriptionID ,
@SubscriptionName ,
@Tenant_ID ,
@VMName  ,
@RG ,
@Location ,
@Size ,
@OSversion ,
@OStype ,
@NIC0Vnet ,
@NIC0Subnet ,
@NIC0PrivateIpAddress ,
@NIC0PublicIpAddress ,
@AvailabilitySet ,
@osDisk ,
@dataDisk0 , 
getdate()

)

