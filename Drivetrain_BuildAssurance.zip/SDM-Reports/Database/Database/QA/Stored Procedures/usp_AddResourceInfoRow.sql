﻿
CREATE PROCEDURE [QA].[usp_AddResourceInfoRow] 
@TenantName nvarchar(255),
@SubscriptionID nvarchar(255),
@SubscriptionName nvarchar(255),
@Tenant_ID nvarchar(255),
@ResourceName nvarchar(255),
@ResourceGroup nvarchar(255),
@ResourceType nvarchar(255),
--@Kind nvarchar(255) = null,
@Location nvarchar(255),
@Sku nvarchar(255),
@LogsEnabled  int = null,
@MetricsEnabled int = null,
@LogsAnalyticsWorkSpaceName nvarchar(255) = null



AS


Delete from [QA].[ResourceAudit]
where 
	Cast(BatchDateTime as Date) = Cast(getdate() as Date)
	and Tenant_ID = @Tenant_ID
	and SubscriptionID = @SubscriptionID
	and ResourceName = @ResourceName
	and ResourceGroup = @ResourceGroup



INSERT INTO [QA].[ResourceAudit]
VALUES
(
@TenantName ,
@SubscriptionID ,
@SubscriptionName ,
@Tenant_ID ,
@ResourceName ,
@ResourceGroup ,
@ResourceType ,
NULL,
@Location ,
@Sku,
@LogsEnabled,
@MetricsEnabled,
@LogsAnalyticsWorkSpaceName,
getdate()

)

