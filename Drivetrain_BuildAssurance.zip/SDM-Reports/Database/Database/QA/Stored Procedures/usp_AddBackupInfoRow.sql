﻿CREATE PROCEDURE [QA].[usp_AddBackupInfoRow] 
@TenantName nvarchar(255),
@SubscriptionID nvarchar(255),
@SubscriptionName nvarchar(255),
@Tenant_ID nvarchar(255),
@ResourceGroupName nvarchar(255),
@VMName nvarchar(255),
@VaultName nvarchar(255),
@BackupStatus nvarchar(255),
@LatestRecoveryPoint nvarchar(255)


AS


Delete from [QA].[VMBackup]
where 
	Cast(BatchDateTime as Date) = Cast(getdate() as Date)
	and Tenant_ID = @Tenant_ID
	and SubscriptionID = @SubscriptionID
	and ResourceGroupName = @ResourceGroupName
	and VMName = @VMName



INSERT INTO [QA].[VMBackup]
VALUES
(@TenantName,
@SubscriptionID,
@SubscriptionName,
@Tenant_ID,
@ResourceGroupName,
@VMName,
@VaultName,
@BackupStatus,
@LatestRecoveryPoint,
getdate()

)

