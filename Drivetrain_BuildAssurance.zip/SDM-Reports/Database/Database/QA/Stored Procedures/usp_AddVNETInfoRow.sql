﻿Create Procedure QA.usp_AddVNETInfoRow
@TenantName nvarchar(255),
@SubscriptionID nvarchar(255),
@SubscriptionName nvarchar(255),
@Tenant_ID nvarchar(255),
@VnetName nvarchar(255),
@Location nvarchar(255),
@Subnet_NSG nvarchar(255),
@Subscription nvarchar(255)




AS

Delete from [QA].[VnetAudit]
where 
	Cast(BatchDateTime as Date) = Cast(getdate() as Date)
	and Tenant_ID = @Tenant_ID
	and SubscriptionID = @SubscriptionID
	and [VnetName] = @VnetName





INSERT INTO [QA].[VnetAudit]
Values
(
@TenantName 
,@SubscriptionID 
,@SubscriptionName 
,@Tenant_ID 
,@VnetName 
,@Location 
,@Subnet_NSG 
,@Subscription 
,getdate()



)