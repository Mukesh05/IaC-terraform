﻿
CREATE PROCEDURE [QA].[usp_AddAdvisorInfoRow] 
@TenantName nvarchar(255),
@SubscriptionID nvarchar(255),
@SubscriptionName nvarchar(255),
@Tenant_ID nvarchar(255),
@ResourceGroup nvarchar(255),
@ResourceType nvarchar(255),
@ResourceName nvarchar(255),
@Category nvarchar(255),
@Impact nvarchar(255),
@Problem nvarchar(255),
@Solution nvarchar(255)


AS


Delete from [QA].[AdvisorAudit]
where 
	Cast(BatchDateTime as Date) = Cast(getdate() as Date)
	and Tenant_ID = @Tenant_ID
	and SubscriptionID = @SubscriptionID
	and ResourceGroup = @ResourceGroup
	and ResourceName = @ResourceName

INSERT INTO [QA].[AdvisorAudit]
VALUES
(
@TenantName ,
@SubscriptionID ,
@SubscriptionName ,
@Tenant_ID ,
@ResourceGroup ,
@ResourceType ,
@ResourceName ,
@Category ,
@Impact ,
@Problem ,
@Solution, 
getdate()

)

