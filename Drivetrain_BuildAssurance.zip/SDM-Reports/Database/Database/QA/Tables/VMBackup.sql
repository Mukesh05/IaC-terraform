﻿CREATE TABLE [QA].[VMBackup] (
    [ID]                  INT            IDENTITY (1, 1) NOT NULL,
    [TenantName]          NVARCHAR (255) NULL,
    [SubscriptionID]      NVARCHAR (255) NULL,
    [SubscriptionName]    NVARCHAR (255) NULL,
    [Tenant_ID]           NVARCHAR (255) NULL,
    [ResourceGroupName]   NVARCHAR (255) NULL,
    [VMName]              NVARCHAR (255) NULL,
    [VaultName]           NVARCHAR (255) NULL,
    [BackupStatus]        NVARCHAR (255) NULL,
    [LatestRecoveryPoint] NVARCHAR (255) NULL,
    [BatchDateTime]       DATETIME       NULL
);

