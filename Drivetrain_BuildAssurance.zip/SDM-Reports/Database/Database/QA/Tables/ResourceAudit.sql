﻿CREATE TABLE [QA].[ResourceAudit] (
    [ID]                         INT            IDENTITY (1, 1) NOT NULL,
    [TenantName]                 NVARCHAR (255) NULL,
    [SubscriptionID]             NVARCHAR (255) NULL,
    [SubscriptionName]           NVARCHAR (255) NULL,
    [Tenant_ID]                  NVARCHAR (255) NULL,
    [ResourceName]               NVARCHAR (255) NULL,
    [ResourceGroup]              NVARCHAR (255) NULL,
    [ResourceType]               NVARCHAR (255) NULL,
    [Kind]                       NVARCHAR (255) NULL,
    [Location]                   NVARCHAR (255) NULL,
    [Sku]                        NVARCHAR (255) NULL,
    [LogsEnabled]                INT            NULL,
    [MetricsEnabled]             INT            NULL,
    [LogsAnalyticsWorkSpaceName] NVARCHAR (255) NULL,
    [BatchDateTime]              DATETIME       NULL
);

