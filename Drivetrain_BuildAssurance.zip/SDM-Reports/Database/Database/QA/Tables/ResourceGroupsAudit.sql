﻿CREATE TABLE [QA].[ResourceGroupsAudit] (
    [ID]                INT              IDENTITY (1, 1) NOT NULL,
    [GUID]              UNIQUEIDENTIFIER CONSTRAINT [DF_ResourceGroupsAudit_GUID] DEFAULT (newid()) ROWGUIDCOL NOT NULL,
    [ClientCode]        NVARCHAR (10)    NULL,
    [ResourceGroupName] NVARCHAR (255)   NULL,
    [Location]          NVARCHAR (255)   NULL,
    [BatchID]           NVARCHAR (255)   NULL,
    [BatchDateTime]     DATETIME         NULL
);

