﻿CREATE TABLE [QA].[RBACUserAudit] (
    [ID]            INT              IDENTITY (1, 1) NOT NULL,
    [GUID]          UNIQUEIDENTIFIER CONSTRAINT [DF_RBACUserAudit_GUID] DEFAULT (newid()) ROWGUIDCOL NOT NULL,
    [ClientCode]    NVARCHAR (10)    NULL,
    [SignInName]    NVARCHAR (255)   NULL,
    [DisplayName]   NVARCHAR (255)   NULL,
    [Role]          NVARCHAR (255)   NULL,
    [ObjectType]    NVARCHAR (255)   NULL,
    [BatchID]       NVARCHAR (255)   NULL,
    [BatchDateTime] DATETIME         NULL
);

