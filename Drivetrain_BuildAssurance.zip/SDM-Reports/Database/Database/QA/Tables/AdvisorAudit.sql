﻿CREATE TABLE [QA].[AdvisorAudit] (
    [ID]               INT            IDENTITY (1, 1) NOT NULL,
    [TenantName]       NVARCHAR (255) NULL,
    [SubscriptionID]   NVARCHAR (255) NULL,
    [SubscriptionName] NVARCHAR (255) NULL,
    [Tenant_ID]        NVARCHAR (255) NULL,
    [ResourceGroup]    NVARCHAR (255) NULL,
    [ResourceType]     NVARCHAR (255) NULL,
    [ResourceName]     NVARCHAR (255) NULL,
    [Category]         NVARCHAR (255) NULL,
    [Impact]           NVARCHAR (255) NULL,
    [Problem]          NVARCHAR (255) NULL,
    [Solution]         NVARCHAR (255) NULL,
    [BatchDateTime]    DATETIME       NULL
);

