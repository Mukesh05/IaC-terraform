﻿CREATE TABLE [QA].[NSGAudit] (
    [ID]            INT              IDENTITY (1, 1) NOT NULL,
    [GUID]          UNIQUEIDENTIFIER CONSTRAINT [DF_NSGAudit_GUID] DEFAULT (newid()) ROWGUIDCOL NOT NULL,
    [ClientCode]    NVARCHAR (10)    NULL,
    [ResourceName]  NVARCHAR (255)   NULL,
    [ResourceGroup] NVARCHAR (255)   NULL,
    [Location]      NVARCHAR (255)   NULL,
    [BatchID]       NVARCHAR (255)   NULL,
    [BatchDateTime] DATETIME         NULL
);

