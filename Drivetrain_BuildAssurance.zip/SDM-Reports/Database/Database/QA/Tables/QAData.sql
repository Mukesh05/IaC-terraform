﻿CREATE TABLE [QA].[QAData] (
    [ReportName] NVARCHAR (255) NULL,
    [Content]    VARCHAR (MAX)  NULL
);

