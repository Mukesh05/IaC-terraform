﻿CREATE TABLE [QA].[StorageAudit] (
    [ID]                     INT              IDENTITY (1, 1) NOT NULL,
    [GUID]                   UNIQUEIDENTIFIER CONSTRAINT [DF_StorageAudit_GUID] DEFAULT (newid()) ROWGUIDCOL NOT NULL,
    [ClientCode]             NVARCHAR (10)    NULL,
    [StorageAccountName]     NVARCHAR (255)   NULL,
    [ResourceGroup]          NVARCHAR (255)   NULL,
    [Location]               NVARCHAR (255)   NULL,
    [Sku]                    NVARCHAR (255)   NULL,
    [Kind]                   NVARCHAR (255)   NULL,
    [AccessTier]             NVARCHAR (255)   NULL,
    [EnableHttpsTrafficOnly] BIT              NOT NULL,
    [BatchID]                NVARCHAR (255)   NULL,
    [BatchDateTime]          DATETIME         NULL
);

