﻿CREATE TABLE [QA].[VnetAudit] (
    [ID]               INT            IDENTITY (1, 1) NOT NULL,
    [TenantName]       NVARCHAR (255) NULL,
    [SubscriptionID]   NVARCHAR (255) NULL,
    [SubscriptionName] NVARCHAR (255) NULL,
    [Tenant_ID]        NVARCHAR (255) NULL,
    [VnetName]         NVARCHAR (255) NULL,
    [Location]         NVARCHAR (255) NULL,
    [Subnet_NSG]       NVARCHAR (MAX) NULL,
    [Subscription]     NVARCHAR (255) NULL,
    [BatchDateTime]    DATETIME       NULL
);

