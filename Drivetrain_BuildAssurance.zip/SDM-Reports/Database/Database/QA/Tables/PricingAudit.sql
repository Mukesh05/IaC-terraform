﻿CREATE TABLE [QA].[PricingAudit] (
    [ID]            INT              IDENTITY (1, 1) NOT NULL,
    [GUID]          UNIQUEIDENTIFIER CONSTRAINT [DF_PricingAudit_GUID] DEFAULT (newid()) ROWGUIDCOL NOT NULL,
    [ClientCode]    NVARCHAR (10)    NULL,
    [Name]          NVARCHAR (255)   NULL,
    [PricingTier]   NVARCHAR (255)   NULL,
    [BatchID]       NVARCHAR (255)   NULL,
    [BatchDateTime] DATETIME         NULL
);

