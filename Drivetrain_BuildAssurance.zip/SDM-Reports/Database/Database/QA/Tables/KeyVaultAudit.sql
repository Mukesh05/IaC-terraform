﻿CREATE TABLE [QA].[KeyVaultAudit] (
    [ID]                    INT              IDENTITY (1, 1) NOT NULL,
    [GUID]                  UNIQUEIDENTIFIER CONSTRAINT [DF_KeyVaultAudit_GUID] DEFAULT (newid()) ROWGUIDCOL NOT NULL,
    [ClientCode]            NVARCHAR (10)    NULL,
    [VaultName]             NVARCHAR (255)   NULL,
    [ResourceGroupName]     NVARCHAR (255)   NULL,
    [Location]              NVARCHAR (255)   NULL,
    [KeyVaultSecretName]    NVARCHAR (255)   NULL,
    [KeyVaultSecretEnabled] BIT              NOT NULL,
    [KeyVaultSecretCreated] DATETIME         NULL,
    [KeyVaultSecretExpires] NVARCHAR (255)   NULL,
    [BatchID]               NVARCHAR (255)   NULL,
    [BatchDateTime]         DATETIME         NULL
);

