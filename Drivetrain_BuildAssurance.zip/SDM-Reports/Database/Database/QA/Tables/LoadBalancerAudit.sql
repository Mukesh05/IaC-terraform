﻿CREATE TABLE [QA].[LoadBalancerAudit] (
    [ID]                INT              IDENTITY (1, 1) NOT NULL,
    [GUID]              UNIQUEIDENTIFIER CONSTRAINT [DF_LoadBalancerAudit_GUID] DEFAULT (newid()) ROWGUIDCOL NOT NULL,
    [ClientCode]        NVARCHAR (10)    NULL,
    [ResourceName]      NVARCHAR (255)   NULL,
    [ResourceGroup]     NVARCHAR (255)   NULL,
    [Location]          NVARCHAR (255)   NULL,
    [FrontEndPrivateIp] NVARCHAR (255)   NULL,
    [FrontEndPublicIp]  NVARCHAR (255)   NULL,
    [BackEndPools]      NVARCHAR (255)   NULL,
    [lbRule-0]          NVARCHAR (255)   NULL,
    [lbRule-1]          NVARCHAR (255)   NULL,
    [probe-0]           NVARCHAR (255)   NULL,
    [probe-1]           NVARCHAR (255)   NULL,
    [Tags]              NVARCHAR (255)   NULL,
    [Subscription]      NVARCHAR (255)   NULL,
    [BatchID]           NVARCHAR (255)   NULL,
    [BatchDateTime]     DATETIME         NULL
);

