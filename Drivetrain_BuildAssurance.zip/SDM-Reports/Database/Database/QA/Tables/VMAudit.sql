﻿CREATE TABLE [QA].[VMAudit] (
    [ID]                     INT            IDENTITY (1, 1) NOT NULL,
    [TenantName]             NVARCHAR (255) NULL,
    [SubscriptionID]         NVARCHAR (255) NULL,
    [SubscriptionName]       NVARCHAR (255) NULL,
    [Tenant_ID]              NVARCHAR (255) NULL,
    [VM Name]                NVARCHAR (255) NULL,
    [RG]                     NVARCHAR (255) NULL,
    [Location]               NVARCHAR (255) NULL,
    [Size]                   NVARCHAR (255) NULL,
    [OS version]             NVARCHAR (255) NULL,
    [OS type]                NVARCHAR (255) NULL,
    [NIC-0-Vnet]             NVARCHAR (255) NULL,
    [NIC-0-Subnet]           NVARCHAR (255) NULL,
    [NIC-0-PrivateIpAddress] NVARCHAR (255) NULL,
    [NIC-0-PublicIpAddress]  NVARCHAR (255) NULL,
    [AvailabilitySet]        NVARCHAR (255) NULL,
    [osDisk]                 NVARCHAR (255) NULL,
    [dataDisk-0]             NVARCHAR (255) NULL,
    [BatchDateTime]          DATETIME       NULL
);

