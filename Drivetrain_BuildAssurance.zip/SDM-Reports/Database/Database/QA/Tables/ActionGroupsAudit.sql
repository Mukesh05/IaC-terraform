﻿CREATE TABLE [QA].[ActionGroupsAudit] (
    [ID]                INT              IDENTITY (1, 1) NOT NULL,
    [GUID]              UNIQUEIDENTIFIER CONSTRAINT [DF_ActionGroupsAudit_GUID] DEFAULT (newid()) ROWGUIDCOL NOT NULL,
    [ClientCode]        NVARCHAR (10)    NULL,
    [Name]              NVARCHAR (255)   NULL,
    [ResourceGroupName] NVARCHAR (255)   NULL,
    [Location]          NVARCHAR (255)   NULL,
    [EmailReceivers0]   NVARCHAR (255)   NULL,
    [EmailReceivers1]   NVARCHAR (255)   NULL,
    [EmailReceivers2]   NVARCHAR (255)   NULL,
    [EmailReceivers3]   NVARCHAR (255)   NULL,
    [EmailReceivers4]   NVARCHAR (255)   NULL,
    [EmailReceivers5]   NVARCHAR (255)   NULL,
    [GroupEnabled]      NVARCHAR (255)   NULL,
    [GroupShortName]    NVARCHAR (255)   NULL,
    [BatchID]           NVARCHAR (255)   NULL,
    [BatchDateTime]     DATETIME         NULL,
    CONSTRAINT [PK_ActionGroupsAudit] PRIMARY KEY CLUSTERED ([ID] ASC)
);


GO
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20200112-193358]
    ON [QA].[ActionGroupsAudit]([BatchID] ASC, [BatchDateTime] ASC);

