﻿CREATE TABLE [QA].[BackupAudit] (
    [ID]                  INT              IDENTITY (1, 1) NOT NULL,
    [GUID]                UNIQUEIDENTIFIER CONSTRAINT [DF_BackupAudit_GUID] DEFAULT (newid()) ROWGUIDCOL NOT NULL,
    [ClientCode]          NVARCHAR (10)    NULL,
    [ResourceGroupName]   NVARCHAR (255)   NULL,
    [VMName]              NVARCHAR (255)   NULL,
    [VaultName]           NVARCHAR (255)   NULL,
    [BackupStatus]        NVARCHAR (255)   NULL,
    [LatestRecoveryPoint] DATETIME         NULL,
    [LastBackupDate]      DATE             NULL,
    [BatchID]             NVARCHAR (255)   NULL,
    [BatchDateTime]       DATETIME         NULL
);

