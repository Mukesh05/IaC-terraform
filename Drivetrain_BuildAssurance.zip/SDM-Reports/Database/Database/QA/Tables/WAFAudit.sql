﻿CREATE TABLE [QA].[WAFAudit] (
    [ID]                     INT              IDENTITY (1, 1) NOT NULL,
    [GUID]                   UNIQUEIDENTIFIER CONSTRAINT [DF_WAFAudit_GUID] DEFAULT (newid()) ROWGUIDCOL NOT NULL,
    [ClientCode]             NVARCHAR (10)    NULL,
    [ApplicationGatewayName] NVARCHAR (255)   NULL,
    [Location]               NVARCHAR (255)   NULL,
    [ResourceGroupName]      NVARCHAR (255)   NULL,
    [BackendAddressPools]    NVARCHAR (255)   NULL,
    [Sku]                    NVARCHAR (255)   NULL,
    [WAFEnabled]             NVARCHAR (255)   NULL,
    [PrivateIPConfig]        NVARCHAR (255)   NULL,
    [PublicIPConfig]         NVARCHAR (255)   NULL,
    [HTTPListeners-0]        NVARCHAR (255)   NULL,
    [HTTPProtocol-0]         NVARCHAR (255)   NULL,
    [Hostname-0]             NVARCHAR (255)   NULL,
    [BatchID]                NVARCHAR (255)   NULL,
    [BatchDateTime]          DATETIME         NULL
);

