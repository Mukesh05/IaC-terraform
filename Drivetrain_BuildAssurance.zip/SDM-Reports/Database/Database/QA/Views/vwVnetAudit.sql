﻿




CREATE View [QA].[vwVnetAudit]
as




With TenantBackupDate
as
(

Select
	TenantName
	,Tenant_ID
	,max(cast(BatchDateTime as date)) BatchDate
from 
	[QA].[VnetAudit]
group by 
	TenantName
	,Tenant_ID
)

Select 
	v.*
	,t.BatchDate BatchDate 

	,b.SubNet1
	,b.NSG1
	,b.SubNet2
	,b.NSG2
	,b.SubNet3
	,b.NSG3

	,b.SubNet4
	,b.NSG4
	,b.SubNet5
	,b.NSG5
	,b.SubNet6
	,b.NSG6

	,Case 
		When IsNull(b.SubNet1,'') <> '' and IsNull(b.NSG1,'') = '' then 'Yes'  
		When IsNull(b.SubNet2,'') <> '' and IsNull(b.NSG2,'') = '' then 'Yes'  
		When IsNull(b.SubNet3,'') <> '' and IsNull(b.NSG3,'') = '' then 'Yes'  
		When IsNull(b.SubNet4,'') <> '' and IsNull(b.NSG4,'') = '' then 'Yes'  
		When IsNull(b.SubNet5,'') <> '' and IsNull(b.NSG5,'') = '' then 'Yes'  
		When IsNull(b.SubNet6,'') <> '' and IsNull(b.NSG6,'') = '' then 'Yes'  
	Else 'No'	
	End MissingNSG

from 
	[QA].[VnetAudit] v

	join TenantBackupDate t
		on v.Tenant_ID = t.Tenant_ID
		and cast(BatchDateTime as date) = t.BatchDate

	left join QA.vwSubNetNSGDetails b
		on v.ID = b.ID






--Select 
--	a.*
--	,cast(BatchDateTime as date) BatchDate 
--	,b.SubNet1
--	,b.NSG1
--	,b.SubNet2
--	,b.NSG2
--	,b.SubNet3
--	,b.NSG3

--	,b.SubNet4
--	,b.NSG4
--	,b.SubNet5
--	,b.NSG5
--	,b.SubNet6
--	,b.NSG6

--	,Case 
--		When IsNull(b.SubNet1,'') <> '' and IsNull(b.NSG1,'') = '' then 'Yes'  
--		When IsNull(b.SubNet2,'') <> '' and IsNull(b.NSG2,'') = '' then 'Yes'  
--		When IsNull(b.SubNet3,'') <> '' and IsNull(b.NSG3,'') = '' then 'Yes'  
--		When IsNull(b.SubNet4,'') <> '' and IsNull(b.NSG4,'') = '' then 'Yes'  
--		When IsNull(b.SubNet5,'') <> '' and IsNull(b.NSG5,'') = '' then 'Yes'  
--		When IsNull(b.SubNet6,'') <> '' and IsNull(b.NSG6,'') = '' then 'Yes'  
--	Else 'No'	
--	End MissingNSG
--	,RANK() OVER (PARTITION BY [VnetName] ORDER BY BatchDateTime desc) AS rank 

--from 
--	[QA].[VnetAudit] a
--	left join QA.vwSubNetNSGDetails b
--		on a.ID = b.ID


