﻿





CREATE View [QA].[vwResourceAudit]
as






With TenantBackupDate
as
(

Select
	TenantName
	,Tenant_ID
	,max(cast(BatchDateTime as date)) BatchDate
from 
	[QA].[ResourceAudit]
group by 
	TenantName
	,Tenant_ID
)

Select 
	v.*
	, case when IsNull(LogsEnabled,0) = 1 then 'Yes' else 'No' end LogsEnabledYN
	, case when MetricsEnabled = 1 then 'Yes' else 'No' end MetricsEnabledYN
	,t.BatchDate BatchDate 


from 
	[QA].[ResourceAudit] v
	join TenantBackupDate t
		on v.Tenant_ID = t.Tenant_ID
		and cast(BatchDateTime as date) = t.BatchDate




--Select 
--	*
--	, case when LogsEnabled = 1 then 'Yes' else 'No' end LogsEnabledYN
--	, case when MetricsEnabled = 1 then 'Yes' else 'No' end MetricsEnabledYN
--	,RANK() OVER (PARTITION BY TenantName,ResourceName ORDER BY BatchDateTime desc) AS rank 

--	,cast(BatchDateTime as date) BatchDate 
--from 
--	[QA].[ResourceAudit]

