﻿
CREATE View  [QA].[vwSubNetNSGDetails]
as


With SubNetNSG as
(
SELECT 
	[ID]
	,VnetName
	,value SubnetNSG
FROM 
	[QA].[VnetAudit] q
	CROSS APPLY STRING_SPLIT([Subnet_NSG], ',')
)

,

Subnetdetails as 
(
Select 
	ID
	,VnetName
	,Case 
		when CharIndex(':',subnetnsg) = 0 then 
			subnetnsg
		else 
			Left(subnetnsg,CharIndex(':',subnetnsg) - 1) 
	end SubNet
	,Case 
		when CharIndex(':',subnetnsg) = 0 then 
			''
		else 
			SubString(Subnetnsg,CharIndex(':',subnetnsg)+1,100) 
	end NSG
From 
	SubNetNSG
) 





, SubNetNSGDetails As 
(Select ROW_NUMBER() Over (Partition By ID Order By ID) As RowID, * From Subnetdetails)



Select ID As [ID],
	Min(Subnet1) As SubNet1,
	Min(NSG1) As NSG1,
	Min(Subnet2) As SubNet2,
	Min(NSG2) As NSG2,
	Min(Subnet3) As SubNet3,
	Min(NSG3) As NSG3,
	Min(Subnet4) As SubNet4,
	Min(NSG4) As NSG4,
	Min(Subnet5) As SubNet5,
	Min(NSG5) As NSG5,
	Min(Subnet6) As SubNet6,
	Min(NSG6) As NSG6
From 

(Select 
	ROW_NUMBER() Over (Partition By ID Order By ID) As RowID,
	ID,
	'SubNet' + Cast(RowID as varchar) As SubNetNum,
	'NSG' + Cast(RowID as varchar) As NSGNum,
	SubNet,
	NSG
From SubNetNSGDetails
) As Pvt

Pivot (Min(SubNet)
	For SubNetNum In ([Subnet1], [Subnet2], [Subnet3], [Subnet4], [Subnet5], [Subnet6])) As Pvt1
Pivot (Min(NSG)
	For NSGNum In ([NSG1], [NSG2], [NSG3], [NSG4], [NSG5], [NSG6])) As Pvt2
Group By ID;



