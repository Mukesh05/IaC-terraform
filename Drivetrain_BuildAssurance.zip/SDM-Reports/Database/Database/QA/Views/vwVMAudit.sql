﻿



CREATE View [QA].[vwVMAudit]
as




With TenantBackupDate
as
(

Select
	TenantName
	,Tenant_ID
	,max(cast(BatchDateTime as date)) BatchDate
from 
	QA.VMAudit
group by 
	TenantName
	,Tenant_ID
)

Select 
	v.*
	,case 
		when [OS type] = '0' then 'Windows' 
		when [OS type] = '1' then 'Linux' 
	Else [OS type] 
	end [OSType]
	,t.BatchDate BatchDate 


from 
	QA.VMAudit v
	join TenantBackupDate t
		on v.Tenant_ID = t.Tenant_ID
		and cast(BatchDateTime as date) = t.BatchDate



--Select 
--	*
--	,case 
--		when [OS type] = 0 then 'Windows' 
--		when [OS type] = 1 then 'Linux' 
--	Else [OS type] 
--	end [OSType]
--	,RANK() OVER (PARTITION BY [VM Name] ORDER BY BatchDateTime desc) AS rank 

--	,cast(BatchDateTime as date) BatchDate 

--from 
--	QA.VMAudit



