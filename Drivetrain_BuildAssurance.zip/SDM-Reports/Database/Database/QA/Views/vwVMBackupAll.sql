﻿


CREATE View [QA].[vwVMBackupAll]

as


Select 
	*
	,Case 
		when BackupStatus IS Null then 'Not Exist' 
		when BackupStatus = '' then 'Not Exist' 
		else BackupStatus 
	end BackupStatus1

	,cast(BatchDateTime as date) BatchDate 
	,DATEADD(SS, Convert(BIGINT,substring(LatestRecoveryPoint,1,10)), '19700101') LatestBackup
--	,RANK() OVER (PARTITION BY VMName ORDER BY BatchDateTime desc) AS rank 

	--,DATEADD(SS, Convert(BIGINT,substring(LatestRecoveryPoint,3,10)), '19700101') LatestBackup
	--,NULL LatestBackup

from QA.VMBackup
