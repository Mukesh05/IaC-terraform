﻿



CREATE View [QA].[vwVMBackup]

as


--Select 
--	*
--	,cast(BatchDateTime as date) BatchDate 
--	,DATEADD(SS, Convert(BIGINT,substring(LatestRecoveryPoint,1,10)), '19700101') LatestBackup
--	,RANK() OVER (PARTITION BY VMName ORDER BY BatchDateTime desc) AS rank 

--	--,DATEADD(SS, Convert(BIGINT,substring(LatestRecoveryPoint,3,10)), '19700101') LatestBackup
--	--,NULL LatestBackup

--from QA.VMBackup





With TenantBackupDate
as
(

Select
	TenantName
	,Tenant_ID
	,max(cast(BatchDateTime as date)) BatchDate
from 
	QA.VMBackup
group by 
	TenantName
	,Tenant_ID
)

Select 
	v.*
	,t.BatchDate BatchDate 
	,DATEADD(SS, Convert(BIGINT,substring(LatestRecoveryPoint,1,10)), '19700101') LatestBackup


from 
	QA.VMBackup v
	join TenantBackupDate t
		on v.Tenant_ID = t.Tenant_ID
		and cast(BatchDateTime as date) = t.BatchDate





