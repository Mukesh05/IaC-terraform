﻿

CREATE View [QA].[vwAdvisorAudit]
as



With TenantBackupDate
as
(

Select
	TenantName
	,Tenant_ID
	,max(cast(BatchDateTime as date)) BatchDate
from 
	[QA].[AdvisorAudit]
group by 
	TenantName
	,Tenant_ID
)

Select 
	v.*
	,t.BatchDate BatchDate 


from 
	[QA].[AdvisorAudit] v
	join TenantBackupDate t
		on v.Tenant_ID = t.Tenant_ID
		and cast(BatchDateTime as date) = t.BatchDate





--Select 
--	*
--	,RANK() OVER (PARTITION BY [ResourceName] ORDER BY BatchDateTime desc) AS rank 

--	,cast(BatchDateTime as date) BatchDate 
--from 
--	[QA].[AdvisorAudit]


