﻿CREATE TABLE [dbo].[BuildAssuranceData] (
    [AuditResults]        NVARCHAR (4000) NULL,
    [CustomerInformation] NVARCHAR (MAX)  NULL
);

