﻿

--/****** Object:  View [dbo].[vwQAResourceInformation]    Script Date: 20/03/2020 09:47:51 ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO


CREATE view [dbo].[vwQAResourceInformation]
as

--select  [dbo].[ProperCase]('FGHJKS')
select 
	ra.BatchDate
	,ra.BatchDateTime
	,(Select dbo.Propercase(ra.TenantName)) TenantName
	,ra.SubscriptionName
	,ra.ResourceType
	,ra.ResourceName
	,ra.ResourceGroup
	,ra.LogsEnabledYN LogsEnabled
	,ra.MetricsEnabledYN MetricsEnabled
	,ra.LogsAnalyticsWorkSpaceName
--	,ba.VMName	
	,case when ba.VMName Is Null then 'No' else 'Yes' end VMBackupPresent
--	,au.[VM Name]
	,case when au.[VM Name] Is Null then 'No' else 'Yes' end VMAuditPresent
--	,aa.ResourceName
	,case when aa.ResourceName Is Null then 'No' else 'Yes' end VMAdvisorPresent
	,ba.LatestRecoveryPoint
	,Case when ba.BackupStatus IS Null then 'Not Exist' else ba.BackupStatus end BackupStatus
	--,DATEADD(ss, Convert(BigINT,ba.LatestRecoveryPoint), '1970/01/01') dd
	,DATEADD(SS, Convert(BIGINT,substring(ba.LatestRecoveryPoint,1,10)), '19700101') LatestRecoveryPointDate
	,au.Location
	,au.OSType
	,au.[NIC-0-PrivateIpAddress]
	,au.[NIC-0-PublicIpAddress]
	,case when au.[NIC-0-PublicIpAddress] is null then 0 else 1 end PublicIP
	,case 
		when au.[NIC-0-PublicIpAddress] is null then 'No' 
		when au.[NIC-0-PublicIpAddress] = '' then 'No' 
	else 'Yes' end PublicIPYN
	,au.[NIC-0-Subnet]
	,au.[NIC-0-Vnet]
	,au.AvailabilitySet
	,au.osDisk
	,aa.ResourceType AAResourceType
	,aa.Category 
	,aa.Impact
	,aa.Problem
	,aa.Solution
	,vnet.Subnet_NSG
	,vnet.SubNet1
	,vnet.NSG1
	,vnet.SubNet2
	,vnet.NSG2
	,vnet.SubNet3
	,vnet.NSG3

	,vnet.SubNet4
	,vnet.NSG4
	,vnet.SubNet5
	,vnet.NSG5
	,vnet.SubNet6
	,vnet.NSG6
	,vnet.MissingNSG
	  
from 
	QA.vwResourceAudit ra

	left join QA.vwVMBackup ba
		on ba.Tenant_ID = ra.Tenant_ID
		and ba.SubscriptionID = ra.SubscriptionID
		and ba.VMName = ra.ResourceName
		and ba.BatchDate = ra.BatchDate
		--and ba.rank = 1

	left join QA.vwVMAudit au
		on ra.Tenant_ID = au.Tenant_ID
		and ra.SubscriptionID = au.SubscriptionID
		and ra.ResourceName = au.[VM Name]
		and au.BatchDate = ra.BatchDate
		--and au.rank = 1

	left join QA.vwAdvisorAudit aa
		on ra.Tenant_ID = aa.Tenant_ID
		and ra.SubscriptionID = aa.SubscriptionID
		and ra.ResourceName = aa.ResourceName
		and ra.BatchDate = aa.BatchDate
		--and aa.rank = 1

	left join QA.vwVnetAudit vnet
		on ra.Tenant_ID = vnet.Tenant_ID
		and ra.SubscriptionID = vnet.SubscriptionID
		and ra.ResourceName = vnet.VnetName
		and ra.BatchDate = vnet.BatchDate
		--and vnet.rank = 1

--where
--	ra.rank = 1






/*

order by 
	--ba.LatestRecoveryPoint desc
	ra.ResourceName

select * from vwQAResourceInformation
[dbo].[vwQAResourceInformation]

*/
--GO


