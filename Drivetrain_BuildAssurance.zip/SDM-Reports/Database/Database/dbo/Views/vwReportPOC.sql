﻿CREATE view [dbo].[vwReportPOC] as 





with resourcelist as 
(
select Distinct 
	[VM Name] ResourceName
	,'QA-VM' Type

from 
	QA.VMAudit


union 

select Distinct 
	me.DisplayName collate database_default
	,case when ra.ResourceName Is Null then 'SCOM only' else 'SCOM,QA' end

from 
	SCOM.ManagedEntityGenericView me

	left join QA.ResourceAudit ra
		on me.DisplayName like ('%' + ra.ResourceName + '%') collate database_default

	--left join SCCM.Compliant comp
	--	on left(me.DisplayName,CHARINDEX('.',me.DisplayName)) = comp.[Computer Name] + '.'

where 
	Path is not null

union

select distinct 
	[Computer Name] 
	,'SCCM'
from 
	SCCM.Compliant

union

Select Distinct 
	ResourceName
	,'QA'
from 
	QA.ResourceAudit

)


--select * from resourcelist order by ResourceName











select Distinct
	'Firebrand Training Ltd.' as Client
	,r.ResourceName
	,r.Type
	,me.DisplayName
	,left(me.DisplayName,CHARINDEX('.',me.DisplayName)) As SCOMComputerName
	,comp.[Computer Name] SCCMComputerName
	,va.[VM Name] VM_Name

	,case 
		when r.Type = 'SCOM,QA' and comp.[Computer Name] is not null then 'SCOM,SCCM,QA'
		when r.Type = 'SCOM,QA' and comp.[Computer Name] is null then 'SCOM,QA'
		when r.Type = 'SCOM Only' and comp.[Computer Name] is not null then 'SCOM,SCCM'
		when r.Type = 'SCOM Only' and comp.[Computer Name] is null then 'SCOM'
		when r.Type = 'QA' and comp.[Computer Name] is null then 'QA'

	end source2

	,Case 
		when me.DisplayName is null and comp.[Computer Name] is null and va.[VM Name] is not null then 'QA Only'
		when me.DisplayName is null and comp.[Computer Name] is not null and va.[VM Name] is not null then 'SCCM,QA'
		when me.DisplayName is not null and comp.[Computer Name] is not null and va.[VM Name] is not null then 'SCOM,SCCM,QA'

		when me.DisplayName is not null and comp.[Computer Name] is null and va.[VM Name] is null then 'SCOM Only'
		when me.DisplayName is not null and comp.[Computer Name] is not null and va.[VM Name] is null then 'SCOM,SCCM'
		when me.DisplayName is not null and comp.[Computer Name] is null and va.[VM Name] is not null then 'SCOM,QA'

		when left(me.DisplayName,CHARINDEX('.',me.DisplayName)) is null and comp.[Computer Name] is not null and va.[VM Name] is null then 'SCCM Only'

	End Source



	,IsNUll(IsNull(IsNull(comp.[Computer Name],me.DisplayName),va.[VM Name]),r.ResourceName) ResourceName2

	,MTV.Name ManagedTypeName
	,mtv.DisplayName as ManagedTypeDisplayName	
	,me.Path 
	,me.FullName
	,me.IsManaged
	,IsDeleted
	,IsAvailable
	,case when me.MonitoringClassId is null then 'No' else 'Yes' end IsMonitored
	,ba.BackupStatus
	,ba.LatestRecoveryPoint
	,Case when ep.EP_DeploymentState = 3 then 'Managed' else 'NA' end EPDeploymentState
	,ep.EpProtected
	,ep.EpAtRisk
	,ep.EpNotYetInstalled
	,comp.CompliantStatus
	,comp.MissingUpdates
	,va.[NIC-0-PrivateIpAddress]
	,va.[NIC-0-PublicIpAddress]

from 
	resourcelist r
	
	left join SCOM.ManagedEntityGenericView me
		on r.ResourceName = me.DisplayName

	left join SCCM.Compliant comp
		on left(r.ResourceName,CHARINDEX('.',r.ResourceName)) = comp.[Computer Name] + '.'
		or r.ResourceName = comp.[Computer Name]


	left join SCCM.EndPoint ep
		on left(r.ResourceName,CHARINDEX('.',r.ResourceName)) = ep.[Computer Name] + '.'


	--left join QA.ResourceAudit ra
	--	on r.ResourceName like ('%' + ra.ResourceName + '%') collate database_default
	--	--on r.ResourceName = ra.ResourceName

	left join SCOM.ManagedTypeView mtv
		on me.MonitoringClassId = mtv.Id
		and mtv.LanguageCode = 'ENU'

	left join QA.VMAudit va
		on (left(r.ResourceName,CHARINDEX('.',r.ResourceName)) = va.[VM Name] + '.')
			or (r.ResourceName = va.[VM Name])

	left join QA.BackupAudit ba
	--	on (ra.ResourceGroup = ba.ResourceGroupName)
	--	or (r.ResourceName = ba.VMName)
	--	--or (comp.[Computer Name] = ba.VMName)
		on IsNUll(IsNull(IsNull(comp.[Computer Name],me.DisplayName),va.[VM Name]),r.ResourceName) = ba.VMName


--where
--	r.ResourceName like '%AZFB-QV03%'
--	mtv.DisplayName in ('Virtual Server','Windows Server')

--order by 
--Case 
--		when me.DisplayName is null and comp.[Computer Name] is null and va.[VM Name] is not null then 'QA Only'
--		when me.DisplayName is null and comp.[Computer Name] is not null and va.[VM Name] is not null then 'SCCM,QA'
--		when me.DisplayName is not null and comp.[Computer Name] is not null and va.[VM Name] is not null then 'SCOM,SCCM,QA'

--		when me.DisplayName is not null and comp.[Computer Name] is null and va.[VM Name] is null then 'SCOM Only'
--		when me.DisplayName is not null and comp.[Computer Name] is not null and va.[VM Name] is null then 'SCOM,SCCM'
--		when me.DisplayName is not null and comp.[Computer Name] is null and va.[VM Name] is not null then 'SCOM,QA'

--		when left(me.DisplayName,CHARINDEX('.',me.DisplayName)) is null and comp.[Computer Name] is not null and va.[VM Name] is null then 'SCCM Only'

--	End 






--select Distinct
--	me.DisplayName
--	,left(me.DisplayName,CHARINDEX('.',me.DisplayName)) As SCOMComputerName
--	,comp.[Computer Name] SCCMComputerName
--	,IsNull(comp.[Computer Name],me.DisplayName)
--	,va.[VM Name]
--	,mtv.DisplayName as ManagedTypeDisplayName	

--from 
--	SCOM.ManagedEntityGenericView me

--	left join SCCM.Compliant comp
--		on left(me.DisplayName,CHARINDEX('.',me.DisplayName)) = comp.[Computer Name] + '.'

--	left join SCOM.ManagedTypeView mtv
--		on me.MonitoringClassId = mtv.Id
--		and mtv.LanguageCode = 'ENU'

--	left join QA.VMAudit va
--		on (left(me.DisplayName,CHARINDEX('.',me.DisplayName)) = va.[VM Name] + '.')
--			or (me.DisplayName = va.[VM Name])


--where
--	mtv.DisplayName in ('Virtual Server','Windows Server')

--order by 1


--select *
--from QA.VMAudit 


--select * from scom.ManagedEntityGenericView where DisplayName like 'AZFB-Staging-01%'



