﻿CREATE procedure [dbo].[ClientAssetData] @ClientName varchar(max)

as


select 
	c.CompanyName
	,c.name
	,c.device_type
	,v.[VM Name]
	,v.Location
	,v.Size
	,v.[OS version]
	,v.[NIC-0-PrivateIpAddress]
	,v.[NIC-0-PublicIpAddress]
	,b.BackupStatus
	,b.LatestRecoveryPoint
	,c.SCCM_server
	,c.days_last_restart
	,c.ad_site_name
	,c.last_compliance_msg_desc
	,c.last_enforcement_error_code
	,c.last_enforcement_msg
	,c.last_logged_on_user
	,c.last_logon_time
	,c.last_wua_scan_age
	,c.is_client
	,c.is_at_risk
	,c.is_active
	,c.is_protected
	,c.is_ep_installed
	,c.infection_status
	
from 
	cmp.ClientAssetData c

	left join QA.VMAudit v
		on v.[VM Name] = c.name

	left join QA.BackupAudit b
		on b.VMName = v.[VM Name]
where 
	CompanyName = @ClientName

