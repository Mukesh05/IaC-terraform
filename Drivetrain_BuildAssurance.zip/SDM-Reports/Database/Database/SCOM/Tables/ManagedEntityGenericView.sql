﻿CREATE TABLE [SCOM].[ManagedEntityGenericView] (
    [Id]                             NVARCHAR (255) NULL,
    [FullName]                       NVARCHAR (MAX) NULL,
    [Name]                           NVARCHAR (255) NULL,
    [Path]                           NVARCHAR (255) NULL,
    [DisplayName]                    NVARCHAR (255) NULL,
    [IsManaged]                      FLOAT (53)     NULL,
    [IsDeleted]                      FLOAT (53)     NULL,
    [LastModified]                   DATETIME       NULL,
    [TypedManagedEntityId]           NVARCHAR (255) NULL,
    [MonitoringClassId]              NVARCHAR (255) NULL,
    [TypedMonitoringObjectIsDeleted] FLOAT (53)     NULL,
    [HealthState]                    FLOAT (53)     NULL,
    [OperationalState]               NVARCHAR (255) NULL,
    [StateLastModified]              DATETIME       NULL,
    [IsAvailable]                    FLOAT (53)     NULL,
    [AvailabilityLastModified]       DATETIME       NULL,
    [InMaintenanceMode]              FLOAT (53)     NULL,
    [MaintenanceModeLastModified]    DATETIME       NULL,
    [BaseManagedEntityId]            NVARCHAR (255) NULL,
    [TimeAdded]                      DATETIME       NULL,
    [LastModifiedBy]                 NVARCHAR (255) NULL
);

