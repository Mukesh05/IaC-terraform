﻿CREATE TABLE [SCOM].[ManagedTypeView] (
    [Id]                    NVARCHAR (255) NULL,
    [Name]                  NVARCHAR (255) NULL,
    [BaseMonitoringClassId] NVARCHAR (255) NULL,
    [ManagementPackId]      NVARCHAR (255) NULL,
    [Hosted]                FLOAT (53)     NULL,
    [Abstract]              FLOAT (53)     NULL,
    [Accessibility]         FLOAT (53)     NULL,
    [Singleton]             FLOAT (53)     NULL,
    [Sealed]                FLOAT (53)     NULL,
    [ManagedTypeTableName]  NVARCHAR (255) NULL,
    [ManagedTypeViewName]   NVARCHAR (255) NULL,
    [ParentFolderId]        NVARCHAR (255) NULL,
    [TimeAdded]             DATETIME       NULL,
    [LastModified]          DATETIME       NULL,
    [ModifiedBy]            NVARCHAR (255) NULL,
    [DisplayName]           NVARCHAR (255) NULL,
    [LanguageCode]          NVARCHAR (255) NULL,
    [Description]           NVARCHAR (MAX) NULL
);

