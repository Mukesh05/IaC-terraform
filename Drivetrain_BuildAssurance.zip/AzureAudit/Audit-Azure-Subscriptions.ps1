﻿<#
.SYNOPSIS
    Gathers Azure Resources in selected subscription

.DESCRIPTION
    Select one subscription to audit resources
    
.NOTES
    Audit can be saved either in Word or HTML file.

    Its required to have Powershell module PScribo installed.
        Install module by running following in PowerShell "Install-Module -Name PScribo"
        Reference: https://www.powershellgallery.com/packages/PScribo


    Location of the Audit Report is selected by user at the end of audit scan.

    Resources gathered:
    Resource Groups
    Virtual Networks
    Vnet Gateways
    Express Route
    Network Connections
    NSGs
    Route Tables (UDRs)
    Storage Accounts
    Virtual Machines
    Network Cards
    VM Disks
    Availability Sets
    Load Balancers
    Public IP Addresses

    File Name : Audit-Azure-Subscriptions.ps1
    Author    : Ingi Ossurarson
    Company   : New Signature
    Version   : 1.0
    Date      : 04-October-2019
    Requires  : PowerShell Version 5.1 or later
    Module    : Az Version 2.x
    Bug Report: Ingi.Ossurarson@NewSignature.com

.EXAMPLE
    .\Audit-Azure-Subscriptions.ps1
#>
[CmdletBinding()]
param (
    [Parameter(Mandatory = $false)]
    [switch]$sendtobackend = $true,

    [Parameter(Mandatory = $false)]
    [switch]$unittesting = $false
) 


#Region Helper Functions for Sending to Backend
Function Send-PostToBackend {
    param (
        [object]$object,
        [string]$name,
        [switch]$sendtobackend = $True
    ) 

    try {
        $postobj = [PSCustomObject]@{
            ReportName = $name
            Content    = $object
        }
        $postobj = $postobj | ConvertTo-Json -Depth 100 
        $postobj | Out-File "$env:temp\$name"
    }
    catch {
        Write-Warning "Error converting object to JSON to send to backend: $_"
        return $null
    }
    
    if ($sendtobackend) {
        $action = Invoke-WebRequest `
            -UseBasicParsing `
            -Uri "https://prod-02.uksouth.logic.azure.com:443/workflows/38a737eef46f473aab3609fa44e109af/triggers/manual/paths/invoke?api-version=2016-10-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=RIZbdhcl8BCGd2pgh1JNAzgcjtJvblUUhcWjfrpXi6A" `
            -Body $postobj `
            -Method Post `
            -ContentType 'application/json'
    }
}

$postobject = [PSCustomObject]@{
    SubscriptionName        = ""
    SubscriptionId          = ""
    DateCollected           = ""
    ResourceGroups          = @()
    VirtualNetworks         = @()
    vNetGateways            = @() 
    ExpressRouteGateways    = @() 
    ExpressRouteConnections = @()
    NetworkSecurityGroups   = @()
    UserDefinedRoutes       = @() 
    StorageAccounts         = @() 
    AllVMs                  = @() 
    VMNICs                  = @() 
    VMDisks                 = @() 
    AvailabilitySets        = @() 
    LoadBalancers           = @()
    PublicIPs               = @() 
}
#EndRegion

Function New-AuditAzureSubscriptions {

    Import-Module PScribo -Force -ErrorAction Stop
    $date = Get-Date
    $snapshotDate = $date.Day, $date.Month, $date.Year -join "-"
    $FileDate = get-date -uformat "%Y%m%d-%H%M"

    #Import-Module Az -ErrorAction Stop
    $testAz = Get-AzTenant -ErrorAction SilentlyContinue
    if (!($testAz)) {
        Login-AzAccount
    }

    $allsubs = Get-AzSubscription
    $menu = @{ }
    Write-Host "`nAzure Subscriptions`n" -Fore Cyan
    for ($i = 1; $i -le $allsubs.count; $i++) {
        Write-Host "$i. $($allsubs[$i-1].name)" 
        $menu.Add($i, ($allsubs[$i - 1].SubscriptionId))
    }
    Write-Host "`n"
    [int]$ans = Read-Host 'Select Subscription'
    $selection = $menu.Item($ans)
    Select-AzSubscription -SubscriptionId $selection

    $SubContext = Get-AzContext
    $SubName = (Get-AzSubscription -SubscriptionId $SubContext.Subscription).Name
    $SubId = (Get-AzSubscription -SubscriptionId $SubContext.Subscription).Id

    # Gather resources before exporting to Document
    $alldisks = get-Azdisk
    $allnics = Get-AzNetworkInterface
    $allnsg = Get-AzNetworkSecurityGroup
    $allpip = Get-AzPublicIpAddress
    $alllb = Get-AzLoadBalancer
    $allrg = Get-AzResourceGroup
    $allsa = Get-AzStorageAccount
    $allvnets = Get-AzVirtualNetwork -WarningAction Ignore
    $allercircuits = Get-AzExpressRouteCircuit
    $allerconnections = Get-AzResource -ResourceType Microsoft.Network/connections
    $allvnetgw = Get-AzResource -ResourceType Microsoft.Network/virtualNetworkGateways
    $alludrs = Get-AzRouteTable

    # ER Connections
    $ERCon = @()
    $allerconnections | Foreach-Object {
        $ERCon += Get-AzVirtualNetworkGatewayConnection -ResourceGroupName $_.ResourceGroupName -Name $_.Name
    }

    $VnetGW = @()
    $allvnetgw | Foreach-Object {
        $VnetGW += Get-AzVirtualNetworkGateway -ResourceGroupName $_.ResourceGroupName -Name $_.Name
    }

    #go through all RGs and get the avset
    $allavset = @()
    $allrg | Foreach-Object {
        $allavset += Get-AzAvailabilitySet -ResourceGroupName $_.ResourceGroupName
    }
    #Build up AV Set Table
    $AllAVSArray = @()
    $allavset | Foreach-Object {
        if ($_.VirtualMachinesReferences.id) {
            $asvms = (($_.VirtualMachinesReferences.id | Foreach-Object { $_.split("/")[8] }) -join ", ")
        }
        else {
            $asvms = "*** No VMs Found ***"
        }
        $asout = "" | Select-Object "Availability Set Name", "Resource Group", Location, Type, "Fault Domain Count", "Update Domain Count", "Associated VMs", Tags
        $asout."Availability Set Name" = $_.Name
        $asout."Resource Group" = $_.ResourceGroupName
        $asout.Location = $_.Location
        $asout.Type = $_.sku
        $asout."Fault Domain Count" = $_.PlatformFaultDomainCount
        $asout."Update Domain Count" = $_.PlatformUpdateDomainCount
        $asout."Associated VMs" = $asvms
        $asout.Tags = $_.Tags | Foreach-Object { [string]::Join(", ", ($_)) }
        $AllAVSArray += $asout
        $asout = ""
        $asvms = ""
    }
    $allvms = Get-AzVM

    $AllVMArray = @()
    $allvms | Foreach-Object {
        #match resources
        $VMId = $_.Id

        $nic = $allnics | Where-Object { $_.VirtualMachine.Id -eq $VMId }
        $nsg = $allnsg | Where-Object { $_.NetworkInterfaces.Id -eq $nic.Id }
        $avset = $allavset | Where-Object { $_.VirtualMachinesReferences.Id -eq $VMId }
        $lb = $alllb | Where-Object { $_.BackendAddressPools.BackendIpConfigurations.Id -match $nic.Name }

        $out = "" | Select-Object "Virtual Machine Name", "Resource Group", "Location", "Network Card", "IP Address", "Availability Set", "Load Balancer", "Diagnostics Enabled", "Diagnostics Storage Account", "Instance Size", "Computer Name", "Administrator Name", "VM Agent Installed", "Automatic Updates enabled", "Publisher", "Operating System", "OS Disk Name", "OS Disk Size", "OS Disk URI", "OS Disk Type", "Data Disks Name", "Data Disks Size", "Data Disks URI", "Data Disks Type", Extensions, Tags
        $out."Virtual Machine Name" = $_.Name;
        $out."Resource Group" = $_.ResourceGroupName;
        $out."Location" = $_.Location;
        $out."Network Card" = $nic.Name;
        $out."IP Address" = $nic.IpConfigurations.PrivateIpAddress;
        $out."Availability Set" = $avset.Name;
        $out."Load Balancer" = $lb.Name;
        $out."Diagnostics Enabled" = $_.DiagnosticsProfile.BootDiagnostics.enabled;
        $out."Diagnostics Storage Account" = $_.DiagnosticsProfile.BootDiagnostics.StorageUri;
        $out."Instance Size" = $_.HardwareProfile.vmSize;
        $out."Computer Name" = $_.OSProfile.computerName;
        $out."Administrator Name" = $_.OSProfile.adminUsername;
        $out."VM Agent Installed" = $_.OSProfile.WindowsConfiguration.provisionVMAgent;
        $out."Automatic Updates enabled" = $_.OSProfile.WindowsConfiguration.enableAutomaticUpdates;
        $out."Publisher" = $_.StorageProfile.imageReference.publisher;
        $out."Operating System" = $_.StorageProfile.imageReference.sku;
        if ($_.StorageProfile.OsDisk.Vhd.Uri -match "core.windows.net") {
            $out."OS Disk Name" = $_.StorageProfile.OsDisk.Name;
            $out."OS Disk Size" = $_.StorageProfile.OsDisk.DiskSizeGB;
            $out."OS Disk URI" = $_.StorageProfile.OsDisk.Vhd.Uri;
            $out."OS Disk Type" = "N/A (Un-Managed Disk)";
            if ($_.StorageProfile.DataDisks.Name) {
                $out."Data Disks Name" = [string]::Join(", ", ($_.StorageProfile.DataDisks.Name));
                $out."Data Disks Size" = [string]::Join(", ", ($_.StorageProfile.DataDisks.DiskSizeGB));
                $out."Data Disks URI" = [string]::Join(", ", ($_.StorageProfile.DataDisks.Vhd.Uri));
                $out."Data Disks Type" = "N/A (Un-Managed Disks)";
            }
        }
        else {
            $out."OS Disk Name" = $_.StorageProfile.OsDisk.Name;
            $out."OS Disk Size" = $_.StorageProfile.OsDisk.DiskSizeGB;
            $out."OS Disk URI" = "N/A (Managed Disk)";
            $out."OS Disk Type" = $_.StorageProfile.OsDisk.ManagedDisk.StorageAccountType;
            if ($_.StorageProfile.DataDisks.Name) {
                $out."Data Disks Name" = [string]::Join(", ", ($_.StorageProfile.DataDisks.Name));
                $out."Data Disks Size" = [string]::Join(", ", ($_.StorageProfile.DataDisks.DiskSizeGB));
                $out."Data Disks URI" = "N/A (Managed Disks)";
                $out."Data Disks Type" = [string]::Join(", ", ($_.StorageProfile.DataDisks.ManagedDisk.StorageAccountType));
            }

        }
        $out.Extensions = [string]::Join(", ", ($_.Extensions | Foreach-Object { $_.Id.split("/")[-1] }));
        $out.Tags = $_.Tags | Foreach-Object { [string]::Join(", ", ($_)) }

        $AllVMArray += $out
        $out = ""
        $nic = ""
        $nsg = ""
        #$osdisk=""
        #$datadisks=""
        $avset = ""
        $lb = ""
    }

    #Build up the Doc 
    <# The document name is used in the file output #>
    $document = Document "Azure Audit Report - $($FileDate)" -Verbose {
        GlobalOption -ForceUppercaseSection -EnableSectionNumbering -PageSize A4 -Margin 24
        BlankLine -Count 10
        Paragraph "Azure Audit Report" -Style Title
        BlankLine
        Paragraph "Subscription Name: $SubName" -Style Title ; $postobject.SubscriptionName = $SubName
        BlankLine
        Paragraph "Subscription Id: $SubId" -Style Title ; $postobject.SubscriptionId = $SubId
        BlankLine
        Paragraph "Date: $($snapshotDate)" -Style Title ; $postobject.DateCollected = $snapshotDate
        BlankLine -Count 10
        PageBreak
        TOC -Name 'Table of Contents'
   
        PageBreak
        ## Resource Groups
        Section -Style Heading1 'Resource Groups' {
            $allrg | Table -Columns ResourceGroupName, Location -Headers 'Resource Group Name', 'Location' -Width 0 -Tabs 1 ; $postobject.ResourceGroups = $allrg | Select ResourceGroupName, Location, ProvisioningState, Tags, ResourceId, ManagedBy
            BlankLine       
        }

        PageBreak
        ## Virtual Networks
        Section -Style Heading1 'Virtual Network Overview' {
            Section -Style Heading2 'Virtual Networks' {
                $vnet += $allvnets | Select-Object @{ Name = "VNET Name"; expression = { $_.Name } }, `
                @{Name = "Resource Group"; expression = { $_.ResourceGroupName } }, `
                @{Name = "VNET Location"; expression = { $_.Location } }, `
                @{Name = "Address Space"; expression = { $_.AddressSpace.AddressPrefixes } }, `
                @{Name = "DNS Servers"; expression = { [string]::Join(", ", ($_.DHCPOptions.DnsServers)) } }, `
                @{Name = "Subnet Names"; expression = { [string]::Join(", ", ($_.Subnets.Name.split(" "))) } }, `
                @{Name = "Subnet Addresses"; expression = { [string]::Join(", ", ($_.Subnets.AddressPrefix.split(" "))) } }, `
                @{Name = "VNET Peering Name"; expression = { [string]::Join(", ", ($_.VirtualNetworkPeerings.Name)) } }, `
                @{Name = "Remote VNET Name"; expression = { [string]::Join(", ", ($_.VirtualNetworkPeerings.RemoteVirtualNetwork | Foreach-Object { $_.id.split("/")[8] })) } }, `
                @{Name = "Peering State"; expression = { [string]::Join(", ", ($_.VirtualNetworkPeerings.PeeringState)) } }, `
                @{Name = "Allow Virtual Network Access"; expression = { [string]::Join(", ", ($_.VirtualNetworkPeerings.AllowVirtualNetworkAccess)) } }, `
                @{Name = "Allow Forwarded Traffic"; expression = { [string]::Join(", ", ($_.VirtualNetworkPeerings.AllowForwardedTraffic)) } }, `
                @{Name = "Allow Gateway Transit"; expression = { [string]::Join(", ", ($_.VirtualNetworkPeerings.AllowGatewayTransit)) } }, `
                @{Name = "Use Remote Gateways"; expression = { [string]::Join(", ", ($_.VirtualNetworkPeerings.UseRemoteGateways)) } }, `
                @{Name = "Tags"; expression = { $_.Tags | Foreach-Object { [string]::Join(", ", ($_)) } } }
                   
                $vnet | Table -Name "FixedWidth-FixedCell-NoHighlighting" -List -ColumnWidths 25, 75 -Width 100 ; $postobject.virtualnetworks = $vnet
                BlankLine       
            }
            Section -Style Heading2 'VNET Gateway' {
                $vnetgwarray += $VnetGW | Select-Object @{ Name = "Gateway Name"; expression = { $_.Name } }, `
                @{Name = "Resource Group"; expression = { $_.ResourceGroupName } }, `
                @{Name = "Gateway Location"; expression = { $_.Location } }, `
                @{Name = "Gateway Type"; expression = { $_.GatewayType } }, `
                @{Name = "Vpn Type"; expression = { $_.VpnType } }, `
                @{Name = "Sku Type"; expression = { $_.Sku.Tier } }, `
                @{Name = "IP Configuration"; expression = { $_.IpConfigurations.PublicIpAddress.Id.split("/")[8] } }, `
                @{Name = "Enable Bgp"; expression = { $_.EnableBgp } }, `
                @{Name = "Bgp Settings"; expression = { $_.BgpSettings } }, `
                @{Name = "Active Active"; expression = { $_.ActiveActive } }, `
                @{Name = "Tags"; expression = { $_.Tags | Foreach-Object { [string]::Join(", ", ($_)) } } }
            
                $vnetgwarray | Table -Name "FixedWidth-FixedCell-NoHighlighting" -List -ColumnWidths 25, 75 -Width 100 ; $postobject.vnetgateways = $vnetgwarray
                BlankLine
            }
            Section -Style Heading2 'Express Route Overview' {            
                $ercircuit += $allercircuits | Select-Object @{ Name = "ER Name"; expression = { $_.Name } }, `
                @{Name = "Resource Group"; expression = { $_.ResourceGroupName } }, `
                @{Name = "ER Location"; expression = { $_.Location } }, `
                @{Name = "Circuit status"; expression = { $_.CircuitProvisioningState } }, `
                @{Name = "Provider status"; expression = { $_.ServiceProviderProvisioningState } }, `
                @{Name = "Provider"; expression = { $_.ServiceProviderProperties.ServiceProviderName } }, `
                @{Name = "Peering location"; expression = { $_.ServiceProviderProperties.PeeringLocation } }, `
                @{Name = "Bandwidth"; expression = { $_.ServiceProviderProperties.BandwidthInMbps } }, `
                @{Name = "Sku Tier"; expression = { $_.Sku.Tier } }, `
                @{Name = "Sku Family"; expression = { $_.Sku.Family } }, `
                @{Name = "Azure Peerings"; expression = { [string]::Join(", ", ($_.Peerings.Name)) } }, `
                @{Name = "Authorizations in Use"; expression = { [string]::Join(", ", ($_.Authorizations.AuthorizationUseStatus)) } }, `
                @{Name = "Allow Classic Operations"; expression = { $_.AllowClassicOperations } }, `
                @{Name = "Tags"; expression = { $_.Tags | Foreach-Object { [string]::Join(", ", ($_)) } } }

                $ercircuit | Table -Name "FixedWidth-FixedCell-NoHighlighting" -List -ColumnWidths 25, 75 -Width 100 ; $postobject.expressroutegateways = $ercircuit
                BlankLine
            }
            Section -Style Heading2 'Network Connections' {
                $ERConArray += $ERCon | Select-Object @{ Name = "Connection Name"; expression = { $_.Name } }, `
                @{Name = "Resource Group"; expression = { $_.ResourceGroupName } }, `
                @{Name = "Location"; expression = { $_.Location } }, `
                @{Name = "Connection Type"; expression = { $_.ConnectionType } }, `
                @{Name = "Connection Status"; expression = { $_.ConnectionStatus } }, `
                @{Name = "Routing Weight"; expression = { $_.RoutingWeight } }, `
                @{Name = "Enable Bgp"; expression = { $_.EnableBgp } }, `
                @{Name = "ER Peer"; expression = { [string]::Join(", ", ($_.PeerText.split("/")[8]).replace('"', '')) } }, `
                @{Name = "VNET-GW 1"; expression = { [string]::Join(", ", ($_.VirtualNetworkGateway1Text.split("/")[8]).replace('"', '')) } }, `
                @{Name = "VNET-GW 2"; expression = { [string]::Join(", ", ($_.VirtualNetworkGateway2Text.split("/")[8]).replace('"', '')) } }, `
                @{Name = "Tags"; expression = { $_.Tags | Foreach-Object { [string]::Join(", ", ($_)) } } }

                $ERConArray | Table -Name "FixedWidth-FixedCell-NoHighlighting" -List -ColumnWidths 25, 75 -Width 100 ; $postobject.ExpressRouteConnections = $ERConArray
                BlankLine
            }
            Section -Style Heading2 'Network Security Groups' {
            
                $nsg += $allnsg | Select-Object @{ Name = "NSG Name"; expression = { $_.Name } }, `
                @{Name = "Resource Group"; expression = { $_.ResourceGroupName } }, `
                @{Name = "Security Rules"; expression = { [string]::Join(", ", ($_.SecurityRules.Name)) } }, `
                @{Name = "Network Interfaces"; expression = { [string]::Join(", ", ($_.NetworkInterfaces.Id.split("/")[8])) } }, `
                @{Name = "Subnets"; expression = { [string]::Join(", ", ($_.Subnets.Id.split("/")[8])) } }, `
                @{Name = "Location"; expression = { $_.Location } }, `
                @{Name = "Tags"; expression = { $_.Tags | Foreach-Object { [string]::Join(", ", ($_)) } } }

                $nsg | Table -Name "FixedWidth-FixedCell-NoHighlighting" -List -ColumnWidths 25, 75 -Width 100 ; $postobject.NetworkSecurityGroups = $nsg
                BlankLine
            }
            Section -Style Heading2 'User Defined Routes' {
       
                $udrs += $alludrs | Select-Object @{ Name = "UDR Name"; expression = { $_.Name } }, `
                @{Name = "Resource Group"; expression = { $_.ResourceGroupName } }, `
                @{Name = "Location"; expression = { $_.Location } }, `
                @{Name = "Subnets"; expression = { [string]::Join(", ", ($_.Subnets.Id.split("/")[10])) } }, `
                @{Name = "Routes"; expression = { [string]::Join(", ", ($_.Routes.Name)) } }, `
                @{Name = "Route AddressPrefix"; expression = { [string]::Join(", ", ($_.Routes.AddressPrefix)) } }, `
                @{Name = "Route NextHopType"; expression = { [string]::Join(", ", ($_.Routes.NextHopType)) } }, `
                @{Name = "Route NextHopIpAddress"; expression = { [string]::Join(", ", ($_.Routes.NextHopIpAddress)) } }, `
                @{Name = "Tags"; expression = { $_.Tags | Foreach-Object { [string]::Join(", ", ($_)) } } }

                $udrs | Table -Name "FixedWidth-FixedCell-NoHighlighting" -List -ColumnWidths 25, 75 -Width 100 ; $postobject.UserDefinedRoutes = $udrs
                BlankLine
            }
        }

        PageBreak
        ## Storage Accounts 
        Section -Style Heading1 'Azure Storage Accounts' {
            $stor += $allsa | Select-Object @{ Name = "Resource Group"; expression = { $_.ResourceGroupName } }, `
            @{Name = "Storage Account Name"; expression = { $_.StorageAccountName } }, `
            @{Name = "Account Type"; expression = { $_.Sku.Name } }, `
            @{Name = "Creation Time"; expression = { $_.CreationTime } }, `
            @{Name = "End Points"; expression = { $_.primaryendpoints.blob } }, `
            @{Name = "Force Https"; expression = { $_.EnableHttpsTrafficOnly } }, `
            @{Name = "Location"; expression = { $_.Location } }, `
            @{Name = "Tags"; expression = { $_.Tags | Foreach-Object { [string]::Join(", ", ($_)) } } }
                     
            $stor | Table -Name "FixedWidth-FixedCell-NoHighlighting" -List -ColumnWidths 25, 75 -Width 100 ; $postobject.StorageAccounts = $stor
            BlankLine       
        }
        PageBreak
    
        ## VIRTUAL MACHINES Table
        $vmstatus = Get-AzVM -Status | Select-Object Name, ResourceGroupName, Location, PowerState
        Style -Name StoppedVM -Color White -BackgroundColor Firebrick
        $vmstatus | Where-Object { $_.PowerState -ne 'VM running' } | Set-Style -Style 'StoppedVM' -Property 'PowerState'

        Section -Style Heading1 'Azure Virtual Machines' {
            Section -Style Heading2 'Virtual Machines Overview' {
                Paragraph "($($vmstatus.Count) Virtual Machines found):"
                Table -InputObject $vmstatus -Columns Name, ResourceGroupName, Location, PowerState -Headers 'VM Name', 'ResourceGroupName', 'Location', 'OS Profile', 'PowerState' -Width 0 -Tabs 1
            }
     
            ## VIRTUAL MACHINE Detailed INFORMATION 
            Section -Style Heading2 'Virtual Machines Details' {
                $AllVMArray | Table -Name "FixedWidth-FixedCell-NoHighlighting" -List -ColumnWidths 25, 75 -Width 100 ; $postobject.AllVMs = $AllVMArray
                BlankLine
            }
            ## VIRTUAL MACHINE NIC INFORMATION
            Section -Style Heading2 'VM Nic Details' {
                if ($allnics -ne $null) {
                    $vNicInfo += $allnics | Select-Object @{ Name = "Virtual Machine Name"; expression = { $_.VirtualMachine.id.split("/")[8] } }, `
                    @{Name = "Interface Name"; expression = { $_.name } }, `
                    @{Name = "Internal IP Address"; expression = { $_.ipconfigurations.PrivateIpAddress } }, `
                    @{Name = "DNS Server"; expression = { [string]$_.DnsSettings.dnsservers } }, `
                    @{Name = "Subnet"; expression = { $_.ipconfigurations.subnet.id.split("/")[10] } }, `
                    @{Name = "IP Allocation"; expression = { $_.IpConfigurations.PrivateIpAllocationMethod } }, `
                    @{Name = "Primary Interface"; expression = { $_.Primary } }, `
                    @{Name = "IP Forwarding Enabled"; expression = { $_.EnableIPForwarding } }, `
                    @{Name = "Public IP Address"; expression = { $_.ipconfigurations.PublicIpAddress.Id.split("/")[8] } }, `
                    @{Name = "Network Security Group"; expression = { $_.NetworkSecurityGroup.id.split("/")[8] } }, `
                    @{Name = "LB Backend Address Pool"; expression = { $_.IpConfigurations.LoadBalancerBackendAddressPools.id.split("/")[8] } }, `
                    @{Name = "LB Inbound Nat Rules"; expression = { [string]::Join(", ", ($_.IpConfigurations.LoadBalancerInboundNatRules | Foreach-Object { $_.id.split("/")[10] })) } }, `
                    @{Name = "Tags"; expression = { $_.Tags | Foreach-Object { [string]::Join(", ", ($_)) } } }
                    $vNicInfo | Table -Name "FixedWidth-FixedCell-NoHighlighting" -List -ColumnWidths 25, 75 -Width 100 ; $postobject.VMNICs = $vNicInfo
                    BlankLine       
                }
            }
            ## VIRTUAL MACHINE Managed Disk INFORMATION
            Section -Style Heading2 'VM Managed Disks Details' {
                if ($alldisks -ne $null) {
                    $vDiskInfo += $alldisks | Select-Object @{ Name = "Disk Name"; expression = { $_.name } }, `
                    @{Name = "Resource Group"; expression = { $_.ResourceGroupName } }, `
                    @{Name = "VM Owner"; expression = { $_.ManagedBy.split("/")[8] } }, `
                    @{Name = "Created"; expression = { [string]$_.TimeCreated } }, `
                    @{Name = "OS Type"; expression = { $_.OsType } }, `
                    @{Name = "Size GB"; expression = { $_.DiskSizeGB } }, `
                        #@{Name="Account Type";expression={$_.AccountType}},`
                    @{Name = "Encryption Settings"; expression = { $_.EncryptionSettings } }, `
                    @{Name = "Location"; expression = { $_.Location } }, `
                    @{Name = "Tags"; expression = { $_.Tags | Foreach-Object { [string]::Join(", ", ($_)) } } }
                    $vDiskInfo | Table -Name "FixedWidth-FixedCell-NoHighlighting" -List -ColumnWidths 25, 75 -Width 100 ; $postobject.VMDisks = $vDiskInfo
                    BlankLine       
                }
            }
            PageBreak
        }
        #avset
        Section -Style Heading1 'Availability Set Details' {
            $AllAVSArray | Table -Name "FixedWidth-FixedCell-NoHighlighting" -List -ColumnWidths 25, 75 -Width 100 ; $postobject.AvailabilitySets = $AllAVSArray
            BlankLine
        }
        PageBreak
        ## Load Balancer INFORMATION
        Section -Style Heading1 'Load Balancer Details' {
            if ($alllb -ne $null) {
                $vlbInfo += $alllb | Select-Object @{ Name = "Name"; expression = { $_.name } }, `
                @{Name = "Resource Group"; expression = { $_.ResourceGroupName } }, `
                @{Name = "Frontend Config"; expression = { [string]::Join(", ", ($_.FrontendIpConfigurations.Name)) } }, `
                @{Name = "Public IP Address"; expression = { [string]::Join(", ", ($_.FrontendIpConfigurations.PublicIpAddress | Foreach-Object { $_.id.split("/")[8] })) } }, `
                @{Name = "Backend Pool Name"; expression = { [string]::Join(", ", ($_.BackendAddressPools.Name)) } }, `
                @{Name = "Backend Pool VM Nic's"; expression = { [string]::Join(", ", ($_.BackendAddressPools.BackendIpConfigurations | Foreach-Object { $_.id.split("/")[8] }))	} }, `
                @{Name = "Health Probes"; expression = { [string]::Join(", ", ($_.Probes.Name)) } }, `
                @{Name = "Health Probes Port"; expression = { [string]::Join(", ", ($_.Probes.Port)) } }, `
                @{Name = "Health Probes Protocol"; expression = { [string]::Join(", ", ($_.Probes.Protocol)) } }, `
                @{Name = "LB Rules"; expression = { [string]::Join(", ", ($_.LoadBalancingRules.Name)) } }, `
                @{Name = "LB Rules Frontend Ports"; expression = { [string]::Join(", ", ($_.LoadBalancingRules.FrontendPort)) } }, `
                @{Name = "LB Rules Backend Ports"; expression = { [string]::Join(", ", ($_.LoadBalancingRules.BackendPort)) } }, `
                @{Name = "LB Rules Protocole"; expression = { [string]::Join(", ", ($_.LoadBalancingRules.Protocol)) } }, `
                @{Name = "Nat Rules"; expression = { [string]::Join(", ", ($_.IpConfigurations.LoadBalancerInboundNatRules | Foreach-Object { $_.id.split("/")[10] })) } }, `
                @{Name = "Nat Rules Frontend Ports"; expression = { [string]::Join(", ", ($_.InboundNatRules.FrontendPort)) } }, `
                @{Name = "Nat Rules Backend Ports"; expression = { [string]::Join(", ", ($_.InboundNatRules.BackendPort)) } }, `
                @{Name = "Nat Rules Protocole"; expression = { [string]::Join(", ", ($_.InboundNatRules.Protocol)) } }, `
                @{Name = "Location"; expression = { $_.Location } }, `
                @{Name = "Tags"; expression = { $_.Tags | Foreach-Object { [string]::Join(", ", ($_)) } } }
                $vlbInfo | Table -Name "FixedWidth-FixedCell-NoHighlighting" -List -ColumnWidths 25, 75 -Width 100 ; $postobject.LoadBalancers = $vlbInfo
              
                BlankLine       
            }
        }
        PageBreak

        ## Public IP Addresses INFORMATION
        Section -Style Heading1 'Public IP Addresses Details' {
            if ($allpip -ne $null) {
                $vpipInfo += $allpip | Select-Object @{ Name = "Name"; expression = { $_.name } }, `
                @{Name = "Resource Group"; expression = { $_.ResourceGroupName } }, `
                @{Name = "Public IP Address"; expression = { $_.IpAddress } }, `
                @{Name = "DNS Address"; expression = { $_.DnsSettings.Fqdn } }, `
                @{Name = "Allocation Method"; expression = { $_.PublicIpAllocationMethod } }, `
                @{Name = "NIC Owner"; expression = { $_.IpConfiguration.Id.split("/")[8] } }, `
                @{Name = "Location"; expression = { $_.Location } }, `
                @{Name = "Tags"; expression = { $_.Tags | Foreach-Object { [string]::Join(", ", ($_)) } } }
                $vpipInfo | Table -Name "FixedWidth-FixedCell-NoHighlighting" -List -ColumnWidths 25, 75 -Width 100 ; $postobject.publicips = $vpipInfo
                BlankLine       
            }
        }
        PageBreak
        #missing route tables, subnets, ExpressRoute, VPN, Connections
    }    
    <#  Generate 'PScribo Demo 1.docx' and 'PScribo Demo 1.html' files. Supported formats include Word, Html, Text #>
    Send-PostToBackend -object $postobject -name "azaudit$(new-guid)" 

    $message = "`nExport to Word Doc or HTML?`n";
    $Word = New-Object System.Management.Automation.Host.ChoiceDescription "&Word"
    $Html = New-Object System.Management.Automation.Host.ChoiceDescription "&Html"
    $options = [System.Management.Automation.Host.ChoiceDescription[]]($Html, $Word)
    $result = $host.ui.PromptForChoice($title, $message, $options, 1)

    # Set Folder Path
    [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") | Out-Null
    $Dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $Dialog.Description = "Select folder where the Azure Report will be saved to"
    $Dialog.ShowDialog()
    $FolderPath = $Dialog.SelectedPath


    ## Handle the result from the user interaction
    switch ($result) {
        0 { $document | Export-Document -Path $FolderPath -Format HTML -Verbose; }
        1 { $document | Export-Document -Path $FolderPath -Format Word -Verbose; }
    }

    Write-Host "Files have been saved to: `n$FolderPath" -ForegroundColor Green

}

if (!$unittesting) {
    New-AuditAzureSubscriptions
}