# Azure Audit


<ul>

| Attribute  | Description |
| ------------- | ------------- |
| `FileName`     | Audit-Azure-Subscriptions.ps1  |
| `Author`   | Ingi Ossurarson |
| `Company`     | New Signature |
| `Version`    | 1.0 |
| `Date`     | 04-October-2019  |
| `Updated`     |  |
| `Requires`     | PowerShell Version 5.1 or later|
| `Module`     | Az Version 2.5.0 |
| `Bug Report`     | Ingi.Ossurarson@NewSignature.com |

</ul>

### Notes
Audit can be saved either in Word or HTML file.

Resources gathered:
```
    Resource Groups
    Virtual Networks
    Vnet Gateways
    Express Route
    Network Connections
    NSGs
    Route Tables (UDRs)
    Storage Accounts
    Virtual Machines
    Network Cards
    VM Disks
    Availability Sets
    Load Balancers
    Public IP Addresses
```