#Requires -Version 5.1 

. .\ASCRecommendations\Get-All-ASC-Recommendations.ps1 -unittesting #Make the functions available from the script

Describe 'Send-PostToBackend function' {
    Context "Mock ConvertTo-Json" {
        Mock ConvertTo-Json -MockWith { throw "foobar" } 
        Mock Write-Warning -Verifiable
        It 'Warns when the inputted object cant be converted to JSON' {
            Send-PostToBackend -object [PSCustomObject]@ {
                Foo = Barr
            } -name "foobar" | Out-Null 
            Assert-VerifiableMock
        }
    }
    Context "Mock Invoke-WebRequest" {
        Mock Invoke-WebRequest -Verifiable
        It 'Attempts to send a request to the backend endpoint' {
            Send-PostToBackend -object [PSCustomObject]@ {
                Foo = Barr
            } -name "foobar" | Out-Null
            Assert-VerifiableMock 
        }
    }
}