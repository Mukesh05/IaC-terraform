# Introduction 
This code repository is the central storage location for New Signature's Build Assurance toolkit. 
In this repo you will find a number of best practice analysis scripts, that will help to QA an Azure environment after build, with the intention of ensuring that the customer is left with a secure environment.

# Contributing
This repository has the following automated QA gates: 
- Automated validation testing of the backend terraform configuration
- Execution of any Pester tests written

Contributions to this repository should be in the form of a Git Pull Request. The authorised Pull Request Reviewers are: 

- Luben Kirov
- Bronson Dreyer
- Andrew Herbert 
- Ingi Ossurarson
- Craig Fretwell
- Jon Simpson
- Platform Services 

[As per request Bryan Lloyd](https://newsigcode.visualstudio.com/DriveTrain/_backlogs/backlog/Platform%20Team/Epics/?workitem=28755)

## Legal
Please note the contents of the .LICENSE file stored in this repository. 

It is required that a Master Services Agreement (MSA) is in place between New Signature and any customer where Drivetrain is used.

Please ensure that any code you contribute is either your own work, released under a permissive (non-copyleft) licence, or has been developed on a customer engagement where a Master Services Agreement is in place. 

If you have any questions or queries about this, please contact legal@newsignature.com. 

## Build Assurance Backend

This pipeline, in addition to hosting the client-side scripts to run the build assurance toolkit, also defines the backend in Azure [which is hosted in the New Signature - UK Ops - Reporting subscription](https://portal.azure.com/#@NEWSIGNATURE1.onmicrosoft.com/resource/subscriptions/f3e39c43-3706-4e75-b890-ebe64fb6591c/overview).

The configuration of the Backend is defined in the .\Terraform_Stack directory. The CI/CD automation is defined in .\Terraform_Pipeline. The CI orchestration is defined in .\azure-pipelines.yml.
The release automation is configured in a release pipeline held inside the [Azure DevOps Drivetrain Project](https://newsigcode.visualstudio.com/DriveTrain)