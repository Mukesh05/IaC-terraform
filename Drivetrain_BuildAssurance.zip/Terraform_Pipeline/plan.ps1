#Import Modules
foreach (
    $module in $(
        Get-ChildItem -Path "$PSScriptRoot\Modules" | Where-Object { $_.Extension -eq ".psm1" }
    )
) {
    Write-Output "Importing $($module.name)"
    Import-Module $module.fullname -Force
}

#Set control variables and run terraform cmdlets from module
Write-Output "Setting backend settings"
$backendsettings.tfpath = $($(Get-Item $PSScriptRoot).Parent.FullName) + '\Terraform_Stack'

Write-Output "Running Terraform Init"
Initialize-Terraform
Write-Output "Publishing Terraform Plan"
Publish-TerraformPlan