# Drivetrain_BuildAssurance Terraform Pipeline

## Background 
In order to implement the requirements defined in [Epic 28735](https://newsigcode.visualstudio.com/DriveTrain/_backlogs/backlog/Platform%20Team/Epics/?workitem=28735), specifically [Feature 28738](https://newsigcode.visualstudio.com/DriveTrain/_backlogs/backlog/Platform%20Team/Epics/?workitem=28738) there was a need to deploy Azure Resources.

In order to implement the resources in a documented and easy-to-maintain manner, it was decided by the Developer to use Terraform to do this.

## What this folder contains

This folder contains PowerShell which wraps around the Terraform.exe executable in order to implement the terraform configuration in HCL for the backend resources required to be implemented for [Feature 28738](https://newsigcode.visualstudio.com/DriveTrain/_backlogs/backlog/Platform%20Team/Epics/?workitem=28738) to be successful. The original genesis for this pipeline can be found in the [Example_Terraform](https://newsigcode.visualstudio.com/DriveTrain/_git/Example_Terraform) repository.
