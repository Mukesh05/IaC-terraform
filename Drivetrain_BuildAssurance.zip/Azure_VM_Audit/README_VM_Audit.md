# Azure Virtual Machine Audit

<ul>

| Attribute  | Description |
| ------------- | ------------- |
| `FileName`     | Azure_All_Subscriptions_VM_Audit.ps1 |
| `Author`   | Craig Fretwell |
| `Company`     | New Signature |
| `Version`    | 1.0 |
| `Date`     | 31-January-2020  |
| `Last Updated`     | 31-January-2020 |
| `Requires`     | PowerShell Version 5.1 or later|
| `Module`     | Az Version 2.5.0 |
| `Runas`     | Administrator {Set-ExecutionPolicy Un-Restricted} |
| `Bug Report`     | Craig.Fretwell@NewSignature.com |

</ul>

-----------------------

## Synopsis
--------
<ul> 
   This PowerShell script will audit all Virtual Machines in every Subscription you have access too and captures the following properties and outputs to CSV
   which then gets converted to XLSX:

    Subscription Name
    Subscription ID
    Resource Group Name
    Virtual Machine Name:
     -IP Address
     -Location
     -SKU
     -Disks
     -VM Size 
     -Number of NICs
     -PowerState
     -OS Version
     -OS Type

    ------
    Please Note:

    All collected information gets compiled into CSV then converts to XLSX and formats the tables to New Signatures colour branding.

    If there's no information within the excel file, that normally means there's no resource present, but double check in the portal if you're unsure. 
## Running the code

For some reason running the script in Visual Studio Code is faster than ISE...so use VS Code :)

