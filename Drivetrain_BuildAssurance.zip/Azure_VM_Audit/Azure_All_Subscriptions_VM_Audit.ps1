<#
.SYNOPSIS
     
    Audit all Virtual Machines in all Azure Subscriptions you have access too.

.DESCRIPTION

   This PowerShell script will audit all Virtual Machines in every Subscription you have access too and captures the following properties ;

    Subscription Name
    Subscription ID
    Resource Group Name
    Virtual Machine Name:
     -IP Address
     -Location
     -SKU
     -Disks
     -VM Size 
     -Number of NICs (and attached Subnet and VNet)
     -PowerState
     -OS Version
     -OS Type

    Please Note:

    All collected information gets compiled into CSV then converts to XLSX and formats the tables to New Signatures colour branding.

.NOTES
    File Name : Azure_All_Subscriptions_VM_Audit.ps1
    Author    : Craig Fretwell
    Company   : New Signature
    Version   : 1.0
    Date      : 31-January-2020
    Updated   : 31-January-2020
    Requires  : PowerShell Version 5.1 or later
    Module    : Az Version 2.5.0
    RunAs     : Administrator {Set-ExecutionPolicy Un-Restricted}
    Bug Report: Craig.Fretwell@NewSignature.com


.EXAMPLE
    .\Azure_All_Subscriptions_VM_Audit.ps1

 /$$   /$$                                /$$$$$$  /$$                                 /$$                                  
| $$$ | $$                               /$$__  $$|__/                                | $$                                  
| $$$$| $$  /$$$$$$  /$$  /$$  /$$      | $$  \__/ /$$  /$$$$$$  /$$$$$$$   /$$$$$$  /$$$$$$   /$$   /$$  /$$$$$$   /$$$$$$ 
| $$ $$ $$ /$$__  $$| $$ | $$ | $$      |  $$$$$$ | $$ /$$__  $$| $$__  $$ |____  $$|_  $$_/  | $$  | $$ /$$__  $$ /$$__  $$
| $$  $$$$| $$$$$$$$| $$ | $$ | $$       \____  $$| $$| $$  \ $$| $$  \ $$  /$$$$$$$  | $$    | $$  | $$| $$  \__/| $$$$$$$$
| $$\  $$$| $$_____/| $$ | $$ | $$       /$$  \ $$| $$| $$  | $$| $$  | $$ /$$__  $$  | $$ /$$| $$  | $$| $$      | $$_____/
| $$ \  $$|  $$$$$$$|  $$$$$/$$$$/      |  $$$$$$/| $$|  $$$$$$$| $$  | $$|  $$$$$$$  |  $$$$/|  $$$$$$/| $$      |  $$$$$$$
|__/  \__/ \_______/ \_____/\___/        \______/ |__/ \____  $$|__/  |__/ \_______/   \___/   \______/ |__/       \_______/
                                                       /$$  \ $$                                                            
                                                      |  $$$$$$/                                                            
                                                       \______/                                                              
#>

[CmdletBinding()]
param (

    [string]$tenantId = "", # Placeholder incase you want to run on a specific Tenant.
    [string]$foldername = 'C:\Azure Audit', # This is the folder location for all audits to be saved too.

    [Parameter(Mandatory = $false)]
    [switch]$sendtobackend = $true,

    [Parameter(Mandatory = $false)]
    [switch]$unittesting = $false,

    [Parameter(Mandatory = $false)]
    [switch]$newazcontext = $true

) 

if (!$unittesting) {
    if ($newazcontext) {
        if ($tenantId -eq "") {
            Login-AzAccount 
            $subs = Get-AzSubscription 
        }
        else {
            Login-AzAccount -tenantid $tenantId 
            $subs = Get-AzSubscription -TenantId $tenantId 
        }
    }
}

#Region Helper functions for sending to backend
Function Send-PostToBackend {
    param (
        [object]$object,
        [string]$name,
        [switch]$sendtobackend = $True
    ) 

    try {
        $postobj = [PSCustomObject]@{
            ReportName = $name
            Content    = $object
        }
        $postobj = $postobj | ConvertTo-Json -Depth 100 
        $postobj | Out-File "$env:temp\$name"
    }
    catch {
        Write-Warning "Error converting object to JSON to send to backend: $_"
        return $null
    }
    
    if ($sendtobackend) {
        $action = Invoke-WebRequest `
            -UseBasicParsing `
            -Uri "https://prod-02.uksouth.logic.azure.com:443/workflows/38a737eef46f473aab3609fa44e109af/triggers/manual/paths/invoke?api-version=2016-10-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=RIZbdhcl8BCGd2pgh1JNAzgcjtJvblUUhcWjfrpXi6A" `
            -Body $postobj `
            -Method Post `
            -ContentType 'application/json'
    }
}
#endregion

Function CreateDirectory {

    Clear-Host
    Write-Host "Creating a new directory called C:\Azure Audit..." -ForegroundColor Yellow; 
    Foreach-Object { Write-Host "" }
    New-item $foldername -ItemType Directory -Force -Verbose 
    Foreach-Object { Write-Host "" }
    Write-Host "New directory has been created $foldername"-ForegroundColor Green; 
    Foreach-Object { Write-Host "" }

}

Function VM_Audit {

    Foreach-Object { Write-Host "" }
    Write-Host "Performing Azure VM Audit, please be patient..." -Verbose -ForegroundColor Yellow
    Foreach-Object { Write-Host "" }

    $allResources = @()
    $file = "$foldername\VMAudit.csv"
    foreach ($sub in $subs) {
        
        Write-Host Auditing Subscription --- $sub.Name -Verbose -ForegroundColor Yellow

        try {
            Select-AzSubscription -SubscriptionId $sub.SubscriptionId -ErrorAction Continue
            $vms = Get-AzVm -Status
            foreach ($vm in $vms) {
                $customPsObject = New-Object -TypeName PsObject
                If ($null -ne $vm.StorageProfile.OsDisk.ManagedDisk.Id) {
                    $osDiskStorageAccount = 'Managed Disk'
                }
                else {
                    $osDiskStorageAccount = ([uri]$vm.StorageProfile.OsDisk.Vhd.Uri).Host
                }
                
                $nics = $vm.NetworkProfile.NetworkInterfaces
                $dataDiskS = $vm.StorageProfile.DataDisks
                $customPsObject | Add-Member -MemberType NoteProperty -Name "Subscription Name" -Value $sub.Name -Verbose
                $customPsObject | Add-Member -MemberType NoteProperty -Name "Subscription ID" -Value $sub.Id -Verbose
                $customPsObject | Add-Member -MemberType NoteProperty -Name "VM Name" -Value $vm.Name -Verbose
                $customPsObject | Add-Member -MemberType NoteProperty -Name "RG" -Value $vm.ResourceGroupName -Verbose
                $customPsObject | Add-Member -MemberType NoteProperty -Name "Location" -Value $vm.Location -Verbose
                $customPsObject | Add-Member -MemberType NoteProperty -Name "Size" -Value $vm.HardwareProfile.VmSize -Verbose
                $customPsObject | Add-Member -MemberType Noteproperty -Name "OS version" -Value $vm.StorageProfile.OsDisk.OsType -Verbose
                $customPsObject | Add-Member -MemberType Noteproperty -Name "OS type" -Value $vm.StorageProfile.ImageReference.Sku -Verbose
                $customPsObject | Add-Member -MemberType Noteproperty -Name "Power State" -Value $vm.PowerState -Verbose 
        
                $i = 0
                foreach ($adapter in $nics) {
                    $nic = Get-AzResource -ResourceId $adapter.Id
                    $vnet = ($nic.Properties.ipConfigurations.properties.subnet -split '/')[-3]
                    $subnet = ($nic.Properties.ipConfigurations.properties.subnet -split '/')[-1]
                    $privateIpAddress = $nic.Properties.ipConfigurations.properties.privateIPAddress
                    $publicIpId = $nic.Properties.ipConfigurations.properties.publicIPAddress.id
                    
                    if ($null -eq $publicIpId) {
                        $publicIpAddress = $null
                    }
                    Else {
                        $publicIpResource = Get-AzResource -ResourceId $publicIpId -ErrorAction SilentlyContinue
                        $publicIpAddress = $publicIpResource.Properties.ipAddress
                    }
                    
                    $availabilitySet = ($vm.AvailabilitySetReference.Id -split '/')[-1]        
                    $customPsObject | Add-Member -MemberType NoteProperty -Name ("NIC-" + $i + "-Vnet") -Value $vnet -Verbose
                    $customPsObject | Add-Member -MemberType NoteProperty -Name ("NIC-" + $i + "-Subnet")  -Value $subnet -Verbose
                    $customPsObject | Add-Member -MemberType NoteProperty -Name ("NIC-" + $i + "-PrivateIpAddress") -Value $privateIpAddress -Verbose
                    $customPsObject | Add-Member -MemberType NoteProperty -Name ("NIC-" + $i + "-PublicIpAddress") -Value $publicIpAddress -Verbose
                    $i++
                }
        
                $customPsObject | Add-Member -MemberType NoteProperty -Name AvailabilitySet -Value $availabilitySet -Verbose
                $customPsObject | Add-Member -MemberType NoteProperty -Name osDisk -Value $osDiskStorageAccount -Verbose
        
                $i = 0
                foreach ($dataDisk in $dataDiskS) {
                    if ($null -ne $DataDisk.ManagedDisk.Id) {
                        $dataDiskHost = 'Managed Disk'
                    }
                    Else {
                        $dataDiskHost = ([uri]($dataDisk.Vhd.Uri)).Host
                    }
                    $customPsObject | Add-Member -MemberType NoteProperty -Name ("dataDisk-" + $i) -Value $dataDiskHost
                    $i++
                }
                
                $allResources += $customPsObject 
            }
        }
        catch {
            Write-Host $error[0]
        }
    }

    Send-PostToBackend -object $allresources -name "vmaudit$(new-guid)" -sendtobackend $sendtobackend
    
    $allResources | Export-Csv $file -NoTypeInformation -Verbose 
    Write-Host "VM list written to $file"

    $xl = new-object -comobject excel.application
    $xl.visible = $False
    $wb = $xl.workbooks.open("$file")
    $table = $wb.ActiveSheet.ListObjects.add( 1, $wb.ActiveSheet.UsedRange, 0, 1)
    $wb.ActiveSheet.UsedRange.EntireColumn.AutoFit()
    $xl.DisplayAlerts = $False
    $wb.SaveAs("$foldername\VM Audit.xlsx", 51)
    $xl.Quit()
}

Function CleanUp {
    Write-Host "Removing CSVs from C:\Azure Audit Folder..." -ForegroundColor Yellow; 
    Foreach-Object { Write-Host "" }
    Remove-Item -Path "$foldername\*.csv" # This will remove all CSV's in Azure Audit folder
    Foreach-Object { Write-Host "" }
}

Function Completion {


    Write-Host "Audit Successful!!" -ForegroundColor Green; 
    Foreach-Object { Write-Host "" }
    Start-Sleep -Seconds 2
    Write-Host "Opening VM Audit File" -ForegroundColor Green; 
    Foreach-Object { Write-Host "" }
    $xl = new-object -comobject excel.application
    $xl.visible = $true
    $wb = $xl.workbooks.open("$foldername\VM Audit.xlsx")

}

if (!$unittesting) {
    CreateDirectory
    VM_Audit
    CleanUp
    Completion
}