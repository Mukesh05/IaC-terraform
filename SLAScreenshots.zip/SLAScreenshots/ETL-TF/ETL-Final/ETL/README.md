# Introduction

This repository is for extract-transform-load(ETL) workstream of Shared Services project.

This project attempts to showcase the capability of Azure Data Factory [ADF](https://docs.microsoft.com/en-us/azure/data-factory/introduction) as a cloud-based ETL and data integration service that allows you to create data-driven workflows for orchestrating data movement and transforming data at scale.

Resources created include:

- Azure Data Factory
- system assigned managed identity for ADF
- Private end Point for ADF
- Private DNS Zone
- Virtual Machines
- Integration runtime (IR)