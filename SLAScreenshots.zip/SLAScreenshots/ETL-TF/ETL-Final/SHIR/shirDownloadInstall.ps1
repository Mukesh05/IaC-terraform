
function download-IntegrationRuntime([string] $url, [string] $irPath) {
    try {
        $ErrorActionPreference = "Stop";
        $client = New-Object System.Net.WebClient
        $client.DownloadFile($url, $irPath)
        Write-Host "Downloaded Integration runtime successfully. IR location: $irPath" -ForegroundColor Green
    }
    catch {
        Write-Host "Fail to download Integration runtime msi" -ForegroundColor Red
        Write-Host $_.Exception.ToString()
        throw
    }
}

function Install-IntegrationRuntime([string] $irPath) {
    if ([string]::IsNullOrEmpty($irPath)) {
        Throw-Error "Integration Runtime path is not specified"
    }

    if (!(Test-Path -Path $irPath)) {
        Throw-Error "Invalid Integration Runtime path: $irPath"
    }
	
    Write-Host "Start Integration Runtime installation"
	
    msiexec.exe /a integrationRuntime.msi /l*v installationlog.txt INSTALLTYPE=AzureTemplate /quiet /norestart | Out-String	
	
    Start-Sleep -Seconds 2

    Write-Host "Installation of Integration Runtime is successful"
}

$uri = "https://go.microsoft.com/fwlink/?linkid=839822"
$irPath = "$PWD\integrationRuntime.msi"

# download-IntegrationRuntime $uri $irPath
Install-IntegrationRuntime $irPath