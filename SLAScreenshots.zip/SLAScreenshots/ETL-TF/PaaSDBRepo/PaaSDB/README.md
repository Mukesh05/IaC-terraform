# PaaS DB 

This repository is for PaaS DB workstream under Shared services project. 

The following ARM templates/Powershell scripts are contained in this repo:

1) Azure SQL Serverless Database. Related files: 

Template : SqlServerlessTemplate.json 
Parameters : parametersSqlServerless.json 
Deploying the template will create the following resources: 
 
 * SQL Server
 * SQL Serverless database. Create an array in the 'databaseInstances' object in the parameters-sqlservless.json file. Multiple database can be deployed at the same time.  
 * dbInstanceautoPauseDelay : Time in minutes after which database is automatically paused. A value of -1 means that automatic pause is disabled. Long term backup does not support autopause so adjust accordingly for dev/test where long term backup is not needed.
 * if parameter 'dbBackupProductionPolicy' value is set to 'true' then the backup retention will be set to 'monthlyRetention: 12M', 'yearlyRetention: 7Y, 'weekOfYear: 1'
 * NB : If the dbBackupProductionPolicy is to be set to true and later false it will not reset to the default 7 days short term.
 * If 'dbAutotuneCreateIndex' value is set to 'true' then the Automatic tuning setting for 'CREATE INDEX' will be enabled. This cannot be enabled for the DR instance!
 * If 'dbAutotuneDropIndex' value is set to 'true' then the Automatic tuning setting for 'DROP INDEX' will be enabled. This cannot be enabled for the DR instance! 
 * Drop index option is currently not compatible with applications using partition switching and index hints. 
 * Automatic tuning 'FORCE PLAN' is enabled by default.
 * If 'dbCreateDrReplica' value is set to 'true' then a database replica will be created in the paired region. NB the resources must have been created before this can be set. 'failoverEnabled' set to 'true'
 * dbInstanceLicenseType : can either be 'LicenseIncluded' for PaYG or 'BasePrice' for BYO license.
 * Ensure 'failoverRegion' is set so that DR resources are created in the correct region. 
 * The parameter 'sqlVaSaName' is the storage account name (not fully qualified) that will be used for SQL vulnerability assessments. This template will enable periodic vulnerability assessments to that storage account. 
 NB : the storage account must already exist and the SQL server managed identity must be granted 'StorageBlobContributor' permissions on that account. This is not automated.
 * A SQL managed identity is created for the SQL server instance. 
 * A Private Endpoint is created for SQL Server in the primary region
 * A Private Endpoint is created for SQL Server in the failpver region if 'failoverEnabled' is set to 'true'
 * A Private DNS zone is updated with the IP of the private instance and the dr instance. Populate the param values accordingly 'privDnsResourceGroup', 'privDnsSubId', 'privDnsZoneName'
 * Public access is disabled
 * Azure AD Auth is enabled. Populate params 'sqlAdAdminGroupName' & 'sqlAdAdminGroupSid' with the correct values from Azure AD.
 * SQL Admin Password is retrieved from the KeyVault. Populate params accordingly. Ensure KeyVault has 'azure Resource Manager for template deployment' enabled. User deploying will need at least 'Microsoft.KeyVault/vaults/deploy/action' role. They do not need to be in the access policy.
 * SQL maintenance window is the default
 * TDE enabled. Platform managed. 

 INDEXING

 Drop index option is currently not compatible with applications using partition switching and index hints. 
---------------


2) Azure SQL Managed instance. Related files: 

Template : SqlManagedInstanceTemplate.json
Parameters : parametersSqlManagedInstance.json 
Deploying the template will create the following resources: 

Before deploying this template ensure that:
- a subnet with sufficient space has been created and delegated to 'Microsoft.Sql/managedInstances' 
- the subnet is protected by an NSG with specific inbound/outbound rules, as mentioned here:  https://docs.microsoft.com/en-us/azure/azure-sql/managed-instance/connectivity-architecture-overview 
- the NSG has a RouteTable assigned with specific routes, as mentioned here: https://docs.microsoft.com/en-us/azure/azure-sql/managed-instance/connectivity-architecture-overview 
The template will create the following resources: 

* SQL Managed Instance 
* SQL Database

\
Parameters
* dbInstanceskuName : Allowed values 'GP_Gen4', 'GP_Gen5', 'BC_Gen4', 'BC_Gen5'
* dbInstanceTier : Allowed valued 'GeneralPurpose','BusinessCritical'
* dbInstanceHwFamily : Must match the dbInstanceskuName. Allowed values : 'Gen4', 'Gen5'
* dbInstanceStorSize : Storage size. INT. Minimum value = 32 GB
* dbInstanceLicenseType : can either be 'LicenseIncluded' for PaYG or 'BasePrice' for BYO license.
* dbInstancevCores : Minimum 4. Allowed values 4, 8, 16, 24, 32, 40, 64, 80
---------------


3) Azure Policies. Related files: 

sub-folder:SQL Policies
executionFile: deploy-policies.ps1 
custom policy file for enforcing short term backup: enforce_SQL_shortterm_backup_retention.json 
custom policy file for denying deployments of sqlDBs without a mentioned tag: deny_deployment_sqlDB_without_tag.json 

The PowerShell execution file automatically handles the following: 

- defines the custom policies inside Azure 
- assigns/enables all 9 mentioned policies 

The Powershell file is exepecting some parameters: 

```powershell
$subscriptionID = represents the subscription on which the policies will be defined and assigned 
$location = the Azure location of the custom policies 
$storageAccountsResourceGroup_for_auditing_policy = the policy responsible for ensuring auditing on SQL Servers requires this parameter to point to a resourceGroup that will host the StorageAccounts that will contain the auditing files 
$logAnalyticsWorkspace_for_diagnostics_settings_policy = the policy responsible for ensuring diagonstic settings are enabled on SQL Servers requires this parameter to point to a Log Analytics Workspace to store the logs 
$allowedTag_for_denyDeployment_policy = the policy responsible with restricting deployments of SQL DBs in case they do not contain a specific tag requires this parameter, which specifies the name of the tag to scan for 
```

