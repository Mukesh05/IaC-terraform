﻿$subscriptionID = "c1319338-2a94-4cd5-a59a-e7233cf51c0e"
$location = "westeurope"
$storageAccountsResourceGroup_for_auditing_policy = "sla-spoketest-rg"
$logAnalyticsWorkspaceName_for_diagnostics_settings_policy = "DefaultWorkspace-c1319338-2a94-4cd5-a59a-e7233cf51c0e-WEU"
$allowedTag_for_denyDeployment_policy = "wibblewobble"

#deploying 2 custom policies
New-AzDeployment -TemplateFile .\deny_deployment_sqlDB_without_tag.json -Location $location
New-AzPolicyDefinition -Name 'enforce-sql-shortterm-backup' -DisplayName 'Enforce SQL short term backup retention' -Policy .\enforce_SQL_shortterm_backup_retention.json


#assigning all 9 policies
$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Configure Azure SQL Server to disable public network access' }
New-AzPolicyAssignment -Name "sql-server-disable-public-access" -DisplayName "SLA - Disable public endpoints for SQL" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Azure SQL Database should have the minimal TLS version of 1.2' }
New-AzPolicyAssignment -Name "sql-server-enforce-TLS" -DisplayName "SLA - No TLS below 1.2 for SQL" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Configure SQL servers to have auditing enabled' }
New-AzPolicyAssignment -Name "sql-server-deploy-auditing" -DisplayName "SLA - Deploy SQL auditing settings" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -storageAccountsResourceGroup $storageAccountsResourceGroup_for_auditing_policy

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Deploy SQL DB transparent data encryption' }
New-AzPolicyAssignment -Name "sql-server-enforce-TDE" -DisplayName "SLA - Enforce TDE on SQL" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Azure Defender for SQL should be enabled for unprotected Azure SQL servers' }
New-AzPolicyAssignment -Name "sql-server-set-defender" -DisplayName "SLA - Azure Defender for SQL set on all SQL Servers" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Deploy Advanced Data Security on SQL servers' }
New-AzPolicyAssignment -Name "sql-server-deploy-VA-and-ATP" -DisplayName "SLA - Deploy Azure SQL Vulnerability Assessment and ATP" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Deploy - Configure diagnostic settings for SQL Databases to Log Analytics workspace' }
New-AzPolicyAssignment -Name "sql-server-deploy-diag-settings" -DisplayName "SLA - Deploy diagnostic settings to SQL Servers" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -logAnalytics $logAnalyticsWorkspaceName_for_diagnostics_settings_policy

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Enforce SQL short term backup retention' }
New-AzPolicyAssignment -Name "enforce-sql-shortterm-backup" -DisplayName "SLA - Enforce SQL short term backup retention" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity

$definition = Get-AzPolicyDefinition | Where-Object { $_.Properties.DisplayName -eq 'Deny deployment of SQL databases without Azure tagging' }
New-AzPolicyAssignment -Name "sql-server-deny-deployment-without-tag" -DisplayName "SLA - Deny deployment of SQL databases without Azure tagging" -PolicyDefinition $definition -Scope "/subscriptions/$subscriptionID" -Location $location -AssignIdentity -allowedTagForSQL $allowedTag_for_denyDeployment_policy
