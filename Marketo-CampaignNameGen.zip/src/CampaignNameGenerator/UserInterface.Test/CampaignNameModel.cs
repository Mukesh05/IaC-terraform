﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using model = UserInterface.Model;

namespace UserInterface.Test
{
	[TestClass]
	public class CampaignNameModel
	{
		[TestMethod]
		public void ResetClearsAllValues()
		{
			model.CampaignNameModel model = new model.CampaignNameModel();

			model.SpecificDate = DateTime.Now;
			
			model.CampaignCity = "City";
			model.CampaignState = "State";
			model.Region = "Region";

			model.Reset();

			Assert.IsNull(model.SpecificDate);
			Assert.AreEqual("", model.CampaignCity);
			Assert.AreEqual("", model.CampaignState);
			Assert.AreEqual("", model.Region);
		}

		[TestMethod]
		public void NameGenerateSpecificDateWithRegion()
		{
			model.CampaignNameModel model = new model.CampaignNameModel();

			model.EventOrSourceType = "ST";
			model.CampaignTitle = "Campaign Title";
			model.ProjectType = "PT";
			model.Region = "GL";
			model.SpecificDate = DateTime.Parse("12 August 2020");

			model.Generate();
			Assert.AreEqual("ST 2020-08-12 PT Campaign Title - GL", model.CampaignName);
		}

		[TestMethod]
		public void NameGeneratePeriodDateWithRegion()
		{
			model.CampaignNameModel model = new model.CampaignNameModel();

			model.EventOrSourceType = "ST";
			model.CampaignTitle = "Campaign Title";
			model.ProjectType = "PT";
			model.Region = "GL";
			model.PeriodDate = "FY2020";

			model.Generate();
			Assert.AreEqual("ST FY2020 PT Campaign Title - GL", model.CampaignName);
		}

		[TestMethod]
		public void NameGenerateCityButNoState()
		{
			model.CampaignNameModel model = new model.CampaignNameModel();

			model.EventOrSourceType = "ST";
			model.CampaignTitle = "Campaign Title";
			model.ProjectType = "PT";
			model.CampaignCity = "City";
			model.Region = "GL";
			model.PeriodDate = "FY2020";

			model.Generate();
			Assert.AreEqual("ST FY2020 PT Campaign Title - City - GL", model.CampaignName);
		}

		[TestMethod]
		public void NameGenerateNoCityButState()
		{
			model.CampaignNameModel model = new model.CampaignNameModel();

			model.EventOrSourceType = "ST";
			model.CampaignTitle = "Campaign Title";
			model.ProjectType = "PT";
			model.CampaignState = "State";
			model.Region = "GL";
			model.PeriodDate = "FY2020";

			model.Generate();
			Assert.AreEqual("ST FY2020 PT Campaign Title - State - GL", model.CampaignName);
		}

		[TestMethod]
		public void NameGenerateCityAndState()
		{
			model.CampaignNameModel model = new model.CampaignNameModel();

			model.EventOrSourceType = "ST";
			model.CampaignTitle = "Campaign Title";
			model.ProjectType = "PT";
			model.CampaignCity = "City";
			model.CampaignState = "State";
			model.Region = "GL";
			model.PeriodDate = "FY2020";

			model.Generate();
			Assert.AreEqual("ST FY2020 PT Campaign Title - City, State - GL", model.CampaignName);
		}
	}
}
