﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using data = UserInterface.Data;
using model = UserInterface.Model;

namespace UserInterface.Test
{
	[TestClass]
	public class CampaignNameGeneratorService
	{
		[TestMethod]
		public void RetrieveModel()
		{
			data.CampaignNameGeneratorService service = new data.CampaignNameGeneratorService();
			model.CampaignNameModel model = service.model;

			Assert.IsInstanceOfType(model, typeof(model.CampaignNameModel));
		}
	}
}
