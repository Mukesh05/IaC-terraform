﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UserInterface.Model;
using FluentValidation.TestHelper;
using UserInterface.CustomValidation;
using FluentAssertions;
using model = UserInterface.Model;

namespace UserInterface.Test
{
	[TestClass]
	public class CampaignNameValidator
	{

		CampaignDateValidator validator = new CampaignDateValidator();

		[TestMethod]
		public void ShouldHaveValidationErrorWhenNoEventOrSourceTypeIsSupplied()
		{
			validator.ShouldHaveValidationErrorFor(x => x.EventOrSourceType, (string)null).WithErrorMessage("Please select value for Event Or Source Type");
		}

		[TestMethod]
		public void ShouldHaveValidationErrorWhenNoProjectTypeIsSupplied()
		{
			validator.ShouldHaveValidationErrorFor(x => x.ProjectType, (string)null).WithErrorMessage("Please select value for Project Type");
		}

		[TestMethod]
		public void ShouldHaveValidationErrorWhenNoRegionIsSupplied()
		{
			validator.ShouldHaveValidationErrorFor(x => x.Region, (string)null).WithErrorMessage("Please select value for Region Type");
		}

		[TestMethod]
		public void ShouldHaveValidationErrorWhenNoSelectedPeriodDateAndSpecificDateIsSupplied()
		{
			var model = new model.CampaignNameModel()
			{
				CampaignCity = "City",
				CampaignState = "State",
				CampaignTitle = "Title",
				EventOrSourceType = "EventOrSourceType",
				ProjectType = "ProjectType",
				Region = "Region",
				PeriodDate = "",
				SpecificDate = null
			};
			validator.ShouldHaveValidationErrorFor(x => x.PeriodDate, model).WithErrorMessage("If Period Date is empty then Specific Date has to be entered");
			validator.ShouldHaveValidationErrorFor(x => x.SpecificDate, model).WithErrorMessage("If Specific Date is empty then Period Date has to be entered");
		}

		[TestMethod]
		public void ShouldHaveNoValidationErrorWhenAllRequiredDataIsSupplied()
		{
			var model = new model.CampaignNameModel()
			{
				CampaignCity = "City",
				CampaignState = "State",
				CampaignTitle = "Title",
				EventOrSourceType = "EventOrSourceType",
				ProjectType = "ProjectType",
				Region = "Region",
				PeriodDate = "FY2000",
				SpecificDate = default(DateTime)
			};

			var result = validator.TestValidate(model);
			result.IsValid.Should().BeTrue();
		}
	}
}
