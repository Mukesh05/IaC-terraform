﻿using System;
using System.Text;

namespace UserInterface.Model
{
	public class CampaignNameModel
	{
		public string EventOrSourceType { get; set; }

		public string CampaignTitle { get; set; }

		public string CampaignCity { get; set; }

		public string CampaignState { get; set; }

		public string ProjectType { get; set; }

		public string Region { get; set; }

		public DateTime? SpecificDate { get; set; } = null;

		public string PeriodDate { get; set; }

		public string CampaignName { get; private set; }

		public CampaignNameModel()
		{
			this.Reset();
		}

		public void Generate()
		{
			StringBuilder GeneratedName = new StringBuilder();

			GeneratedName.Append(EventOrSourceType);

			//Check to see if specific date is empty and if it is use the selected source type
			if (SpecificDate.HasValue)
			{
				GeneratedName.Append(SpecificDate.Value.ToString(" yyyy-MM-dd "));
			}
			else
			{
				GeneratedName.Append(" ");
				GeneratedName.Append(PeriodDate);
				GeneratedName.Append(" ");
			}

			// Check the project type
			GeneratedName.Append(ProjectType);	

			if (CampaignTitle != string.Empty)
			{
				GeneratedName.Append(" ");
				GeneratedName.Append(CampaignTitle);
			}

			//Check the Campaign State
			if (CampaignCity != string.Empty && CampaignState != string.Empty)
			{
				GeneratedName.Append(" - ");
				GeneratedName.Append(CampaignCity + ", " + CampaignState);
			}
			else if (CampaignCity != string.Empty && CampaignState == string.Empty)
			{
				GeneratedName.Append(" - ");
				GeneratedName.Append(CampaignCity);
			}
			else if (CampaignCity == string.Empty && CampaignState != string.Empty)
			{
				GeneratedName.Append(" - ");
				GeneratedName.Append(CampaignState);
			}

			//Check the region
			if (Region != string.Empty)
			{
				GeneratedName.Append(" - ");
				GeneratedName.Append(Region);
			}

			this.CampaignName = GeneratedName.ToString();
		}

		public void Reset()
		{
			this.EventOrSourceType = "";
			this.CampaignTitle = "";
			this.CampaignCity = "";
			this.CampaignState = "";
			this.ProjectType = "";
			this.Region = "";
			this.SpecificDate = null;
			this.PeriodDate = "";
			this.CampaignName = "";
		}
	}
}
