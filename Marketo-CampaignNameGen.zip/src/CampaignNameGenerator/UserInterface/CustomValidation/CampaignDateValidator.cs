﻿using System; 
using FluentValidation;
using UserInterface.Model;

namespace UserInterface.CustomValidation
{
	public class CampaignDateValidator : AbstractValidator<CampaignNameModel>
	{
		public CampaignDateValidator()
		{
			RuleFor(x => x.PeriodDate)
							.NotEmpty()
							.When(x => !x.SpecificDate.HasValue)
							.WithMessage("If Period Date is empty then Specific Date has to be entered");

			RuleFor(x => x.SpecificDate)
							.NotNull()
							.When(x => string.IsNullOrEmpty(x.PeriodDate))
							.WithMessage("If Specific Date is empty then Period Date has to be entered");

			RuleFor(x => x.EventOrSourceType)
							.NotEmpty()
							.WithMessage("Please select value for Event Or Source Type");

			RuleFor(x => x.ProjectType)
							.NotEmpty()
							.WithMessage("Please select value for Project Type");

			RuleFor(x => x.Region)
							.NotEmpty()
							.WithMessage("Please select value for Region Type");
		}
	}
}
