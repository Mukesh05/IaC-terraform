﻿using System;
using System.Text;

namespace UserInterface.Data
{
	public class CampaignNameGeneratorService
	{
		public Model.CampaignNameModel model { get; set; }

		public CampaignNameGeneratorService()
		{
			this.model = new Model.CampaignNameModel();
		}
	}
}
