# Introduction 
A basic Web hosted Blazor application that generates Campaign Names for use within Dynamics 365 and Marketo.  The generator provides a consistent method to generate marketing campaigns.

# Build and Test
The source repository has been built using Visual Studio 2019 and dotNET core 3.1.

# Local Debug

In order to debug the application locally you need to set some enviornment variables, these are :-

ASPNETCORE_ENVIRONMENT - Development
ASPNETCORE_AzureAppConfigConnectionString - Connection to an Azure Application Configuration Service.
