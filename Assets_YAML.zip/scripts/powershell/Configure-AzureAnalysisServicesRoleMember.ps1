[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $AASServerName,
    [string]
    $ModelName,
    [string]
    $RoleName,
    [string]
    $ObjectId,
    [string]
    $ServicePrincipalAppId,
    [string]
    $ServicePrincipalSecret,
    $modulesPath
)

Import-Module -Name "$modulesPath/common.psm1"
Import-Module -Name "$modulesPath/analysis-services.psm1"

if (!($module = Get-InstalledModule -Name SqlServer -ErrorAction SilentlyContinue)) 
{
    $module = Install-Module -Name SqlServer -Scope CurrentUser -AllowClobber -Force -Verbose
}

Import-Module SqlServer

$azContext = Get-AzContext
$tenantId = $azContext.Tenant.Id
$aasServer = $AASServerName

$secret = ConvertTo-SecureString $ServicePrincipalSecret -AsPlainText -Force
$credentials = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $ServicePrincipalAppId, $secret

Write-Verbose "Set service principal context"
Set-ASContext -Server $aasServer -TenantId $tenantId -Credentials $credentials

Write-Verbose "Remove leftover firewall rule"
Remove-CurrentServerFromASFirewall -Server $aasServer -AzContext $azContext

Write-Verbose "Set firewall rull for pipeline"
$addedFirewallRule = New-CurrentServerToASFirewall -Server $aasServer -AzContext $azContext -TenantId $tenantId -Credentials $credentials

Write-Verbose "Wait for firewall rule replication"
Start-Sleep -Seconds 30

Write-Verbose "Add AAD Group to Model Role"
$result = New-AADGroupASRoleMember -Server $aasServer -ObjectId $ObjectId -RoleName $RoleName -ModelName $ModelName -TenantId $tenantId -Credentials $credentials

if ($addedFirewallRule) {
    Write-Verbose "Remove firewall rule"
    Remove-CurrentServerFromASFirewall -Server $aasServer -AzContext $azContext
}


Remove-Module -Name "analysis-services"
Remove-Module -Name "common"