[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $TeamObjectId,
    [string]
    $TeamName,
    [string]
    $TeamRoleName,
    [string]
    $DynamicsAppId,
    [string]
    $DynamicsClientSecret,
    [string]
    $DynamicsInstanceUrl,
    [string]
    $modulesPath
)

Import-Module -Name "$modulesPath/common.psm1"
Import-Module -Name "$modulesPath/dynamics.psm1"

if (!($module = Get-InstalledModule -Name Microsoft.Xrm.Data.PowerShell -ErrorAction SilentlyContinue)) 
{
    $module = Install-Module -Name Microsoft.Xrm.Data.PowerShell -Scope CurrentUser -AllowClobber -Force -Verbose -SkipPublisherCheck -AcceptLicense
}

Connect-Dynamics365AsServicePrincipal -ClientId $DynamicsAppId -ClientSecret $DynamicsClientSecret -DynamicsInstanceUrl $DynamicsInstanceUrl

$team = Build-DynamicsAADGroupBasedTeam -TeamName $TeamName -ObjectId $TeamObjectId

$currentRoles =  Get-CrmTeamSecurityRoles -TeamId $team.ReturnProperty_Id

if(
    $null -eq $currentRoles -or 
    (
        ($currentRoles.GetType().Name -eq "PSCustomObject" -and $currentRoles.RoleName -ne $TeamRoleName) -or
        !(($currentRoles).RoleName -contains $TeamRoleName)
    )
)
{
    Add-CrmSecurityRoleToTeam -TeamId $team.ReturnProperty_Id -SecurityRoleName $TeamRoleName
    Write-Host "Adding Team to specified Dynamics Role"
}
else {
    Write-Host "Team is already a member of the specified Dynamics Role"
}


Remove-Module -Name "dynamics"
Remove-Module -Name "common"