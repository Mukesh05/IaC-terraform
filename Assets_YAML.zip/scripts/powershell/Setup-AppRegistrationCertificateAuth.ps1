[CmdletBinding()]
param (
    [string]
    $KeyVaultName,
    [string]
    $CertificateName,
    [string]
    $ApplicationId,
    [string]
    $modulesPath)

Import-Module -Name "$modulesPath/common.psm1"

if (!($module = Get-InstalledModule -Name AzureADPreview -ErrorAction SilentlyContinue)) 
{
    $module = Install-Module -Name AzureADPreview -Scope CurrentUser -AllowClobber -Force -Verbose -SkipPublisherCheck -AcceptLicense
}

Import-Module AzureADPreview

Connect-AzureADPipeline

Add-Type -AssemblyName System.Security

$cert = Get-AzKeyVaultCertificate -VaultName $KeyVaultName -Name $CertificateName;
$pfx = $cert.Certificate

$validFrom = [datetime]::Parse($pfx.GetEffectiveDateString());
$validFrom = [System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId($validFrom, [System.TimeZoneInfo]::Local.Id, 'GMT Standard Time');
$validTo = [datetime]::Parse($pfx.GetExpirationDateString());
$validTo = [System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId($validTo, [System.TimeZoneInfo]::Local.Id, 'GMT Standard Time');

$base64Value = [System.Convert]::ToBase64String($pfx.GetRawCertData());
$base64Thumbprint = [System.Convert]::ToBase64String($pfx.GetCertHash());

$adApp = Get-AzureADApplication -Filter "AppId eq '$ApplicationId'"
$existingAppKeyCred = Get-AzureADApplicationKeyCredential -ObjectId $adApp.ObjectId
if($null -ne $existingAppKeyCred) {
    if($existingAppKeyCred.GetType().Name -eq 'KeyCredential'){
        $existingBase64Thumbprint = [System.Text.Encoding]::UTF8.GetString($existingAppKeyCred.CustomKeyIdentifier)
        if($base64Thumbprint -eq $existingBase64Thumbprint){
            Write-Host "Azure AD Application Key Credential is already present. Skipping processing.."
        }
        else {
            $cred = New-AzureADApplicationKeyCredential -ObjectId $adApp.ObjectId `
                -CustomKeyIdentifier $base64Thumbprint `
                -Type AsymmetricX509Cert `
                -Usage Verify `
                -Value $base64Value `
                -StartDate $validFrom `
                -EndDate $validTo;
            Write-Host "Created Azure AD Application Key Credential in Azure AD"
        }
    }
    else{
        $found=$false;
        foreach($item in $existingAppKeyCred){
            $existingBase64Thumbprint = [System.Text.Encoding]::UTF8.GetString($item.CustomKeyIdentifier)
            if($base64Thumbprint -eq $existingBase64Thumbprint){
                $found=$true;                
            }
        }
        if($found){
            Write-Host "Azure AD Application Key Credential is already present. Skipping processing.."
        }else {
            $cred = New-AzureADApplicationKeyCredential -ObjectId $adApp.ObjectId `
                -CustomKeyIdentifier $base64Thumbprint `
                -Type AsymmetricX509Cert `
                -Usage Verify `
                -Value $base64Value `
                -StartDate $validFrom `
                -EndDate $validTo;
            Write-Host "Created Azure AD Application Key Credential in Azure AD"
        }
    }
}
else {
    $cred = New-AzureADApplicationKeyCredential -ObjectId $adApp.ObjectId `
        -CustomKeyIdentifier $base64Thumbprint `
        -Type AsymmetricX509Cert `
        -Usage Verify `
        -Value $base64Value `
        -StartDate $validFrom `
        -EndDate $validTo;
    Write-Host "Created Azure AD Application Key Credential in Azure AD"
}

Remove-Module -Name "common"