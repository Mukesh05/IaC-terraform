[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $WorkspaceName,
    [string]
    $SQLUserName,
    [string]
    $SQLPassword,
    [string]
    $ServicePrincipalTenantId,
    [string]
    $ServicePrincipalAppId,
    [string]
    $ServicePrincipalSecret,
    [string]
    $modulesPath
)

Import-Module -Name "$modulesPath/powerbi.psm1"

if (!($module = Get-InstalledModule -Name MicrosoftPowerBIMgmt -ErrorAction SilentlyContinue)) 
{
    $module = Install-Module -Name MicrosoftPowerBIMgmt -Scope CurrentUser -AllowClobber -Force -Verbose -SkipPublisherCheck -AcceptLicense
}

Import-Module MicrosoftPowerBIMgmt

$SecurePassword = ConvertTo-SecureString $ServicePrincipalSecret -AsPlainText -Force 
$Credential = New-Object System.Management.Automation.PSCredential ($ServicePrincipalAppId, $SecurePassword)

Connect-PowerBIServiceAccount -ServicePrincipal -Credential $Credential -Tenant $ServicePrincipalTenantId

$workspace = Get-PowerBIWorkspace -Name $WorkspaceName

$datasets = Get-PowerBIDataset -Workspace $Workspace

foreach($dataset in $datasets)
{
    Update-PowerBIDatasetSQLCredentials -Workspace $workspace -DatasetId $dataset.Id -SqlUsername $SQLUserName -SqlPassword $SQLPassword
}


Remove-Module -Name "powerbi"