[CmdletBinding()]
param (
    [string]
    $MemberObjectId,
    [string]
    $DirectoryRoleName,
    $modulesPath
)

Import-Module -Name "$modulesPath/common.psm1"

if (!($module = Get-InstalledModule -Name AzureADPreview -ErrorAction SilentlyContinue)) 
{
    $module = Install-Module -Name AzureADPreview -Scope CurrentUser -AllowClobber -Force -Verbose -SkipPublisherCheck -AcceptLicense
}

Import-Module AzureADPreview

Connect-AzureADPipeline

$roles = Get-AzureADDirectoryRole
$roleToAssign = $roles.Where({$_.DisplayName -eq $DirectoryRoleName})

if($null -eq $roleToAssign){
    $RoleTemplate = Get-AzureADDirectoryRoleTemplate | Where-Object {$_.DisplayName -eq $DirectoryRoleName}
    if($null -eq $RoleTemplate){
        Write-Error "Directory Role not found. Please verify the name"
    }
    else {
        Enable-AzureADDirectoryRole -RoleTemplateId $RoleTemplate.ObjectId
        $roles = Get-AzureADDirectoryRole
        $roleToAssign = $roles.Where({$_.DisplayName -eq $DirectoryRoleName})
    }
}

$currentRoleMembers = Get-AzureADDirectoryRoleMember -ObjectId $roleToAssign.ObjectId

if(
    $null -eq $currentRoleMembers -or 
    (
        ($currentRoleMembers.GetType().Name -eq "ServicePrincipal" -and $currentRoleMembers.ObjectId -ne $MemberObjectId) -or 
        !(($currentRoleMembers).ObjectId -contains $MemberObjectId)
    )
)
{
    Add-AzureADDirectoryRoleMember -ObjectId $roleToAssign.ObjectId -RefObjectId $MemberObjectId
    Write-Host "Adding Object Id to specified Directory Role"
}
else {
    Write-Host "Object Id is already a member of the specified Directory Role"
}

Remove-Module -Name "common"