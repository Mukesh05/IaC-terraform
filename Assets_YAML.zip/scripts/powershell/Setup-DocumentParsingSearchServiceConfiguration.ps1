[CmdletBinding()]
param (
    [Parameter(Mandatory)]
    [ValidateScript( { Test-Path -Path $_ -PathType Container })]
    [string]
    $ConfigurationFolder,
    [Parameter(Mandatory)]
    [string]
    $SearchServiceName,
    [string]
    $ResourceGroupName,
    [Parameter(Mandatory)]
    [ValidateScript( { Test-Path -Path $_ -PathType Container })]
    [string]
    $modulesPath
)
$ErrorActionPreference = "Stop"
Import-Module -Name "$modulesPath/common.psm1"
Import-Module -Name "$modulesPath/search-service.psm1"

$searchServiceAuth = Build-SearchServiceAuthHeader -ResourceGroupName $ResourceGroupName -SearchServiceName $SearchServiceName

Deploy-SearchServiceDataSources -DataSourcesFolder $ConfigurationFolder -SearchServiceName $SearchServiceName -AuthHeaders $searchServiceAuth
Deploy-SearchServiceSkillSets -SkillSetsFolder $ConfigurationFolder -SearchServiceName $SearchServiceName -AuthHeaders $searchServiceAuth
Deploy-SearchServiceIndexes -IndexesFolder $ConfigurationFolder -SearchServiceName $SearchServiceName -AuthHeaders $searchServiceAuth
Deploy-SearchServiceIndexers -IndexersFolder $ConfigurationFolder -SearchServiceName $SearchServiceName -AuthHeaders $searchServiceAuth

Remove-Module -Name "common" -Force
Remove-Module -Name "search-service" -Force