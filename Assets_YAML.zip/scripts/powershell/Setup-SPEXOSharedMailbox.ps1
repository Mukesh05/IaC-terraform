[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $MailboxDisplayName,
    [string]
    $MailboxEmailName,
    [string]
    $ExchangeOnlineAppId,
    [string]
    $ExchangeOnlineKeyVaultName,
    [string]
    $ExchangeOnlineCertificateName,
    [string]
    $modulesPath
)

Import-Module -Name "$modulesPath/common.psm1"

if (!($module = Get-InstalledModule -Name ExchangeOnlineManagement -ErrorAction SilentlyContinue)) 
{
    $module = Install-Module -Name ExchangeOnlineManagement -Scope CurrentUser -AllowClobber -Force -Verbose -SkipPublisherCheck -AcceptLicense
}
if (!($module = Get-InstalledModule -Name AzureADPreview -ErrorAction SilentlyContinue)) 
{
    $module = Install-Module -Name AzureADPreview -Scope CurrentUser -AllowClobber -Force -Verbose -SkipPublisherCheck -AcceptLicense
}

Import-Module AzureADPreview

Connect-AzureADPipeline

Connect-EXOServicePrinicpalAzure -ServicePrinicpalAppId $ExchangeOnlineAppId -KeyVaultName $ExchangeOnlineKeyVaultName -CertificateName $ExchangeOnlineCertificateName

if (!($mailbox = Get-EXOMailbox -Filter "DisplayName -eq '$MailboxDisplayName'" -ErrorAction SilentlyContinue))
{
    $mailbox = New-Mailbox -Shared -Name $MailboxEmailName -DisplayName $MailboxDisplayName -Alias $MailboxEmailName -Force
}

Write-AzureDevOpsPipelineVariable -variableName "exoMailboxEmailAddress" -variableValue $mailbox.PrimarySmtpAddress -isSecret $false

Disconnect-ExchangeOnline -Confirm:$false

Remove-Module -Name "common"