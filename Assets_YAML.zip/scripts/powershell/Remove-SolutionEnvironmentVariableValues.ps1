[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $SolutionName
)

$inputFile = Get-Content $SolutionName\EnvironmentVariables\environment_variable_values.json -Raw
$json = $inputFile.ToString() | ConvertFrom-Json
foreach($row in $json.EnvironmentVariableValues){
    $row.Value = ""
}
$outputFile = $json | ConvertTo-Json
Set-Content $SolutionName\EnvironmentVariables\environment_variable_values.json -Value $outputFile -Force