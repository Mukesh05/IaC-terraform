[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $AASServerName,
    [string]
    $ModelName,
    [string]
    $ModelFilePath,
    [string]
    $SQLServerName,
    [string]
    $SQLDatabaseName,
    [string]
    $SQLUserName,
    [string]
    $SQLPassword,
    [string]
    $ServicePrincipalAppId,
    [string]
    $ServicePrincipalSecret,
    $modulesPath
)


Import-Module -Name "$modulesPath/common.psm1"
Import-Module -Name "$modulesPath/analysis-services.psm1"

if (!($module = Get-InstalledModule -Name SqlServer -ErrorAction SilentlyContinue)) 
{
    $module = Install-Module -Name SqlServer -Scope CurrentUser -AllowClobber -Force -Verbose
}

Import-Module SqlServer

$azContext = Get-AzContext
$tenantId = $azContext.Tenant.Id
$aasServer = $AASServerName

$secret = ConvertTo-SecureString $ServicePrincipalSecret -AsPlainText -Force
$credentials = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $ServicePrincipalAppId, $secret

$model = Get-ASModel -ModelFile $ModelFilePath
$model = Set-ASModelName -Model $model -NewName $ModelName
$model = Remove-ASModelSecurityIds -Model $model

$model = Set-ASModelSQLSecurity -Model $model -Server $SQLServerName -Database $SQLDatabaseName -UserName $SQLUserName -Password $SQLPassword

$tmslCommand = Set-PreparedTMSLCommand -Model $model -Overwrite $true -ModelName $ModelName

Write-Verbose "Set service principal context"
#Set-ASContext -Server $aasServer -TenantId $tenantId -Credentials $credentials

Write-Verbose "Remove leftover firewall rule"
Remove-CurrentServerFromASFirewall -Server $aasServer -AzContext $azContext

Write-Verbose "Set firewall rull for pipeline"
$addedFirewallRule = New-CurrentServerToASFirewall -Server $aasServer -AzContext $azContext -TenantId $tenantId -Credentials $credentials

Write-Verbose "Wait for firewall rule replication"
Start-Sleep -Seconds 30

Write-Verbose "Deploy model"
$result = Deploy-ASModel -Server $aasServer -Command $tmslCommand -TenantId $tenantId -Credentials $credentials

# Remove firewall rule
if ($addedFirewallRule) {
    Write-Verbose "Remove firewall rule"
    Remove-CurrentServerFromASFirewall -Server $aasServer -AzContext $azContext
}

switch ($result) {
    0 {
        Write-Host "Deploy database to '$aasServer' complete"
    }
    1 {
        Write-Host "Deploy database to '$aasServer' complete with warnings"
    }
    -1 {
        Write-Error "Deploy database to '$aasServer' complete with errors"
        throw
    }
}

Remove-Module -Name "analysis-services"
Remove-Module -Name "common"