function Update-PowerBIDatasetSQLCredentials {
    param (
        [object]
        $Workspace,
        [string]
        $DatasetId,
        [string]
        $SqlUsername,
        [string]
        $SqlPassword
    )
    $passwordLength = $SQLPassword.Length
    Write-Host "SQL Login Password Length $passwordLength"
    $dataset = Get-PowerBIDataset -Id $DatasetId -Workspace $Workspace
    $datasource = Get-PowerBIDatasource -DatasetId $dataset.Id -WorkspaceId $Workspace.Id
    $uri = "gateways/"+$datasource.GatewayId+"/datasources/"+$datasource.DatasourceId
    $usernameJson = "{""name"":""username"",""value"":""$SqlUsername""}"
    $passwordJson = "{""name"":""password"",""value"":""$SqlPassword""}"
    $patchBody= @{
        "credentialDetails" = @{
            "credentials" = "{""credentialData"":[$usernameJson,$passwordJson]}"
            "credentialType" = "Basic"
            "encryptedConnection" = "Encrypted"
            "encryptionAlgorithm" = "None"
            "privacyLevel" = "Organizational"
        }
    }
    $patchBodyJson = ConvertTo-Json -InputObject $patchBody -Depth 6 -Compress
    Invoke-PowerBIRestMethod -Url $uri -Method Patch -Body $patchBodyJson
}