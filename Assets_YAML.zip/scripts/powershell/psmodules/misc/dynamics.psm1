function Connect-Dynamics365AsServicePrincipal {
    param (
        [string]
        $ClientId,
        [string]
        $ClientSecret,
        [string]
        $DynamicsInstanceUrl
    )
    
    Connect-CrmOnline -ServerUrl $DynamicsInstanceUrl -ClientSecret $ClientSecret -OAuthClientId $ClientId
}
function Connect-PowerPlatformAsServicePrincipal {
    param (
        [string]
        $ClientId,
        [string]
        $ClientSecret
    )
    Add-PowerAppsAccount -Endpoint "prod" -TenantID (Get-AzContext).Tenant.Id -ApplicationId $ClientId -ClientSecret $ClientSecret
}
function Get-CrmRecordWithFilter
{
    [CmdletBinding()]
    PARAM(
        [parameter(Mandatory=$false)]
        [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$conn,
        [parameter(Mandatory=$true, Position=1)][alias("EntityName")]
        [string]$EntityLogicalName,
        [parameter(Mandatory=$false, Position=2)][alias("FieldName")]
        [string]$FilterAttribute,
        [parameter(Mandatory=$false, Position=3)][alias("Op")]
        [string]$FilterOperator,
        [parameter(Mandatory=$false, Position=4)][alias("Value", "FieldValue")]
        [string]$FilterValue,
        [parameter(Mandatory=$false, Position=5)]
        [string[]]$Fields, 
        [parameter(Mandatory=$false, Position=6)]
        [switch]$AllRows,
        [parameter(Mandatory=$false, Position=7)]
        [int]$TopCount
    )

    if($conn -eq $null)
    {
        $records = Get-CrmRecords -EntityLogicalName $EntityLogicalName -FilterAttribute $FilterAttribute -FilterOperator $FilterOperator -FilterValue $FilterValue -Fields $Fields -TopCount 1        
    }
    else
    {
        $records = Get-CrmRecords -conn $conn -EntityLogicalName $EntityLogicalName -FilterAttribute $FilterAttribute -FilterOperator $FilterOperator -FilterValue $FilterValue -Fields $Fields -TopCount 1
    }
    if($records.Count -eq 1)
    {
        return $records.CrmRecords[0]
    }
    else
    {
        Write-Host "no record"
    }
}
function Get-SystemApplicationUser {
    param (
        [string]
        $ClientId
    )
    $record = Get-CrmRecords -EntityLogicalName SystemUser -FilterAttribute applicationid -FilterOperator "eq" -FilterValue $ClientId -Fields systemuserid,applicationid

    return $record.CrmRecords
}
function Build-SystemApplicationUser {
    param (
        [string]
        $ClientId,
        [string]
        $FirstName,
        [string]
        $LastName,
        [string]
        $UserName
    )
    if($systemUser = Get-SystemApplicationUser -ClientId $ClientId)
    {
        Write-Host "System User Already Exists"
        return $systemUser
    }

    $businessUnit = Get-CrmRecordWithFilter -EntityLogicalName BusinessUnit -FilterAttribute parentbusinessunitid -FilterOperator "null" -Fields businessunitid,name
    $businessUnitId = $businessUnit.businessunitid
    New-CrmRecord -EntityLogicalName systemuser -Fields @{
        "applicationid"=[System.guid]::New($clientId);
        "firstname"=$FirstName;
        "lastname"=$LastName;
        "internalemailaddress"=$UserName;
        "windowsliveid"=$UserName;
        "businessunitid"=(New-CrmEntityReference -EntityLogicalName businessunit -Id $businessUnitId);
    }
    Write-Host "Create Dynamics Application User: $ClientId"
    
    $systemUser = Get-SystemApplicationUser -ClientId $ClientId
    return $systemUser;
}
function Set-UserSystemSecurityRole {
    param (
        [string]
        $RoleName
    )
    $record = Get-CrmRecords -EntityLogicalName role -FilterAttribute name -FilterOperator "eq" -FilterValue $RoleName -Fields roleid,name,businessunitid

    return $record.CrmRecords
}
function Get-InstalledManagedSolutions {
    $output=@()
    $records = Get-CrmRecords -EntityLogicalName Solution -Fields uniquename,friendlyname,description,createdby,publisherid,createdon,solutionpackageversion,ismanaged,version,installedon,modifiedon
    foreach ($solution in $records.CrmRecords) {

        foreach($item in ($solution |get-Member -MemberType NoteProperty| Select Name| Where-Object {$_.Name -like "*_Property"})){
            $solution.PSObject.Properties.Remove($item.Name)
        }
        $output +=$solution
    }
    return $output
}
function Get-DynamicsTeamByName {
    param (
        [string]
        $Name
    )
    $record = Get-CrmRecords -EntityLogicalName team -FilterAttribute name -FilterOperator "eq" -FilterValue $Name
    
    return $record.CrmRecords
}
function Get-DynamicsTeamByAADObjectId {
    param (
        [string]
        $ObjectId
    )
    $record = Get-CrmRecords -EntityLogicalName team -FilterAttribute azureactivedirectoryobjectid -FilterOperator "eq" -FilterValue $ObjectId

    return $record.CrmRecords
}
function Build-DynamicsAADGroupBasedTeam {
    param (
        [string]
        $TeamName,
        [string]
        $ObjectId
    )
    if($team = Get-DynamicsTeamByAADObjectId -ObjectId $ObjectId)
    {
        Write-Host "Team Already Exists"
        return $team
    }
    $businessUnit = Get-CrmRecordWithFilter -EntityLogicalName BusinessUnit -FilterAttribute parentbusinessunitid -FilterOperator "null" -Fields businessunitid,name
    $businessUnitId = $businessUnit.businessunitid
    #Docs on optionset values https://docs.microsoft.com/en-us/dynamics365/customer-engagement/web-api/team?view=dynamics-ce-odata-9#properties
    New-CrmRecord -EntityLogicalName team -Fields @{
        "azureactivedirectoryobjectid"=[System.guid]::New($ObjectId);
        "name"=$TeamName;
        "membershiptype"=(New-CrmOptionSetValue -Value 0);
        "teamtype"=(New-CrmOptionSetValue -Value 2);
        "businessunitid"=(New-CrmEntityReference -EntityLogicalName businessunit -Id $businessUnitId);
        "administratorid"=(New-CrmEntityReference -EntityLogicalName systemuser -Id (Get-MyCrmUserId));
    }
    Write-Host "Created Dynamics AAD Group Based Team: $ObjectId"
    $team = Get-DynamicsTeamByAADObjectId -ObjectId $ObjectId
    return $team;
}
function Get-CrmTeamSecurityRoles {
    [CmdletBinding()]
    param (
        [parameter(Mandatory=$true, Position=1)]
        [string]$TeamId
    )
    $roles = New-Object System.Collections.Generic.List[PSObject]

    $fetch = @"
    <fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true" no-lock="true">
		  <entity name="role">
		    <attribute name="name"/>
			<attribute name="roleid" />
		    <link-entity name="teamroles" from="roleid" to="roleid" visible="false" intersect="true">
                <link-entity name="team" from="teamid" to="teamid" alias="team">
                    <attribute name="name"/>
                    <attribute name="businessunitid"/>
                    <filter type="and">
                        <condition attribute="teamid" operator="eq" value="{0}" />
                    </filter>
		        </link-entity>
		    </link-entity>
		  </entity>
		</fetch>
"@ -F $TeamId

    (Get-CrmRecordsByFetch -conn $conn -Fetch $fetch).CrmRecords | select @{name="RoleId";Expression={$_.roleid}}, @{name="RoleName";Expression={$_.name}}, @{name="TeamName";expression={$_.'team.name'}}, @{name="BusinessUnitName";expression={($_.'team.businessunitid').Name}} | % {$roles.Add($_)}
    return $roles
}
function Get-CrmQueueDetails {
    param (
        [Parameter(Mandatory=$true,Position=1)]
        [string]
        $QueueId
    )
    Write-Verbose -Message "Retreiving CRM Queue Details for Queue Id: $QueueId"
    $queue = Get-CrmRecordWithFilter -EntityLogicalName queue -FilterAttribute queueid -FilterOperator "eq" -FilterValue $QueueId -Fields queueid,businessunitid,emailaddress,emailrouteraccessapproval,defaultmailboxname,isemailaddressapprovedbyo365admin,queuetypecode
    if(!$queue){
        Write-Error -Message "Failed to retreive Queue Id: $QueueId from CRM. Please validate the queue exists and the input id is correct."
    }
    return $queue
}
function Get-FieldSecurityProfileSystemUserMembership {
    param (
        [Parameter(Mandatory=$true, Position=1, ParameterSetName="CrmRecord")]
        [PSObject]
        $FieldSecurityProfileRecord,
        [Parameter(Mandatory=$true, Position=1, ParameterSetName="Id")]
        [string]
        $FieldSecurityProfileId,
        [Parameter(Mandatory=$false, Position=2, ParameterSetName="Name")]
        [string]
        $FieldSecurityProfileName
    )
    $membership = New-Object System.Collections.Generic.List[PSObject]
    if(-not $FieldSecurityProfileRecord -and $FieldSecurityProfileName){
        $FieldSecurityProfileRecord = Get-CrmRecordWithFilter -EntityLogicalName fieldsecurityprofile -FilterOperator "eq" -FilterAttribute "name" -FilterValue $FieldSecurityProfileName -Fields * 
    }
    if($FieldSecurityProfileRecord){
        $FieldSecurityProfileId = $FieldSecurityProfileRecord.fieldsecurityprofileid
    }
        
    $fetch = @"
    <fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true" no-lock="true">
        <entity name="systemuserprofiles">
            <attribute name="systemuserprofileid"/>
            <attribute name="systemuserid" />
            <attribute name="fieldsecurityprofileid" />
            <filter type="and">
                <condition attribute="fieldsecurityprofileid" operator="eq" value="{0}" />
            </filter>
        </entity>
    </fetch>
"@ -F $FieldSecurityProfileId

    (Get-CrmRecordsByFetch -Fetch $fetch).CrmRecords | Select-Object @{name="SystemUserId";Expression={$_.systemuserid}}, `
    @{name="FieldSecurityProfileId";Expression={$_.fieldsecurityprofileid}} | ForEach-Object {$membership.Add($_)}

    return $membership
}
function Get-FieldSecurityProfileTeamMembership {
    param (
        [Parameter(Mandatory=$true, Position=1, ParameterSetName="CrmRecord")]
        [PSObject]
        $FieldSecurityProfileRecord,
        [Parameter(Mandatory=$true, Position=1, ParameterSetName="Id")]
        [string]
        $FieldSecurityProfileId,
        [Parameter(Mandatory=$false, Position=2, ParameterSetName="Name")]
        [string]
        $FieldSecurityProfileName
    )
    $membership = New-Object System.Collections.Generic.List[PSObject]
    if(-not $FieldSecurityProfileRecord -and $FieldSecurityProfileName){
        $FieldSecurityProfileRecord = Get-CrmRecordWithFilter -EntityLogicalName fieldsecurityprofile -FilterOperator "eq" -FilterAttribute "name" -FilterValue $FieldSecurityProfileName -Fields * 
    }
    if($FieldSecurityProfileRecord){
        $FieldSecurityProfileId = $FieldSecurityProfileRecord.fieldsecurityprofileid
    }
        
    $fetch = @"
    <fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true" no-lock="true">
        <entity name="teamprofiles">
            <attribute name="teamprofileid"/>
            <attribute name="teamid" />
            <attribute name="fieldsecurityprofileid" />
            <filter type="and">
                <condition attribute="fieldsecurityprofileid" operator="eq" value="{0}" />
            </filter>
        </entity>
    </fetch>
"@ -F $FieldSecurityProfileId

    (Get-CrmRecordsByFetch -Fetch $fetch).CrmRecords | Select-Object @{name="TeamId";Expression={$_.teamid}}, `
    @{name="FieldSecurityProfileId";Expression={$_.fieldsecurityprofileid}} | ForEach-Object {$membership.Add($_)}

    return $membership
}
function Add-CrmFieldSecurityProfileToUser {
    param (
        [parameter(Mandatory=$true, Position=1, ParameterSetName="CrmRecord")]
        [PSObject]$UserRecord,
        [parameter(Mandatory=$false, Position=2, ParameterSetName="CrmRecord")]
        [PSObject]$FieldSecurityProfileRecord,
        [parameter(Mandatory=$true, Position=1, ParameterSetName="Id")]
        [string]$UserId,
        [parameter(Mandatory=$false, Position=2, ParameterSetName="Id")]
        [string]$FieldSecurityProfileId,
        [parameter(Mandatory=$false, Position=2)]
        [string]$FieldSecurityProfileName
    )

    if($FieldSecurityProfileRecord -eq $null -and $FieldSecurityProfileId -eq "" -and $FieldSecurityProfileName -eq "")
    {
        Write-Warning "You need to specify Field Security Profile information"
        return
    }

    if($FieldSecurityProfileName -ne "")
    {
        if($UserRecord -eq $null){
            $UserRecord = Get-CrmRecord -conn $conn -EntityLogicalName systemuser -Id $UserId -Fields businessunitid
        }

        $securityProfile = Get-CrmRecordWithFilter -EntityLogicalName fieldsecurityprofile -FilterOperator "eq" -FilterAttribute "name" -FilterValue $FieldSecurityProfileName -Fields *

        if(!$securityProfile)
        {
            Write-Warning "No Field Security Profile found"
            return
        }
    }
    
    if($SecurityRoleName -ne "")
    {
        Add-CrmRecordAssociation -conn $conn -CrmRecord1 $UserRecord -CrmRecord2 $securityProfile -RelationshipName systemuserprofiles_association
    }
    elseif($UserRecord -ne $null)
    {
        Add-CrmRecordAssociation -conn $conn -CrmRecord1 $UserRecord -CrmRecord2 $FieldSecurityProfileRecord -RelationshipName systemuserprofiles_association
    }
    else
    {
        Add-CrmRecordAssociation -conn $conn -EntityLogicalName1 team -Id1 $UserId -EntityLogicalName2 role -Id2 $FieldSecurityProfileId -RelationshipName systemuserprofiles_association
    }
}
function Add-CrmFieldSecurityProfileToTeam {
    param (
        [parameter(Mandatory=$true, Position=1, ParameterSetName="CrmRecord")]
        [PSObject]$TeamRecord,
        [parameter(Mandatory=$false, Position=2, ParameterSetName="CrmRecord")]
        [PSObject]$FieldSecurityProfileRecord,
        [parameter(Mandatory=$true, Position=1, ParameterSetName="Id")]
        [string]$TeamId,
        [parameter(Mandatory=$false, Position=2, ParameterSetName="Id")]
        [string]$FieldSecurityProfileId,
        [parameter(Mandatory=$false, Position=2)]
        [string]$FieldSecurityProfileName
    )

    if($FieldSecurityProfileRecord -eq $null -and $FieldSecurityProfileId -eq "" -and $FieldSecurityProfileName -eq "")
    {
        Write-Warning "You need to specify Field Security Profile information"
        return
    }

    if($FieldSecurityProfileName -ne "")
    {
        if($TeamRecord -eq $null){
            $TeamRecord = Get-CrmRecord -conn $conn -EntityLogicalName team -Id $TeamId
        }

        $securityProfile = Get-CrmRecordWithFilter -EntityLogicalName fieldsecurityprofile -FilterOperator "eq" -FilterAttribute "name" -FilterValue $FieldSecurityProfileName -Fields *

        if(!$securityProfile)
        {
            Write-Warning "No Field Security Profile found"
            return
        }
    }
    
    if($SecurityRoleName -ne "")
    {
        Add-CrmRecordAssociation -conn $conn -CrmRecord1 $TeamRecord -CrmRecord2 $securityProfile -RelationshipName teamprofiles_association
    }
    elseif($TeamRecord -ne $null)
    {
        Add-CrmRecordAssociation -conn $conn -CrmRecord1 $TeamRecord -CrmRecord2 $FieldSecurityProfileRecord -RelationshipName teamprofiles_association
    }
    else
    {
        Add-CrmRecordAssociation -conn $conn -EntityLogicalName1 team -Id1 $TeamId -EntityLogicalName2 role -Id2 $FieldSecurityProfileId -RelationshipName teamprofiles_association
    }
}