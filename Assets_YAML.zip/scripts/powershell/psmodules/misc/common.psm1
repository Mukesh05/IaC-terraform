function Connect-AzureADContext
{
    $azContext = Get-AzContext
    $tenantId = $azContext.Tenant.Id
    $accountId = $azContext.Account.Id
    Connect-AzureAD -AccountId $accountId -TenantId $tenantId
}

function Connect-AzureADPipeline
{
    $context = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile.DefaultContext
    $graphToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://graph.microsoft.com").AccessToken
    $aadToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://graph.windows.net").AccessToken
    Write-Output "Context: $($context.Account.Id)"
    Connect-AzureAD -AadAccessToken $aadToken -AccountId $context.Account.Id -TenantId $context.tenant.id -MsAccessToken $graphToken
}

function Connect-EXOServicePrinicpalAzure {
    param (
        $ServicePrinicpalAppId,
        $KeyVaultName,
        $CertificateName
    )
    $organization = ((Get-AzureADTenantDetail).VerifiedDomains | Where-Object -Property Initial).Name
    $pfxSecret = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name $CertificateName;
    $pfxUnprotectedBytes = [Convert]::FromBase64String($pfxSecret.SecretValueText);
    $pfx = New-Object Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList $pfxUnprotectedBytes, $null, "Exportable";
    Write-Verbose -Message "Connecting to Exchange Online using AppId: $ServicePrinicpalAppId to Organization: $organization"
    Connect-ExchangeOnline -AppId $ServicePrinicpalAppId -Certificate $pfx -Organization $organization
}

function Get-ResourceAccessToken {
    param (
        $resourceScope
    )
    $accesstoken = & az account get-access-token --resource=$resourceScope --query accessToken
    return $accesstoken
}

function Write-AzureDevOpsPipelineVariable {
    param (
        [string]
        $variableName,
        $variableValue,
        [bool]
        $isSecret
    )
    Write-Host "##vso[task.setvariable variable=$variableName;issecret=$isSecret]$variableValue"
    Write-Host "Created Pipeline Variable ($variableName)"
}