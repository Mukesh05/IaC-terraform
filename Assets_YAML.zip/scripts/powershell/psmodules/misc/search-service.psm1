function Build-SearchServiceAuthHeader {
    param (
        [Parameter(Mandatory, ParameterSetName = 'ByAPIKey')]
        [string]
        $ApiKey,
        [Parameter(Mandatory, ParameterSetName = 'ByResourceGroup')]
        [string]
        $ResourceGroupName,
        [Parameter(Mandatory, ParameterSetName = 'ByResourceGroup')]
        [string]
        $SearchServiceName
    )    
    if($PSCmdlet.ParameterSetName -eq 'ByResourceGroup') {
        if (!($module = Get-InstalledModule -Name Az.Search -ErrorAction SilentlyContinue)) 
        {
            $module = Install-Module -Name Az.Search -Scope CurrentUser -AllowClobber -Force -Verbose -SkipPublisherCheck -RequiredVersion 0.7.4
        }
        Import-Module Az.Search

        Write-Host "Search API Key was not provided, obtaining from search site $SearchServiceName in resource group $ResourceGroupName"
        $searchKeys = Get-AzSearchAdminKeyPair -ResourceGroupName $ResourceGroupName -ServiceName $SearchServiceName
        if ($null -eq $searchKeys) {
            Write-Error "Unable to access the API Keys for search service $SearchServiceName in resource group $ResourceGroupName." 
        }
        $ApiKey = $searchKeys.Primary
    }
    $headers = @{"Content-Type" = "application/json"
                 "api-key"      = $ApiKey 
                }
    return $headers
}

function Deploy-SearchServiceDataSources {
    param (
        [Parameter(Mandatory)]
        [ValidateScript( { Test-Path -Path $_ -PathType Container })]
        [string] 
        $DataSourcesFolder,
        [Parameter(Mandatory)]
        [string] 
        $SearchServiceName,
        [string]
        $SearchAPIVersion = "2020-06-30",
        [int] 
        $MaxAPICallCount = 20, # max number of requests before we pause so we dont get the "too many requests error". Defaults to 20
        [int] 
        $APICallPauseDuration = 120,   # defaults to 120 seconds
        [object]
        $AuthHeaders
    )
    $apiCallCount = 0
    $files = Get-ChildItem -Path $DataSourcesFolder -Filter *.json -Recurse | Where-Object { $_.Name -like "ds-*"}
    $files | ForEach-Object { $fileData = Get-Content -Path $_.FullName -raw
        $filename = $_.Name
        try
        {
            if ($apiCallCount -ge $MaxAPICallCount) {
                Write-Host "Max API Call count of $MaxAPICallCount reached. Pausing for $APICallPauseDuration seconds."
                Start-Sleep -Seconds $APICallPauseDuration
                $apiCallCount = 0
            }
            $apiCallCount++
            Write-Verbose -Message "Executing Deploy-SearchServiceDataSource for $filename"
            Deploy-SearchServiceDataSource -DataSourceDefinition $fileData -SearchServiceName $SearchServiceName -SearchAPIVersion $SearchAPIVersion -AuthHeaders $AuthHeaders
        }
        catch {
            $summaryMsg = $_.Exception.Message
            $detailed = $_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction SilentlyContinue
            $detailedMsg = $detailed.error.message
            Write-Error "Error with creating data source $filename. $summaryMsg. Detailed error: $detailedMsg"
        }
    }
}

function Deploy-SearchServiceDataSource {
    param (
        [Parameter(Mandatory)]
        [string]
        $DataSourceDefinition,
        [Parameter(Mandatory)]
        [string] 
        $SearchServiceName,
        [string]
        $SearchAPIVersion = "2020-06-30",
        [object]
        $AuthHeaders
    )
    try
    {
        $dataObjectJson = ConvertFrom-Json -InputObject $DataSourceDefinition
        $apiUrl = "https://$SearchServiceName.search.windows.net/datasources/$($dataObjectJson.name)?api-version=$SearchAPIVersion"
        $response = Invoke-WebRequest -Method Put -Uri $apiUrl -Headers $AuthHeaders -Body $DataSourceDefinition
        if (($response.StatusCode -eq 201) -or ($response.StatusCode -eq 204)) {
            Write-Host "- $($dataObjectJson.name) applied"
        }
        else {
            Write-Error "Issues with creating data source $($dataObjectJson.name) with Url $datasourceUrl. Status code returned was $($response.StatusCode). Msg: $($response.StatusDescription)"
        }
    }
    catch {
        $summaryMsg = $_.Exception.Message
        $detailed = $_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction SilentlyContinue
        $detailedMsg = $detailed.error.message
        Write-Error "Error with creating data source $filename. $summaryMsg. Detailed error: $detailedMsg"
    }
}
function Get-SearchServiceDataSourcesFromFileSystem {
    param (
        [Parameter(Mandatory)]
        [ValidateScript( { Test-Path -Path $_ -PathType Container })]
        [string] 
        $DataSourcesFolder,
        [Parameter(Mandatory)]
        [string] 
        $SearchServiceName,
        [string]
        $SearchAPIVersion = "2020-06-30",
        [object]
        $AuthHeaders
    )
    $apiCallCount = 0
    $dataSourceList
    $files = Get-ChildItem -Path $DataSourcesFolder -Filter *.json -Recurse | Where-Object { $_.Name -like "ds-*"}
    $files | ForEach-Object { $fileData = Get-Content -Path $_.FullName -raw
        $filename = $_.Name
        $dataSourceList += ConvertFrom-Json -InputObject $fileData
    }
    return $dataSourceList
}
function Get-SearchServiceDataSource {
    param (
        [Parameter(Mandatory)]
        [string] 
        $DataSourceName,
        [Parameter(Mandatory)]
        [string] 
        $SearchServiceName,
        [string]
        $SearchAPIVersion = "2020-06-30",
        [object]
        $AuthHeaders
    )
    try
    {
        $apiUrl = "https://$SearchServiceName.search.windows.net/datasources/$($DataSourceName)?api-version=$SearchAPIVersion"
        $response = Invoke-WebRequest -Method Get -Uri $apiUrl -Headers $AuthHeaders
        if ($response.StatusCode -eq 200) {
            Write-Host "- $DataSourceName retrived"
        }
        else {
            Write-Error "Issues with retriving data source $DataSourceName with Url $datasourceUrl. Status code returned was $($response.StatusCode). Msg: $($response.StatusDescription)"
        }
        return ConvertFrom-Json -InputObject $response.Content
    }
    catch {
        $summaryMsg = $_.Exception.Message
        $detailed = $_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction SilentlyContinue
        $detailedMsg = $detailed.error.message
        Write-Error "Error with retreiving data source $DataSourceName. $summaryMsg. Detailed error: $detailedMsg"
    }
}

function Deploy-SearchServiceSkillSets {
    param (
        [Parameter(Mandatory)]
        [ValidateScript( { Test-Path -Path $_ -PathType Container })]
        [string] 
        $SkillSetsFolder,
        [Parameter(Mandatory)]
        [string] 
        $SearchServiceName,
        [string]
        $SearchAPIVersion = "2020-06-30",
        [int] 
        $MaxAPICallCount = 20, # max number of requests before we pause so we dont get the "too many requests error". Defaults to 20
        [int] 
        $APICallPauseDuration = 120,   # defaults to 120 seconds
        [object]
        $AuthHeaders
    )
    $apiCallCount = 0
    $files = Get-ChildItem -Path $SkillSetsFolder -Filter *.json -Recurse | Where-Object { $_.Name -like "ss-*"}
    $files | ForEach-Object { $fileData = Get-Content -Path $_.FullName -raw
        $filename = $_.Name
        try
        {
            if ($apiCallCount -ge $MaxAPICallCount) {
                Write-Host "Max API Call count of $MaxAPICallCount reached. Pausing for $APICallPauseDuration seconds."
                Start-Sleep -Seconds $APICallPauseDuration
                $apiCallCount = 0
            }
            $apiCallCount++
            Deploy-SearchServiceSkillSet -SkillSetDefinition $fileData -SearchServiceName $SearchServiceName -SearchAPIVersion $SearchAPIVersion -AuthHeaders $AuthHeaders
        }
        catch {
            $summaryMsg = $_.Exception.Message
            $detailed = $_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction SilentlyContinue
            $detailedMsg = $detailed.error.message
            Write-Error "Error with creating skill set $filename. $summaryMsg. Detailed error: $detailedMsg"
        }
    }
}

function Deploy-SearchServiceSkillSet {
    param (
        [Parameter(Mandatory)]
        [string]
        $SkillSetDefinition,
        [Parameter(Mandatory)]
        [string] 
        $SearchServiceName,
        [string]
        $SearchAPIVersion = "2020-06-30",
        [object]
        $AuthHeaders
    )
    try
    {
        $dataObjectJson = ConvertFrom-Json -InputObject $SkillSetDefinition
        $apiUrl = "https://$SearchServiceName.search.windows.net/skillsets/$($dataObjectJson.name)?api-version=$SearchAPIVersion"
        $response = Invoke-WebRequest -Method Put -Uri $apiUrl -Headers $AuthHeaders -Body $SkillSetDefinition
        if (($response.StatusCode -eq 201) -or ($response.StatusCode -eq 204)) {
            Write-Host "- $($dataObjectJson.name) applied"
        }
        else {
            Write-Error "Issues with creating skill set $($dataObjectJson.name) with Url $apiUrl. Status code returned was $($response.StatusCode). Msg: $($response.StatusDescription)"
        }
    }
    catch {
        $summaryMsg = $_.Exception.Message
        $detailed = $_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction SilentlyContinue
        $detailedMsg = $detailed.error.message
        Write-Error "Error with creating skill set $filename. $summaryMsg. Detailed error: $detailedMsg"
    }
}

function Deploy-SearchServiceIndexes {
    param (
        [Parameter(Mandatory)]
        [ValidateScript( { Test-Path -Path $_ -PathType Container })]
        [string] 
        $IndexesFolder,
        [Parameter(Mandatory)]
        [string] 
        $SearchServiceName,
        [string]
        $SearchAPIVersion = "2020-06-30",
        [int] 
        $MaxAPICallCount = 20, # max number of requests before we pause so we dont get the "too many requests error". Defaults to 20
        [int] 
        $APICallPauseDuration = 120,   # defaults to 120 seconds
        [object]
        $AuthHeaders
    )
    $apiCallCount = 0
    $files = Get-ChildItem -Path $IndexesFolder -Filter *.json -Recurse | Where-Object { $_.Name -like "ix-*"}
    $files | ForEach-Object { $fileData = Get-Content -Path $_.FullName -raw
        $filename = $_.Name
        try
        {
            if ($apiCallCount -ge $MaxAPICallCount) {
                Write-Host "Max API Call count of $MaxAPICallCount reached. Pausing for $APICallPauseDuration seconds."
                Start-Sleep -Seconds $APICallPauseDuration
                $apiCallCount = 0
            }
            $apiCallCount++
            Deploy-SearchServiceIndex -IndexDefinition $fileData -SearchServiceName $SearchServiceName -SearchAPIVersion $SearchAPIVersion -AuthHeaders $AuthHeaders
        }
        catch {
            $summaryMsg = $_.Exception.Message
            $detailed = $_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction SilentlyContinue
            $detailedMsg = $detailed.error.message
            Write-Error "Error with creating index $filename. $summaryMsg. Detailed error: $detailedMsg"
        }
    }
}

function Deploy-SearchServiceIndex {
    param (
        [Parameter(Mandatory)]
        [string]
        $IndexDefinition,
        [Parameter(Mandatory)]
        [string] 
        $SearchServiceName,
        [string]
        $SearchAPIVersion = "2020-06-30",
        [object]
        $AuthHeaders
    )
    try
    {
        $dataObjectJson = ConvertFrom-Json -InputObject $IndexDefinition
        $apiUrl = "https://$SearchServiceName.search.windows.net/indexes/$($dataObjectJson.name)?api-version=$SearchAPIVersion"
        $response = Invoke-WebRequest -Method Put -Uri $apiUrl -Headers $AuthHeaders -Body $IndexDefinition
        if (($response.StatusCode -eq 201) -or ($response.StatusCode -eq 204)) {
            Write-Host "- $($dataObjectJson.name) applied"
        }
        else {
            Write-Error "Issues with creating index $($dataObjectJson.name) with Url $apiUrl. Status code returned was $($response.StatusCode). Msg: $($response.StatusDescription)"
        }
    }
    catch {
        $summaryMsg = $_.Exception.Message
        $detailed = $_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction SilentlyContinue
        $detailedMsg = $detailed.error.message
        Write-Error "Error with creating index $filename. $summaryMsg. Detailed error: $detailedMsg"
    }
}

function Deploy-SearchServiceIndexers {
    param (
        [Parameter(Mandatory)]
        [ValidateScript( { Test-Path -Path $_ -PathType Container })]
        [string] 
        $IndexersFolder,
        [Parameter(Mandatory)]
        [string] 
        $SearchServiceName,
        [string]
        $SearchAPIVersion = "2020-06-30",
        [int] 
        $MaxAPICallCount = 20, # max number of requests before we pause so we dont get the "too many requests error". Defaults to 20
        [int] 
        $APICallPauseDuration = 120,   # defaults to 120 seconds
        [object]
        $AuthHeaders
    )
    $apiCallCount = 0
    $files = Get-ChildItem -Path $IndexersFolder -Filter *.json -Recurse | Where-Object { $_.Name -like "ir-*"}
    $files | ForEach-Object { $fileData = Get-Content -Path $_.FullName -raw
        $filename = $_.Name
        try
        {
            if ($apiCallCount -ge $MaxAPICallCount) {
                Write-Host "Max API Call count of $MaxAPICallCount reached. Pausing for $APICallPauseDuration seconds."
                Start-Sleep -Seconds $APICallPauseDuration
                $apiCallCount = 0
            }
            $apiCallCount++
            Deploy-SearchServiceIndexer -IndexerDefinition $fileData -SearchServiceName $SearchServiceName -SearchAPIVersion $SearchAPIVersion -AuthHeaders $AuthHeaders
        }
        catch {
            $summaryMsg = $_.Exception.Message
            $detailed = $_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction SilentlyContinue
            $detailedMsg = $detailed.error.message
            Write-Error "Error with creating indexer $filename. $summaryMsg. Detailed error: $detailedMsg"
        }
    }
}

function Deploy-SearchServiceIndexer {
    param (
        [Parameter(Mandatory)]
        [string]
        $IndexerDefinition,
        [Parameter(Mandatory)]
        [string] 
        $SearchServiceName,
        [string]
        $SearchAPIVersion = "2020-06-30",
        [object]
        $AuthHeaders
    )
    try
    {
        $dataObjectJson = ConvertFrom-Json -InputObject $IndexerDefinition
        $apiUrl = "https://$SearchServiceName.search.windows.net/indexers/$($dataObjectJson.name)?api-version=$SearchAPIVersion"
        $response = Invoke-WebRequest -Method Put -Uri $apiUrl -Headers $AuthHeaders -Body $IndexerDefinition
        if (($response.StatusCode -eq 201) -or ($response.StatusCode -eq 204)) {
            Write-Host "- $($dataObjectJson.name) applied"
        }
        else {
            Write-Error "Issues with creating indexer $($dataObjectJson.name) with Url $apiUrl. Status code returned was $($response.StatusCode). Msg: $($response.StatusDescription)"
        }
    }
    catch {
        $summaryMsg = $_.Exception.Message
        $detailed = $_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction SilentlyContinue
        $detailedMsg = $detailed.error.message
        Write-Error "Error with creating indexer $filename. $summaryMsg. Detailed error: $detailedMsg"
    }
}