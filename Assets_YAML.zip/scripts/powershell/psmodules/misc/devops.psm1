function Get-DevOpsServiceEndpoints {
    param (
        [string] $devOpsOrgName,
        [string] $devOpsProjectName
    )

    # $token = Get-ResourceAccessToken -resourceScope "499b84ac-1321-427f-aa17-267ca6975798/.default"
    # $DevOpsHeaders = @{Authorization = 'Bearer ' + $token}
    # $uri = "https://dev.azure.com/$devOpsOrgName/$devOpsProjectName/_apis/serviceendpoint/endpoints?api-version=6.1-preview.4"

    # Invoke-RestMethod -Uri $uri -Headers $DevOpsHeaders
    & az devops login --org https://dev.azure.com/$devOpsOrgName
    $list = & az devops service-endpoint list --org https://dev.azure.com/$devOpsOrgName --project $devOpsProjectName
}