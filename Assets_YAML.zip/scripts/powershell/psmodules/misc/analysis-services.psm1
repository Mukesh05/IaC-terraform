function Get-ASModel($ModelFile) {
    if ([string]::IsNullOrWhitespace($ModelFile) -eq $false `
                -and $ModelFile -ne $env:SYSTEM_DEFAULTWORKINGDIRECTORY `
                -and $ModelFile -ne [String]::Concat($env:SYSTEM_DEFAULTWORKINGDIRECTORY, "\")) {
        try {
            return Get-Content $ModelFile -Encoding UTF8 | ConvertFrom-Json
        } catch {
            $errMsg = $_.exception.message
            throw "Not a valid model file (.asdatabase/.bim) provided. ($errMsg)"
        }
    } else {
        $errMsg = $_.exception.message
        throw "No model file (.asdatabase/.bim) provided. ($errMsg)"
    }
}
function Set-ASModelName($Model, $NewName) {
    if ([string]::IsNullOrWhitespace($NewName) -eq $false `
        -and [string]::IsNullOrEmpty($NewName) -eq $false) {
        $Model.name = $NewName
        $Model = ($Model | Select-Object -Property * -ExcludeProperty id) # Remove not needed Id property
        return $Model
    } else {
        return $Model
    }
}

function Remove-ASModelSecurityIds($Model) {
    $roles = $Model.model.roles
    foreach($role in $roles) {
        if ($role.members) {
            $role.members = @()
        }
    }
    return $Model
}

function Set-ASModelSQLSecurity($Model, $Server, $Database, $UserName, $Password) {
    $connectionDetails = ConvertFrom-Json '{"connectionDetails":{"protocol":"tds","address":{"server":"server","database":"database"}}}'
    $credential = ConvertFrom-Json '{"credential":{"AuthenticationKind":"UsernamePassword","kind":"kind","path":"server","Username":"user","Password":"pass","EncryptConnection":true}}'
    $dataSources = $Model.model.dataSources
    foreach($dataSource in $dataSources) {
        if ($dataSource.type) {
            $connectionDetails.connectionDetails.protocol = $dataSource.connectionDetails.protocol
            $connectionDetails.connectionDetails.address.server = $Server
            $connectionDetails.connectionDetails.address.database = $Database
            $dataSource.connectionDetails = $connectionDetails.connectionDetails
            $credential.credential.kind = $dataSource.credential.kind
            # $credential.credential.EncryptConnection = $dataSource.credential.EncryptConnection
            # $credential.credential.AuthenticationKind = $dataSource.credential.AuthenticationKind
            $credential.credential.path = $Server
            $credential.credential.Username = $UserName
            $credential.credential.Password = $Password
            $dataSource.credential = $credential.credential
        }
    }
    return $Model
}

function Set-PreparedTMSLCommand($Model, $Overwrite, $ModelName) {
    $createTmsl = '{"create":{"database":{"name":"emptyModel"}}}' | ConvertFrom-Json
    $updateTmsl = '{"createOrReplace":{"object":{"database":"existingModel"},"database":{"name":"emptyModel"}}}' | ConvertFrom-Json

    if ($Overwrite) {
        $tmsl = $updateTmsl
        $tmsl.createOrReplace.object.database = $ModelName
        $tmsl.createOrReplace.database = $Model
        return ConvertTo-Json $tmsl -Depth 100 -Compress
    } else {
        $tmsl = $createTmsl
        $tmsl.create.database = $Model
        return ConvertTo-Json $tmsl -Depth 100 -Compress
    }
}

function Deploy-ASModel {
    [CmdletBinding()]
    param (
        [Parameter()]
        [string]
        $Server,
        $Command,
        [string]
        $TenantId,
        [System.Management.Automation.PSCredential]
        $Credentials
    )
    try {
        $result = Invoke-ASCmd -Server $Server -Query $Command -ServicePrincipal -Credential $Credentials -TenantId $TenantId
        return Get-ProcessMessages($result)
    } catch {
        $errMsg = $_.exception.message
        throw "Error during deploying the model ($errMsg)"
    }
}

function New-AADGroupASRoleMember {
    param (
        [Parameter()]
        [string]
        $Server,
        [string]
        $ObjectId,
        [string]
        $RoleName,
        [string]
        $ModelName,
        [string]
        $TenantId,
        [System.Management.Automation.PSCredential]
        $Credentials
    )
    
    try {
        $memberName = "obj:$ObjectId@$TenantId"
        $result = Add-RoleMember -MemberName $memberName -RoleName $RoleName -Database $ModelName -Server $Server -ServicePrincipal -Credential $Credentials -TenantId $TenantId -ErrorAction Stop
        return Get-ProcessMessages($result)
    }
    catch {
        $errMsg = $_.exception.message
        Write-Host $errMsg
    }
}

function Get-ProcessMessages($result) {
    $return = 0
    $resultXml = [Xml]$result
    $messages = $resultXml.return.root.Messages
    
    foreach($message in $messages) {
        $err = $message.Error
        if ($err) {
            $return = -1
            $errCode = $err.errorcode
            $errMsg = $err.Description
            Write-Host "##vso[task.logissue type=error;]Error: $errMsg (ErrorCode: $errCode)"
        }
        $warn = $message.Warning
        if ($warn) {
            if ($return -eq 0) {
                $return = 1
            }
            $warnCode = $warn.WarningCode
            $warnMsg = $warn.Description
            Write-Host "##vso[task.logissue type=warning;]Warning: $warnMsg (WarnCode: $warnCode)"
        }
    }

    return $return
}

function Set-ASContext {
    [CmdletBinding()]
    param (
        [Parameter()]
        [string]
        $Server,
        [string]
        $TenantId,
        [System.Management.Automation.PSCredential]
        $Credentials
    )

    $environment = $Server.Split('/')[2];
    Add-AzAnalysisServicesAccount -Credential $Credentials -ServicePrincipal -TenantId $TenantId -RolloutEnvironment $environment
}

function New-CurrentServerToASFirewall {
    [CmdletBinding()]
    param (
        [Parameter()]
        [string]
        $Server,
        [string]
        $TenantId,
        [System.Management.Automation.PSCredential]
        $Credentials,
        $AzContext
    )

    $qry = "<Discover xmlns='urn:schemas-microsoft-com:xml-analysis'><RequestType>DISCOVER_PROPERTIES</RequestType><Restrictions/><Properties/></Discover>"
    $serverName = $Server.Split('/')[3].Replace(':rw','');
    $added = $false
    try{
        $result = Invoke-ASCmd -Server $Server -Query $qry -ServicePrincipal -Credential $Credentials -TenantId $TenantId -ErrorAction Stop
    }catch{
        $errMsg = $_.Exception.Message
        $start = $errMsg.IndexOf("Client with IP Address '") + 24
        $length = $errMsg.IndexOf("' is not allowed to access the server.") - $start
        if (($start -gt 24) -and ($length -ge 7)) {
            $startIP = $errMsg.SubString($start, $length)
            $endIP = $startIP
        } 
        else {
            Write-Host "##vso[task.logissue type=error;]Error during adding automatic firewall rule ($errMsg)"
            throw
        }
    }finally{
        $error.clear()
    }

    if (($null -ne $startIP) -and ($null -ne $endIP)) {
        try {
            $added = $true
            Write-Verbose "Adding Client IP Address $startIP to $endIP to Azure Analysis Services Firewall"
            $currentConfig = (Get-AzAnalysisServicesServer -Name $serverName -DefaultProfile $AzContext)[0].FirewallConfig
            $currentFirewallRules = $currentConfig.FirewallRules
            $firewallRule = New-AzAnalysisServicesFirewallRule -FirewallRuleName 'azdo-pipeline-aas-rule' -RangeStart $startIP -RangeEnd $endIP -DefaultProfile $AzContext
            $currentFirewallRules.Add($firewallRule)
            if ($currentConfig.EnablePowerBIService) {
                $firewallConfig = New-AzAnalysisServicesFirewallConfig -FirewallRule $currentFirewallRules -EnablePowerBIService -DefaultProfile $AzContext
            } else {
                $firewallConfig = New-AzAnalysisServicesFirewallConfig -FirewallRule $currentFirewallRules -DefaultProfile $AzContext
            }
            $result = Set-AzAnalysisServicesServer -Name $serverName -FirewallConfig $firewallConfig -DefaultProfile $AzContext
        } catch {
            $errMsg = $_.exception.message
            Write-Host "##vso[task.logissue type=error;]Error during adding firewall rule ($errMsg)"
            throw
        }
    }

    return $added
}

function Remove-CurrentServerFromASFirewall($Server, $AzContext) {
    $serverName = $Server.Split('/')[3].Replace(':rw','');
    try {
        $currentConfig = (Get-AzAnalysisServicesServer -Name $serverName -DefaultProfile $AzContext)[0].FirewallConfig
        $newFirewallRules = $currentConfig.FirewallRules
        $newFirewallRules.RemoveAll({ $args[0].FirewallRuleName -eq "azdo-pipeline-aas-rule" })
        if ($currentConfig.EnablePowerBIService) {
            $firewallConfig = New-AzAnalysisServicesFirewallConfig -FirewallRule $newFirewallRules -EnablePowerBIService -DefaultProfile $AzContext
        } else {
            $firewallConfig = New-AzAnalysisServicesFirewallConfig -FirewallRule $newFirewallRules -DefaultProfile $AzContext
        }
        $result = Set-AzAnalysisServicesServer -Name $serverName -FirewallConfig $firewallConfig -DefaultProfile $AzContext
    } catch {
        $errMsg = $_.exception.message
        Write-Host "##vso[task.logissue type=error;]Error during removing firewall rule ($errMsg)"
        throw
    }
}