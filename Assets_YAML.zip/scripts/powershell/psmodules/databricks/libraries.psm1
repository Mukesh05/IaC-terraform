function Uninstall-DatabricksPackages {
    param(
        [string] $clusterId
    )

    $needsRestart = $false
    $installedPackages = (databricks libraries list --cluster-id $clusterId | ConvertFrom-Json).library_statuses.length
    $clusterState =  Get-DatabricksClusterState($clusterId)

    if ($installedPackages -gt 0 -and $clusterState -eq "RUNNING") {
        $needsRestart = $true
    }

    databricks libraries uninstall --all --cluster-id $clusterId    
    Restart-Cluster $clusterId $needsRestart    
}

function Deploy-WheelsOnDBFS {
    param(
        [string] $localwheelsFolder,
        [string] $libraries
    )
    $dbfsPath = "dbfs:/FileStore/wheels"
    $result = databricks fs rm -r $dbfsPath

    $jsonLibraries = ConvertFrom-Json -InputObject $libraries
    Start-Block "Upload wheels on DBFS"
    
    foreach($package in ls $localwheelsFolder) {

        $fileName = $package.Name

        if (!$fileName) {
            $fileName = $package
        }

        Write-Host "Uploading package $fileName"
        $result = databricks fs cp "$localwheelsFolder/$fileName" "$dbfsPath/$fileName" 
        Write-Host $result
        $jsonLibraries += (ConvertFrom-Json -InputObject "{ 'whl' : '$dbfsPath/$fileName' }")
    }

    return ($jsonLibraries | ConvertTo-Json)
}

function Get-DatabricksClusterState {
    param(
        [string] $clusterId
    )
    return (databricks clusters get --cluster-id $clusterId | ConvertFrom-Json).state
}

function Restart-Cluster {
    param(
        [string] $clusterId,
        [boolean] $needsRestart
    )

    $state = Get-DatabricksClusterState($clusterId)

    if ($needsRestart) {
        Write-Host "Restarting cluster"
        databricks clusters restart --cluster-id $clusterId
    }
    else {
        if ($state -ne "RUNNING") {
        Write-Host "Starting cluster"
           databricks clusters start --cluster-id $clusterId
        }
    }

    $state = ""
    while ($state -ne "RUNNING") {
        
        $state = Get-DatabricksClusterState($clusterId)   
        Write-Host "Cluster $clusterId state is $state"
        
        if ($state -ne "RUNNING") {
            Start-Sleep 10
        }
    }
}

function Wait-LibraryInstall {
    param(
        [string] $clusterId
    )

    $length = 1 
    while($length -ne 0) {
        
        $length = (((databricks libraries list --cluster-id $clusterId | ConvertFrom-Json).library_statuses) | Where-Object { $_.status -ne "INSTALLED" }).length    
        Write-Host "Waiting for $length libraries to install"
        if ($length -ne 0) {
            Start-Sleep 10
        }
    }
}

function Install-DatabricksLibraries {
    param(
        [string] $clusterId,
        [string] $libraries,
        [string] $token,
        [string] $location
    )
    
    Start-Block "Databricks install libraries for cluster $clusterId"
    
    Write-Host "Uninstalling packages"
    Uninstall-DatabricksPackages $clusterId    
    
    $body = "{
      'cluster_id': '$clusterId',
      'libraries': --libraries--
    }".Replace("'", '"').Replace("--libraries--", $libraries)

    $headers = @{"Authorization"="Bearer $token";}
    $URL = "https://$location.azuredatabricks.net/api/2.0/libraries/install"
    
    Write-Host "Installing libraries"
    Write-Host "$body"    
    Invoke-RestMethod -Method "POST" -Uri $URL -Headers $headers -Body $body

    Wait-LibraryInstall($clusterId)

}

Export-ModuleMember -Function Install-DatabricksLibraries, Deploy-WheelsOnDBFS