function Start-Block {
    param(
        [object] $text
    )
    Write-Host ""
    Write-Host ""
    Write-Host ==========================================
    Write-Host ==========================================
    Write-Host ""
    Write-Host $text
    Write-Host ""
    Write-Host ==========================================
    Write-Host ==========================================
    Write-Host ""
    Write-Host ""
}