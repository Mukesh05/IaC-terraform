function Find-DatabricksIdClusterByName {
    param(
        [string] $clusterName
    )

    $clusters = (databricks clusters list --output json | ConvertFrom-Json).clusters

    foreach ($cluster in $clusters) {
        If ($cluster.cluster_name -eq $clusterName) {
            return $cluster.cluster_id
        }
    }

    return ""
}

function New-DatabricksClusterInternal {
    param(
        [object] $specs
    )

    $clusterId = Find-DatabricksIdClusterByName $specs.cluster_name 
    if ($clusterId -eq "") {
        
        Write-Host "Cluster not found... Creating"
        $specString = ($specs | ConvertTo-Json)
        $specString = $specString.replace('"', '\"')

        $result = databricks clusters create --json $specString
        Write-Host $result
        $clusterId = ($result | ConvertFrom-Json).cluster_id    
    }
    else {
        Write-Host "Cluster already exists"
    }
    Write-Host "Cluster Id is $clusterId"
    return $clusterId   
}

function New-DatabricksCluster {
    param(
        [object] $specs
    )
    $clusterName = $specs.cluster_name
    Start-Block "Creating cluster $clusterName"

    try {
        $clusterId = New-DatabricksClusterInternal $specs
    }
    catch {
        Write-Host "Cluster creation failed, waiting for 2 minutes"
        Start-Sleep 120
        $clusterId = New-DatabricksClusterInternal $specs
    }

    return $clusterId
}

Export-ModuleMember -Function New-DatabricksCluster
