function Set-DatabricksCLIConfiguration {
    param(
        [string] $resourceGroupName,
        [string] $workspaceName,
        [string] $location,
        [string] $subscriptionId
    )

    Start-Block "Configuring databricks CLI for workspace $workspaceName"
    
    $accessToken = (az account get-access-token --resource "2ff814a6-3304-4ab8-85cb-cd0e6f879c1d" | ConvertFrom-Json).accessToken
    $resourceManagementToken = (az account get-access-token --resource "https://management.core.windows.net/" | ConvertFrom-Json).accessToken


    $headers = @{"Authorization"="Bearer $accessToken";
        "X-Databricks-Azure-SP-Management-Token"=$resourceManagementToken;
        "X-Databricks-Azure-Workspace-Resource-Id"="/subscriptions/$subscriptionId/resourceGroups/$resourceGroupName/providers/Microsoft.Databricks/workspaces/$workspaceName"
    }

    $token = (Invoke-RestMethod -Method "POST" -Uri "https://$location.azuredatabricks.net/api/2.0/token/create" -Headers $headers).token_value

    $config = "[DEFAULT]
host = https://$location.azuredatabricks.net/
token = $token"

    Set-Content "$home/.databrickscfg" $config
    Write-Host $config
    return $token
}

function Import-DatabricksNotebooks {
    param(
        [string] $artifactsPath
    )
    
    Start-Block "Import notebooks"
    $sourcePath = "$artifactsPath"
    databricks workspace delete "/master" --recursive
    databricks workspace mkdirs "/master"

    databricks workspace import_dir $sourcePath /master
}