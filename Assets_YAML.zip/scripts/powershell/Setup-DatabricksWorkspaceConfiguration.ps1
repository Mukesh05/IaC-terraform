param(
    $artifactsPath,
    $modulesPath,
    $workspaceName,
    $resourceGroupName,
    $location,
    $subscriptionId,
    $specsPath,
    $specFile
)

Import-Module -Name "$modulesPath/common.psm1"
Import-Module -Name "$modulesPath/workspace.psm1"
Import-Module -Name "$modulesPath/cluster.psm1"
Import-Module -Name "$modulesPath/libraries.psm1"

python -m pip install --upgrade pip setuptools wheel databricks-cli
$workspaceSettings = (Get-Content "$specsPath/$specFile" | ConvertFrom-Json)
$3rdPartylibraries = (Get-Content "$specsPath/libraries.json")


foreach($workspaceSetting in $workspaceSettings) {    
    $cliToken = Set-DatabricksCLIConfiguration $resourceGroupName $workspaceName $location $subscriptionId
    
    if ($workspaceSetting.copyNotebooks) {
        Import-DatabricksNotebooks $artifactsPath
    }

    $allLibraries = $3rdPartylibraries
    if ($workspaceSetting.uploadLocalWheelsOnDBFS) {
        $allLibraries = Deploy-WheelsOnDBFS "$artifactsPath/pythonWheels" $3rdPartylibraries
    }
    
    foreach($cluster in $workspaceSetting.clusters) {
        $clusterId = New-DatabricksCluster $cluster.specs
        
        if (!!$clusterId) {
            Write-Host "##vso[task.setvariable variable=clusterId]$clusterId"
        }
        
        if ($cluster.installLibraries) {
            Install-DatabricksLibraries $clusterId $allLibraries $cliToken $location
        }

    }    
}

Remove-Module -Name "common"
Remove-Module -Name "workspace"
Remove-Module -Name "cluster"
Remove-Module -Name "libraries"