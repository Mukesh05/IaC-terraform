[CmdletBinding()]
param (
    [Parameter(Mandatory=$true, Position=1)]
    [string]
    $QueueId,
    [Parameter(Mandatory=$true, Position=2)]
    [string]
    $MailboxEmailAddress,
    [Parameter(Mandatory=$true)]
    [string]
    $DynamicsAppId,
    [Parameter(Mandatory=$true)]
    [string]
    $DynamicsClientSecret,
    [Parameter(Mandatory=$true)]
    [string]
    $DynamicsInstanceUrl,
    [string]
    $modulesPath
)

Import-Module -Name "$modulesPath/common.psm1"
Import-Module -Name "$modulesPath/dynamics.psm1"

if (!($module = Get-InstalledModule -Name Microsoft.Xrm.Data.PowerShell -ErrorAction SilentlyContinue)) 
{
    $module = Install-Module -Name Microsoft.Xrm.Data.PowerShell -Scope CurrentUser -AllowClobber -Force -Verbose -SkipPublisherCheck -AcceptLicense
}

Connect-Dynamics365AsServicePrincipal -ClientId $DynamicsAppId -ClientSecret $DynamicsClientSecret -DynamicsInstanceUrl $DynamicsInstanceUrl

$queue = Get-CrmQueueDetails -QueueId $QueueId
if ($queue) {
    if($queue.emailaddress -ne $MailboxEmailAddress -or $queue.emailrouteraccessapproval -ne "Approved" -or $queue.isemailaddressapprovedbyo365admin -ne "Yes") {
        Write-Verbose -Message "Queue Mailbox configuration does not match desired state. Reconfiguring Queue Mailbox based on inputs."
        Set-CrmQueueMailbox -QueueId $QueueId -EmailAddress $MailboxEmailAddress -ApplyDefaultEmailSettings -ScheduleTest -ApproveEmail
    }
    else {
        Write-Host "Queue Mailbox is already in desired state. Skipping change operations."
    }
}
else {
    Write-Error "Queue object not returned from query."
    throw;
}

Remove-Module -Name "dynamics"
Remove-Module -Name "common"