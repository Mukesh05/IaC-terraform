[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $SolutionPath,
    [string]
    $ResourceGroup,
    [string]
    $StorageAccountName
)

$filePath = "$SolutionPath\Other\Customizations.xml"

[xml]$xmlDocument = Get-Content $filePath
$jsonObject = $xmlDocument.ImportExportXml.msdyn_exporttodatalakeconfigs.msdyn_exporttodatalakeconfig.msdyn_schema | ConvertFrom-Json
$context = Get-AzContext
$storageAccount = Get-AzStorageAccount -ResourceGroupName $ResourceGroup -Name $StorageAccountName
$jsonObject.SubscriptionId = $context.Subscription.Id
$jsonObject.ResourceGroupName = $storageAccount.ResourceGroupName
$jsonObject.StorageAccountName = $storageAccount.StorageAccountName
$jsonObject.BlobEndpoint = $storageAccount.PrimaryEndpoints.Blob
$jsonObject.QueueEndpoint = $storageAccount.PrimaryEndpoints.Queue
$jsonObject.TableEndpoint = $storageAccount.PrimaryEndpoints.Table
$jsonObject.FileEndpoint = $storageAccount.PrimaryEndpoints.File
$jsonObject.FileSystemEndpoint = $storageAccount.PrimaryEndpoints.Dfs

$updatedRecord = $jsonObject | ConvertTo-Json -Compress
$xmlDocument.ImportExportXml.msdyn_exporttodatalakeconfigs.msdyn_exporttodatalakeconfig.msdyn_schema = [string] $updatedRecord
$xmlDocument.ImportExportXml.msdyn_exporttodatalakeconfigs.msdyn_exporttodatalakeconfig.msdyn_name = [string] $storageAccount.StorageAccountName
$xmlDocument.Save($filePath)

Write-Host "Updated Export to Datalake Solution"