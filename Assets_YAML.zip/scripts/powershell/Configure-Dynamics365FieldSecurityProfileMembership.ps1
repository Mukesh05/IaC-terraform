[CmdletBinding()]
param (
    [Parameter(Mandatory=$true, Position=1)]
    [ValidateSet("User","Application","Team", IgnoreCase=$false)]
    $MemberType=[ordered]@{
        'User'          = 0
        'Application'   = 1
        'Team'          = 2
    },
    [Parameter(Mandatory=$false,Position=2,ParameterSetName='Application')]
    [string]
    $ApplicationClientId,
    [Parameter(Mandatory=$false,Position=2,ParameterSetName='User')]
    [string]
    $UserName,
    [Parameter(Mandatory=$false,Position=2,ParameterSetName='Team')]
    [string]
    $TeamName,
    [Parameter(Mandatory=$true,Position=3)]
    [string]
    $FieldSecurityProfileName,
    [Parameter(Mandatory=$true, Position=4)]
    [string]
    $DynamicsAppId,
    [Parameter(Mandatory=$true, Position=5)]
    [string]
    $DynamicsClientSecret,
    [Parameter(Mandatory=$true, Position=6)]
    [string]
    $DynamicsInstanceUrl,
    [Parameter(Mandatory=$true, Position=7)]
    [ValidateScript( { Test-Path -Path $_ -PathType Container })]
    [string]
    $modulesPath
)

Import-Module -Name "$modulesPath/common.psm1"
Import-Module -Name "$modulesPath/dynamics.psm1"

if (!($module = Get-InstalledModule -Name Microsoft.Xrm.Data.PowerShell -ErrorAction SilentlyContinue)) 
{
    $module = Install-Module -Name Microsoft.Xrm.Data.PowerShell -Scope CurrentUser -AllowClobber -Force -Verbose -SkipPublisherCheck -AcceptLicense
}

Connect-Dynamics365AsServicePrincipal -ClientId $DynamicsAppId -ClientSecret $DynamicsClientSecret -DynamicsInstanceUrl $DynamicsInstanceUrl

if($MemberType -eq "User"){
    #TODO
}
if($MemberType -eq "Application"){
    $applicationUser = Get-SystemApplicationUser -ClientId $ApplicationClientId
    $fieldSecurityProfileMembership = Get-FieldSecurityProfileSystemUserMembership -FieldSecurityProfileName $FieldSecurityProfileName

    if($null -eq $fieldSecurityProfileMembership -or 
        (
            ($fieldSecurityProfileMembership.GetType().Name -eq "PSCustomObject" -and $fieldSecurityProfileMembership.SystemUserId -ne $applicationUser.systemuserid) -or
            !(($fieldSecurityProfileMembership).SystemUserId -contains $applicationUser.systemuserid)
        )
    )
    {
        Add-CrmFieldSecurityProfileToUser -UserId $applicationUser.systemuserid -FieldSecurityProfileName $FieldSecurityProfileName
        Write-Host "Adding Application User to specified Dynamics Field Security Profile"
    }
    else {
        Write-Host "Application User is already a member of the specified Dynamics Field Security Profile"
    }
}
if($MemberType -eq "Team"){

    $team = Get-DynamicsTeamByName -Name $TeamName
    $fieldSecurityProfileMembership = Get-FieldSecurityProfileTeamMembership -FieldSecurityProfileName $FieldSecurityProfileName
    if($null -eq $fieldSecurityProfileMembership -or 
        (
            ($fieldSecurityProfileMembership.GetType().Name -eq "PSCustomObject" -and $fieldSecurityProfileMembership.teamid -ne $team.teamid) -or
            !(($fieldSecurityProfileMembership).SystemUserId -contains $team.teamid)
        )
    )
    {
        Add-CrmFieldSecurityProfileToTeam -TeamId $team.teamid -FieldSecurityProfileName $FieldSecurityProfileName
        Write-Host "Adding Team to specified Dynamics Field Security Profile"
    }
    else {
        Write-Host "Team is already a member of the specified Dynamics Field Security Profile"
    }
}

Remove-Module -Name "dynamics"
Remove-Module -Name "common"