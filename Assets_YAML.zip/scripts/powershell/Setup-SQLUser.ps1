param(
    [string]
    $userName,
    [string]
    $password,
    [string]
    $dbServer,
    [string]
    $dbName,
    [string]
    $dbRoleName,
    [string]
    $sqlToken
)

Write-Host "Create SQL connectionstring"

$connDb = New-Object System.Data.SqlClient.SQLConnection
$connMaster = New-Object System.Data.SqlClient.SQLConnection
$connDb.ConnectionString = "Server=$dbServer;Initial Catalog=$dbName;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30"
$connDb.AccessToken = $sqlToken
$connMaster.ConnectionString = "Server=$dbServer;Initial Catalog=master;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30"
$connMaster.AccessToken = $sqlToken
$passwordLength = $password.Length
Write-Host "SQL Login Password Length $passwordLength"
Write-Host "Connect to database and execute SQL script for master db"
$connMaster.Open()
$queryMaster = "IF NOT EXISTS (SELECT [name]
    FROM [sys].[database_principals]
    WHERE [type] = N'S' AND [name] = N'$userName')
    BEGIN
        CREATE LOGIN [$userName] WITH PASSWORD=N'$password';
        CREATE USER [$userName] FOR LOGIN [$userName] WITH DEFAULT_SCHEMA=[dbo];
    END
    ELSE
    IF NOT EXISTS (SELECT [name]
        FROM [sys].[sql_logins]
        WHERE [name] = N'$userName' AND PWDCOMPARE('$password',password_hash)=0)
    BEGIN
        ALTER LOGIN [$userName] WITH PASSWORD=N'$password';
    END
"
$commandMaster = New-Object -TypeName System.Data.SqlClient.SqlCommand($queryMaster, $connMaster)
$Result = $commandMaster.ExecuteNonQuery()
$connMaster.Close()
Write-Host "Connect to database and execute SQL script for $dbname db"
$connDb.Open()
$queryDb = "IF NOT EXISTS (SELECT [name]
    FROM [sys].[database_principals]
    WHERE [type] = N'S' AND [name] = N'$userName')
    BEGIN
        CREATE USER [$userName] FOR LOGIN [$userName] WITH DEFAULT_SCHEMA=[dbo];
    END
    IF NOT EXISTS (
        SELECT DP1.name AS DatabaseRoleName,   
        isnull (DP2.name, 'No members') AS DatabaseUserName   
        FROM sys.database_role_members AS DRM  
        RIGHT OUTER JOIN sys.database_principals AS DP1  
        ON DRM.role_principal_id = DP1.principal_id  
        LEFT OUTER JOIN sys.database_principals AS DP2  
        ON DRM.member_principal_id = DP2.principal_id  
        WHERE DP1.type = N'R' AND DP1.name =N'$dbRoleName' AND DP2.name = N'$userName' AND DP2.type=N'S'
    )
    BEGIN
        ALTER ROLE [$dbRoleName] ADD MEMBER [$userName];
    END
"
Write-Host $queryDb
$commandDb = New-Object -TypeName System.Data.SqlClient.SqlCommand($queryDb, $connDb)
$Result = $commandDb.ExecuteNonQuery()
$connDb.Close()