param (
    [Parameter(Mandatory=$true)]
    [string]
    $TerraformOutputString
)

if ($PSBoundParameters['Verbose']) {
    Write-Host "Terraform output json is:"
    Write-Host $TerraformOutputString
}

$terraformOutputObj = $TerraformOutputString | ConvertFrom-Json

$terraformOutputObj.PSObject.Properties | ForEach-Object {
    $type = ($_.value.type).ToLower()
    $isSensitive = ($_.value.sensitive)
    $keyname = "TerraformOutputs.$($_.name)"
    $value = $_.value.value

    if ($isSensitive -eq $true) {
        Write-Host "##vso[task.setvariable variable=$keyname;issecret=$isSensitive]$value"
        Write-Host "Added Azure DevOps secret variable '$keyname' ('$type')"
    } elseif ($type -eq "string") {
        Write-Host "##vso[task.setvariable variable=$keyname]$value"
        Write-Host "Added Azure DevOps variable '$keyname' ('$type') with value '$value'"
    } else {
        Throw "Type '$type' is not supported for '$keyname'"
    }
}