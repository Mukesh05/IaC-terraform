[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $AppUserEmail,
    [string]
    $AppUserFirstName,
    [string]
    $AppUserLastName,
    [string]
    $AppUserClientId,
    [string]
    $AppUserRoleName,
    [string]
    $DynamicsAppId,
    [string]
    $DynamicsClientSecret,
    [string]
    $DynamicsInstanceUrl,
    [string]
    $modulesPath
)

Import-Module -Name "$modulesPath/common.psm1"
Import-Module -Name "$modulesPath/dynamics.psm1"

if (!($module = Get-InstalledModule -Name Microsoft.Xrm.Data.PowerShell -ErrorAction SilentlyContinue)) 
{
    $module = Install-Module -Name Microsoft.Xrm.Data.PowerShell -Scope CurrentUser -AllowClobber -Force -Verbose -SkipPublisherCheck -AcceptLicense
}

Connect-Dynamics365AsServicePrincipal -ClientId $DynamicsAppId -ClientSecret $DynamicsClientSecret -DynamicsInstanceUrl $DynamicsInstanceUrl

$user = Build-SystemApplicationUser -ClientId $AppUserClientId -FirstName $AppUserFirstName -LastName $AppUserLastName -UserName $AppUserEmail

$currentRoles =  Get-CrmUserSecurityRoles -UserId $user.ReturnProperty_Id

if(
    $null -eq $currentRoles -or 
    (
        ($currentRoles.GetType().Name -eq "PSCustomObject" -and $currentRoles.RoleName -ne $AppUserRoleName) -or
        !(($currentRoles).RoleName -contains $AppUserRoleName)
    )
)
{
    Write-Host "Adding Application User to specified Dynamics Role: $AppUserRoleName"
    Add-CrmSecurityRoleToUser -UserId $user.ReturnProperty_Id -SecurityRoleName $AppUserRoleName
    Write-Verbose -Message "Successfully added Application User to specified Dynamics Role: $AppUserRoleName"
}
else {
    Write-Host "Application User is already a member of the specified Dynamics Role: $AppUserRoleName"
}

Remove-Module -Name "dynamics"
Remove-Module -Name "common"