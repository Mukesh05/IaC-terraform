param(
    $aadObjectId,
    $aadGroupName,
    $dbServer,
    $dbName,
    $dbRoleName,
    $sqlToken
)

Write-Verbose "Get SID"
$objId=$aadObjectId.Trim('"')
function ConvertTo-Sid {
    param (
    [string]$objectId
    )

    [guid]$guid = [System.Guid]::Parse($objectId)
    foreach ($byte in $guid.ToByteArray()) {
        $byteGuid += [System.String]::Format("{0:X2}", $byte)
    }
    return "0x" + $byteGuid
}

$SID=ConvertTo-Sid($objId)

Write-Verbose "Create SQL connectionstring"

$conn = New-Object System.Data.SqlClient.SQLConnection
$conn.ConnectionString = "Server=$dbServer;Initial Catalog=$dbName;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30"
$conn.AccessToken = $sqlToken
Write-Verbose "Connect to database and execute SQL script"
$conn.Open()
$query = "IF NOT EXISTS (SELECT [name]
    FROM [sys].[database_principals]
    WHERE [type] = N'X' AND [name] = N'$aadGroupName')
    BEGIN
    CREATE USER [$aadGroupName] WITH DEFAULT_SCHEMA=[dbo], SID = $SID, TYPE= X;
    ALTER ROLE [$dbRoleName] ADD MEMBER [$aadGroupName];
    END
    IF NOT EXISTS (
        SELECT DP1.name AS DatabaseRoleName,   
        isnull (DP2.name, 'No members') AS DatabaseUserName   
        FROM sys.database_role_members AS DRM  
        RIGHT OUTER JOIN sys.database_principals AS DP1  
        ON DRM.role_principal_id = DP1.principal_id  
        LEFT OUTER JOIN sys.database_principals AS DP2  
        ON DRM.member_principal_id = DP2.principal_id  
        WHERE DP1.type = N'R' AND DP1.name =N'$dbRoleName' AND DP2.name = N'$aadGroupName' AND DP2.type=N'X'
    )
    BEGIN
    ALTER ROLE [$dbRoleName] ADD MEMBER [$aadGroupName];
    END
"
Write-Host $query
$command = New-Object -TypeName System.Data.SqlClient.SqlCommand($query, $conn)
$Result = $command.ExecuteNonQuery()
$conn.Close()