[CmdletBinding()]
param (
    [string]
    $KeyVaultName,
    [string]
    $KeyVaultSecretName,
    [string]
    $PipelineSecretName,
    $modulesPath
)

Import-Module -Name "$modulesPath/common.psm1"

$secret = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name $KeyVaultSecretName -AsPlainText

Write-AzureDevOpsPipelineVariable -variableName $PipelineSecretName -variableValue $secret -isSecret $true

Remove-Module -Name "common"