﻿if(!$env:PAT) {
    Write-Host "No PAT Token is stored for use in this script. "
    Write-Host "Create an Azure DevOps PAT and set an environment variable"
    Write-Host 'e.g. $env:PAT="xxxxxxxxxxxxxxxxxxxxxxxxxxx" '
    exit
}

Write-Output "Generating report."

 $Tenant = "newsigcode"
 $Project = "Engineering"
 $TeamName = "Platform"
 $Queries = @(
     [PSCustomObject]@{
         Id = "79e86956-e4a9-4d2a-b940-901a871aeea1";
         Name = "Platform - Bugs closed this week";
     },
     [PSCustomObject]@{
         Id = "64161c16-e474-4007-b4da-62af1066d459";
         Name = "Platform - Features & Stories closed this week";
     },
     [PSCustomObject]@{
         Id = "91e6737e-32da-4fd7-9ded-7e973d51f03e";
         Name = "Platform - Currently Doing";
     },
     [PSCustomObject]@{
         Id = "b6772589-c600-40f7-92ed-40992d8d4907";
         Name = "Platform - Features transitioned to Solution Design this week";
     }
 )

#$reportName = "{0}-{1}.md" -f $TeamName, ((Get-Date).ToString("yyyy-MMM-dd"))
~\code\engineering\Markdown_Reports\Scripts\Get-AzDoQueryResults.ps1 -AzureDevOpsPAT $($env:PAT) `
                                                                    -Tenant $Tenant `
                                                                    -Project $Project `
                                                                    -Queries $Queries `
                                                                    -TeamName $TeamName `
                                                                    -Title $Title
