﻿if(!$env:PAT) {
    Write-Host "No PAT Token is stored for use in this script. "
    Write-Host "Create an Azure DevOps PAT and set an environment variable"
    Write-Host 'e.g. $env:PAT="xxxxxxxxxxxxxxxxxxxxxxxxxxx" '
    exit
}

Write-Output "Generating reports."

function Get-PrintableTeamName() {
    [CmdLetBinding()]
    param (
        [string]$Project,
        [string]$TeamName
    )

    $PrintableTeamName = $TeamName

    if ([String]::IsNullOrEmpty($TeamName)) {
        $PrintableTeamName = "$($Project) Team"
    }

    return $PrintableTeamName
}

$Tenant = "newsigcode"
$Project = "Engineering"
$TeamName = "Platform"
$Queries = @(
    [PSCustomObject]@{
        Id = "79e86956-e4a9-4d2a-b940-901a871aeea1";
        Name = "Platform - Bugs closed this week";
    },
    [PSCustomObject]@{
        Id = "64161c16-e474-4007-b4da-62af1066d459";
        Name = "Platform - Features & Stories closed this week";
    },
    [PSCustomObject]@{
        Id = "91e6737e-32da-4fd7-9ded-7e973d51f03e";
        Name = "Platform - Currently Doing";
    },
    [PSCustomObject]@{
        Id = "b6772589-c600-40f7-92ed-40992d8d4907";
        Name = "Platform - Features transitioned to Solution Design this week";
    }
)

$PrintableTeamName = Get-PrintableTeamName -Project $Project -TeamName $TeamName
$reportName = "{0} - {1}" -f $Project, $PrintableTeamName
$Title = $reportName
$OutputFile = Join-Path -Path 'c:\temp\pw-reports\' -ChildPath "$($Title) - $((Get-Date).ToString("yyyy-MMM-dd")).md"

~\code\engineering\Markdown_Reports\Scripts\Get-AzDoQueryResults.ps1 -AzureDevOpsPAT $($env:PAT) `
                                                                    -Tenant $Tenant `
                                                                    -Project $Project `
                                                                    -Queries $Queries `
                                                                    -TeamName $TeamName `
                                                                    -Title $Title `
                                                                    -OutputFile $OutputFile

#

$Tenant = "newsigcode"
$Project = "Engineering"
$TeamName = "Strategy"
$Queries = @(
    [PSCustomObject]@{
        Id = "3a421291-ce90-46b0-a956-0d138ff686d5";
        Name = "Strategy - closed this week features and stories";
    },
    [PSCustomObject]@{
        Id = "f67279ec-7e1c-47ac-ae09-99b89cf2be1a";
        Name = "Strategy - currently doing";
    },
    [PSCustomObject]@{
        Id = "004da2b8-cfb6-43f1-b9b7-8189b23ee112";
        Name = "features transitioned to Discovery this week";
    }
)

$PrintableTeamName = Get-PrintableTeamName -Project $Project -TeamName $TeamName
$reportName = "{0} - {1}" -f $Project, $PrintableTeamName
$Title = $reportName
$OutputFile = Join-Path -Path 'c:\temp\pw-reports\' -ChildPath "$($Title) - $((Get-Date).ToString("yyyy-MMM-dd")).md"

~\code\engineering\Markdown_Reports\Scripts\Get-AzDoQueryResults.ps1 -AzureDevOpsPAT $($env:PAT) `
                                                                    -Tenant $Tenant `
                                                                    -Project $Project `
                                                                    -Queries $Queries `
                                                                    -TeamName $TeamName `
                                                                    -Title $Title `
                                                                    -OutputFile $OutputFile
#

$Tenant = "newsigcode"
$Project = "Engineering"
$TeamName = "Business Reporting"
$Queries = @(
    [PSCustomObject]@{
        Id = "205aa6cd-dd53-4bdd-b94b-667075868e12";
        Name = "Business Reporting - Bugs Closed this week";
    },
    [PSCustomObject]@{
        Id = "2244ae2e-60e9-4c00-8c25-c39a357ec6ee";
        Name = "Business Reporting - Features Delivered this week";
    },
    [PSCustomObject]@{
        Id = "b4829975-11b5-4691-8cdc-3bc8b4ec1c56";
        Name = "Business Reporting - Features In Development this week";
    },
    [PSCustomObject]@{
        Id = "1d0f39fc-509a-4304-9ea2-942e19ad774a";
        Name = "Business Reporting - Epics and Features lacking descriptions";
    }
)

$PrintableTeamName = Get-PrintableTeamName -Project $Project -TeamName $TeamName
$reportName = "{0} - {1}" -f $Project, $PrintableTeamName
$Title = $reportName
$OutputFile = Join-Path -Path 'c:\temp\pw-reports\' -ChildPath "$($Title) - $((Get-Date).ToString("yyyy-MMM-dd")).md"

~\code\engineering\Markdown_Reports\Scripts\Get-AzDoQueryResults.ps1 -AzureDevOpsPAT $($env:PAT) `
                                                                    -Tenant $Tenant `
                                                                    -Project $Project `
                                                                    -Queries $Queries `
                                                                    -TeamName $TeamName `
                                                                    -Title $Title `
                                                                    -OutputFile $OutputFile
#

$Tenant = "newsigcode"
$Project = "Engineering"
$TeamName = "Business Systems"
$Queries = @(
    [PSCustomObject]@{
        Id = "f6f4b282-4715-4e52-b8af-62c409f593b9";
        Name = "Business Systems - Bugs closed this week";
    },
    [PSCustomObject]@{
        Id = "19fe5df3-fd0b-4de9-8ed9-f8ce0b5280c5";
        Name = "Business Systems - Features & Stories & Tasks closed this week";
    },
    [PSCustomObject]@{
        Id = "37ab455a-cc31-448a-a57f-1258d4b774f1";
        Name = "Business Systems - Currently Doing";
    },
    [PSCustomObject]@{
        Id = "068542a9-1620-4fed-85cb-3a6e2103f74c";
        Name = "Business Systems - Epics and Features lacking descriptions";
    }
)

$PrintableTeamName = Get-PrintableTeamName -Project $Project -TeamName $TeamName
$reportName = "{0} - {1}" -f $Project, $PrintableTeamName
$Title = $reportName
$OutputFile = Join-Path -Path 'c:\temp\pw-reports\' -ChildPath "$($Title) - $((Get-Date).ToString("yyyy-MMM-dd")).md"

~\code\engineering\Markdown_Reports\Scripts\Get-AzDoQueryResults.ps1 -AzureDevOpsPAT $($env:PAT) `
                                                                    -Tenant $Tenant `
                                                                    -Project $Project `
                                                                    -Queries $Queries `
                                                                    -TeamName $TeamName `
                                                                    -Title $Title `
                                                                    -OutputFile $OutputFile

#

$Tenant = "newsigcode"
$Project = "Engineering"
$TeamName = "ServiceNow"
$Queries = @(
    [PSCustomObject]@{
        Id = "339fbd3e-daca-4597-b64c-e6a4eac55043"
        Name = "ServiceNow - Bugs closed this week";
    },
    [PSCustomObject]@{
        Id = "dd88b398-df75-450c-b478-e4a7ac15cd5c"
        Name = "ServiceNow - Features & Stories closed this week";
    },
    [PSCustomObject]@{
        Id = "43ff2125-205d-43a4-824d-d2912cc56646"
        Name = "ServiceNow - Currently Doing";
    },
    [PSCustomObject]@{
        Id = "a61deab5-00a1-4194-8792-4cf82cf4d05d"
        Name = "ServiceNow - Features transitioned to Solution Design this week"
    }
)

$PrintableTeamName = Get-PrintableTeamName -Project $Project -TeamName $TeamName
$reportName = "{0} - {1}" -f $Project, $PrintableTeamName
$Title = $reportName
$OutputFile = Join-Path -Path 'c:\temp\pw-reports\' -ChildPath "$($Title) - $((Get-Date).ToString("yyyy-MMM-dd")).md"

~\code\engineering\Markdown_Reports\Scripts\Get-AzDoQueryResults.ps1 -AzureDevOpsPAT $($env:PAT) `
                                                                    -Tenant $Tenant `
                                                                    -Project $Project `
                                                                    -Queries $Queries `
                                                                    -TeamName $TeamName `
                                                                    -Title $Title `
                                                                    -OutputFile $OutputFile

#

$Tenant = "newsigcode"
$Project = "Engineering"
$Title = "Weekly Report"
$TeamName = "MBG Technical Integration"
$Queries = @(
    [PSCustomObject]@{
        Id = "758cf77f-4dd4-4a61-bfe5-00dcd1c3b721";
        Name = "MBG - Bugs closed this week";
    },
    [PSCustomObject]@{
        Id = "35df7d6e-6716-4955-83e3-6365c57e8b6a";
        Name = "MBG - Currently doing tree";
    },
    [PSCustomObject]@{
        Id = "29023f9e-5920-4734-afb2-7c03921496e9";
        Name = "MBG - Features & Stories closed this week";
    }
)

$PrintableTeamName = Get-PrintableTeamName -Project $Project -TeamName $TeamName
$reportName = "{0} - {1}" -f $Project, $PrintableTeamName
$Title = $reportName
$OutputFile = Join-Path -Path 'c:\temp\pw-reports\' -ChildPath "$($Title) - $((Get-Date).ToString("yyyy-MMM-dd")).md"

~\code\engineering\Markdown_Reports\Scripts\Get-AzDoQueryResults.ps1 -AzureDevOpsPAT $($env:PAT) `
                                                                    -Tenant $Tenant `
                                                                    -Project $Project `
                                                                    -Queries $Queries `
                                                                    -TeamName $TeamName `
                                                                    -Title $Title `
                                                                    -OutputFile $OutputFile

#

$Tenant = "newsigcode"
$Project = "IT Operations"
$Title = "Operations Report"
$TeamName = ""
$Queries = @(
    [PSCustomObject]@{
        Id = "4629c585-5d19-4087-9587-83e0d6ba5575";
        Name = "Closed this week - IT Ops";
    },
    [PSCustomObject]@{
        Id = "b6531e0c-e869-4a27-8034-b4c980688407";
        Name = "Currently Doing - IT Operations";
    },
    [PSCustomObject]@{
        Id = "b60c3530-dfea-4109-b3ec-0e61a3c49c2e";
        Name = "Blocked - IT Operations";
    }
)

$PrintableTeamName = Get-PrintableTeamName -Project $Project -TeamName $TeamName
$reportName = "{0} - {1}" -f $Project, $PrintableTeamName
$Title = $reportName
$OutputFile = Join-Path -Path 'c:\temp\pw-reports\' -ChildPath "$($Title) - $((Get-Date).ToString("yyyy-MMM-dd")).md"


~\code\engineering\Markdown_Reports\Scripts\Get-AzDoQueryResults.ps1 -AzureDevOpsPAT $($env:PAT) `
                                                                    -Tenant $Tenant `
                                                                    -Project $Project `
                                                                    -Queries $Queries `
                                                                    -TeamName $TeamName `
                                                                    -Title $Title `
                                                                    -OutputFile $OutputFile

#

$Tenant = "newsigcode"
$Project = "IT Operations"
$Title = "Operations Integration Report"
$TeamName = "IT Ops Integration"
$Queries = @(
    [PSCustomObject]@{
      Id = "5e41fff1-02a6-4251-9187-5d12e588b9bf";
      Name = "Blocked - IT Operations Integration";
    },
    [PSCustomObject]@{
        Id = "d7de191d-9686-4f25-8c0e-f0c2e9c71ba9";
        Name = "Currently Doing - IT Operations Integration";
    },
    [PSCustomObject]@{
        Id = "2f0d7394-060e-4044-a2d4-0b5eef50fec6";
        Name = "Features Closed this week - IT Ops Integration";
    },
    [PSCustomObject]@{
        Id = "fa9bb793-76e4-4d5c-82d7-c74cacad03ec";
        Name = "Stories Closed this week - IT Ops Integration";
    },
    [PSCustomObject]@{
        Id = "73b76198-caf5-47d2-9125-f78448ddf1cb";
        Name = "Tasks Closed this Week - IT Ops Integration";
    }
)

$PrintableTeamName = Get-PrintableTeamName -Project $Project -TeamName $TeamName
$reportName = "{0} - {1}" -f $Project, $PrintableTeamName
$Title = $reportName
$OutputFile = Join-Path -Path 'c:\temp\pw-reports\' -ChildPath "$($Title) - $((Get-Date).ToString("yyyy-MMM-dd")).md"
  
~\code\engineering\Markdown_Reports\Scripts\Get-AzDoQueryResults.ps1 -AzureDevOpsPAT $($env:PAT) `
                                                                    -Tenant $Tenant `
                                                                    -Project $Project `
                                                                    -Queries $Queries `
                                                                    -TeamName $TeamName `
                                                                    -Title $Title `
                                                                    -OutputFile $OutputFile

#

$Tenant = "newsigcode"
$Project = "IT Operations"
$Title = "Projects Report"
$TeamName = "IT Ops Projects"
$Queries = @(
    [PSCustomObject]@{
      Id = "891ea4ac-37f1-42ce-b280-72a12faed31c";
      Name = "Blocked - IT Ops Projects";
    },
    [PSCustomObject]@{
        Id = "9a3669c7-bfee-4546-9feb-373a77896328";
        Name = "Currently Doing - IT Ops Projects";
    },
    [PSCustomObject]@{
        Id = "89061c83-4806-457b-ab2b-a8fa42c5cd38";
        Name = "Features Closed this week - IT Ops Projects";
    },
    [PSCustomObject]@{
        Id = "16379ad5-7473-4818-83c8-a46fb05070a1";
        Name = "Stories Closed this week - IT Ops Projects";
    },
    [PSCustomObject]@{
        Id = "33d445af-78dc-4de5-83e4-a2753e6ca026";
        Name = "Tasks Closed this Week - IT Ops Projects";
    }
)

$PrintableTeamName = Get-PrintableTeamName -Project $Project -TeamName $TeamName
$reportName = "{0} - {1}" -f $Project, $PrintableTeamName
$Title = $reportName
$OutputFile = Join-Path -Path 'c:\temp\pw-reports\' -ChildPath "$($Title) - $((Get-Date).ToString("yyyy-MMM-dd")).md"
 
~\code\engineering\Markdown_Reports\Scripts\Get-AzDoQueryResults.ps1 -AzureDevOpsPAT $($env:PAT) `
                                                                    -Tenant $Tenant `
                                                                    -Project $Project `
                                                                    -Queries $Queries `
                                                                    -TeamName $TeamName `
                                                                    -Title $Title `
                                                                    -OutputFile $OutputFile

#

$Tenant = "newsigcode"
$Project = "GMS Reporting"
$Title = "Weekly Report"
$TeamName = ""
$Queries = @(
    [PSCustomObject]@{
        Id = "fa484f8b-07d6-4ccd-8bfb-f9f7544406b7";
        Name = "Currently Doing - GMS Reporting";
    },
    [PSCustomObject]@{
        Id = "2d66ad13-b3ee-45ad-bda8-64348e73e696";
        Name = "GMS Reporting - Issues and Tasks closed this week";
    },
    [PSCustomObject]@{
        Id = "b771e316-1554-4f64-800c-74de96f3786a";
        Name = "GMS Reporting - Issues and Tasks started this week";
    }
)

$PrintableTeamName = Get-PrintableTeamName -Project $Project -TeamName $TeamName
$reportName = "{0} - {1}" -f $Project, $PrintableTeamName
$Title = $reportName
$OutputFile = Join-Path -Path 'c:\temp\pw-reports\' -ChildPath "$($Title) - $((Get-Date).ToString("yyyy-MMM-dd")).md"

~\code\engineering\Markdown_Reports\Scripts\Get-AzDoQueryResults.ps1 -AzureDevOpsPAT $($env:PAT) `
                                                                    -Tenant $Tenant `
                                                                    -Project $Project `
                                                                    -Queries $Queries `
                                                                    -TeamName $TeamName `
                                                                    -Title $Title `
                                                                    -OutputFile $OutputFile

#

$Tenant = "newsigcode"
$Project = "REMI BPR"
$Title = "Weekly Report"
$TeamName = $null
$Queries = @(

      [PSCustomObject]@{
        Id = "b7aafb5c-15f9-4ec3-aa7e-0c12266a451c";
        Name = "REMI BPR - Active (includes proposed, not closed)";
      },
      [PSCustomObject]@{
        Id = "f870b9bf-6322-431a-8f42-1290a6ebdfe4";
        Name = "REMI BPR - Blockers - REMI Only";
      },
      [PSCustomObject]@{
        Id = "63abc214-7689-4dc6-ba80-5b096c771ccd";
        Name = "REMI BPR - Currently Doing";
      },
      [PSCustomObject]@{
        Id = "ebcd446a-e39a-4db2-8423-aa38eb8de88b";
        Name = "REMI BPR - Due next sprint";
      },
      [PSCustomObject]@{
        Id = "43574a82-0211-43eb-80a7-1074241e997c";
        Name = "REMI BPR - Due this sprint";
      },
      [PSCustomObject]@{
        Id = "eece95f1-663e-476d-9c24-d5ee2545a762";
        Name = "REMI BPR - Overdue";
      },
      [PSCustomObject]@{
        Id = "3e9b2ebd-6522-4b64-9114-d6c37ca05c22";
        Name = "REMI BPR - Stories (Issues) Closed this Week";
      },
      [PSCustomObject]@{
        Id = "a649a346-7c75-43c8-8d88-63a771f5583a";
        Name = "REMI BPR - Stories (Issues) Started this Week";
      },
      [PSCustomObject]@{
        Id = "ebd1f34c-6a79-4ca9-989b-1c7caf4dac0c";
        Name = "REMI BPR - Tasks Closed this Week";
      },
      [PSCustomObject]@{
        Id = "34073800-2698-4913-adc5-f5581546d248";
        Name = "REMI BPR - Tasks Started this Week";
      }
)

$PrintableTeamName = Get-PrintableTeamName -Project $Project -TeamName $TeamName
$reportName = "{0} - {1}" -f $Project, $PrintableTeamName
$Title = $reportName
$OutputFile = Join-Path -Path 'c:\temp\pw-reports\' -ChildPath "$($Title) - $((Get-Date).ToString("yyyy-MMM-dd")).md"

~\code\engineering\Markdown_Reports\Scripts\Get-AzDoQueryResults.ps1 -AzureDevOpsPAT $($env:PAT) `
                                                                    -Tenant $Tenant `
                                                                    -Project $Project `
                                                                    -Queries $Queries `
                                                                    -TeamName $TeamName `
                                                                    -Title $Title `
                                                                    -OutputFile $OutputFile

#

Write-Output "All Reports Written."
