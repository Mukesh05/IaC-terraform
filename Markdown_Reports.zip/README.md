# Markdown Reporting

[[_TOC_]]

## Introduction

This project is a set of scripts and configuration that generate weekly reports based on queries in Azure DevOps

## Getting Started

Checkout the code and load the folder into VSCode to edit

## Permissions Required

The build account can be used provided it has permissions across devops to update wikis and execute work item queries and OData queries. This is done as follows:

``` YAML
  env:
    SYSTEM_ACCESSTOKEN: $(System.AccessToken)
```

If this account doesn't have sufficient permissions, a user with enough access must create a [Personal Access Token (PAT)](https://docs.microsoft.com/en-us/azure/devops/organizations/accounts/use-personal-access-tokens-to-authenticate?view=azure-devops&tabs=preview-page) with the following rights for all projects that reports will be generated for:
- Work Items - **Read**
- Wiki - **Read &amp; Write**
- Analytics - **Read**

Use this token directly in the release with $(PAT) since it is a secret value.

### Requests used are below:
```
"https://dev.azure.com/{0}/{1}/_apis/wiki/wikis/?api-version=5.1"
"https://dev.azure.com/{0}/{1}/_apis/wiki/wikis/{2}/pages?api-version=5.1&path={3}&includecontent=true"
"https://dev.azure.com/{0}/{1}/_apis/wiki/wikis/{2}/pages?api-version=5.1&path={3}"

"https://dev.azure.com/{0}/{1}/_apis/wit/wiql/{2}?api-version=5.1"

"https://analytics.dev.azure.com/{0}/{1}/_odata/v3.0-preview/Iterations?`$filter={2}&`$select={3}"
```

## Build and Test

This code runs in a pipeline (see below):
https://dev.azure.com/newsigcode/DriveTrain/_build?definitionId=225&_a=summary

## Contribute

Adding new reports is easy. Find the report details you need by project and use the guid in the query uri to reference it.
