function Get-AzDoWikiName {
    param (
        [string]$AuthString,
        [string]$Tenant,
        [string]$Project
    )

    $Header = @{
        Authorization = $AuthString; 
        "content-type" = "application/json" 
    }

    $uri = "https://dev.azure.com/{0}/{1}/_apis/wiki/wikis/?api-version=5.1" -f $Tenant, $Project
    
    $body = Invoke-RestMethod -Headers $Header `
                              -Method GET `
                              -Uri $uri `
                              -ResponseHeadersVariable responseHeaders

    $body.value[0].name
}

function Get-AzDoWikiPage {
    Param(
        [string]$AuthString,
        [string]$Tenant,
        [string]$Project,
        [string]$WikiName,
        [string]$Path
    )

    $Header = @{
        Authorization = $AuthString; 
        "content-type" = "application/json" 
    }

    $uri = "https://dev.azure.com/{0}/{1}/_apis/wiki/wikis/{2}/pages?api-version=5.1&path={3}&includecontent=true" -f $Tenant, $Project, $WikiName, $Path
    
    $body = Invoke-RestMethod -Headers $Header `
                                -Method GET `
                                -Uri $uri `
                                -ResponseHeadersVariable responseHeaders

    #eTag is needed to update an existing page which is not documented. The eTag
    #is to be added to the request header as If-Match.
    $etag = [string]$responseHeaders["ETag"][0]
    $body | Add-Member NoteProperty 'eTag' $etag

    Write-Host ("Page path : {0}, Page id : {1}, page Etag : {2}" -f $path, $body.id, $body.eTag )

    $body
}

function Add-AzDoWikiPageContent {
    param (
        [string]$AuthString,
        [string]$Tenant,
        [string]$Project,
        [psobject]$WikiPage,
        [psobject]$MarkDown
    )

    $Header = @{
        Authorization = $AuthString; 
        "content-type" = "application/json";
        "If-Match" = $WikiPage.eTag
    }

    $uri = "{0}?api-version=5.1" -f $WikiPage.url
    
    $requestBody = [PSCustomObject]@{
        content = $MarkDown
    } | ConvertTo-Json

    $result = Invoke-RestMethod -Headers $Header -Method Put -Uri $uri -Body $requestBody
    Write-Host $result
}

function Add-AzDoWikiPages {
    param (
        [string]$AuthString,
        [string]$Tenant,
        [string]$Project,
        [string]$WikiName,
        [string]$Path
    )

    $Header = @{
        Authorization = $AuthString; 
        "content-type" = "application/json" 
    }

    #Loop through every page in the path and create if it doesn't exist.
    $pages = $path.Split('/');
    $currentPath = "";
    foreach($page in $pages){
        
        if($page -eq ""){
            continue;
        }
        
        $currentPath += "/";
        $currentPath += $page;
        $encodedPath = [uri]::EscapeDataString($currentPath)
    
        Write-Host "Verifying sub-page :  $currentPath"

        $uri = "https://dev.azure.com/{0}/{1}/_apis/wiki/wikis/{2}/pages?api-version=5.1&path={3}" -f $Tenant, $Project, $WikiName, $encodedPath
        
        try {

            Invoke-RestMethod -Headers $Header -Method GET -Uri $uri | Out-Null
            Write-Host "Wike page $currentPath exists."

        }
        catch {

            if($_.Exception.Response.StatusCode = 404){

                Write-Host "Wiki page $currentPath does not exist. Creating a new page ..."
                Invoke-RestMethod -Headers $Header -Method PUT -Uri $uri | Out-Null
                Write-Host "$currentPath wiki page was created.";
            
            }
            else {
                throw
            }
        }
    }    
}

function Add-AzDoWikiContent {
    param (
        [string]$AuthString,
        [string]$Tenant,
        [string]$Project,
        [string]$Path,
        [psobject]$MarkDown
    )

    $wikiName = Get-AzDoWikiName -AuthString $AuthString -Tenant $Tenant -Project $Project
    Write-Host ("Retrieved wiki name : {0}" -f $wikiName)

    Add-AzDoWikiPages -AuthString $AuthString -Tenant $Tenant -Project $Project -WikiName $wikiName -path $Path
    $wikiPage = Get-AzDoWikiPage -AuthString $AuthString -Tenant $Tenant -Project $Project -WikiName $wikiName -Path $Path
    Add-AzDoWikiPageContent -AuthString $AuthString -Tenant $Tenant -Project $Project -WikiPage $wikiPage -Path $Path -MarkDown $MarkDown
}