Add-Type -Language CSharp -ErrorAction SilentlyContinue -WarningAction SilentlyContinue @"
namespace Tools.Powershell 
{
    using System; 
    using System.Text;

    public static class Converter 
    {
        public static string ConvertUnicodeStringToAsciiString(string UnicodeString)
        {
            Encoding ascii = Encoding.ASCII;
            Encoding unicode = Encoding.Unicode;

            // Convertsion happen via a byte array.
            byte[] unicodeBytes = unicode.GetBytes(UnicodeString);

            // Perform the conversion from one encoding to the other.
            byte[] asciiBytes = Encoding.Convert(unicode, ascii, unicodeBytes);
            char[] asciiChars = new char[ascii.GetCharCount(asciiBytes, 0, asciiBytes.Length)];
            ascii.GetChars(asciiBytes, 0, asciiBytes.Length, asciiChars, 0);
            string asciiString = new string(asciiChars);
            return asciiString;
        }
    }
}
"@;

Function Convert-UnicodeStringToAscii
{
    [CmdletBinding()]
    param (
        [Parameter()]
        [String]
        $InputString
    )

    return [Tools.Powershell.Converter]::ConvertUnicodeStringToAsciiString($InputString)
}

# Convert-UnicodeStringToAscii -InputString "“hello - -  “ there -   "