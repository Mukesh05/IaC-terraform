﻿[CmdletBinding()]
Param(
    [string]$AzureDevOpsPAT = $env:PAT,
    [string]$AzureDevOpsJWT = $env:SYSTEM_ACCESSTOKEN,
    $Tenant = "newsigcode",
    $Project = "IT Operations",
    $TeamName = $null,
    $Queries = @(
        [PSCustomObject]@{
            Id = "4629c585-5d19-4087-9587-83e0d6ba5575";
            Name = "Closed this week - IT Ops";
        },
        [PSCustomObject]@{
            Id = "9a3669c7-bfee-4546-9feb-373a77896328";
            Name = "Currently Doing - IT Operations";
        }
    ),
    [string]$Title = "$($TeamName) Report",
    [string]$OutputFile = $null,
    [string]$Sprint = "Sprint Not Found"
)

Add-Type -Assembly System.Web
. ("Scripts\AzDoWikiFunctions.ps1")
. ("Scripts\Convert-UnicodeStringToAscii.ps1")

function Get-AzDoWorkItem()
{
    param(
        $Ref,
        $Header
    )

    $uri = ("$Ref{0}" -f '?$expand=relations')

    $body = Invoke-RestMethod -Headers $Header `
                              -Method GET `
                              -Uri $uri

    $parentItems =  $body.relations | Where-Object { $_.Attributes.Name -eq "Parent" }
    $parentHref = $null
    if($parentItems) {
        $parentHref = $parentItems.url |Select-Object -First 1
    }

    $item = [PSCustomObject]@{
        id = $body.id;
        type = $body.fields.'System.WorkItemType';
        title = $body.fields.'System.Title';
        state = $body.fields."System.State"
        parentId = ($parentItems | ForEach-Object { ($_.url -split '/') |Select-Object -Last 1 });
        parentHref = $parentHref
    }

    return $item
}

function Get-AzDoWorkItemQueryResults
{
    [CmdletBinding()]
    Param(
        [string]$AuthString,
        [string]$Tenant,
        [string]$Project,
        [string]$QueryId
    )

    $AzureDevOpsAuthenicationHeader = @{
            "Authorization" = $AuthString;
            "content-type" = "application/json"
        }

    $encodedProjectName = [uri]::EscapeDataString($Project)

    $uri = "https://dev.azure.com/{0}/{1}/_apis/wit/wiql/{2}?api-version=5.1" -f $Tenant, $encodedProjectName, $QueryId

    $tickets = New-Object -TypeName 'System.Collections.Hashtable'

    try {
        $body = Invoke-RestMethod -Headers $AzureDevOpsAuthenicationHeader `
                                  -Method GET `
                                  -Uri $uri

        if ($body.queryType -eq 'flat') {

            foreach ($wi in $body.workItems) {
                $ticket = Get-AzDoWorkItem -ref $wi.url `
                                           -header $AzureDevOpsAuthenicationHeader

                $tickets.Add($wi.id, $ticket) | Out-Null
            }
        }

        if ($body.queryType -eq 'tree') {
            foreach($item in $body.workItemRelations) {
                $wi = $item.target
                $ticket = Get-AzDoWorkItem -ref $wi.url `
                                           -Header $AzureDevOpsAuthenicationHeader

                $tickets.Add($wi.id, $ticket) | Out-Null
            }
        }

        # set a dummy value to ensure no match when we see a real ticket
        $lastParent = -1

        $tickets.Values | Sort-Object -Property parentId,id | ForEach-Object {
            if (($null -ne $_.parentId) -and ($lastParent -ne $_.parentId)) {
                $parentDetail = Get-AzDoWorkItem -ref $_.parentHref -header $AzureDevOpsAuthenicationHeader
                $filteredParentTitle = Convert-UnicodeStringToAscii -InputString $parentDetail.title
                Write-Output ( "* {0} **{1}** `"{2}`"" -f $parentDetail.type,$parentDetail.id,$filteredParentTitle )
                $lastParent = $_.parentId
            }

            $filteredTitle = Convert-UnicodeStringToAscii -InputString $_.Title

            Write-Output ("  * {0} **{1}** `"{2}`" `"{3}`"" -f $_.type,$_.id,$filteredTitle,$_.state)
        }
    }
    catch {
        Write-Host "Query $($QueryId) Execution failed with StatusCode: $($_.Exception.Response.StatusCode)"
    }
}

function Write-AzDoQueryReport {
    [CmdletBinding()]
    Param(
        [string]$AuthString,
        [string]$Tenant,
        [string]$Project,
        [System.Object[]]$Queries,
        [string]$Title,
        [string]$Sprint,
        [string]$TeamName
    )

    # Write Header
    #Write-Output ( "# {0} - {1} ({2} - {3})" -f $Title, $Sprint, ((Get-Date).AddDays(-7)).ToString('dd-MMM-yyyy'), (Get-Date).ToString('dd-MMM-yyyy'))
    $output = ("# {0} - {1} ({2} - {3})" -f $Title, $Sprint, ((Get-Date).AddDays(-7)).ToString('dd-MMM-yyyy'), (Get-Date).ToString('dd-MMM-yyyy'))
    $output += "`n[[_TOC_]]`n"
    $output += "`n"

    # Assemble the query results into sub-section groups of data and output
    $Queries | ForEach-Object {

        #Write-Output ("## {0}" -f $_.Name)
        $output += "## {0}" -f $_.Name;
        $output += "`n"

        $results = Get-AzDoWorkItemQueryResults -AuthString $AuthString `
                                                -Tenant $Tenant `
                                                -Project $Project `
                                                -QueryId $_.Id

        if([String]::IsNullOrEmpty($results))
        {
            #Write-Output "* No items"
            $output += "* No items"
            $output += "`n"
        }
        else
        {
            #Write-Output $results
            $output += ($results -join "`n")
            $output += "`n"
        }
    }

    <#
        Set the path to the structure of the wiki pages/sub-pages required.
        Pages/sub-pages will be created if they don't already exist.
        Use alpha month identifier to prevent issues with USA/Rest of World
        mm/dd dd/mm conflict
    #>
    $currentDate = Get-Date -format "dd-MMM-yyyy";
 
    $PrintableTeamName = Get-PrintableTeamName -Project $Project -TeamName $TeamName 

    $path = "/Weekly Reports/$currentDate/$PrintableTeamName";

    # detect local run and don't update the wikis, just show the results
    if(!$env:BUILD_ARTIFACTSTAGINGDIRECTORY) {
        $output
    } else {
        Add-AzDoWikiContent -AuthString $AuthString -Tenant $Tenant -Project $Project -Path $path -MarkDown $output
    }
}

function Get-AzDoSprintIteration
{
    [CmdletBinding()]
    Param(
        [string]$AuthString,
        [string]$Tenant,
        [string]$Project,
        [string]$TeamName
    )

    $iterationName = $null

    $Header = @{
        Authorization = $AuthString;
        "content-type" = "application/json"
    }

    # if the project has multiple teams - get the given team's iteration name
    $today = (get-date).tostring("yyyy-MM-ddT00:00:00Z")
    $oDataQuery = "StartDate le {0} and EndDate ge {1} and IterationLevel2 eq '{2}'" -f $today, $today, $TeamName
    $oDataFilter = "IterationName,StartDate,EndDate,IterationPath"

    # if the project has only one team use this query instead
    if ([string]::IsNullOrEmpty($TeamName)){
        $oDataQuery = "StartDate le {0} and EndDate ge {1}" -f $today, $today
    }

    $encodedODataQuery = [uri]::EscapeUriString($oDataQuery)
    $encodedODataFilter = [uri]::EscapeUriString($oDataFilter)
    $encodedProject = [uri]::EscapeUriString($Project)

    $uri = "https://analytics.dev.azure.com/{0}/{1}/_odata/v3.0-preview/Iterations?`$filter={2}&`$select={3}" -f `
            $Tenant, $encodedProject, $encodedODataQuery, $encodedODataFilter

    #Write-Host "query: $($uri)"
    $body = Invoke-RestMethod -Headers $Header `
                                -Method GET `
                                -Uri $uri
    $value = $body.value

    if($value -is [array]){
        $iterationName = $body.value[0].IterationName
    } else {
        $iterationName = $body.value.IterationName
    }

    return $iterationName
}

function Get-Title() {
    [CmdLetBinding()]
    param (
        [string]$Title,
        [string]$Project,
        [string]$TeamName
    )
    # Fix Title if TeamName is $null indicating Default Team
    if(([String]::IsNullOrEmpty($TeamName))) {
        $Title = "$($Project) Team Report"
    }

    return $Title
}

function Get-PrintableTeamName() {
    [CmdLetBinding()]
    param (
        [string]$Project,
        [string]$TeamName
    )

    $PrintableTeamName = $TeamName

    if ([String]::IsNullOrEmpty($TeamName)) {
        $PrintableTeamName = "$($Project) Team"
    }

    return $PrintableTeamName
}

# main

# set default authentication header string
$AuthString = "Bearer $($AzureDevOpsJWT)"

if(![String]::IsNullOrEmpty($AzureDevOpsPAT)) {
    $AuthString = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($AzureDevOpsPAT)"))
}

$Title = Get-Title -Title $Title -TeamName $TeamName -Project $Project

$sprintName = $null
try {
    $sprintName = Get-AzDoSprintIteration -AuthString $AuthString `
                                          -Tenant $Tenant `
                                          -Project $Project `
                                          -TeamName $TeamName
}
catch {
    Write-Output "Unable to obtain sprint from API"
}

if ($null -ne $sprintName) {
    $Sprint = $sprintName
} else {
    $ErrorMessageTeamName = Get-PrintableTeamName -TeamName $TeamName -Project $Project
    Write-Output "No current iteration found for team $($ErrorMessageTeamName) in project: $($Project)."
}

$OutputFileNameProvided = ![string]::IsNullOrEmpty($OutputFile)

if ($OutputFileNameProvided) {
    Write-AzDoQueryReport -AuthString $AuthString `
                          -Tenant $Tenant `
                          -Project $Project `
                          -Queries $Queries `
                          -Title $Title `
                          -Sprint $Sprint `
                          -TeamName $TeamName `
                        | Out-File -FilePath $OutputFile
} else {
    $result = Write-AzDoQueryReport -AuthString $AuthString `
                                    -Tenant $Tenant `
                                    -Project $Project `
                                    -Queries $Queries `
                                    -Title $Title `
                                    -Sprint $Sprint `
                                    -TeamName $TeamName

    Write-Output $result
}

# add a small delay in exiting so that we can generate a unique timestamp
# ensuring that the pipeline execution order is reflected in the wiki page
# order (but reversed, because devops puts new subpages at the top of the list)
# don't ask me why it does this - it just does. So here's a quick workaround
# also there's currently no way to override this with a .order document via the
# AzDo REST API v5.1
Start-Sleep -Seconds 2