# Assets_Policies

This repository is intended to hold standalone Azure Policy and/or Azure RBAC Role Definition files.
These  may be consumed as part of the DriveTrain product assemblies, or used by themselves by individual engineers as single-solutions.

## Getting Started

If you've never worked with Azure Policies before, it may be a good idea to create your own one from scratch in a personal test environment first.

There are many good resources on how to write Azure Policies, here are some we recommend;

- https://docs.microsoft.com/en-us/azure/governance/policy/overview
- https://handsonlabs.microsoft.com/handsonlabs/Account/SignIn?redirect=/handsonlabs/SelfPacedLabs?storyId=story://content-private/content/sp-azuregovernance/1-azpolicy/a-policy
- https://docs.microsoft.com/en-us/azure/governance/policy/concepts/definition-structure
- https://github.com/Azure/azure-policy

## Build and Test

This pipeline has a CI build pipeline associated with it. There is a basic integration test in the CI pipeline which ensures all the policies in the repository are able to be deployed to Azure successfully. You will be unable to contribute a policy which does not deploy to Azure.
This is to ensure that all the Policy files in this repository are valid.

## Contribute

We welcome contributions from *anybody* into this repository.
To ensure that the repository contains good-quality modules, to make a contribution you will need to make a *pull request* from a branch that you have created. This ensures that the contents of the repository have been peer-reviewed.

As above, please ensure that any policies you wish to contribute are deployable in Azure.

## Legal
Please note the contents of the .LICENSE file stored in this repository.

It is required that a Master Services Agreement (MSA) is in place between New Signature and any customer where Drivetrain is used.

Please ensure that any code you contribute is either your own work, released under a permissive (non-copyleft) licence, or has been developed on a customer engagement where a Master Services Agreement is in place.

If you have any questions or queries about this, please contact legal@newsignature.com.

### Using Git

If you are unfamiliar with Git, or you do not understand how to create a pull request or git branch, the following references may be helpful for you if you are new to Git source control.

- https://git-scm.com/videos
- https://docs.microsoft.com/en-us/azure/devops/repos/git/gitworkflow?view=azure-devops

If you are still stuck after reviewing the above, message the Platform Services team in the Drivetrain Teams -> General Channel and someone will be happy to walk you through how to get started.
