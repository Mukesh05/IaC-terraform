Param (
  [string] $ManagementGroupName = $env:ManagementGroup,
  [string] $SourceFolder = $(Get-Item ($PSScriptRoot)).parent.FullName
)

$SourceFolder = Join-Path -Path $SourceFolder -ChildPath Policies -Resolve
$Policies = Get-ChildItem -Recurse -Path $SourceFolder -Include '*.json'

if ($null -ne $ManagementGroupName ) {
  if ($null -ne $(Get-AzContext)) {
    Describe 'Testing Policy Files' {
      foreach ($policy in $policies) {
        Context "Testing Policy $($policy.name)" {
          It "Checks $($policy.name) can be deployed to a test management group" {
            $json = Get-Content $policy.FullName | ConvertFrom-Json
            $metadata = "{""category"": ""DriveTrain"", ""product"": ""New Signature DriveTrain""}"

            New-AzPolicyDefinition `
              -Name $json.properties.name `
              -Description $json.properties.description `
              -DisplayName $json.properties.displayName `
              -Mode $json.properties.Mode `
              -Metadata $metadata `
              -ManagementGroupName $ManagementGroupName `
              -Policy (ConvertTo-Json $json.properties.policyRule -Depth 18).ToString() `
              -Parameter (ConvertTo-Json $json.properties.parameters -Depth 8).ToString() `
            | Should Not Be $null
          }
        }
      }
    }
  }
  else {
    Write-Error "Unable to complete integration tests as no Az Context found"
  }
}
else { Write-Error "Unable to complete integration tests as no management group name supplied" }
