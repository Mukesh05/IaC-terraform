Param (
    [string] $ManagementGroupName
)

Write-Host "Remove Policy Set Definition"
Get-AzPolicySetDefinition -ManagementGroupName $ManagementGroupName | Where-Object { $_.Properties.metadata.categories -Like 'Drivetrain' } | Remove-AzPolicySetDefinition -Force | Out-Null

Write-Host "Remove Policy Definition"
Get-AzPolicyDefinition -ManagementGroupName $ManagementGroupName | Where-Object { $_.Properties.metadata.categories -Like 'Drivetrain' } | Remove-AzPolicyDefinition -Force | Out-Null