Param (
  [string] $ManagementGroupName = $env:ManagementGroup,
  [string] $SourceFolder = $(Get-Item ($PSScriptRoot)).parent.FullName
)

$SourceFolder = Join-Path -Path $SourceFolder -ChildPath Initiatives -Resolve
$Initiatives = Get-ChildItem -Recurse -Path $SourceFolder -Include '*.json'

function IntChecker {
  param (
    [string]$string
  )
  $chars = $string.ToCharArray()
  foreach ($c in $chars) {
    $i = 0
    do {
      if ($c -eq $i.ToString()) {
        return $true
      }
      $i++
    }
    while ($i -lt 10)
  }
  return $false
}

if ($null -ne $ManagementGroupName ) {
  if ($null -ne $(Get-AzContext)) {
    Describe 'Testing Initiative Files' {
      foreach ($Initiative in $Initiatives) {
        Context "Testing Policy $($Initiative.name)" {
          It "Checks $($Initiative.name) can be deployed to a test management group" {
            $json = Get-Content $Initiative.FullName | ConvertFrom-Json

            #Check for Builtin Policy Definitions and handle custom policies - Assumes custom policies do not contain integers in name and that no initiatives contain a mix of both
            if (IntChecker $json.policyDefinitions.policyDefinitionID) { $PolicyDefinition = (ConvertTo-Json $json.policyDefinitions -Depth 8).ToString() }
            else { $PolicyDefinition = (ConvertTo-Json $json.policyDefinitions -Depth 8).ToString().Replace("/providers/Microsoft.Authorization", "/providers/Microsoft.Management/managementgroups/$($ManagementGroupName)/providers/Microsoft.Authorization")}
            New-AzPolicySetDefinition `
              -ManagementGroupName $ManagementGroupName `
              -Name $json.properties.name `
              -Description $json.properties.description `
              -PolicyDefinition $PolicyDefinition `
              -Parameter (ConvertTo-Json $json.properties.parameters -Depth 8).ToString() `
            | Should Not Be $null
          }
        }
      }
    }
  }
  else {
    Write-Error "Unable to complete integration tests as no Az Context found"
  }
}
else { Write-Error "Unable to complete integration tests as no management group name supplied" }