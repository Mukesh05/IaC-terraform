Param (
  [string] $SourceFolder = $(Get-Item ($PSScriptRoot)).parent.FullName
)

$SourceFolder = Join-Path -Path $SourceFolder -ChildPath Policies -Resolve
$Policies = Get-ChildItem -Recurse -Path $SourceFolder -Include '*.json'

Describe 'Testing Policy Files' {
  foreach ($policy in $policies) {
    Context "Testing Policy $($policy.name)" {
      It "Checks $($policy.name) is valid JSON" {
        $json = Get-Content $policy.FullName | ConvertFrom-Json
        $json | Should not be $null
      }

      It "Checks $($policy.name) has a name property" {
        $json = Get-Content $policy.FullName | ConvertFrom-Json
        $json.properties.name | Should not be $null
      }


      It "Checks $($policy.name) has a description property" {
        $json = Get-Content $policy.FullName | ConvertFrom-Json
        $json.properties.description | Should not be $null
      }

      It "Checks $($policy.name) has a displayname property" {
        $json = Get-Content $policy.FullName | ConvertFrom-Json
        $json.properties.displayName | Should not be $null
      }

      It "Checks $($policy.name) has a Mode property" {
        $json = Get-Content $policy.FullName | ConvertFrom-Json
        $json.properties.Mode | Should not be $null
      }

      It "Checks $($policy.name) has a policyRule property" {
        $json = Get-Content $policy.FullName | ConvertFrom-Json
        $json.properties.policyRule | Should not be $null
      }

      It "Checks $($policy.name) has a parameters property" {
        $json = Get-Content $policy.FullName | ConvertFrom-Json
        $json.properties.parameters | Should not be $null
      }

      It "Checks $($policy.name) has a policyRule property that can be converted back to JSON" {
        $json = Get-Content $policy.FullName | ConvertFrom-Json
        $(ConvertTo-Json $json.properties.policyRule -Depth 8).ToString() | Should not be $null
      }

      It "Checks $($policy.name) has a parameters property that can be converted back to JSON" {
        $json = Get-Content $policy.FullName | ConvertFrom-Json
        $(ConvertTo-Json $json.properties.parameters -Depth 8).ToString() | Should not be $null
      }

      It "Checks $($policy.name) has a valid effect" {
        $json = Get-Content $policy.FullName | ConvertFrom-Json
        $valideffects = @('Append', 'Audit', 'AuditIfNotExists', 'Deny', 'DeployIfNotExists', 'Disabled', 'EnforceRegoPolicy', 'Modify')
        $valideffects -contains $json.properties.policyrule.then.effect | Should be $true
      }

      It "Checks $($policy.name) has a valid name length" {
        $json = Get-Content $policy.FullName | ConvertFrom-Json
        ($json.properties.name).length | Should BeLessThan 65
      }

      It "Checks $($policy.name) has a valid displayName length" {
        $json = Get-Content $policy.FullName | ConvertFrom-Json
        ($json.properties.displayName).length | Should BeLessThan 129
      }

      It "Checks $($policy.name) has a valid description length" {
        $json = Get-Content $policy.FullName | ConvertFrom-Json
        ($json.properties.description).length | Should BeLessThan 513
      }

      It "Checks $($policy.name) has a category set in its metadata" {
        $json = Get-Content $policy.FullName | ConvertFrom-Json
        $json.properties.metadata.category | Should not be $null
      }

    }
  }
}