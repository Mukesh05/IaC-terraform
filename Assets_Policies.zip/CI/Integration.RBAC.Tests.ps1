# Param (
#   [string] $ManagementGroupName = $env:ManagementGroup,
#   [string] $SourceFolder = $(Get-Item ($PSScriptRoot)).parent.FullName
# )

# $SourceFolder = Join-Path -Path $SourceFolder -ChildPath RBAC -Resolve
# $RBACdefinitions = Get-ChildItem -Recurse -Path $SourceFolder -Include '*.json'

# if ($null -ne $ManagementGroupName ) {
#   if ($null -ne $(Get-AzContext)) {
#     $managementGroup = Get-AzManagementGroup -GroupName $ManagementGroupName
#     Describe 'Testing RBAC Files' {
#       foreach ($RBAC in $RBACdefinitions) {
#         Context "Testing RBAC definition $($RBAC.name)" {
#           It "Checks $($RBAC.name) can be deployed to a test management group" {

#             #Set the scope to the Management Group
#             $(Get-Content -Path $RBAC.FullName | ForEach-Object { $_ -replace """/""", ("""" + $managementGroup.Id + """") }) | Set-Content -Path $RBAC.FullName

#             #Test deploying the role
#             New-AzRoleDefinition -InputFile $_.FullName
#           }
#         }
#       }
#     }
#   }
#   else {
#     Write-Error "Unable to complete integration tests as no Az Context found"
#   }
# }
# else { Write-Error "Unable to complete integration tests as no management group name supplied" }
