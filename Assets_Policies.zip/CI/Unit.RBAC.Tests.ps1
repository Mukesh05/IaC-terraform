Param (
  [string] $SourceFolder = $(Get-Item ($PSScriptRoot)).parent.FullName
)

$SourceFolder = Join-Path -Path $SourceFolder -ChildPath RBAC -Resolve
$RBACdefinitions = Get-ChildItem -Recurse -Path $SourceFolder -Include '*.json'

Describe 'Testing RBAC Files' {
  foreach ($RBAC in $RBACdefinitions) {
    Context "Testing RBAC $($RBAC.name)" {
      It "Checks $($RBAC.name) is valid JSON" {
        $json = Get-Content $RBAC.FullName | ConvertFrom-Json
        $json | Should not be $null
      }
    }
  }
}

