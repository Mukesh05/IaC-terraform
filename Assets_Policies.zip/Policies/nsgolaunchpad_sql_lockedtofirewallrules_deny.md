

# Details

This policy restrict IP ranges to be used in SQL PaaS firewall rules. Any IP ranges that are not listed in the policy assignment
will be denied.

