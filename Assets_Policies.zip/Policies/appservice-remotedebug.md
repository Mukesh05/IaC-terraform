# App Services - Remote Debugging

This is a set of two policies;

1. _appservice-remotedebug-audit_ to audit whether remote debugging is off or not on an app service
2. _appservice-remotedebug-deny_ to deny the deployment of app services / modification of app services to have the remote debugging setting turned on

NB: If the Deny policy is applied, it will block all new App Services from being deployed if debugging is enabled and if it is an existing app, it will error when trying to switch it on.
