

# Details

This policy deny creation of storage accounts that are not connected to a VNet Service Endpoint 

