

# Details

This policy restrict IP ranges to be used in Storage Accounts firewall rules. Any IP ranges that are not listed in the policy assignment
will be denied  from been added to the firewall rules.

