# VMs - Backup Protection

This is a set of two policies

- Audit VMs that are not protected by Recovery Services Vault.

- Deny the creation of VMs that not protected by Recovery Services Vault.

Added to implement the governance best practices documented in [HLD provided by UK Azure Professional Services team](https://newsignature1.sharepoint.com/:b:/s/AzureGo/EaO_VP0GwWdMifM5griAgHoBfqj3kBCwjF9wghxVZW8d5g?e=pGphaL)

## NB

Audit policy audits for existence of the virtual machine name field within backupprotecteditems.
Deny policy denys virtual machines with a non-existence of the virtual machine name field within backupprotecteditems.
Deny policy is potentially something that cannot be enforced as the virtual machine would need to be provisioned first before being protected by recovery services vault.

## References

[ARM Reference Documentation for Recovery Services Vault]: https://docs.microsoft.com/en-us/azure/templates/microsoft.recoveryservices/2016-06-01/vaults
