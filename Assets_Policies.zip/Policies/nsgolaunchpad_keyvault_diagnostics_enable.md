

# Details

This Policy will enable the diagnostics settings for the Key Vaults to send data to central Log Analytics workspace

