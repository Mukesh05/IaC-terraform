# Azure Managed Disks - Not Encrypted

This is a set of two policies

- Audit Managed Disks that do not have disk encryption enabled

- Deny the creation of Managed Disks that do not have disk encryption enabled

Added to implement the governance best practices documented in [HLD provided by UK Azure Professional Services team](https://newsignature1.sharepoint.com/:b:/s/AzureGo/EaO_VP0GwWdMifM5griAgHoBfqj3kBCwjF9wghxVZW8d5g?e=pGphaL)

## NB

Audit policy audits for the non-existence of the encryptionsettings field on disks
Deny policy denys disks with a non-existence of the encryptionsettings field
This leaves a scenario where it is possible for a disk to fail encryption, but allows the possibility of disks that are currently undergoing encryption to exist and pass audit

## References

[ARM Reference Documentation for Managed Disks]: https://docs.microsoft.com/en-us/azure/templates/microsoft.compute/2017-03-30/disks
