# Tag Children of Resource Groups

A set of 8 append policies that check for the following for the following tags for a value of "notset" for each tag in resource groups where the corresponding tag on the parent resource group is set. If the value of the tag on a resource is set to "notset" (default enforcetagging policy value) it will inherit from the parent resource group, if the tag is not "notset" on the parent resource group.

## Tags

- Owner
- Project
- Cost Centre
- Support Level
- Environment
- Department
- Maintenance
- Auto-Start-Up-Shutdown
