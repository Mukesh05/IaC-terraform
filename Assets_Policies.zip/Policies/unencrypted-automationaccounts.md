# Automation Accounts - Unencrypted Variables

This is a set of two policies, one to audit, and one to deny, whether encryption has been set on a automation account variable.

NB: If the Deny policy is applied, it will block all new variables from being created that do not have encryption set to enabled and if the switch is changed on existing variables, it is also denied.
