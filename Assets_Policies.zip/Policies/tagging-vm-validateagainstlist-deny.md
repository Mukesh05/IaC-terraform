# Revisions

15/01/2020, v1, Initial release

# Author

adam.evans@newsignature.com

# Details

Enforces VMs to have the specified tag, with the value being validated against the provided list. Was used in a project to ensure all VM's had an encryption tag that was one of four values. VM deployments without the tag will be denied.

# Project\Customer Usage

Originaly written for Maersk CSP project