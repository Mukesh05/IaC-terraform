# Revisions

16/01/2020, v1, Initial release

# Author

adam.evans@newsignature.com

# Details

Checks that Auditing has been enabled on a Azure SQL Service instance at the server level. Taken from: https://github.com/Azure/azure-policy/tree/master/samples/SQL/audit-sql-server-auditing

# Project\Customer Usage

Originaly used in Maersk CSP project.