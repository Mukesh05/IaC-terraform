# Azure Regions - Control allowed regions

_Azure Regions - Control allowed regions_ is a deny policy which denies deployments to Azure Regions other than those expressly permitted when the policy is assigned.
