# Revisions

15/01/2020, v1, Initial release

# Author

adam.evans@newsignature.com
Taken from https://github.com/Azure/azure-policy/tree/master/samples/Network/load-balancer-skus

# Details

Restricts Load Balancers to use specified SKU's. Can be utilised to enforce various standards.

# Project\Customer Usage

Originaly used in Maersk CSP project.