# Revisions

15/01/2020, v1, Initial release

# Author

adam.evans@newsignature.com

# Details

Audits whether or not an Azure SQL Server has had an AAD Admin assigned, as is best practice. Taken from: https://github.com/Azure/azure-policy/tree/master/samples/SQL/audit-if-no-sql-active-directory-admin

# Project\Customer Usage

Originaly used in Maersk CSP project.