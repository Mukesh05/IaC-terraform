# Azure Storage - File and Blob Encryption Not Set

This is a set of two policies:

1. _unencrypted-storage-audit_ audits whether file and blob encryption is enabled on Azure Storage Accounts.
2. _unencrypted-storage-deny_ denies deployment of storage accounts with file and blob encryption disabled, and prevents disabling these on existing resources.

NB: If the Deny policy is applied, it will block all new storage accounts that do not have setting specified and may introduce a situation where it is more preferable to deploy storage accounts through ARM than the portal.

- [Microsoft ARM Reference]: https://docs.microsoft.com/en-us/azure/templates/microsoft.storage/2019-04-01/storageaccounts#encryptionservice-object
