# VMs - Deny Unmanaged Disks

This policy ensures all Disks for Virtual Machines are managed on creation.
It will also block attachment of unmanaged disks to VMs.
