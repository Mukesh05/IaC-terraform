# VMs - Connection to Log Analytics / Azure Monitor

Audits Virtual Machines that are not connected to a Log Analytics workspace and do not have both logs and metrics enabled.
