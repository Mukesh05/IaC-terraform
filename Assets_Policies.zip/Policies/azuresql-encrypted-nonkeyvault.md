# Azure SQL - Databases not encrypted with KeyVault-hosted key

This is a set of two policies:

1. _azuresql-encrypted-nonkeyvault-audit_ one to audit one whether encryption of Azure SQL databases using Azure Keyvault is enabled.
2. _azuresql-encrypted-nonkeyvault-deny_ to deny Azure SQL deployments where they are not encrypted using Azure Keyvault.

NB: If the Deny policy is applied, it is unclear if Deny policy will actually block any database actions or SQL server actions.
