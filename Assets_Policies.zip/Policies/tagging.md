# Enforce Tags on All Resources

A set of 8 append policies that check for the following tags and apply a default value of "notset" for each tag where the tag is not present on a resource.

## Tags

- Owner
- Project
- Cost Centre
- Support Level
- Environment
- Department
- Maintenance
- Auto-Start-Up-Shutdown
