# Revisions

15/01/2020, v1, Initial release

# Author

adam.evans@newsignature.com
Taken from https://github.com/Azure/azure-policy/tree/master/samples/Network/application-gateway-skus

# Details

Restricts Application Gateway to use specified SKU's. Can be utilised to enforce various standards. For example, enforce only v2 SKUs, enforce use of WAF SKUs or restrict that WAF SKUs can't be used.

# Project\Customer Usage

Originaly used in Maersk CSP project