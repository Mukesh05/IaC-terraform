# Azure Storage - Azure Storage - DeployifNotExists Require HTTPS on Storage Accounts

This is a single policy designed to remediate any storage accounts deployed in a state where Secure Transfer is not enabled by enabling it.

The policy requires Contributor permissions to be assigned to the policy using -AssignIdentity if deploying via PowerShell, when the policy is assigned.

Retrieved from https://github.com/Azure/Azure-Security-Center/blob/master/Remediation%20scripts/Require%20secure%20transfer%20to%20storage%20account/Azure%20Policy%20-%20DeployIfNotExists/azuredeploy.json