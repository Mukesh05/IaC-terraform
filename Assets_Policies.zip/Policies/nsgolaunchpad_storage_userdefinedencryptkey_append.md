

# Details

This Policy will append the encryption settings to the Storage Account for the customer-provided key. 

