# Key Vault - Enforce Soft-Delete and Purge Protection - Append

An append policy to ensure all KeyVaults that are deployed have Soft Delete and Purge Protection as a technical control to implement the governance best practices documented in [HLD provided by UK Azure Professional Services team](https://newsignature1.sharepoint.com/:b:/s/AzureGo/EaO_VP0GwWdMifM5griAgHoBfqj3kBCwjF9wghxVZW8d5g?e=pGphaL)
