# Revisions

15/01/2020, v1, Initial release

# Author

adam.evans@newsignature.com

# Details

Denies an Azure Load Balancer from having a public IP assigned. Can be assigned in environments that enforce all traffic through edge firewalls, ensuring that a backdoor can't be created through a load balancer.

# Project\Customer Usage

Originaly written for Maersk CSP project