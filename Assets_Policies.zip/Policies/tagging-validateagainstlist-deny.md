# Revisions

15/01/2020, v1, Initial release

# Author

adam.evans@newsignature.com

# Details

Enforces a specified tag and validates the value against a provided list. Applies to all Resource Types unless they have been added to the exclusion.

# Project\Customer Usage

Not deployed to any customers, but a variant on a policy utilised for the Maersk CSP project.