# Azure Virtual Machines - DeployifNotExists Automatically Deploy Backup

This is a single policy designed to remediate any virtual machines deployed in a state where Azure Backup is not enabled by enabling it.

It is should be used with the following considerations for RSV architecture
- A single RSV should not support more than 30 VMs
- VMs must be in the same region as the RSV
- VMs must be in the same subscription as the RSV
- This policy will by default set the RSV "DefaultPolicy", if this is not desired the policy parameters should be changed

It is reccomended to deploy this policy at the Resource Group level in non-trivial scenarios.

The policy requires Contributor permissions to be assigned to the policy using -AssignIdentity if deploying via PowerShell, when the policy is assigned.
