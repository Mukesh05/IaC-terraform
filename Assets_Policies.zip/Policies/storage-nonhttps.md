# Azure Storage - Audit/Deny non-https-only Storage Accounts

This is a set of two policies:

1. _storage-nonhttps-audit_ to audit whether HTTPS only is set on Azure Storage Accounts
2. _storage-nonhttps-deny_ to deny the deployment of storage accounts when, or modification of existing accounts to, HTTPS-only is not set on the account.

NB: If the Deny policy is applied, it will block all new storage accounts that do not have the setting specified for supportsHttpsTrafficOnly enabled.
