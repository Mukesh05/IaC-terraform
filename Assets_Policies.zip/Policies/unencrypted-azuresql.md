# Azure SQL - No TDE Configured

This is a set of two policies:

1. _unencrypted-azuresql-audit_ to audit whether encryption has not been set in the deployment of the Azure SQL resource or enabled on the existing resource.
2. _unencrypted-azuresql-deny_ to deny creation or modification if encryption has not been set in the deployment of the Azure SQL resource or is going to be un-set  on an existing resource.

NB: If the Deny policy is applied, it will block all new sql deployments that do not have TDE enabled and if the switch is changed in existing resources, it is also denied.
