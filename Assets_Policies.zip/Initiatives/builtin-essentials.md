# Built In Guardrails

Anti-malware =
"/providers/Microsoft.Authorization/policyDefinitions/2835b622-407b-4114-9198-6f7064cbe0dc"

Adds the specified tag with its value from the parent resource group when any resource missing this tag is created or updated. Existing resources can be remediated by triggering a remediation task. If the tag exists with a different value it will not be changed.
 = /providers/Microsoft.Authorization/policyDefinitions/ea3f2387-9b95-492a-a190-fcdc54f7b070

Adds the specified tag and value when any resource group missing this tag is created or updated. Existing resource groups can be remediated by triggering a remediation task. If the tag exists with a different value it will not be changed. = 726aca4c-86e9-4b04-b0c5-073027359532

This policy enables you to restrict the locations your organization can create resource groups in. Use to enforce your geo-compliance requirements = e765b5de-1225-4ba3-bd56-1ac6695af988

This policy enables you to restrict the locations your organization can specify when deploying resources. Use to enforce your geo-compliance requirements =  Excludes resource groups, Microsoft.AzureActiveDirectory/b2cDirectories, and resources that use the 'global' region. e56962a6-4747-49cd-b67b-bf8b01975c4c

The policy initiative requires Contributor permissions to be assigned to the policy using -AssignIdentity if deploying via PowerShell, when the policy is assigned.