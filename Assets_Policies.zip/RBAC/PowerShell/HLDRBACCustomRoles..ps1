﻿##This powershell will create 6 roles and will appy it to a certain MG that is specified below. You will need to log into Azure to apply. If you get an error, you might need to select a subscription.

function New-AFCustomRbacRole
{
    [CmdletBinding()]
    #[OutputType([Microsoft.Azure.Commands.Resources.Models.Authorization.PSRoleDefinition])]
    Param
    (
        # Custom role name
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$Name,

        # Custom role description
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$Description,

        # Custom role Actions
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string[]]$Action,

        # Custom role NotActions
        [Parameter(Mandatory=$false)]
        [ValidateNotNullOrEmpty()]
        [string[]]$NotAction,

        # Custom role scope
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string[]]$AssignableScopes
    )

    Begin
    {
    }
    Process
    {
        $Role = $null
        $Role = Get-AzRoleDefinition -Name $Name -ErrorAction SilentlyContinue
        if ($Role -eq $null) {
            $Role = Get-AzRoleDefinition -Name 'Reader'
            $Role.Id = $null
            $Role.Name = $Name
            $New = $true
        } else {
            $New = $false
        }

        $Role.Actions.Clear()
        $Item = $null
        foreach ($Item in $Action) {
            $Role.Actions.Add($Item)
        }
        $Item = $null
        $Role.NotActions.Clear()
        foreach ($Item in $NotAction) {
            $Role.NotActions.Add($Item)
        }
        $Role.Description = $Description
        $Role.AssignableScopes.Clear()
        $Role.AssignableScopes = $AssignableScopes

        if ($New) {
            New-AzRoleDefinition -Role $Role
        } else {
            Set-AzRoleDefinition -Role $Role
        }
    }
    End
    {
    }
}

# Input the management group to apply the roles to:
$ManagementGroupScopes =  '/providers/Microsoft.Management/managementGroups/"Management Group ID"'

#Advanced User Custom Role
$CustomRoles = @()
$Role = New-AFCustomRbacRole -Name 'Advanced User' -Description 'Full Agile user with Contributor access and safety barriers.' `
            -Action '*'`
            -NotAction 'Microsoft.Authorization/*/Delete',`
                    'Microsoft.Authorization/*/Write',`
                    'Microsoft.Authorization/elevateAccess/action',`
                    'Microsoft.Network/PublicIPAddresses/Write',`
                    'Microsoft.Network/VirtualNetworks/Write',`
                    'Microsoft.Network/AzureFirewalls/Write',`
                    'Microsoft.Network/AzureFirewalls/Write',`
                    'Microsoft.Sql/Servers/FirewallRules/Write',`
                    'Microsoft.Sql/servers/firewallRules/delete',`
                    'Microsoft.Cache/redis/firewallRules/delete',`
                    'Microsoft.Network/ApplicationGatewayWebApplicationFirewallPolicies/Write',`
                    'Microsoft.DataLakeStore/Accounts/FirewallRules/Write',`
                    'Microsoft.DataLakeAnalytics/Accounts/FirewallRules/Write',`
                    'Microsoft.ServiceBus/Namespaces/IpFilterRules/Write',`
                    'Microsoft.ServiceBus/Namespaces/IpFilterRules/Delete',`
                    'Microsoft.ServiceBus/Namespaces/Networkruleset/Write',`
                    'Microsoft.ServiceBus/Namespaces/Networkrulesets/Delete',`
                    'Microsoft.ServiceBus/Namespaces/Queues/AuthorizationRules/Delete',`
                    'Microsoft.EventHub/Namespaces/IpFilterRules/Write',`
                    'Microsoft.EventHub/Namespaces/IpFilterRules/Delete',`
                    'Microsoft.Compute/Disks/BeginGetAccess/Action',`
                    'Microsoft.Compute/Snapshots/BeginGetAccess/Action',`
                    'Microsoft.RecoveryServices/Vaults/BackupFabrics/ProtectionContainers/ProtectedItems/RecoveryPoints/Restore/Action',`
                    'Microsoft.RecoveryServices/Vaults/backupFabrics/protectionContainers/protectedItems/recoveryPoints/provisionInstantItemRecovery/action',`
                    'Microsoft.Network/RouteTables/Write',`
                    'Microsoft.Network/RouteTables/Routes/Write',`
                    'Microsoft.Resources/subscriptions/resourceGroups/validateMoveResources/action',`
                    'Microsoft.Resources/subscriptions/resourceGroups/moveResources/action',`
                    'Microsoft.DataLakeAnalytics/accounts/firewallRules/delete',`
                    'Microsoft.DataLakeAnalytics/accounts/firewallRules/write',`
                    'Microsoft.DataLakeStore/accounts/firewallRules/delete',`
                    'Microsoft.DataLakeStore/accounts/firewallRules/write',`
                    'Microsoft.DBforMariaDB/servers/firewallRules/delete',`
                    'Microsoft.DBforMariaDB/servers/firewallRules/write',`
                    'Microsoft.DBforMySQL/servers/firewallRules/delete',`
                    'Microsoft.DBforMySQL/servers/firewallRules/write',`
                    'Microsoft.DBforPostgreSQL/servers/firewallRules/delete',`
                    'Microsoft.DBforPostgreSQL/servers/firewallRules/write',`
                    'Microsoft.DBforPostgreSQL/serversv2/firewallRules/delete',`
                    'Microsoft.DBforPostgreSQL/serversv2/firewallRules/write',`
                    'Microsoft.Security/webApplicationFirewalls/delete'`
    -AssignableScopes $ManagementGroupScopes
$CustomRoles += $Role.Name

#Audior Custom Role
$CustomRoles = @()
$Role = New-AFCustomRbacRole -Name 'Auditor' -Description 'Reader access only.' `
            -Action '*/Read'`
            -AssignableScopes $ManagementGroupScopes
$CustomRoles += $Role.Name

#IT Admin Custom Role
$CustomRoles = @()
$Role = New-AFCustomRbacRole -Name 'IT Admin' -Description 'Contributor access for IT Admins.' `
            -Action '*'`
            -NotAction 'Microsoft.Authorization/*/Delete',`
                    'Microsoft.Authorization/*/Write',`
                    'Microsoft.Authorization/ElevateAccess/Action'`
            -AssignableScopes $ManagementGroupScopes
$CustomRoles += $Role.Name

#Security Operator Custom Role
$CustomRoles = @()
$Role = New-AFCustomRbacRole -Name 'Security Operator' -Description 'Reader rights and administrative rights to Sentinel and Azure Security Center.' `
            -Action '*/Read',`
                    'Microsoft.SecurityGraph/*',`
                    'Microsoft.Security/*'`
            -AssignableScopes $ManagementGroupScopes
$CustomRoles += $Role.Name

#Senior IT Adminr Custom Role
$CustomRoles = @()
$Role = New-AFCustomRbacRole -Name 'Senior IT Admin' -Description 'Owner access for Senior IT Admins.' `
            -Action '*'`
            -AssignableScopes $ManagementGroupScopes
$CustomRoles += $Role.Name

#Standard User Custom Role
$CustomRoles = @()
$Role = New-AFCustomRbacRole -Name 'Standard User' -Description 'Virtual Machine Contributor rights only.' `
                -Action 'Microsoft.Authorization/*/read',`
                        'Microsoft.Compute/availabilitySets/*',`
                        'Microsoft.Compute/locations/*',`
                        'Microsoft.Compute/virtualMachines/*',`
                        'Microsoft.Compute/virtualMachineScaleSets/*',`
                        'Microsoft.DevTestLab/schedules/*',`
                        'Microsoft.Insights/alertRules/*',`
                        'Microsoft.Network/applicationGateways/backendAddressPools/join/action',`
                        'Microsoft.Network/loadBalancers/backendAddressPools/join/action',`
                        'Microsoft.Network/loadBalancers/inboundNatPools/join/action',`
                        'Microsoft.Network/loadBalancers/inboundNatRules/join/action',`
                        'Microsoft.Network/loadBalancers/probes/join/action',`
                        'Microsoft.Network/loadBalancers/read',`
                        'Microsoft.Network/locations/*',`
                        'Microsoft.Network/networkInterfaces/*',`
                        'Microsoft.Network/networkSecurityGroups/join/action',`
                        'Microsoft.Network/networkSecurityGroups/read',`
                        'Microsoft.Network/publicIPAddresses/join/action',`
                        'Microsoft.Network/publicIPAddresses/read',`
                        'Microsoft.Network/virtualNetworks/read',`
                        'Microsoft.Network/virtualNetworks/subnets/join/action',`
                        'Microsoft.RecoveryServices/locations/*',`
                        'Microsoft.RecoveryServices/Vaults/backupFabrics/backupProtectionIntent/write',`
                        'Microsoft.RecoveryServices/Vaults/backupFabrics/protectionContainers/protectedItems/*/read',`
                        'Microsoft.RecoveryServices/Vaults/backupFabrics/protectionContainers/protectedItems/read',`
                        'Microsoft.RecoveryServices/Vaults/backupFabrics/protectionContainers/protectedItems/write',`
                        'Microsoft.RecoveryServices/Vaults/backupPolicies/read',`
                        'Microsoft.RecoveryServices/Vaults/backupPolicies/write'`
                -AssignableScopes $ManagementGroupScopes
            $CustomRoles += $Role.Name
