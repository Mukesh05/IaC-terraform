# The powershell script is based on the 6 custom roles in the high-level design

# Adavnced user Role
All permissions have been given to this role other than the following
Microsoft.Authorization/*/Delete
Microsoft.Authorization/*/Write
Microsoft.Authorization/elevateAccess/action
Microsoft.Network/PublicIPAddresses/Write
Microsoft.Network/VirtualNetworks/Write
Microsoft.Network/AzureFirewalls/Write
Microsoft.Network/AzureFirewalls/Write
Microsoft.Sql/Servers/FirewallRules/Write
Microsoft.Sql/servers/firewallRules/delete
Microsoft.Cache/redis/firewallRules/delete
Microsoft.Network/ApplicationGatewayWebApplicationFirewallPolicies/Write
Microsoft.DataLakeStore/Accounts/FirewallRules/Write
Microsoft.DataLakeAnalytics/Accounts/FirewallRules/Write
Microsoft.ServiceBus/Namespaces/IpFilterRules/Write
Microsoft.ServiceBus/Namespaces/IpFilterRules/Delete
Microsoft.ServiceBus/Namespaces/Networkruleset/Write
Microsoft.ServiceBus/Namespaces/Networkrulesets/Delete
Microsoft.ServiceBus/Namespaces/Queues/AuthorizationRules/Delete
Microsoft.EventHub/Namespaces/IpFilterRules/Write
Microsoft.EventHub/Namespaces/IpFilterRules/Delete
Microsoft.Compute/Disks/BeginGetAccess/Action
Microsoft.Compute/Snapshots/BeginGetAccess/Action
Microsoft.RecoveryServices/Vaults/BackupFabrics/ProtectionContainers/ProtectedItems/RecoveryPoints/Restore/Action
Microsoft.RecoveryServices/Vaults/backupFabrics/protectionContainers/protectedItems/recoveryPoints/provisionInstantItemRecovery/action
Microsoft.Network/RouteTables/Write
Microsoft.Network/RouteTables/Routes/Write
Microsoft.Resources/subscriptions/resourceGroups/validateMoveResources/action
Microsoft.Resources/subscriptions/resourceGroups/moveResources/action
Microsoft.DataLakeAnalytics/accounts/firewallRules/delete
Microsoft.DataLakeAnalytics/accounts/firewallRules/write
Microsoft.DataLakeStore/accounts/firewallRules/delete
Microsoft.DataLakeStore/accounts/firewallRules/write
Microsoft.DBforMariaDB/servers/firewallRules/delete
Microsoft.DBforMariaDB/servers/firewallRules/write
Microsoft.DBforMySQL/servers/firewallRules/delete
Microsoft.DBforMySQL/servers/firewallRules/write
Microsoft.DBforPostgreSQL/servers/firewallRules/delete
Microsoft.DBforPostgreSQL/servers/firewallRules/write
Microsoft.DBforPostgreSQL/serversv2/firewallRules/delete
Microsoft.DBforPostgreSQL/serversv2/firewallRules/write
Microsoft.Security/webApplicationFirewalls/delete

#Auditor Role
This role only has read permissions
*/Read

# IT Admin Role
All permissions have been given to this role other than the following
Microsoft.Authorization/*/Delete
Microsoft.Authorization/*/Write
Microsoft.Authorization/ElevateAccess/Action

# Security Operator Role
This role only allows the following permissions
*/Read
Microsoft.SecurityGraph/*
Microsoft.Security/*

# Senior IT Admin Role
This role allowed all permissions, the same as owner role

# Standard User Role
This role only allows the following permissions
Microsoft.Authorization/*/read
Microsoft.Compute/availabilitySets/*
Microsoft.Compute/locations/*
Microsoft.Compute/virtualMachines/*
Microsoft.Compute/virtualMachineScaleSets/*
Microsoft.DevTestLab/schedules/*
Microsoft.Insights/alertRules/*
Microsoft.Network/applicationGateways/backendAddressPools/join/action
Microsoft.Network/loadBalancers/backendAddressPools/join/action
Microsoft.Network/loadBalancers/inboundNatPools/join/action
Microsoft.Network/loadBalancers/inboundNatRules/join/action
Microsoft.Network/loadBalancers/probes/join/action
Microsoft.Network/loadBalancers/read
Microsoft.Network/locations/*
Microsoft.Network/networkInterfaces/*
Microsoft.Network/networkSecurityGroups/join/action
Microsoft.Network/networkSecurityGroups/read
Microsoft.Network/publicIPAddresses/join/action
Microsoft.Network/publicIPAddresses/read
Microsoft.Network/virtualNetworks/read
Microsoft.Network/virtualNetworks/subnets/join/action
Microsoft.RecoveryServices/locations/*
Microsoft.RecoveryServices/Vaults/backupFabrics/backupProtectionIntent/write
Microsoft.RecoveryServices/Vaults/backupFabrics/protectionContainers/protectedItems/*/read
Microsoft.RecoveryServices/Vaults/backupFabrics/protectionContainers/protectedItems/read
Microsoft.RecoveryServices/Vaults/backupFabrics/protectionContainers/protectedItems/write
Microsoft.RecoveryServices/Vaults/backupPolicies/read
Microsoft.RecoveryServices/Vaults/backupPolicies/write


