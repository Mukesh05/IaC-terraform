# Advanced User

Full Agile user with Contributor access and safety barriers
