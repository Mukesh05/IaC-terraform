# Security Operator
Reader rights and administrative rights to Sentinel and Azure Security Center