# Standard User
Virtual Machine Contributor rights only