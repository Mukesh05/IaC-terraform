[CmdletBinding()]
param(
  [string]$folderpath
)

$policies = @()
foreach ($file in $(Get-ChildItem $folderpath | Where-Object { $_.name -match ".json" })) {
  $json = Get-Content $file.fullname | ConvertFrom-Json
  $policies += [PSCustomObject]@{
    displayName = $json.properties.displayName
    type = $json.properties.type
    name = $json.properties.name
    policyType = $json.properties.policyType
    description = $json.properties.description
  }
}
return $policies