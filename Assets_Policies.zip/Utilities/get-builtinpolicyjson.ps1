function Get-PolicyJson {
  param(
    [string]$id,
    [switch]$view = $false
  )

  if ($null -eq $(Get-AzContext)) {
    throw "Not logged into Azure, please login and retry"
  }

  $policy = Get-AzPolicyDefinition -Id "/providers/Microsoft.Authorization/policyDefinitions/$id"

  if ($null -eq $policy) {
    throw "Could not find policy with ID $id in $((Get-AzContext).subscription.name)"
  }

  $tempfile = "$(New-Guid)" + ".json"
  $json = @($policy.properties) | Convertto-json -Depth 100 | ForEach-Object { [System.Text.RegularExpressions.Regex]::Unescape($_) }
  if ($view) {
    $json | Out-File "$env:temp\$tempfile"
    notepad "$env:temp\$tempfile"
  }
  return $json
}