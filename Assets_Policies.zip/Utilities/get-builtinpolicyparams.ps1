function Get-PolicyParams {
  param(
    [string]$id
  )

  if ($null -eq $(Get-AzContext)) {
    throw "Not logged into Azure, please login and retry"
  }

  $policy = Get-AzPolicyDefinition -Id "/providers/Microsoft.Authorization/policyDefinitions/$id"

  if ($null -eq $policy) {
    throw "Could not find policy with ID $id in $((Get-AzContext).subscription.name)"
  }

  return [PSCustomObject]@{
    id = $policy.resourceid
    displayName = $policy.Properties.displayName
    policyType = $policy.Properties.policyType
    description = $policy.Properties.description
    parameters = $policy.Properties.parameters
  } | Format-List
}