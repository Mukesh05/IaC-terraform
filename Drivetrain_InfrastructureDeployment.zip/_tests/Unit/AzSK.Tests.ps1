

# $nottemplatesearch = Get-ChildItem -Recurse | Where-Object { ($_.psIsContainer -ne "True") -and (($_.Extension -notmatch "JSON") -OR (($_.Extension -match "JSON") -and ($_.NAME -like "*.parameters.json")) -or ($_.FullName -like "*_temp*") -or ($_.FullName -like "*.vscode*")) }
# $nottemplates = ""

# foreach ($template in $nottemplatesearch) {
#   $nottemplates = $nottemplates = "," + $template.FullName
# }
# <# Pester Test File #>
# function Get-AzSKTemplateResultsAsCsvData {
#   [CmdLetBinding()]
#   param (
#     [string] $ArmTemplatePath = ".\",
#     [string[]] $Exclusions = @("Azure_KubernetesService_AuthN_Enabled_AAD", <# Templates don't always need AAD #>
#       "Azure_SQLDatabase_AuthZ_Use_AAD_Admin", <# Templates don't always need AAD #>
#       "Azure_AppService_AuthN_Use_AAD_for_Client_AuthN", <# Templates don't always need AAD #>
#       "Azure_VNet_NetSec_Justify_Peering", <# This is too prescriptive #>
#       "Azure_APIManagement_DP_Use_HTTPS_URL_Scheme", <# no back end endpoints defined in the template #>
#       "Azure_SQLDatabase_Audit_Enable_Threat_Detection_Server", <# settings not present in this template until real implementation #>
#       "Azure_KubernetesService_Deploy_Enable_Cluster_RBAC", <# Templates don't always need AAD #>
#       "Azure_CosmosDB_Config_Default_Consistency")        <# seems to fail even when this is not specifically set #>
#   )
#   [string]$ExcludeControlIds = $Exclusions -join ','

#   $resultsPath = Get-AzSKARMTemplateSecurityStatus -ARMTemplatePath $ArmTemplatePath `
#     -ExcludeFiles $nottemplates `
#     -Recurse `
#     -DoNotOpenOutputFolder `
#     -ExcludeControlIds $ExcludeControlIds `
#     -UseBaselineControls `
#     -ErrorAction SilentlyContinue `
#     -WarningAction SilentlyContinue

#   $resultsCsvFileName = (Get-ChildItem -Path $resultsPath -Filter *.csv | Select-Object -First 1).FullName

#   $importedData = Import-Csv -Path $resultsCsvFileName -Delimiter ','

#   return $importedData
# }

# $templateSecurityStatusData = Get-AzSKTemplateResultsAsCsvData
# Describe "ARM Template Validation" {
#   $Thresholds = @("High", "Medium", "Low")
#   $filteredRecords = $templateSecurityStatusData | Where-Object { $Thresholds.Contains($_.Severity) }

#   Context "Templates must pass secure DevOps Kit for Azure baseline..." {
#     foreach ($record in $filteredRecords) {
#       It "$($record.ControlId) in $($record.FilePath) at line $($record.ResourceLineNumber) with severity `"$($record.Severity)`" Should be `"Passed`". Info: `"$($record.Description)`"" {
#         $record.Status | Should Be "Passed"
#       }
#     }
#   }
# }

# Remove-Module -Name AzSk -Force
# Remove-Module -Name Az.Accounts -Force