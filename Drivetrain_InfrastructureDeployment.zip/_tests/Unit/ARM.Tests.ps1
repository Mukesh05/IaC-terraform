$templates = Get-ChildItem -Recurse | Where-Object { ($_.Extension -match "JSON") -AND ($_.NAME -notlike "*.parameters.json") -and ($_.FullName -notlike "*_temp*") -and ($_.FullName -notlike "*.vscode*")}
$regexCommentFilter = '(?:[^:])(//[A-Za-z0-9 .]*)'
<# Pester Test File #>

Describe 'Testing ARM Templates' {

    Foreach ($template in $templates) {
        Context "Testing $($template.Name)" {
            $msg = "Checks the Template ["+$($Template.Name)+"] is valid JSON"
            It "$msg" {
                $content = Get-Content $template.fullname
                $content =  [regex]::Replace($content, $regexCommentFilter, "") #Regex to remove ARM comments from JSON before checking validity
                $json = $content | ConvertFrom-JSON -ErrorAction Stop
                $json | Should not be $null
            }

            # Check and see if the template name is the exclusion list at the beginning of this script
            If ($template.Name -notin $paramCheckExclude) {
              # Load the template in and convert from JSON, can't use the object above as that is in an "It" so can't be referenced properly
              $json = Get-Content $template.fullname | ConvertFrom-Json
              # Get the parameters from the template
              $jsonParams = $json.parameters

              # Loop through each parameter, have to use the PSObject properties to get the names of each parameter
              Foreach ($jsonParam in $jsonParams.PSObject.Properties) {
                # Retrieve the parameter name
                $paramName = $jsonParam.Name
                # Get the parameter values, by selecting the parameter from the original parameters object and expand on the parameter property so we can compare its contents
                $paramValues = $jsonParams | Select-object $paramName -ExpandProperty $paramName
                It "Check parameter $($paramName) in template $($Template.Name) has metadata descriptions on all template parameters" {
                  $paramValues.metadata.description | Should not be $null
                }
              }
            }
         }

    }
}

Describe 'Self-test: Validate regex comment filter will strip comments, but not affect URIs' {
    $inputJsonDocument = `
@'
{
    "contentVersion": "1.0.0.0",
    "$schema": "https://schema.management.azure.com/schemas/2015-01-01/deploymentTemplate.json#",
    "parameters": {
        "dataFactoryName": {
            "type": "string",
            "defaultValue": "[concat('adf-', uniqueString(resourceGroup().id))]",
            "metadata": {
                "description": "Name of the data factory. Must be globally unique."  // comment with spaces
            }
        }
    },
    "variables": {},
    "resources": [ // comment here
        {
            "type": "Microsoft.DataFactory/factories",
            "apiVersion": "2018-06-01",
            "name": "[parameters('dataFactoryName')]",
            "location": "[resourceGroup().location]",
            "identity": {
                "type": "SystemAssigned"
            }
        }
    ] //comment here
}
'@

    $expectedJsonDocument = `
@'
{
    "contentVersion": "1.0.0.0",
    "$schema": "https://schema.management.azure.com/schemas/2015-01-01/deploymentTemplate.json#",
    "parameters": {
        "dataFactoryName": {
            "type": "string",
            "defaultValue": "[concat('adf-', uniqueString(resourceGroup().id))]",
            "metadata": {
                "description": "Name of the data factory. Must be globally unique."
            }
        }
    },
    "variables": {},
    "resources": [
        {
            "type": "Microsoft.DataFactory/factories",
            "apiVersion": "2018-06-01",
            "name": "[parameters('dataFactoryName')]",
            "location": "[resourceGroup().location]",
            "identity": {
                "type": "SystemAssigned"
            }
        }
    ]
}
'@
    $result =  [regex]::Replace($inputJsonDocument, $regexCommentFilter, "")

    it 'should not contain comments' {
        ($result.contains('comment')) | should be $false
    }

    it 'should contain unaffected uris' {
        ($result.contains('https://schema.management.azure.com/schemas/2015-01-01/deploymentTemplate.json#')) | should be $true
    }

    it 'should json deserialize expected data' {
        $json = $expectedJsonDocument | ConvertFrom-JSON -ErrorAction Stop
        $json | Should not be $null
    }

    it 'should json deserialize result data' {
        $json = $result | ConvertFrom-JSON -Verbose -ErrorAction Stop
        $json | Should not be $null
    }
}
