#Ensure required environment variables are set.
if ($null -eq $env:LaunchPadHubTest) {
  Write-Warning "Please ensure the LaunchPadHubTest environment variable is set to a subscription ID to execute integration test!"
}
else {

  <# Prereqs - Set up Temporary Storage Account and Import Deployment Functions#>
  $rootFolder = $(Get-Item $PSScriptRoot).Parent.Parent.Fullname
  Import-Module "$rootFolder\_helpers\DeploymentLibrary.psm1" -Force
  $fixture = "$rootFolder\_tests\_fixtures\Hub.parameters.json"
  $sut = "hub.json"
  $deploymentName = $("Hubintegrationtest" + "-" + $((Get-Date).ToUniversalTime()).ToString('MMddHHmmss'))
  $templateparameters = (Get-Content $fixture | ConvertFrom-Json).parameters

  try {
    $tempRgName = ("temp" + $(New-Guid).guid.split("-")[0])
    $library = Publish-TemplateLibrary `
      -AzureSubscription $env:LaunchPadHubTest `
      -ResourceGroup $tempRgName `
      -Template $sut `
      -ArtifactStagingDirectory $rootFolder

    function Remove-TemplateLibrary {
      Remove-AzResourceGroup $tempRgName -Force | Out-Null
    }
  }
  catch {
    throw "Error in Publish-TemplateLibrary : $_"
  }

  <# Pester Tests #>
  Describe "$sut" {
    It "Deploys Successfully to Azure" {
      Publish-SubscriptionDeployment `
        -StorageAccountName $library `
        -templateFile $sut `
        -templateParametersFile $fixture `
        -DeploymentName $deploymentname
    }
  }
  Describe "Azure Resource Group" {
    It "is deployed with the correct Name" {
      Get-AzResourceGroup `
        -ResourceGroupName $templateparameters.vnetResourceGroupName.value `
      | Should Not BeNullorEmpty
    }
  }

  Describe "Azure Bastion" {
    It "has deployed with the correct name in the correct resource group " {
      Get-AzBastion `
        -ResourceGroupName $templateparameters.vnetResourceGroupName.value `
        -Name $templateparameters.bastionName.value `
      | Should Not BeNullorEmpty
    }
  }

  Write-Host $deploymentname
  if (Get-AzResourceGroup -ResourceGroupName $templateparameters.vnetResourceGroupName.value -erroraction silentlycontinue) {
    Remove-AzResourceGroup -ResourceGroupName $templateparameters.vnetResourceGroupName.value -force
  }
  Remove-TemplateLibrary
}