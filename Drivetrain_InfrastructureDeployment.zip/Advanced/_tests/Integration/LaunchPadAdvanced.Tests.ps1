#Ensure required environment variables are set.
if ($null -eq $env:launchPadManagementGroupTest) {
  Write-Warning "Please ensure the launchPadManagementGroupTest environment variable is set to a subscription ID to execute integration test!"
}
else {

  <# Prereqs - Set up Temporary Storage Account and Import Deployment Functions#>
  $rootFolder = $(Get-Item $PSScriptRoot).Parent.Parent.Fullname
  Import-Module "$rootFolder\_helpers\DeploymentLibrary.psm1" -Force
  $fixture = "$rootFolder\_tests\_fixtures\LaunchPadAdvanced.parameters.json"
  $sut = "LaunchPadAdvanced.json"
  $templateparameters = (Get-Content $fixture | ConvertFrom-Json).parameters
  $deploymentName = $("LaunchPadAdvancedintegrationtest" + "-" + $((Get-Date).ToUniversalTime()).ToString('MMddHHmmss'))

  try {
    $tempRgName = ("temp" + $(New-Guid).guid.split("-")[0])
    $library = Publish-TemplateLibrary `
      -AzureSubscription $templateparameters.hubSubscriptionID.value `
      -ResourceGroup $tempRgName `
      -Template $sut `
      -ArtifactStagingDirectory $rootFolder

    function Remove-TemplateLibrary {
      Remove-AzResourceGroup $tempRgName -Force | Out-Null
    }
  }
  catch {
    throw "Error in Publish-TemplateLibrary : $_"
  }

  <# Pester Tests #>
  Describe "LaunchPadAdvanced.json" {
    It "Deploys Successfully to Azure" {
      Publish-ManagementGroupDeployment `
        -StorageAccountName $library `
        -ManagementGroupId $env:launchPadManagementGroupTest `
        -templateFile $sut `
        -templateParametersFile $fixture `
        -DeploymentName $deploymentname
    }
  }

  Write-Host $deploymentname
  Remove-TemplateLibrary
  Set-AzContext -Subscription $templateparameters.hubSubscriptionID.value
  if (Get-AzResourceGroup -ResourceGroupName $templateparameters.hubvnetResourceGroupName.value -erroraction silentlycontinue) {
    Remove-AzResourceGroup -ResourceGroupName $templateparameters.hubvnetResourceGroupName.value -force
  }
  Set-AzContext -Subscription $templateparameters.sharedServicesSubscriptionID.value
  if (Get-AzResourceGroup -ResourceGroupName $templateparameters.sharedservicesvnetResourceGroupName.value -erroraction silentlycontinue) {
    Remove-AzResourceGroup -ResourceGroupName $templateparameters.sharedservicesvnetResourceGroupName.value -force
  }
}