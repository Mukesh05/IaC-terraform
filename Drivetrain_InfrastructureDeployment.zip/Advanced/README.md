# Drivetrain LaunchPad Advanced

## Management Group Level Deployment

Please note that deploying using LaunchPadAdvanced.json is a Management Group-level deployment. There are some considerations when using Management Group-level deployments that must be taken into consideration. [Please also refer to the Microsoft Documentation Here.](https://docs.microsoft.com/en-us/azure/azure-resource-manager/templates/deploy-to-Management-Group).

### Required access

The principal deploying the template must have permissions to create resources at the Management Group scope. The principal must have permission to execute the deployment actions (`Microsoft.Resources/deployments/*`) and to create the resources defined in the template. For example, to create a management group, the principal must have Contributor permission at the tenant root Management Group scope. To create role assignments, the principal must have Owner permission.