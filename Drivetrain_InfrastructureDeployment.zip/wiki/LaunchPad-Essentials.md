# LaunchPad Essentials
The Essentials SKU of the LaunchPad is designed to get customers started in the cloud with the bare essentials.

## What's in the Box
- Included in the essentials version are the following resources:
- Virtual Network
- Network Security Groups
- Bastion Server
- Active Directory Domain Controllers

<img src="https://newsigcode.visualstudio.com/f8287ead-8d77-4249-b430-6fef6fc3e559/_apis/git/repositories/6a7803e6-80a1-4a6a-9169-aef0bb044fb4/Items?path=%2F.attachments%2FLZEssentials_vsdx.png&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=wikiMaster&download=false&resolveLfs=true&%24format=octetStream&api-version=5.0-preview.1" />
