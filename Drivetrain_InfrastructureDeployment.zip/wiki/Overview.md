# Infrastructure Deployment

## Introduction

This wiki is for the Infrastructure Deployment package from DriveTrain, as part of the GPS-214 service line. The left navigation will lead you to important information regards installation and customisations for the product. As part of DriveTrain the package is Inner Source  and open to contributions from all employees of New Signature, the link will explain in more details and also how to contriubute.

## Overview

DriveTrain Infrastructure Deployment is a collection of tools used to deploy and/or configure resources into Azure. At its core it is a set of ARM templates and PowerShell/CLI scripts written in the spirit of infrastructure as code.

## Goals

1. Provide tools to facilitate deployment acceleration and consistency
1. Empower both professional and managed services engineers to build in Azure
1. Create re-usable, connectable deployment modules for Azure resources

## Guiding Principles

- Re-usability
- Reliability
- Idempotence
- Modularity

## Priorities

- Accessible to engineers
- Comprehensive documentation

### Feedback

Any product feedback is very welcome! Please direct your feedback to:

- The _Infrastructure Deployment_ teams channel in the Drivetrain Teams site.
- Bronson Dryer - Service Design Lead (Product Owner)

## Legal

It is required that a Master Services Agreement (MSA) is in place between New Signature and any customer where Drivetrain is used.

Please ensure that any code you contribute is either your own work, released under a permissive (non-copyleft) licence, or has been developed on a customer engagement where a Master Services Agreement is in place.

If you have any questions or queries about this, please contact legal@newsignature.com.
