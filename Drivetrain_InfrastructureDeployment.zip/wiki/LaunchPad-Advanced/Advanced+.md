[![Build Status](https://dev.azure.com/newsigcode/DriveTrain/_apis/build/status/Azure%20Go/Drivetrain_InfrastructureDeployment?branchName=master)](https://dev.azure.com/newsigcode/DriveTrain/_build/latest?definitionId=118&branchName=master)

# LaunchPad Advanced
The Advanced SKU of the LaunchPad is designed to get customers started in the cloud with a view to expanding their existing data center into the cloud as part of an expansion or migration strategy.

## Pre-requisites

[Pre-requisites List](https://dev.azure.com/newsigcode/DriveTrain/_wiki/wikis/DriveTrain.wiki/829/Pre-requisites)

## What's in the Box Summary

### [Monitoring](https://dev.azure.com/newsigcode/DriveTrain/_wiki/wikis/DriveTrain.wiki/17/Infrastructure-Monitoring)
- [Management Groups Tree](https://dev.azure.com/newsigcode/DriveTrain/_wiki/wikis/DriveTrain.wiki/456/Management-Groups-Design)
- RBAC Model
- Azure Policies
- Log Analytics
- Log Storage
- Key Vault

### LaunchPad Infrastructure
- [Hub](https://dev.azure.com/newsigcode/DriveTrain/_wiki/wikis/DriveTrain.wiki/460/Core-Subscription-Design-(Hub))
- [Spoke](/Packages/Infrastructure-Deployment/LaunchPad/LaunchPad-Advanced/Spoke-Subscription-Design)

**Task performed**

- Single Region
- Create Management Groups hierarchy(Tenant Root -> NS Drivetrain Root --> Hub, Prod, UAT, Test, Dev ---> Hub Subscription, Prod Subscription etc)
- Install Monitoring & Log Analytics
- Map subscriptions into Management Groups (Manual?)
- Apply Policies at Management Groups Level
- Apply RBAC at Management Groups Level
- Add Secure VNet with NSG & Gateway Subnet
- Add PDC & BDC with Availability Sets
- Add Basion Server
- Add Backup & Recovery Services
- Add VPN Gateway Subnet
- Add DNS Servers

# Question Log

- Add your queries here

- Long grass

<img src="https://newsigcode.visualstudio.com/f8287ead-8d77-4249-b430-6fef6fc3e559/_apis/git/repositories/6a7803e6-80a1-4a6a-9169-aef0bb044fb4/Items?path=%2F.attachments%2FLZEssentials_vsdx.png&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=wikiMaster&download=false&resolveLfs=true&%24format=octetStream&api-version=5.0-preview.1" />

