# Hub Infrastructure

![image.png](/.attachments/image-0e49bc82-6e60-4631-8134-2f09f906454c.png)

[Core.vsdx](/.attachments/Core-727fd95d-7bdc-4c5f-9195-bc3d6a70a102.vsdx)

## Included in the Medium:
  - Hub Virtual Network (see below for subnetting)
  - Network Security Groups
  - Bastion Server/Azure Bastion
  - Active Directory Domain Controllers - DNS only for now 
  - VPN Gateway
  - Azure Firewall & NSGs
  - Recovery Services Vault for Any VM's deployed
  - Security Center
  - Key Vault


## Subnetting for Hub Virtual Network

| **Subnet**  | **Address**   | **Mask**  | **Comments**   | **Range**  |
|---------|-----------|-------|------------|---|
| GatewaySubnet | 10.0.0.0/27  | 255.255.255.224  | VPN Gateway Subnet for VPN/ExpressRoute  | 10.0.0.1* - 10.0.0.30  |
| AzureBastionSubnet | 10.0.0.32/27  |  255.255.255.224 | Azure Bastion if available in region  |  10.0.0.33* - 10.0.0.62 |
| AzureFirewallSubnet | 10.0.0.64/26  | 255.255.255.192  | Azure Firewall Deployment  | 10.0.0.65* - 10.0.0.126 |
| snet-core-weu-addns |  10.0.0.128/27 | 255.255.255.224  | Core IaaS AD DNS  |  10.0.0.129* - 10.0.0.158 |
| snet-core-weu-rdp | 10.0.0.160/27 | 255.255.255.192 | Remote desktop VM | 10.0.0.161* - 10.0.0.190 |
| Spare Addresses | 10.0.0.192/26  | 255.255.255.192  | -  | 10.0.0.193* - 10.0.0.254  |
 
[Link to calculator](http://www.davidc.net/sites/default/subnets/subnets.html?network=10.0.0.0&mask=24&division=9.350)

* asterisk doesn't include 3 azure reserved addresses per subnet



## Discussion points
[29/11]
AD - DNS - point to cloudflare 1.1.1.1 or google 8.8.8.8/4.4.4.4 (ADDS installed - not configured - will provide dns to vnet)
Jump server (JIT enabled through azure firewall via azure security centre in psm1 module)
NSGs empty with sane defaults
UDR to prem via firewall/UDR local vnet rule for local LZ devices
Request additional (reserve) /24 subnet we can use in the future if required in the Core LZ?

Links:

[Azure Firewall Documentation](https://docs.microsoft.com/en-us/azure/firewall/tutorial-hybrid-portal)
[Availability of Fault Domains by Region](https://github.com/MicrosoftDocs/azure-docs/blob/master/includes/managed-disks-common-fault-domain-region-list.md)