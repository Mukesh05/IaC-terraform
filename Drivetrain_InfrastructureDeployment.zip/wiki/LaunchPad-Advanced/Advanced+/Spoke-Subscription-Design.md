# Spoke

The Hub will be connected to a number of spokes where application infrastructure will be deployed.

## Overview

![image.png](/.attachments/image-8c5b0b50-bc1f-491e-b9cd-f6b732df70b3.png)

[Spoke.vsdx](/.attachments/Spoke-6a8c0605-c3ab-4e89-a1e5-eb29b9b6fed2.vsdx)

## Example Subnet Split

Using a 172.16.0.0/22 network we can obtain the following subnets

| **Subnet**  | **Address**   | **Mask**  | **Comments**   | **Range**  |
|---------|-----------|-------|------------|---|
| Management Subnet | 172.16.0.0/26 | 255.255.255.192  | x  | 172.16.0.1 - 172.16.0.63  |
| Unallocated | 172.16.0.64/26  |  255.255.255.192 | x  |  172.16.0.64 - 172.16.0.127 |
| Unallocated | 172.16.0.128/25  | 255.255.255.128 | x  |  172.16.0.129 - 172.16.0.254 |
| Workload | 172.16.1.0/24  |  255.255.255.0 | x  |  172.16.1.1 - 172.16.1.254 |
| Unallocated | 172.16.2.0/23  |  255.255.254.0 | x  |  172.16.2.1 - 172.16.3.254 |

[Subnet calculator](http://www.davidc.net/sites/default/subnets/subnets.html?network=172.16.0.0&mask=22&division=9.f00)