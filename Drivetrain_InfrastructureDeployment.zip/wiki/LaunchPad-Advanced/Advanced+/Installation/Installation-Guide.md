# About

The Launch Pad Advanced (aka Medium Landing Zone) Infrastructure Deployment portion of DriveTrain refers to infrastructure as code (IaC) solutions.

# Team

**Product Owner**: Bronson Dreyer
**Azure Technical Leads:** CoE, 
**Development Team:** Byron Glover, Rahul Saraf, Simon Hawke


# Installation Instructions
The ARM templates, and PowerShell scripts to deploy the package are made available on a Universal Package feed in Azure DevOps, the release version is available to any user of the NewSigCode Azure DevOps instance.

In order to download the necessary files, you will need to install the Azure CLI (https://docs.microsoft.com/en-us/cli/azure/install-azure-cli?view=azure-cli-latest ) and the add in for Azure DevOps (az extension add --name azure-devops).You can find the current/latest version under the artifacts in AzDo - [Artifacts](https://dev.azure.com/newsigcode/DriveTrain/_packaging?_a=package&feed=DriveTrain&package=newsig.deployment&protocolType=UPack&version=1.2.0&view=versions). Once you have installed the CLI you can run the following commands :-

```powershell
az login

az artifacts universal download `
    --organization "https://dev.azure.com/newsigcode/" `
    --feed "DriveTrain@Release" `
    --name "newsig.arm.infrastructure" `
    --version "<Replace with Latest Version>" `
    --path C:\Temp\InfrastructureMonitoring-<Replace with Latest Version>

C:\Temp\InfrastructureMonitoring-<Replace with Latest Version>\Install-LaunchPadAdvancedHub.ps1
```

