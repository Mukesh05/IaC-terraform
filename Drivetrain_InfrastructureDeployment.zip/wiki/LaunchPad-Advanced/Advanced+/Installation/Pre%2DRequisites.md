# Parameters

Launchpad Advanced needs a number of inputs to be able to deploy the Monitoring, Management Groups, plus the Hub and Spoke Infrastructure that you need. You can supply these as command-line parameters when you execute the script or you can answer the prompts to enter the values when the script asks for them from you.

## The table below lists these items for the First Stage of the Hub deployment

| *Item* | *Script&nbsp;Parameter&nbsp;Name* | *Description* | *Example&nbsp;Value* | *Required*  |  |  | |
|--|--|--|--|--|--|--|--|
| Tenant&nbsp;Id | ```AzureTenantId```  | Guid that identifies the Azure AD Tenant you wish to work with | ```a1a2578a-8fd3-4595-bb18-7d17df8944b0``` | Yes |  |  |  |
| Subscription&nbsp;Id  | ```AzureSubscription``` | Guid that identifies the Azure Subscription that the Hub infrastructure will be deployed into | ```32b907e8-6013-4e4d-b0f1-8497cff38c86```| Yes |  |  |  |
| Hub&nbsp;RG&nbsp;Name | ```ResourceGroupName``` | Resource Group for all Hub Resources | rg-lz-hub1-uks | No |  |  |  |
| Hub&nbsp;Region&nbsp;Name | ```ResourceGroupLocation``` | Azure Region for the Hub deployment | uksouth | Yes  |  |  |  |
| Monitoring&nbsp;RG&nbsp;Name | ```MonitoringResourceGroup``` |Resource Group where all Monitoring components are deployed | Az-Mon  | No |  |  |  |
| Username&nbsp;for&nbsp;DNS&nbsp;&amp;&nbsp;Bastion&nbsp;VMs | ```VmAdminUser``` | Windows Server Admin Username | ladmin  | Yes |  |  |  |
| Password&nbsp;for&nbsp;DNS&nbsp;&amp;&nbsp;Bastion&nbsp;VMs | ```VmAdminPassword``` | PowerShell SecureString with a server password | Any Strong Password | Yes |  |  |  |
| Environment&nbsp;Id&nbsp;for&nbsp;Resource&nbsp;Names | ```EnvironmentCode``` | Moniker/Id for the deployment | hub1 | Yes |  |  |  |
| CIDR&nbsp;of&nbsp;Hub&nbsp;Network | ```VNetCIDR``` | CIDR for hub network address space. Should be /22 or larger | 10.0.0.0/22 | Yes  |  |  |  |
| IP&nbsp;of&nbsp;Remote&nbsp;GW | ```OnPremiseGatewayIpAddress``` | IP address to reach LAN Gateway for On-Prem or other server infrastructure | 1.2.3.4 | Yes  |  |  |  |
| CIDR&nbsp;of&nbsp;Remote&nbsp;LAN | ```OnPremiseNetworkAddressPrefix``` | CIDR for remote LAN Address Space (for routing configuration) | 192.168.1.0/24 | Yes |  |  |  |
| Pre-Shared&nbsp;Key&nbsp;of&nbsp;VPN | ```VpnPSK``` | IKE or similar key data for establishing secure link between Azure Gateway and on-prem router  | secret1234 | Yes |  |  |  |
| SKU&nbsp;for&nbsp;Azure&nbsp;VPN | ```VpnGwSku``` | Pick a performance tier from [here](https://docs.microsoft.com/en-us/azure/vpn-gateway/vpn-gateway-about-vpn-gateway-settings#gwsku) to match your throughput and budget | VpnGw1 | Yes |  |  |  |
| Bastion&nbsp;VM&nbsp;Size | ```BastionVmSize``` | Azure VM SKU, see [here](https://docs.microsoft.com/en-us/azure/virtual-machines/windows/sizes-general) for details. | Standard_B2s | Yes |  |  |  |
| Bastion&nbsp;OS&nbsp;Version | ```BastionOsVersion``` | Windows Server Version for Bastion Jump Box VM | 2019-Datacenter | Yes |  |  |  |
| VPN&nbsp;GW&nbsp;Required | ```DeployVpnGateway``` | Option Flag $true if present | PowerShell flag/switch | No |  |  |  |

## The table below lists these items for the Second Stage of the Spoke deployment

| *Item* | *Script&nbsp;Parameter&nbsp;Name* | *Description* | *Example&nbsp;Value* | *Required*  |  |  | |
|--|--|--|--|--|--|--|--|
| Tenant&nbsp;Id |```AzureTenantId``` |Guid that identifies the Azure AD Tenant you wish to work with | ```a1a2578a-8fd3-4595-bb18-7d17df8944b0``` | Yes| | | | |
|Subscription&nbsp;Id | ```AzureSubscription```|  Guid that identifies the Azure Subscription that the Hub infrastructure will be deployed into | ```32b907e8-6013-4e4d-b0f1-8497cff38c86```| Yes | | | | |
|Spoke&nbsp;RG&nbsp;Name |```ResourceGroupName``` | Resource Group for all Spoke Resources | ```rg-lz-spoke1-uks``` | Yes |  |  |  |
| Spoke&nbsp;Region&nbsp;Name |```ResourceGroupLocation```  | Azure Region for the Hub deployment | uksouth | Yes  |  |  |  |
| Monitoring&nbsp;RG&nbsp;Name | ```MonitoringResourceGroup``` |Resource Group where all Monitoring components are deployed | Az-Mon  | No |  |  |  |
| Domain&nbsp;for&nbsp;Spoke&nbsp;Bastion&nbsp;VM |```ActiveDirectoryDomain``` | Domain name value | Contoso | Yes | | | |
| Username&nbsp;for&nbsp;Spoke&nbsp;Bastion&nbsp;VM |```ActiveDirectoryAdminUser``` | Windows Server Admin Username | ladmin  | Yes |  |  |  |
| Password&nbsp;for&nbsp;Spoke&nbsp;Bastion&nbsp;VM|```ActiveDirectoryAdminPassword```| PowerShell SecureString with a server password | Any Strong Password | Yes |  |  |  |
| CIDR&nbsp;of&nbsp;Spoke&nbsp;Network  | ```VNetCIDR```|CIDR for spoke network address space. Should be /22 or larger | 10.1.0.0/22 | Yes  |  |  |  |
| IP&nbsp;of&nbsp;Hub&nbsp;Firewall |```FirewallPrivateIpAddress``` | IP Address of Hub Firewall for Routing Traffic via Hub | 10.0.0.68 | Yes | | | |
| Hub&nbsp;Subscription&nbsp;Id | ```HubVNetSubscription```| Azure Subscription for Hub VNET | guid | Yes | | | |
| Hub&nbsp;VNET&nbsp;RG&nbsp;Name |```HubVNetResourceGroupName``` | Resource group name for the RG holding the Hub VNET resource |rg-lz-hub1-uks | Yes | | | |
| Hub&nbsp;VNET&nbsp;Name| ```HubVNetName```|  Name for the Hub VNET resource| vnet-hub1-uks-appname | Yes| | | |
|DNS&nbsp;Servers | ```DnsServerIPs```| List of IP Addresses for Local DNS Servers (likely Hub DNS boxes or load-balancer) | ```1.1.1.1,8.8.8.8``` | Yes | | | |
|Region&nbsp;Mnemonic |```ShortRegionCode``` |Short representation of region | uks | Yes | | | |
|Environment&nbsp;Code | ```EnvironmentCode```| Id of environment type | prod |Yes | | | |
|Application&nbsp;Name | ```ApplicationName```| Name of Application to be deployed in the spoke | app1 |Yes | | | |
