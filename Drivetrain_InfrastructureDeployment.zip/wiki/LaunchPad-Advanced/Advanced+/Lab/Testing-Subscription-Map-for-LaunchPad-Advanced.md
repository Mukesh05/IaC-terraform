#Launch Pad Medium

## AAD Directory

nsgo1.onmicrosoft.com / 6f1aa459-4cba-45cc-a9a9-3b24a8334aee

## Subscriptions

| **Subscription**  | **Id**   | **Name**  | **Comments**   | **A**  |
|---------|-----------|-------|------------|---|
| Hub / Core |  8e0c3018-45b1-4070-91fd-0485bb8c5701  | New Signature - Lab Subscription - 0  |   |  |
| Prod | 13d08427-9356-48f8-82ae-d267a39d7919   | New Signature - Lab Subscription - 1  |   |  |
| UAT |  e9baadae-bd2f-4f57-a28a-02603511bca5  |  New Signature - Lab Subscription - 2 |   |  |
| Test |  19f93587-7629-4ac4-9c93-8647cb6df3cb  |  New Signature - Lab Subscription - 3 |   |  |