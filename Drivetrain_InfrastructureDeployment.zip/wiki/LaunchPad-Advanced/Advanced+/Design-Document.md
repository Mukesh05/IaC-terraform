# Purpose
The design document serves to capture the intent behind the overall LauchPad solution and in the case of Advanced and Enterprise, the client requirements which extend the base configuration.

# Audience
The document is intended for a mainly **technical audience** as it goes into depth on the configuration details in Azure.
# Sections
The document is divided into the following sections:
##  Cloud Principles
- Agility
- Scalability
- Reliability
- Managbility
- Governance
- Efficiency
## Design Principles
This is a statement of the design approach taken in this engagement.

- Role Based Access Control
- Azure Policies
- Azure Naming Standards
- Azure Tagging
## Core Subscription
This constitutes the shared subscription hosting the main resources used across the enterprise. It consists of:
- Domain Controllers
## Spoke Subscription
This is any subscription holding application services regardless of environment type. It may include:
## High Availability
## Azure Backup
## Azure Monitoring
## Azure Key Vault
## Azure Security
## Azure Update Management
## Azure DSC
## Azure Cost Management
## Azure Migration
