# Management Groups - Design


![image.png](/.attachments/image-f4dce9b7-ab21-4219-ab13-9a35f7bd1a42.png)

Soure file:
[ManagementGroups.vsdx](/.attachments/ManagementGroups-d43898f9-78cd-43d3-83a7-fcf4d2b10879.vsdx)