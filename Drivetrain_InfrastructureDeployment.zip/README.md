# Azure LaunchPad / Landing Zone

## Overview

DriveTrain Landing Zone deploys a collection of Azure Resources to one or more Azure Subscriptions in accordance with several New Signature reference architectures.

This is intended to allow implementation engineers a time-saving method to deploy New Signature best practice infrastructure framework to a client, and construct further environment-specific requirements on top of this fast-deployed framework.

## Testing & Validation
[Pester](https://github.com/Pester/Pester) is used for both Unit & Integration Tests.

In order to run the Unit tests, you will need:
- The [Secure DevOps Kit for Azure Powershell Module, version 4.7.0 on your machine](https://www.powershellgallery.com/packages/AzSK/4.7.0)
- [Pester, version 4.9.0]
- Windows PowerShell 5.1
To run the global unit tests locally execute the following command from the root of the repository `invoke-pester .\_tests\Unit\*`
To run the Advanced Unit & Integration tests execute the following command from the root of the repository `invoke-pester .Advanced\_tests\*`

To run the essentials tests, perform the same command with the path changed to the Essentials directory.

## Contribute
We welcome contributions from *anybody* into this repository.
To ensure that the repository contains good-quality code, to make a contribution you will need to make a *pull request* from a branch that you have created. This ensures that the contents of the repository have been peer-reviewed.

All pull requests need to pass Unit & Integration tests before being merged to master. If you are making changes, please ensure the test fixtures in the */_tests/_fixtures directory are updated accordingly.

[The branching model we use is Release Flow](https://docs.microsoft.com/en-us/azure/devops/learn/devops-at-microsoft/release-flow).

## Legal
Please note the contents of the .LICENSE file stored in this repository.

It is required that a Master Services Agreement (MSA) is in place between New Signature and any customer where Drivetrain is used.

Please ensure that any code you contribute is either your own work, released under a permissive (non-copyleft) licence, or has been developed on a customer engagement where a Master Services Agreement is in place.

If you have any questions or queries about this, please contact legal@newsignature.com.

### Using Git

If you are unfamiliar with Git, or you do not understand how to create a pull request or git branch, the following references may be helpful for you if you are new to Git source control.

- https://git-scm.com/videos
- https://docs.microsoft.com/en-us/azure/devops/repos/git/gitworkflow?view=azure-devops

If you are still stuck after reviewing the above, message the Platform Services team in the Drivetrain Teams -> General Channel and someone will be happy to walk you through how to get started.
